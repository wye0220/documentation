/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity takes in 2 type of contents - application-config.json and issue folder. It updates the given application-config.json after
 * reading the information from the issue.json that is there in the issue folder provided. Either the issue would be added or updated based on issue id.
 */
public class UpdateAppConfigJson extends AbstractActivity {

	private String activityName;
	
	private List<String> attributeToMap;
	
	private String description;
	
	private String lastPublishedDate;
	
	private String appConfigJsonName;
	
	public void setDescription(String description) {
		this.description = description;
	}

	public void setLastPublishedDate(String lastPublishedDate) {
		this.lastPublishedDate = lastPublishedDate;
	}
	
	public void setAttributeToMap(List<String> attributeToMap) {
		this.attributeToMap = attributeToMap;
	}

	public void setAppConfigJsonName(String appConfigJsonName) {
		this.appConfigJsonName = appConfigJsonName;
	}

	private String isFree;
	
	public void setIsFree(String isFree) {
		this.isFree = isFree;
	}

	private String inContentAppConfigJson;
	
	private String inContentIssueFolder;
	
	private String outContentUpdatedAppConfigJson;

	public void setOutContentUpdatedAppConfigJson(String outContentUpdatedAppConfigJson) {
		this.outContentUpdatedAppConfigJson = outContentUpdatedAppConfigJson;
	}

	public void setInContentAppConfigJson(String inContentAppConfigJson) {
		this.inContentAppConfigJson = inContentAppConfigJson;
	}

	public void setInContentIssueFolder(String inContentIssueFolder) {
		this.inContentIssueFolder = inContentIssueFolder;
	}

	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private TempFileManager tempFileManager;

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		
		ContentInfo[] contentInfosAppConfig = publishingContext.getInputContentInfos(inContentAppConfigJson);
		
		ContentInfo[] contentInfosIssueFolder = publishingContext.getInputContentInfos(inContentIssueFolder);
		
		if (contentInfosIssueFolder != null && contentInfosIssueFolder.length > 0) {

			File unzippedFolder = contentInfosIssueFolder[0].getFile();
			
			File issueJson = findFile(unzippedFolder, "issue.json");
			
			if(issueJson == null || !issueJson.exists()){
				throw new PublishingException("Invalid Issue Json file: " + issueJson);
			}
		
			File appConfigJson = null;
			if (contentInfosAppConfig != null && contentInfosAppConfig.length > 0) {
				appConfigJson = contentInfosAppConfig[0].getFile();
			}
			File updatedAppConfig = tempFileManager.getTemporaryFile(".json", publishingContext.getProcessId());
			
			FileUtils.copyFile(appConfigJson, updatedAppConfig);
			
			updateAppConfigJson(issueJson, updatedAppConfig, unzippedFolder.getName(), publishingContext);
			
			URI uri = new URI("file", updatedAppConfig.getAbsolutePath(), null);
			
			ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(outContentUpdatedAppConfigJson, uri, updatedAppConfig);
			outContentInfo.setResourceName(appConfigJsonName);
			
		}

	}
	
	private File findFile(File rootDir, String fileName) {
	    File[] files = rootDir.listFiles();
	    List<File> directories = new ArrayList<File>(files.length);
	    for (File file : files) {
	        if (file.getName().equals(fileName)) {
	            return file;
	        } else if (file.isDirectory()) {
	            directories.add(file);
	        }
	    }

	    for (File directory : directories) {
	        File file = findFile(directory, fileName);
	        if (file != null) {
	            return file;
	        }
	    }

	    return null;
	}
	
	private void updateAppConfigJson(File issueJsonFile, File appConfigJsonFile, String jsonFileParentFolder, PublishingContext publishingContext)
			throws JsonProcessingException, IOException {
		JsonFactory factory = new JsonFactory();
		ObjectMapper objectMapper = new ObjectMapper(factory);
		JsonNode treeNode = objectMapper.readTree(appConfigJsonFile);
		ArrayNode issuesNode = (ArrayNode) treeNode.path("issues");

		JsonNode rootNode = objectMapper.readTree(issueJsonFile);
		
		ArrayNode variantsNode = (ArrayNode) rootNode.path("variants");
		Iterator<JsonNode> variantsIterator = variantsNode.elements();
		String thumbnailPortrait = null;
		String thumbnailLandscape = null;
		String previewPortrait = null;
		String previewLandscape = null;
		while (variantsIterator.hasNext()) {
			JsonNode node = variantsIterator.next();
			String orientation = node.path("orientation").asText();
			if (orientation.equalsIgnoreCase("landscape")) {
				ArrayNode pagesNodes = (ArrayNode) node.path("pages");
				if(pagesNodes!=null && pagesNodes.size() > 0){
					thumbnailLandscape = jsonFileParentFolder + "/" + pagesNodes.get(0).path("thumbnail").asText();
					previewLandscape = thumbnailLandscape.replaceFirst("_thumbnail", "_preview");
				}
			} else if (orientation.equalsIgnoreCase("portrait")) {
				ArrayNode pagesNodes = (ArrayNode) node.path("pages");
				if(pagesNodes!=null && pagesNodes.size() > 0){
					thumbnailPortrait = jsonFileParentFolder + "/" + pagesNodes.get(0).path("thumbnail").asText();
					previewPortrait = thumbnailPortrait.replaceFirst("_thumbnail", "_preview");
				}
			}
		}
		
		String isFreeResolved = resolveParameter(isFree, publishingContext);
		
		ObjectNode issueNode = createIssueNode(objectMapper, thumbnailLandscape, thumbnailPortrait, previewLandscape, previewPortrait,
				jsonFileParentFolder, isFreeResolved, resolveParameter(lastPublishedDate, publishingContext), resolveParameter(description, publishingContext), rootNode);

		String issueId = rootNode.path("id").asText();
		deleteIssue(issuesNode, issueId, publishingContext);
		issuesNode.add(issueNode);
		writeNodeToFile(objectMapper, treeNode, appConfigJsonFile);
	}

	private void deleteIssue(ArrayNode issuesNode, String issueId, PublishingContext publishingContext) throws IOException {
		Iterator<JsonNode> issuesIterator = issuesNode.elements();
		int index = 0;
		while (issuesIterator.hasNext()) {
			JsonNode node = issuesIterator.next();
			String title =  node.path("id").asText();
			if(title.equalsIgnoreCase(issueId)){
//				deleteIssueFolder(node, publishingContext);
				issuesNode.remove(index);
				break;
			}
			index++;
		}
	}

//	private void deleteIssueFolder(JsonNode issueNode, PublishingContext publishingContext) throws IOException {
//		String bundle = issueNode.path("bundle").asText();
//		String[] parts = bundle.split("/");
//		String issueFolderName = null; 
//		if(parts!=null && parts.length >0){
//			issueFolderName = parts[0];
//			issueFolderName = issueFolderName.replace(".zip", "");
//		}
//		
//		String issueHomeRes = resolveParameter(issueHome, publishingContext);
//		
//		FileUtils.deleteDirectory(new File(issueHomeRes+"/"+issueFolderName));
//		
//	}

	private void writeNodeToFile(ObjectMapper objectMapper, JsonNode node, File f) throws UnsupportedEncodingException, IOException {
		String issueJson = objectMapper.writeValueAsString(node);

		FileOutputStream fileOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(f);
			fileOutputStream.write(issueJson.getBytes("UTF-8"));
		} finally {
			if (fileOutputStream != null)
				fileOutputStream.close();
		}

	}

	private ObjectNode createIssueNode(ObjectMapper objectMapper, String thumbnailLandscape, String thumbnailPortrait,
			String previewLandscape, String previewPortrait, String jsonFileParentFolder, String isFree, String lastPublishedDate, String description, JsonNode issueRootNode) {
		ObjectNode issueNode = objectMapper.createObjectNode();
	
		issueNode.put("publishedDate", getCurrentGMTDateTime());
		if (lastPublishedDate != null && !lastPublishedDate.isEmpty()) {
			issueNode.put("lastPublishedDate", lastPublishedDate);
		}
		else{
			issueNode.put("lastPublishedDate", getCurrentGMTDateTime());
		}
		issueNode.put("bundle", jsonFileParentFolder + ".zip");
		issueNode.put("retinaBundle", jsonFileParentFolder + ".retina.zip");
		issueNode.put("tabletIssuePath", "html5");

		issueNode.put("minimumAppVersion", "1.0.0");
		issueNode.put("appleId", "");
		issueNode.put("description", description);
		issueNode.put("isFree", isFree);
		issueNode.put("media:thumbnail", "");

		ArrayNode mediaThumbnailNode = objectMapper.createArrayNode();
		mediaThumbnailNode.add("value1");
		issueNode.put("media:thumbnail", mediaThumbnailNode);

		// create contents node
		ObjectNode thumbnailsNode = objectMapper.createObjectNode();
		if (thumbnailLandscape != null) {
			thumbnailsNode.put("landscape", thumbnailLandscape);
		}
		if (thumbnailPortrait != null) {
			thumbnailsNode.put("portrait", thumbnailPortrait);
		}
		issueNode.put("thumbnails", thumbnailsNode);

		ArrayNode mediaContentNode = objectMapper.createArrayNode();
		if (previewLandscape != null) {
			mediaContentNode.add(previewLandscape);
		}
		if (previewPortrait != null) {
			mediaContentNode.add(previewPortrait);
		}
		
		issueNode.put("media:content", mediaContentNode);

		ObjectNode previewsNode = objectMapper.createObjectNode();
		if (previewLandscape != null) {
			previewsNode.put("landscape", previewLandscape);
		}
		if (previewPortrait != null) {
			previewsNode.put("portrait", previewPortrait);
		}
		issueNode.put("previews", previewsNode);
		
		//Copy all specified attributes from the issue.json
		for (String attrName : attributeToMap) {
			String value = issueRootNode.path(attrName).asText();
			if (value != null) {
				issueNode.put(attrName, value);
			}
		}
		
		return issueNode;
	}

	private String getCurrentGMTDateTime() {
		long milliSeconds = System.currentTimeMillis();
		String GMT_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(GMT_DATE_TIME_FORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		String strDate = sdf.format(new Date(milliSeconds));
		return strDate + "Z";
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
}

/*****************************************************************************\
 **
 ** �1990-2015 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.constants.OfficeDocumentOutputFormats;
import com.quark.qpp.office.service.local.OfficeService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.utility.FacadeUtility;

/**
 * This activity renders an Office Document into desired output format.
 * 
 */
public class RenderOfficeDocument extends AbstractActivity {

	/*
	 * asset Id of the office document to be rendered
	 */
	private String assetId;
	
	/*
	 * content type of the office document to be rendered
	 */
	private String officeContentType;
	
	/*
	 * Name with which this activity expects content
	 */
	private static final String IN_CONTENT_NAME = "SourceContent";

	/*
	 * String value of the output format
	 */
	private String outputFormat;

	/*
	 * Comma separated output format properties applicable for an output format.
	 */
	private String outputFormatProperties;

	/*
	 * Output file name
	 */
	private String outputFileName;

	/*
	 * Name with which this activity emits content
	 */
	private String outContentName;

	/*
	 * Name of this activity
	 */
	private String activityName;

	@Autowired
	private OfficeService officeService;
	
	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private StreamingService officeStreamingService;

	@Autowired
	private TempFileManager tempFileManager;

	@Autowired
	private AssetService assetService;

	@Autowired
	private ContentStructureService contentStructureService;

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public void setOfficeContentType(String officeContentType) {
		this.officeContentType = officeContentType;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setOutContentName(String outContentName) {
		this.outContentName = outContentName;
	}

	public void setOutputFormatProperties(String outputFormatProperties) {
		this.outputFormatProperties = outputFormatProperties;
	}

	public void setOutputFileName(String outputFileName) {
		this.outputFileName = outputFileName;
	}

	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		String resolvedOutputFormat = resolveParameter(outputFormat, publishingContext);
		String resolvedOutputFormatProperties = resolveParameter(outputFormatProperties, publishingContext);
		NameValue[] nameValues = createPropertiesMap(resolvedOutputFormatProperties);

		String resolvedOutContentName = resolveParameter(outContentName, publishingContext);
		String resolvedOutFileName = resolveParameter(outputFileName, publishingContext);
		
		String resolvedAssetIdVal = resolveParameter(assetId, publishingContext);
		if(resolvedAssetIdVal != null && resolvedAssetIdVal.trim().length() > 0) {
			long resolvedAssetId = Long.valueOf(resolvedAssetIdVal);
		
			if (resolvedOutFileName == null || resolvedOutFileName.trim().length() == 0) {
				resolvedOutFileName = ((TextValue) assetService.getAttributeValues(resolvedAssetId, new long[] { DefaultAttributes.NAME })[0]
						.getAttributeValue()).getValue();
			}
		}
		//replacing characters <  > : " / \ | ? * which can not be used in filename.
		resolvedOutFileName = resolvedOutFileName.replaceAll("<|>|:|\"|/|\\\\|\\||\\?|\\*", "_");
		ContentInfo[] inData = publishingContext.getInputContentInfos(IN_CONTENT_NAME);
		File inputFile = null;
		if (inData == null || inData.length ==  0) {
			return;
		}
		inputFile = inData[0].getFile();
		InputStream in = null;
		
		String resolvedContentType = resolveParameter(officeContentType, publishingContext);
		long contentTypeId = facadeUtility.getContentTypeId(resolvedContentType);
		
		if (resolvedOutFileName == null || resolvedOutFileName.trim().length() == 0) {
			resolvedOutFileName = "output";
		}
		String outFileExtension = getFileExtension(resolvedOutputFormat, nameValues, contentTypeId);
		File outputFile = tempFileManager.getTempFileWithGivenName(resolvedOutFileName + "." + outFileExtension,
				publishingContext.getProcessId());
		FileOutputStream fileOutputStream = null;
		
		long contextId = -1;
		try {
			contextId = officeService.createOfficeDocumentReadWriteContext();
			in = new FileInputStream(inputFile);
			officeStreamingService.upload(in, contextId);
			officeService.readOfficeDocumentBasedOnStreamContext(contextId, contentTypeId, resolvedOutputFormat, nameValues);
			fileOutputStream = new FileOutputStream(outputFile);
			officeStreamingService.download(fileOutputStream, contextId);
		} finally {
			if(in != null) {
				in.close();
			}
			if(fileOutputStream != null) {
				fileOutputStream.close();
			}
			officeService.closeContext(contextId);
		}
		
		ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(resolvedOutContentName,
				new URI("file", outputFile.getAbsolutePath(), null), outputFile);
		outContentInfo.setResourceName(resolvedOutFileName);
		outContentInfo.setFileExtension(outFileExtension);
		String mimeType = null;
		if(("pdf").equalsIgnoreCase(outFileExtension)) {
			mimeType = "application/pdf";
		} else if(("htm").equalsIgnoreCase(outFileExtension)) {
			mimeType = "text/html";
		} else if(("ppsx").equalsIgnoreCase(outFileExtension)) {
			mimeType = "application/vnd.openxmlformats-officedocument.presentationml.slideshow";
		}
		outContentInfo.setMimeType(mimeType);
	}

	private String getFileExtension(String outputFormat, NameValue[] outputFormatProperties, long contentTypeId)
			throws InvalidContentTypeException, QppServiceException {
		if (outputFormat == null || outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.IMAGE)) {
			String imageFormat = null;
			for (int i = 0; i < outputFormatProperties.length; i++) {
				if (outputFormatProperties[i].getName().equalsIgnoreCase(ImageOutputProperties.IMAGE_FORMAT)) {
					imageFormat = outputFormatProperties[i].getValue();
				}
			}
			if (imageFormat == null || imageFormat.trim().length() == 0) {
				imageFormat = "png"; // TODO keep this in sync with OfficeService property office.defaultImageFormat=png.
			}
			if (imageFormat.equalsIgnoreCase("pdf")) {
				return "pdf";
			} else {
				return "zip";
			}
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.HTML)) {
			if (contentTypeId == DefaultContentTypes.MICROSOFT_EXCEL || contentTypeId == DefaultContentTypes.MICROSOFT_EXCEL_TEMPLATE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_EXCEL, contentTypeId)
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_EXCEL_TEMPLATE, contentTypeId)
					|| contentTypeId == DefaultContentTypes.MICROSOFT_WORD || contentTypeId == DefaultContentTypes.MICROSOFT_WORD_TEMPLATE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_WORD, contentTypeId)
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_WORD_TEMPLATE, contentTypeId)
					|| contentTypeId == DefaultContentTypes.MICROSOFT_VISIO || contentTypeId == DefaultContentTypes.MICROSOFT_VISIO_TEMPLATE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_VISIO, contentTypeId)
					|| contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_VISIO_TEMPLATE, contentTypeId)){
				return "zip";
			} else {
				return "htm";
			}
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.XML)) {
			return "xml";
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.TEXT)) {
			return "txt";
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.XPS)) {
			return "xps";
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.EPUB)) {
			return "epub";
		} else if (outputFormat.equalsIgnoreCase(OfficeDocumentOutputFormats.PPSX)) {
			return "ppsx";
		}
		return null;
	}

	/**
	 * Creats a HashMap<String, String> from a string of properties defined in format of type
	 * property1=value1;property2=value2;property3=value3;...;
	 * 
	 * @param outputFormatProperties
	 * @return
	 */
	private NameValue[] createPropertiesMap(String outputFormatProperties) {
		ArrayList<NameValue> list = new ArrayList<NameValue>();
		if (outputFormatProperties != null) {
			String[] properties = outputFormatProperties.split(";");
			for (int i = 0; properties != null && i < properties.length; i++) {
				String[] nameValue = properties[i].split("=");
				if (nameValue != null && nameValue.length == 2) {
					String key = nameValue[0];
					String value = nameValue[1];
					NameValue nameVal = new NameValue(key, value);
					list.add(nameVal);
				}
			}
		}
		return list.toArray(new NameValue[] {});
	}

	@Override
	public void clean(String processId) {
	}

}

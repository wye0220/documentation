package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.constants.VisioDataOutputFormats;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.OfficeFacade;

/**
 * This Activity extracts the page from the given Visio file in the specified format.
 */
public class ExtractVisioPage extends AbstractActivity {

	/*
	 * Name with which this activity emits content
	 */
	private String OUTPUT_CONTENT_NAME = "VISIO_PAGE";

	private String visioDocumentUri;
	private String pageName;
	private String outputFormat;
	private String outputFormatProperties;

	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}

	public void setOutputFormatProperties(String outputFormatProperties) {
		this.outputFormatProperties = outputFormatProperties;
	}

	@Autowired
	private OfficeFacade officeFacade;

	@Autowired
	private TempFileManager tempFileManager;
	
	protected String activityName;
	
	public void setVisioDocumentUri(String visioDocumentUri) {
		this.visioDocumentUri = visioDocumentUri;
	}
	
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		String resolvedVisioDocumentUri = resolveParameter(visioDocumentUri, publishingContext);
		String resolvedPageName = resolveParameter(pageName, publishingContext);
		String resolvedOutputFormat = resolveParameter(outputFormat, publishingContext);
		String resolvedOutputFormatProperties = resolveParameter(outputFormatProperties, publishingContext);
		HashMap<String, String> propertiesMap = createPropertiesMap(resolvedOutputFormatProperties);

		File file = tempFileManager.getTemporaryFile(".temp", publishingContext.getProcessId());		
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(file);
			officeFacade.getVisioPageOutputBasedOnURI(resolvedVisioDocumentUri, resolvedOutputFormat, resolvedPageName, propertiesMap, null, null, outputStream);
		} finally {
			if (outputStream != null) {
				outputStream.close();
			}
		}
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI("file://" + file.getAbsolutePath()), file);

		//Populate content info
		if (resolvedOutputFormat == null || resolvedOutputFormat.isEmpty()) {
			//Set default values so that file extension can be resolved properly 
			resolvedOutputFormat = VisioDataOutputFormats.IMAGE;
		}		
		//Identify file extension based on output format. Cannot use contentStructure Service as it does not provide file extension. 
		String outFileExtension = null;
		String outMimeType = null;
		if (resolvedOutputFormat.equalsIgnoreCase(VisioDataOutputFormats.HTML)) {
			outFileExtension = "zip";
			outMimeType = "application/zip";
		} else {
			String imageFormat = null;
			if (propertiesMap != null) {
				imageFormat = propertiesMap.get(ImageOutputProperties.IMAGE_FORMAT);
			}
			if(imageFormat == null || imageFormat.isEmpty()){
				imageFormat = "png";
			}			
			outFileExtension = imageFormat.toLowerCase();
			if(imageFormat.equalsIgnoreCase("pdf")){
				outMimeType = "application/pdf";
			} else {
				outMimeType = "image/"+imageFormat.toLowerCase();
			}
		}

		contentInfo.setFileExtension(outFileExtension);
		contentInfo.setMimeType(outMimeType);
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}
	
	/**
	 * Creates a HashMap<String, String> from a string of properties defined in format of type property1=value1;property2=value2;property3=value3;...;
	 * @param outputFormatProperties
	 * @return
	 */
	private HashMap<String, String> createPropertiesMap(String outputFormatProperties) {
		HashMap<String, String> map = new HashMap<String, String>();
		if (outputFormatProperties != null) {
			String[] properties = outputFormatProperties.split(";");
			for (int i = 0; properties != null && i < properties.length; i++) {
				String[] nameValue = properties[i].split("=");
				if (nameValue != null && nameValue.length == 2) {
					String key = nameValue[0];
					String value = nameValue[1];
					map.put(key, value);
				}
			}
		}
		return map;
	}

}

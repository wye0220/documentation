/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
/**
 * 
 * This activity updates attributes filename and path of INTERACTIVE element.   
 *
 */
public class UpdateInteractivityData extends AbstractActivity  {
	
	private static final String MODIFIER_XML_CONTENT_NAME = "ModifierXML";
	
	/*
	 * Name with which this activity emits content
	 */
	private static final String OUT_CONTENT_NAME = "UpdatedModifierXML";
	
	@Autowired
	private AssetService assetService;
	
	private Logger logger = Logger.getLogger(UpdateInteractivityData.class);
	
	@Autowired
	private TempFileManager fileManager;

	private String activityName;	
	
	private DocumentBuilder builder = null;
	
	public void init() throws ParserConfigurationException{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
	}
	
	
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo contInfo  = publishingContext.getInputContentInfos(MODIFIER_XML_CONTENT_NAME)[0];
		
		File modifierFile = contInfo.getFile();
		
		File updatedFile = fileManager.getTemporaryFile(".xml", publishingContext.getProcessId());
		updateXmlForInteractiveData(modifierFile, updatedFile);
		ContentInfo  contentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, convertInputToURI("file://" + updatedFile.getAbsolutePath()));
		contentInfo.setMimeType("text/xml");
		contentInfo.setFileExtension("xml");
		
		contentInfo.setResourceName(updatedFile.getName());
	}

	

	public static void main(String[] args) {
		try {
			new UpdateInteractivityData().updateXmlForInteractiveData(new File("c:/temp/mod.xml"), new File("c:/temp/mod1.xml"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void updateXmlForInteractiveData(File modifierXML, File updatedFile) throws Exception {
		FileInputStream xmlInputStream = null;
		try {
			xmlInputStream = new FileInputStream(modifierXML);

			Document document = builder.parse(new InputSource(xmlInputStream));
			
			updateDocumentForAveInteractivity(document);
			
			updateDocumentForAppStudioInteractivity(document);			
				
			//Write updated document to the out file provided.
			FileOutputStream xmlOutputStream = null;
			try {
				TransformerFactory tFactory = TransformerFactory.newInstance();
				Transformer transformer = tFactory.newTransformer();

				DOMSource source = new DOMSource(document);
				xmlOutputStream = new FileOutputStream(updatedFile);
				StreamResult result = new StreamResult(xmlOutputStream);
				transformer.transform(source, result);
				xmlOutputStream.close();
			} finally {
				if (xmlOutputStream != null) {
					xmlOutputStream.close();
				}
			}			
		} finally {
			if (xmlInputStream != null) {
				try {
					xmlInputStream.close();
				} catch (IOException e) {
					logger.error(e);
				}
			}
		}
	}


	
	private void updateDocumentForAppStudioInteractivity(Document document) throws XPathExpressionException, NumberFormatException,
			AssetNotFoundException, InvalidAttributeException, QppServiceException {
		// Update filename and path attributes of Ave INTERACTIVITY element, so that filename contains asset name and path contains asset
		// id.
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		String xpathExpression = "//INTERACTIVITY//sourcesettings";
		XPathExpression expression = xpath.compile(xpathExpression);
		NodeList nodeList = (NodeList) expression.evaluate(document, XPathConstants.NODESET);
		for (int j = 0; nodeList != null && j < nodeList.getLength(); j++) {
			Node currNode = nodeList.item(j);
			Node dataProviderNode = getDataProviderNode(currNode);
			if (dataProviderNode != null) {
				NodeList childNodes = currNode.getChildNodes();

				for (int i = 0; childNodes != null && i < childNodes.getLength(); i++) {
					Node childNode = childNodes.item(i);
					if (childNode.getNodeName().equalsIgnoreCase("sourceid")) {
						String sourceID = childNode.getTextContent();
						if(sourceID.startsWith("file:")){
							sourceID= sourceID.replaceFirst("file:", "");
						}
						String assetId = getAssetId(sourceID);
						childNode.setTextContent(assetId);
					} else if (childNode.getNodeName().equalsIgnoreCase("sourcepath")) {
						String sourcePath = childNode.getTextContent();
						if(sourcePath.startsWith("file:")){
							sourcePath= sourcePath.replaceFirst("file:", "");
						}
						String assetId = getAssetId(sourcePath);
						String assetName = getAssetName(Long.parseLong(assetId));
						childNode.setTextContent(assetName);
					} 
					else if (childNode.getNodeName().equalsIgnoreCase("sourcetype")) {
						//Set souce type as QPP in this case
						childNode.setTextContent("6");
					}
				}
			}
		}
	}

	private Node getDataProviderNode(Node sourcePathNode) {
		Node interactivityNode = sourcePathNode.getParentNode().getParentNode().getParentNode();
		NodeList nodeList = interactivityNode.getChildNodes();
		for (int j = 0; nodeList != null && j < nodeList.getLength(); j++) {
			Node currNode = nodeList.item(j);
			if (currNode.getNodeName().equalsIgnoreCase("DATAPROVIDER")) {
				Node attrNode = currNode.getAttributes().getNamedItem("DATAPROVIDERXTID");
				if (attrNode != null) {
					if ("1347965009".equals(attrNode.getNodeValue())) {
						return currNode;
					}
				}
			}
		}
		return null;
	}


	private void updateDocumentForAveInteractivity(Document document) throws XPathExpressionException, NumberFormatException, AssetNotFoundException, InvalidAttributeException, QppServiceException {
		//Update filename and path attributes of Ave INTERACTIVITY element, so that filename contains asset name and path contains asset id. 
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		String xpathExpression = "//BOX//INTERACTIVITY//fileSource";
		XPathExpression expression = xpath.compile(xpathExpression);
		NodeList nodeList = (NodeList)expression.evaluate(document, XPathConstants.NODESET);
		for (int j = 0; nodeList != null && j < nodeList.getLength(); j++) {
			Node currNode = nodeList.item(j);
			Node dataProvider = currNode.getAttributes().getNamedItem("dataprovider");
			if (dataProvider != null) {
				dataProvider.setTextContent("QPS");
			}
			Node path = currNode.getAttributes().getNamedItem("path");
			String assetId = getAssetId(path.getNodeValue());
			if (assetId != null) {
				path.setNodeValue(assetId);
				Node fileName = currNode.getAttributes().getNamedItem("fileName");
				String assetName = getAssetName(Long.parseLong(assetId));
				fileName.setNodeValue(assetName);
			}
		}
		
		xpathExpression = "//BOX//INTERACTIVITY//DATAPROVIDER[@DATAPROVIDERXTID]";
		expression = xpath.compile(xpathExpression);
		Node node = (Node) expression.evaluate(document, XPathConstants.NODE);
		if (node != null) {
			Node attrNode = node.getAttributes().getNamedItem("DATAPROVIDERXTID");
			if (attrNode != null) {
				attrNode.setTextContent("1347965009");
			}
		}
	}


	private String getAssetId(String nodeValue) {
		int firstIndex = nodeValue.indexOf("_");
		if (firstIndex == -1) {
			return null;
		}
		// the audio/video child asset is usually referred as path="91_1.0.wmv"
		String assetId = nodeValue.substring(0, firstIndex);
		return assetId;
	}


	private String getAssetName(long assetId) throws NumberFormatException, AssetNotFoundException, InvalidAttributeException,
			QppServiceException {
			AttributeValue[] attributeValues = assetService.getAttributeValues(assetId,
					new long[] { DefaultAttributes.NAME });
			return ((TextValue) attributeValues[0].getAttributeValue()).getValue(); //"name.mp4";//		
	}

	@Override
	public void validate(PublishingContext context) throws Exception {

		
	}
	@Override
	public void clean(String processId) {
		fileManager.cleanup(processId);
	}
	
	@Override
	public String getName() {
		return activityName;
	}
	
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
}

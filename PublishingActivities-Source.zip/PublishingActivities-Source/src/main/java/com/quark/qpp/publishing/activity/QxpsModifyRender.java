/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.xml.sax.SAXException;

import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.AssetIdentityInfo;
import com.quark.qpp.publishing.util.QppAssetsUriUtility;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qxpsm.AddFileRequest;
import com.quark.qxpsm.AppStudioRequest;
import com.quark.qxpsm.CopyDeskDocRequest;
import com.quark.qxpsm.DeleteRequest;
import com.quark.qxpsm.Html5Request;
import com.quark.qxpsm.JPEGRenderRequest;
import com.quark.qxpsm.ModifierFileRequest;
import com.quark.qxpsm.NameValueParam;
import com.quark.qxpsm.PDFRenderRequest;
import com.quark.qxpsm.QContentData;
import com.quark.qxpsm.QException;
import com.quark.qxpsm.QRequestContext;
import com.quark.qxpsm.QuarkXPressRenderRequest;
import com.quark.qxpsm.QxpsmStreamingService;
import com.quark.qxpsm.RequestParameters;
import com.quark.qxpsm.RequestService;
import com.quark.qxpsm.SmartTemplateRequest;

/**
 * This activity uses QXP Template and Modifier XML to provide the output in the desired format like PDF, JPEG,
 * AVE, etc.. depending upon the property {@link #renderFormat}. The QXP template is resolved from the property {@link #templateUri}.
 *
 * <p>
 * Prerequisites:
 * <li>renderFormat : The format in which QXP template is to be rendered.It can have values like PDF, JPEG, AVE, QXP, QCD.</li>
 * <li>templateUri : URI of the QXP template.</li>
 * <li>templateAttachmentURIs : comma separated URI's of the QXP template attachments</li>
 * <li>videoPreviewUri : URI for video preview</li>
 * </p>
 * <br>
 * <p>
 * This activity requires following input contents :
 * <li>Modifier XML with the name specified by {@link #MODIFIER_XML_CONTENT_NAME}</li>
 * <li>Attachments with the name specified by {@link #ATTACHMENT_CONTENT_NAME}</li>
 * </p>
 * <br>
 * <p>
 * Name with which this activity emits content is specified by {@link #OUT_CONTENT_NAME}.
 * </p>
 *
 **/
public class QxpsModifyRender extends AbstractActivity  {
	
	private boolean clearDocpool = true;
	
	private final String QXPS_TRANSACTION_UID_PARAM_NAME = "TRANSACTION-UUID";
	
	private final String DEFAULT_VIDEO_PREVIEW_IMAGE = "Default_Video_Preview.jpg";

	/*
	 * Names with which this activity expects input content
	 */
	private static final String MODIFIER_XML_CONTENT_NAME = "ModifierXML";
	
	private static final String SMARTCONTENT_XML_CONTENT_NAME = "SmartContentXML";

	private static final String ATTACHMENT_CONTENT_NAME = "Attachment";
	
	private static final String ASSET_METADATA_XML_CONTENT_NAME = "AssetMetadataXml"; 
	
	private String qxpsUserName;
	private String qxpsPassword;
	  
    private String addAssetMetadataToDocpool;
    private String templateVariables;
    private String ancillaryXsltUri;
    
    private String createTaggedPdf;
        
    public void setCreateTaggedPdf(String createTaggedPdf) {
		this.createTaggedPdf = createTaggedPdf;
	}

	public void setAncillaryXsltUri(String ancillaryXsltUri) throws URISyntaxException {
		this.ancillaryXsltUri = ancillaryXsltUri;
	}

	public void setTemplateVariables(String templateVariables) {
        this.templateVariables = templateVariables;
    }

	public void setAddAssetMetadataToDocpool(String addAssetMetadataToDocpool) {
		this.addAssetMetadataToDocpool = addAssetMetadataToDocpool;
	}

	public void setQxpsUserName(String qxpsUserName) {
		this.qxpsUserName = qxpsUserName;
	}

	public void setQxpsPassword(String qxpsPassword) {
		this.qxpsPassword = qxpsPassword;
	}

	/*
	 * Name with which this activity emits content
	 */
	private static final String OUT_CONTENT_NAME = "QxpsRenderOutput";

	private static final String QPP_TEMPLATE_ATTACHMENT_NAME = "QppTemplateAttachment";
	
	private String html5TocSection;
	private String html5Layouts;
	
	public void setHtml5TocSection(String html5TocSection) {
		this.html5TocSection = html5TocSection;
	}

	public void setHtml5Layouts(String html5Layouts) {
		this.html5Layouts = html5Layouts;
	}

	@Autowired
	private AssetService assetService;

	@Autowired
	private QppAssetsUriUtility qppAssetsUriUtility;

	private Logger logger = Logger.getLogger(QxpsModifyRender.class);

	@Autowired
	private URIHandlerRegistry uRIHandlerRegistry;

	@Autowired
	private TempFileManager fileManager;

	private String activityName;
	
	// default values
	private String renderFormat = "PDF";
	private String scale = "1";
	
	private String box = null;
	
	public void setBox(String box) {
		this.box = box;
	}

	private String layout = null;
	private String outputStyle = null;

	private String maxPages;
	
	public void setMaxPages(String maxPages) {
		this.maxPages = maxPages;
	}

	private String convertSectionToPages;

	public void setConvertSectionToPages(String convertSectionToPages) {
		this.convertSectionToPages = convertSectionToPages;
	}

	private URI templateUri;

	private String templateAttachmentURIs;

	private Map<String, List<URI>>  resolvedTemplateAttachmentURIs = new HashMap<String, List<URI>>();

	private Map<String, URI> resolvedTemplateUrisMap = new HashMap<String, URI>();
	
	private URI videoPreviewUri;

	private URI resolvedVideoPreviewUri;

	private String annotateErrors = null;

	private String appendErrors = null;

	private String organization;
	private String publication;
	private String issue;
	private String articleTitle;
	private String articleSource;

	private String upload;

	/*
	 * Name of the user to log In to AppStudio
	 */
	private String username;

	/*
	 * Password of the user to log In to AppStudio
	 */
	private String password;
	
	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setArticleSource(String articleSource) {
		this.articleSource = articleSource;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}

	public void setUpload(String upload) {
		this.upload = upload;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setTemplateAttachmentURIs(String templateAttachmentURIs) throws URISyntaxException {
		this.templateAttachmentURIs = templateAttachmentURIs;
	}

	public void setAnnotateErrors(String annotateErrors) {
		this.annotateErrors = annotateErrors;
	}

	public void setVideoPreviewUri(String videoPreviewUri) throws URISyntaxException {
		this.videoPreviewUri = convertInputToURI(videoPreviewUri);
	}

	public void setAppendErrors(String appendErrors) {
		this.appendErrors = appendErrors;
	}

	@Autowired
	RequestService requestService;

	@Autowired
	private QxpsmStreamingService qxpsmStreamingService;

	public void setTemplateUri(String templateLocation) throws URISyntaxException {
		templateUri = convertInputToURI(templateLocation);
	}

	public void setRenderFormat(String renderFormat) {
		this.renderFormat = renderFormat;
	}

	public void setScale(String scale) {
		this.scale = scale;
	}

	public void setOutputStyle(String outputStyle) {
		this.outputStyle = outputStyle;
	}

	public void setLayout(String layout) {
		this.layout = layout;
	}
	
	public boolean isClearDocpool() {
		return clearDocpool;
	}

	public void setClearDocpool(boolean clearDocpool) {
		this.clearDocpool = clearDocpool;
	}
	
	private static String ANCILLARY_XSL_DOCPOOL_NAME = "ancillary.xslt"; 
	
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		// Read modifier stream and upload to docpool
		ContentInfo[] modifierData  = publishingContext.getInputContentInfos(MODIFIER_XML_CONTENT_NAME);
		ContentInfo[] smartContentData  = publishingContext.getInputContentInfos(SMARTCONTENT_XML_CONTENT_NAME);
		ContentInfo[] assetMetadataXml  = publishingContext.getInputContentInfos(ASSET_METADATA_XML_CONTENT_NAME);
		
		String modifierDocPoolName = null;
		boolean isSmartDoc = false;
		if (smartContentData != null && smartContentData.length > 0) {
			// Download modifier to local temp path and then upload
			File modifierFile = smartContentData[0].getFile();
			modifierDocPoolName = addStreamToDocpool(publishingContext, "smartdoc.xml", modifierFile);
			isSmartDoc = true;
		}
		else{
			// Download modifier to local temp path and then upload
			File modifierFile = modifierData[0].getFile();
			modifierDocPoolName = addStreamToDocpool(publishingContext, "mod.xml", modifierFile);
		}
		
		//Add asset attribute xml to docpool as it will be required for resolving template variables
		String resolvedAddAssetMetadata = resolveParameter(addAssetMetadataToDocpool, publishingContext);
		if (resolvedAddAssetMetadata != null && "true".equalsIgnoreCase(resolvedAddAssetMetadata) && assetMetadataXml != null && assetMetadataXml.length > 0) {
			   String attributesXMLName = "attributes.xml";
			   attributesXMLName = addStreamToDocpool(publishingContext, attributesXMLName, assetMetadataXml[0].getFile());
		}

		// resolve template uri and upload to docpool
		String templateDocpoolName = "template.qxp";
		URI resolvedTemplateUri = resolvedTemplateUrisMap.get(publishingContext.getProcessId());
		File templateContentFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), resolvedTemplateUri);
		templateDocpoolName = addStreamToDocpool(publishingContext, templateDocpoolName, templateContentFile);

		String scheme = resolvedTemplateUri.getScheme();
		//If template comes from QPP, resolve its attachments from QPP
		if(scheme.equalsIgnoreCase("qpp")){
			//Get all attachments and add their QPP URIs to resolvedTemplateAttachmentURIs list
			List<URI> urisList = fetchAttachmentsFromQppAndCopyToDocpool(resolvedTemplateUri, publishingContext);
			List<URI> existingAttachmentsUrisList = resolvedTemplateAttachmentURIs.get(publishingContext.getProcessId());
			if (existingAttachmentsUrisList != null) {
				urisList.addAll(existingAttachmentsUrisList);
			}
			resolvedTemplateAttachmentURIs.put(publishingContext.getProcessId(), urisList);
			
		}

		ContentInfo[] inData = publishingContext.getInputContentInfos(ATTACHMENT_CONTENT_NAME);
		// upload all attachments to docpool if any
		for(int i=0; i<inData.length; i++) {
			ContentInfo attachmentContent = inData[i];
			File attachedImageFile = attachmentContent.getFile();
			String modifierDocPoolAttachName  =  attachmentContent.getFile().getName();
			if (attachedImageFile != null && attachedImageFile.exists() && attachedImageFile.length() > 0) {
				addStreamToDocpool(publishingContext, modifierDocPoolAttachName, attachedImageFile);
			}
		}

		// execute render request
		String url = null;
		String mimeType = null;
		String fileExtension = null;
		String applicableFormat = resolveParameter(renderFormat, publishingContext);

		//Copy default video preview file
		if (resolvedVideoPreviewUri != null) {
			File videoThumbNailImage = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), resolvedVideoPreviewUri);
			addStreamToDocpool(publishingContext, DEFAULT_VIDEO_PREVIEW_IMAGE, videoThumbNailImage);
		}

		if (applicableFormat.equalsIgnoreCase("pdf")) {
			url = getModifiedPdf(templateDocpoolName, modifierDocPoolName, publishingContext, isSmartDoc);
			mimeType = "application/pdf";
			fileExtension = "pdf";
		} else if (applicableFormat.equalsIgnoreCase("jpeg")) {
			mimeType = "application/zip";
			fileExtension = "zip";
			url = getModifiedJpeg(templateDocpoolName, modifierDocPoolName, publishingContext, isSmartDoc);
		}
		else if (applicableFormat.equalsIgnoreCase("qxp")) {
			url = getModifiedQxp(templateDocpoolName, modifierDocPoolName, publishingContext, isSmartDoc);
			mimeType = "application/vnd.quark.quarkxpress";
			fileExtension = "qxp";
		}
		else if (applicableFormat.equalsIgnoreCase("qcd")) {
			url = getModifiedQcd(templateDocpoolName, modifierDocPoolName, publishingContext);
			mimeType = "application/x-quark.copydesk";
			fileExtension = "qcd";
		}
		else if (applicableFormat.equalsIgnoreCase("appstudio") ) {
			url = getModifiedAppStudio(templateDocpoolName, modifierDocPoolName, publishingContext, isSmartDoc);
			mimeType = "application/zip";
			fileExtension = "zip";
		} else if (applicableFormat.equalsIgnoreCase("html5") ) {
			url = getModifiedHtml5(templateDocpoolName, modifierDocPoolName, publishingContext, isSmartDoc);
			mimeType = "application/zip";
			fileExtension = "zip";
		}

		ContentInfo  contentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, convertInputToURI(url));
		contentInfo.setMimeType(mimeType);
		contentInfo.setFileExtension(fileExtension);

		String modifiedUrl = url.replaceAll("\\\\", "/");
		contentInfo.setResourceName(modifiedUrl.substring(modifiedUrl.lastIndexOf("/") + 1));		
	}

	private List<URI> fetchAttachmentsFromQppAndCopyToDocpool(URI templateUri, PublishingContext publishingContext) throws Exception {

		//Extract qpp asset ID from the URI
		long projectAssetId = getAssetIdFromUri(templateUri);

		//Fetch all attachments from QPP
		AssetRelation[] allAttachments = assetService.getChildAssetRelations(projectAssetId);

		List<URI> uriList = new ArrayList<URI>();
		//Construct QPP URIs for all attached assets and add URIs to resolvedTemplateAttachmentURIs list
		for (AssetRelation attachment : allAttachments) {
			long assetId = attachment.getChildAssetId();
			AssetVersion assetVersion = attachment.getChildAssetVersion();

			StringBuilder sb = new StringBuilder();
			sb.append("//assets/");
			sb.append(assetId);
			if(assetVersion != null) {
				sb.append("?");
				sb.append("majorversion="+assetVersion.getMajorVersion());
				sb.append("&");
				sb.append("minorversion="+assetVersion.getMinorVersion());
			}
			URI assetURI = new URI("qpp", sb.toString(), null);
			uriList.add(assetURI);

			ContentInfo  contentInfo = publishingContext.registerOutputContentInfo(QPP_TEMPLATE_ATTACHMENT_NAME, assetURI);

			File attachmentFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), assetURI);
			addStreamToDocpool(publishingContext, attachmentFile.getName(), attachmentFile);

			setRelationAttributes(contentInfo, attachment, attachmentFile.getName());

		}
		return uriList;
	}

	private void setRelationAttributes(ContentInfo contentInfo, AssetRelation assetRelation, String assetName ) {
		//Set these attributes with template attachments as they are required for creating QXP relations in further activities.
		contentInfo.setAttribute(DefaultAttributes.ID+"",  String.valueOf(assetRelation.getChildAssetId()));
		contentInfo.setAttribute(DefaultAttributes.NAME+"",  String.valueOf(assetName));
		contentInfo.setAttribute(DefaultAttributes.MAJOR_VERSION+"",  String.valueOf(assetRelation.getChildAssetVersion().getMajorVersion()));
		contentInfo.setAttribute(DefaultAttributes.MAJOR_VERSION+"",  String.valueOf(assetRelation.getChildAssetVersion().getMinorVersion()));

	}

	private long getAssetIdFromUri(URI qppUri) throws Exception {
		AssetIdentityInfo assetInfo = qppAssetsUriUtility.parseQppUri(qppUri);
		return assetInfo.getAssetID();
	}

	
	private String getModifiedHtml5(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext, boolean isSmartDoc) throws Exception  {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);
	
		Html5Request html5Request = new Html5Request();
		html5Request.setWebreader("true");
		
		String resolvedHtml5Layouts = resolveParameter(html5Layouts, publishingContext);
		String resolvedHtml5TocSection = resolveParameter(html5TocSection, publishingContext);
		String resolvedOutputStyle = resolveParameter(outputStyle, publishingContext);
		
		if(resolvedHtml5Layouts != null && !resolvedHtml5Layouts.trim().isEmpty()){
			html5Request.setLayouts(resolvedHtml5Layouts);
		}
		if(resolvedOutputStyle != null && !resolvedOutputStyle.trim().isEmpty()){
			html5Request.setOutputstyle(resolvedOutputStyle);
		}
		if(resolvedHtml5TocSection != null && !resolvedHtml5TocSection.trim().isEmpty()){
			html5Request.setTocSection(resolvedHtml5TocSection);
		}
		
		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(html5Request);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
			
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		
		if(isSmartDoc){
			SmartTemplateRequest smartTemplateRequest = createSmartTemplateRequest(modifierDocPoolName, publishingContext);
			smartTemplateRequest.setRequest(modifierRequest);
			populateSmartDocSpecificParams(publishingContext, requestParameters);
			requestParameters.setRequest(smartTemplateRequest);
		} else {
			requestParameters.setRequest(modifierRequest);
		}
		
		rc.setRequest(requestParameters);	
		
		QContentData qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();		
	}

	private String getModifiedJpeg(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext, boolean isSmartDoc) throws Exception {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);
		
		/* Create JPEG Request */
		JPEGRenderRequest jpegRenderRequest = new JPEGRenderRequest();
		
		String resolvedLayout = resolveParameter(layout, publishingContext);
		if (resolvedLayout != null && !resolvedLayout.isEmpty()) {
			jpegRenderRequest.setLayout(resolvedLayout);
		}
		
		jpegRenderRequest.setScale(resolveParameter(scale, publishingContext));
		
		String maxPagesParam = resolveParameter(maxPages, publishingContext);
		int previewMaxPages = maxPagesParam != null && !maxPagesParam.trim().isEmpty() ? Integer.parseInt(maxPagesParam) : 0;
		
//		jpegRenderRequest.setPage(resolveParameter(pageNumber, publishingContext));
		
		String resolvedBox = resolveParameter(box, publishingContext);
		if(resolvedBox != null && !resolvedBox.isEmpty()){
			jpegRenderRequest.setBoxes(resolvedBox);	
		}
		else {
			if (previewMaxPages > 0) {
				jpegRenderRequest.setPages("1-" + previewMaxPages);
			} else {
				jpegRenderRequest.setPages("1-end");
			}			
		}
		jpegRenderRequest.setDownload("true");
		
		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(jpegRenderRequest);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		
		if(isSmartDoc){
			SmartTemplateRequest smartTemplateRequest = createSmartTemplateRequest(modifierDocPoolName, publishingContext);
			smartTemplateRequest.setRequest(modifierRequest);
			populateSmartDocSpecificParams(publishingContext, requestParameters);
			requestParameters.setRequest(smartTemplateRequest);
		} else {
			requestParameters.setRequest(modifierRequest);
		}
		
		rc.setRequest(requestParameters);
		
		QContentData qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();		
	}
	 
	private RequestParameters getTxnUIDRequestParameter(String processId) {
		NameValueParam nameValueParam = new NameValueParam();
		nameValueParam.setParamName(QXPS_TRANSACTION_UID_PARAM_NAME);
		nameValueParam.setTextValue(processId);
		RequestParameters requestParameters = new RequestParameters();
		requestParameters.setParams(new NameValueParam[]{nameValueParam});
		return requestParameters;
	}

	private String getModifiedPdf(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext, boolean isSmartDoc) throws Exception {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);
		
		/* Create PDF Request */
		PDFRenderRequest pdfRenderRequest = new PDFRenderRequest();
		String resolvedLayout = resolveParameter(layout, publishingContext);
		if (resolvedLayout != null && !resolvedLayout.isEmpty()) {
			pdfRenderRequest.setLayout(resolvedLayout);
		}

		//pdfRenderRequest.setPage(resolveParameter(pageNumber, publishingContext));
		pdfRenderRequest.setOutputStyle(resolveParameter(outputStyle, publishingContext));
		String taggedPdf = resolveParameter(createTaggedPdf, publishingContext);
		if (taggedPdf != null && !taggedPdf.isEmpty()) {
			pdfRenderRequest.setCreateTaggedPdf(taggedPdf);
		}

		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(pdfRenderRequest);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		
		if(isSmartDoc){
			SmartTemplateRequest smartTemplateRequest = createSmartTemplateRequest(modifierDocPoolName, publishingContext);
			smartTemplateRequest.setRequest(modifierRequest);
			populateSmartDocSpecificParams(publishingContext, requestParameters);
			requestParameters.setRequest(smartTemplateRequest);
		} else {
			requestParameters.setRequest(modifierRequest);
		}
		
		rc.setRequest(requestParameters);
		QContentData qData = null;
		//		qData=requestService.processRequest(rc);
		/* Using qxpsmStreaming service since it returns a local temp file path */
			qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private String getModifiedAppStudio(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext, boolean isSmartDoc) throws Exception {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);

		/* Create AppStudio Request */
		AppStudioRequest appstudioRenderRequest = new AppStudioRequest();

		String resolvedUpload = resolveParameter(this.upload, publishingContext);
		if (resolvedUpload != null && resolvedUpload.equalsIgnoreCase("true")) {
			appstudioRenderRequest.setUpload("true");
			appstudioRenderRequest.setOrganization(resolveParameter(organization, publishingContext));
			appstudioRenderRequest.setPublication(resolveParameter(publication, publishingContext));
			appstudioRenderRequest.setIssue(resolveParameter(issue, publishingContext));
			appstudioRenderRequest.setArticle(resolveParameter(articleTitle, publishingContext));
			appstudioRenderRequest.setArticleSource(resolveParameter(articleSource, publishingContext));
			appstudioRenderRequest.setUserName(resolveParameter(username, publishingContext));
			appstudioRenderRequest.setPassword(resolveParameter(password, publishingContext));
		}

		appstudioRenderRequest.setConvertSectionsToPageStacks(resolveParameter(convertSectionToPages, publishingContext));
		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(appstudioRenderRequest);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
		
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		
		if(isSmartDoc){
			SmartTemplateRequest smartTemplateRequest = createSmartTemplateRequest(modifierDocPoolName, publishingContext);
			smartTemplateRequest.setRequest(modifierRequest);
			populateSmartDocSpecificParams(publishingContext, requestParameters);
			requestParameters.setRequest(smartTemplateRequest);
		} else {
			requestParameters.setRequest(modifierRequest);
		}
		
		rc.setRequest(requestParameters);		
		QContentData qData = null;
		/* Using qxpsmStreaming service since it returns a local temp file path */
		qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}
	
	private String getModifiedQxp(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext, boolean isSmartDoc) throws FileNotFoundException, IOException, Exception {


		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);

		/* Create AVE Request */
		QuarkXPressRenderRequest qxpRenderRequest = new QuarkXPressRenderRequest();
		String resolvedLayout = resolveParameter(layout, publishingContext);
		if (resolvedLayout != null && !resolvedLayout.isEmpty()) {
			qxpRenderRequest.setLayout(resolvedLayout);
		}

		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(qxpRenderRequest);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
		
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		
		if(isSmartDoc){
			SmartTemplateRequest smartTemplateRequest = createSmartTemplateRequest(modifierDocPoolName, publishingContext);
			smartTemplateRequest.setRequest(modifierRequest);
			populateSmartDocSpecificParams(publishingContext, requestParameters);
			requestParameters.setRequest(smartTemplateRequest);
		} else {
			requestParameters.setRequest(modifierRequest);
		}
		
		rc.setRequest(requestParameters);
		
		QContentData qData = null;
		/* Using qxpsmStreaming service since it returns a local temp file path */
		qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private String getModifiedQcd(String templateDocpoolName, String modifierDocPoolName, PublishingContext publishingContext) throws FileNotFoundException, IOException, Exception {

		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(templateDocpoolName);
		rc.setResponseAsURL(true);

		/* Create Copydesk Request */
		CopyDeskDocRequest qcdRenderRequest = new CopyDeskDocRequest();

		ModifierFileRequest modifierRequest = new ModifierFileRequest();
		modifierRequest.setRequest(qcdRenderRequest);
		modifierRequest.setAppendErrors(resolveParameter(appendErrors, publishingContext));
		modifierRequest.setAnnotateErrors(resolveParameter(annotateErrors, publishingContext));
		modifierRequest.setFile("file:"+modifierDocPoolName);
		
		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		requestParameters.setRequest(modifierRequest);
		rc.setRequest(requestParameters);
		
		QContentData qData = null;
		/* Using qxpsmStreaming service since it returns a local temp file path */
		qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private String addStreamToDocpool(PublishingContext publishingContext, String docpoolName, File file) throws IOException,
			FileNotFoundException, Exception {
		// Append processId as docpool path .
		docpoolName = publishingContext.getProcessId() + "/" + docpoolName;
		addFileToDocPool(publishingContext.getProcessId(), file, docpoolName);
		return docpoolName;
	}

	private void addFileToDocPool(String processId, File file, String fileName) throws Exception {
		QRequestContext requestContext = new QRequestContext();
		requestContext.setDocumentName(fileName);
		requestContext.setResponseAsURL(false);
		
		if (qxpsUserName != null && !qxpsUserName.trim().isEmpty()) {
			requestContext.setUserName(qxpsUserName);
		}
		if (qxpsPassword != null && !qxpsPassword.trim().isEmpty()) {
			requestContext.setUserPassword(qxpsPassword);
		}
		
		AddFileRequest addFileRequest = new AddFileRequest();
		
		requestContext.setRequest(addFileRequest);
		
		qxpsmStreamingService.processRequest(requestContext, new File[] { file });
	}

	@Override
	public void validate(PublishingContext context) throws Exception {

		// validate if all expected parameter values are available via channel
		checkForValue(renderFormat, context);
		if (templateUri == null) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "Template URI is not valid." });
		}

		resolvedTemplateUrisMap.put(context.getProcessId(), getResolvedURI(templateUri, context));

		if (videoPreviewUri != null) {
			resolvedVideoPreviewUri = getResolvedURI(videoPreviewUri, context);
		}


		if (templateAttachmentURIs != null) {
			URI templateAttachURI = convertInputToURI(templateAttachmentURIs);

			String scheme = templateAttachURI.getScheme();
			String commaSepUris = null;
			if (scheme.equalsIgnoreCase("param")) {
				String paramName = resolveParameter(templateAttachURI.toString(), context);
				if (paramName != null) {
					commaSepUris = paramName;
				}
			} else {
				// comma separated strings
				commaSepUris = templateAttachmentURIs;
			}
			if (commaSepUris != null) {
				String[] attachmentUris = commaSepUris.split(",");
				List<URI> urisList = new ArrayList<URI>();
				for (String uri : attachmentUris) {
					URI aUri =  convertInputToURI(uri);
					urisList.add(aUri);
					context.registerOutputContentInfo(QPP_TEMPLATE_ATTACHMENT_NAME, aUri);
					File attachmentFile = uRIHandlerRegistry.resolveToFile(context.getProcessId(), aUri);
					addStreamToDocpool(context, attachmentFile.getName(), attachmentFile);
				}
				resolvedTemplateAttachmentURIs.put(context.getProcessId(), urisList);
			}
		}
	}


	private URI getResolvedURI(URI sourceUri, PublishingContext context) throws InvalidActivityParameterException, URISyntaxException {
		String scheme = sourceUri.getScheme();
		URI resolvedURI = null;
		if(scheme.equalsIgnoreCase("param")){
			String paramName = resolveParameter(sourceUri.toString(), context);
			if (paramName == null || paramName.isEmpty()) {
				throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER);
			}
			resolvedURI = convertInputToURI(paramName);
		}
		else{
			resolvedURI = sourceUri;
		}
		return resolvedURI;
	}

	@Override
	public void clean(String processId) {
		deleteFileFromDocPool(processId);
		List<URI> uriList = resolvedTemplateAttachmentURIs.remove(processId);
		if (uriList != null) {
			uriList.clear();
		}
		fileManager.cleanup(processId);
		resolvedTemplateUrisMap.remove(processId);		
	}

	private void deleteFileFromDocPool(String fileName) {
		if(clearDocpool){
			QRequestContext requestContext = new QRequestContext();
			requestContext.setDocumentName(fileName);
			requestContext.setResponseAsURL(false);
			
			if (qxpsUserName != null && !qxpsUserName.trim().isEmpty()) {
				requestContext.setUserName(qxpsUserName);
			}
			if (qxpsPassword != null && !qxpsPassword.trim().isEmpty()) {
				requestContext.setUserPassword(qxpsPassword);
			}
			
			DeleteRequest deleteRequest = new DeleteRequest();
			requestContext.setRequest(deleteRequest);
			try {
				qxpsmStreamingService.processRequest(requestContext, null);
				logger.debug("deleted file from docpool. filename = " + fileName);
			} catch (Exception e) {
				logger.error("Unable to delete " + fileName + " from QXPS docpool.");
			}
		}
	}

	@Override
	public String getName() {
		return activityName;
	}
	
	private SmartTemplateRequest createSmartTemplateRequest(String modifierDocPoolName, PublishingContext publishingContext) throws FileNotFoundException, IOException, Exception {
		SmartTemplateRequest smartTemplateRequest = new SmartTemplateRequest();
		
		URI xsltUri = null;
		String resolvedXsltUri = resolveParameter(ancillaryXsltUri, publishingContext);
		if (resolvedXsltUri != null && !resolvedXsltUri.isEmpty()) {
			xsltUri = convertInputToURI(resolvedXsltUri);
			if (xsltUri != null) {
				File xsltFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), xsltUri);
				String ancillaryXslDocName = addStreamToDocpool(publishingContext, ANCILLARY_XSL_DOCPOOL_NAME, xsltFile);
				smartTemplateRequest.setAncillaryXsltFile("file:"+ancillaryXslDocName);
			}
		}
		return smartTemplateRequest;
	}
	
	private void populateSmartDocSpecificParams(PublishingContext publishingContext,
			RequestParameters requestParameters)
			throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		String templateVariablesString = resolveParameter(templateVariables, publishingContext);
		List<NameValueParam> nameValueParamList = new ArrayList<NameValueParam>();
		if (templateVariablesString != null && !templateVariablesString.isEmpty()) {
			Map<String, String> resolvedTemplateVariables = resolveTemplateVariablesForAttributes(publishingContext,
					templateVariablesString);
			if (resolvedTemplateVariables != null) {
				Set<String> paramNames = resolvedTemplateVariables.keySet();
				for (String aParamName : paramNames) {
					NameValueParam nameValueParam = new NameValueParam();
					nameValueParam.setParamName(aParamName);
					nameValueParam.setTextValue(resolvedTemplateVariables.get(aParamName));
					nameValueParamList.add(nameValueParam);
				}
			}
		}

		if (nameValueParamList.size() > 0) {
			// Append existing paramateres (if any)
			if (requestParameters.getParams() != null && requestParameters.getParams().length > 0) {
				nameValueParamList.addAll(Arrays.asList(requestParameters.getParams()));
			}
			requestParameters.setParams(nameValueParamList.toArray(new NameValueParam[0]));
		}
	}
	
	private Map<String, String> resolveTemplateVariablesForAttributes(PublishingContext publishingContext,
			String templateVariablesString)
			throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		
		Map<String, String> templateVariablesMap = new HashMap<String, String>();
		String templateVariablesArray[] = templateVariablesString.split(",");
		for (int i = 0; i < templateVariablesArray.length; i++) {
			String aVariable = templateVariablesArray[i];
			String[] keyValue = aVariable.split("=");
			if (keyValue != null && keyValue.length == 2) {
				String paramName = keyValue[0];
				String paramValue = keyValue[1];
				templateVariablesMap.put(paramName, paramValue);				
			}
			else{
				logger.warn("Inavlid template variable format: "+aVariable);
			}
		}
		return templateVariablesMap;		
	}

}

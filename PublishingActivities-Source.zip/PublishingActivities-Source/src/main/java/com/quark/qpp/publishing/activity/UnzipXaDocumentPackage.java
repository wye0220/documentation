/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.dto.ContentIdentifier;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * Unzips the content package only if the supplied content is in zip format. If the content provided is not in zip format, then same
 * content, without any alteration, is registered as out content. Format of the content is identified from the file extension of the File
 * object associated with the content.
 * 
 * <p>
 * Name with which the activity expects content is defined in the variable {@link #IN_CONTENT_NAME}.
 * </p>
 * 
 * <p>
 * After unzipping it emits following content:
 * <li>Main dita document - whose content name is defined in the variable {@link #OUT_MAIN_DITA_DOC}.  </li>
 * <li>Referenced XML - whose content name is defined in the variable {@link #OUT_XML_ATTACHMENT}.  </li>
 * <li>Referenced non-XML - whose content name is defined in the variable {@link #OUT_NON_XML_ATTACHMENT}.  </li> 
 * </p>
 * 
 * 
 **/
public class UnzipXaDocumentPackage extends AbstractActivity {

	private String activityName;

	/*
	 * Name with which this activity expects content
	 */
	private static final String IN_CONTENT_NAME = "ZippedContent";

	/*
	 * Names with which this activity emits content 
	 */
	private static final String OUT_MAIN_DITA_DOC = "MainDitaDoc";
	private static final String OUT_XML_ATTACHMENT = "XmlAttachment";
	private static final String OUT_NON_XML_ATTACHMENT = "NonXmlAttachment";

	private String mainDitaDocNameInZip;
	
	@Autowired
	private ContentStructureService contentStructureService;

	private Logger logger = Logger.getLogger(UnzipXaDocumentPackage.class);

	@Autowired
	private TempFileManager fileManager;

	public void setMainDitaDocNameInZip(String mainDitaDocNameInZip) {
		this.mainDitaDocNameInZip = mainDitaDocNameInZip;
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] inContentInfos = publishingContext.getInputContentInfos(IN_CONTENT_NAME);

		if (inContentInfos == null || inContentInfos.length == 0) {
			throw new PublishingException("No content supplied...");			
		}

		ContentInfo inContentInfo = inContentInfos[0];

		// If the content supplied is Zip, then unzip and register its dependencies with the publishing context.
		if (isMimeTypeZip(inContentInfo.getFile())) {
			// Unzip the content to process folder
			unzipPackageAndRegisterContent(inContentInfo.getFile(), publishingContext);
		} else {
			// If the content is not zip content, simply register the in-content as MainDitaDoc
			publishingContext.registerOutputContentInfo(OUT_MAIN_DITA_DOC, inContentInfo.getUri(), inContentInfo.getFile());
		}

	}

	private boolean isMimeTypeZip(File file) throws IOException, QppServiceException {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			byte[] initialBytes = new byte[4*1024];
			int count = fis.read(initialBytes);
			
			/*
			 * If input size is less than buffer then down-size the buffer else empty remaining bytes in the buffer cause the content to be detected as
			 * application/octet
			 */
			if(count<initialBytes.length) {
				byte[] resizedArray = new byte[count];
				System.arraycopy(initialBytes, 0, resizedArray , 0, count);
				initialBytes = resizedArray;
			}
			
			ContentIdentifier contentIdentifier = contentStructureService.getContentIdentifier(null, null, initialBytes);
			String mimeType = contentIdentifier.getMimeType();
			if (mimeType != null && (mimeType.contains("xml") || mimeType.equals("text/plain"))) {
				return false;
			}
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		return true;
	}

	private void unzipPackageAndRegisterContent(File zipFile, PublishingContext publishingContext) throws IOException, PublishingException,
			URISyntaxException {
		FileInputStream zfis = null;
		ZipFile zf = null;
		ZipInputStream in = null;
		FileOutputStream out = null;
		try {
			zfis = new FileInputStream(zipFile);
			in = new ZipInputStream(zfis);
			zf = new ZipFile(zipFile);

			for (Enumeration em = zf.entries(); em.hasMoreElements();) {
				em.nextElement();
				ZipEntry ze = in.getNextEntry();
				String entryName = ze.getName();

				File targetFile = fileManager.getTempFileWithGivenName(ze.getName(), publishingContext.getProcessId());
				
				int idx = entryName.lastIndexOf('/');
				if (idx >= 0) {
					if (entryName.substring(idx + 1).length() == 0){
						//This is folder. so simply return
						continue;
					}
				}

				out = new FileOutputStream(targetFile);
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				out.close();

				String outContentName = null;
				String fileExtension = getFileExtensionFromFileName(ze.getName());
				String mimeType = null;
				if (ze.getName().equalsIgnoreCase(mainDitaDocNameInZip)) {
					outContentName = OUT_MAIN_DITA_DOC;
					mimeType = "text/xml";
				} else if (fileExtension != null && (fileExtension.equalsIgnoreCase("xml") || fileExtension.equalsIgnoreCase("dita"))) {
					outContentName = OUT_XML_ATTACHMENT;
					mimeType = "text/xml";
				} else {
					outContentName = OUT_NON_XML_ATTACHMENT;
				}
				ContentInfo contentInfo = publishingContext.registerOutputContentInfo(outContentName, convertInputToURI("file://" + targetFile.getAbsolutePath()),
						targetFile);
				contentInfo.setFileExtension(fileExtension);	
				contentInfo.setMimeType(mimeType);
			}
		} catch (ZipException e) {
			logger.error("Invalid Zip File.",e);
			throw new PublishingException(PublishingExceptionCodes.INVALID_CONTENT, e);
		}finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
				if (zfis != null) {
					zfis.close();
				}
				if (zf != null) {
					zf.close();
				}
			} catch (IOException e) {
				logger.error("Error on closing streams: ", e);
			}
		}
	}

	private String getFileExtensionFromFileName(String fileName) {
		int dotInd = fileName.lastIndexOf('.');
		if (dotInd > 0 && dotInd < fileName.length()) {
			String extension = fileName.substring(dotInd + 1);
			return extension;
		}

		return null;
	}

	@Override
	public void clean(String processId) {
		fileManager.cleanup(processId);
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		if (mainDitaDocNameInZip == null || mainDitaDocNameInZip.isEmpty()) {
			throw new Exception("ACTIVITY VALIDATION FAILED : Activity parameter mainDitaDocNameInZip not defined");
		}
	}
}

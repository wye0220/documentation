package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.office.service.constants.ExcelDataObjectTypes;
import com.quark.qpp.office.service.constants.ExcelDataOutputFormats;
import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.exceptions.ExcelDataException;
import com.quark.qpp.office.service.exceptions.OfficeServiceExceptionCodes.ExcelDataExceptionCodes;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.OfficeFacade;
import com.quark.qpp.service.xmlBinding.WorksheetInfo;
import com.quark.qpp.service.xmlBinding.WorksheetInfoList;

/**
 * This Activity extracts the data from the given excel file in the specified format.
 */
public class ExtractExcelDataObject extends AbstractActivity {

	/*
	 * Name with which this activity emits content
	 */
	private String OUTPUT_CONTENT_NAME = "EXCEL_DATA_OBJECT";

	private String excelDocumentUri;
	private String sheetName;
	private String dataObjectType;
	private String dataObjectName;
	private String outputFormat;
	private String outputFormatProperties;
	private String excelContentType;
	
	public void setDataObjectType(String dataObjectType) {
		this.dataObjectType = dataObjectType;
	}

	public void setDataObjectName(String dataObjectName) {
		this.dataObjectName = dataObjectName;
	}

	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}

	public void setOutputFormatProperties(String outputFormatProperties) {
		this.outputFormatProperties = outputFormatProperties;
	}

	public void setExcelContentType(String excelContentType) {
		this.excelContentType = excelContentType;
	}

	@Autowired
	private OfficeFacade officeFacade;

	@Autowired
	private TempFileManager tempFileManager;
	
	protected String activityName;
	
	public void setExcelDocumentUri(String excelDocumentUri) {
		this.excelDocumentUri = excelDocumentUri;
	}
	
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		String resolvedExcelDocumentUri = resolveParameter(excelDocumentUri, publishingContext);
		String resolvedSheetName = resolveParameter(sheetName, publishingContext);
		String resolvedDataObjectType = resolveParameter(dataObjectType, publishingContext);
		String resolvedDataObjectName = resolveParameter(dataObjectName, publishingContext);
		String resolvedOutputFormat = resolveParameter(outputFormat, publishingContext);
		String resolvedOutputFormatProperties = resolveParameter(outputFormatProperties, publishingContext);
		HashMap<String, String> propertiesMap = createPropertiesMap(resolvedOutputFormatProperties);

		File file = tempFileManager.getTemporaryFile(".temp", publishingContext.getProcessId());
		FileOutputStream outputStream = null;
		
		try {
			outputStream = new FileOutputStream(file);
			if(resolvedExcelDocumentUri != null && resolvedExcelDocumentUri.trim().length() > 0) {
				if (resolvedDataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.TABLE)) {
					officeFacade.getTableBasedOnURI(resolvedExcelDocumentUri, resolvedSheetName, resolvedDataObjectName,
							resolvedOutputFormat, propertiesMap, null, null, outputStream);			
				} else if (resolvedDataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.CHART)) {
					officeFacade.getChartBasedOnURI(resolvedExcelDocumentUri, resolvedSheetName, resolvedDataObjectName,
							propertiesMap, null, null, outputStream);
					resolvedOutputFormat = ExcelDataOutputFormats.IMAGE;
				} else if (resolvedDataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.NAMED_RANGE)) {
					officeFacade.getNamedRangeBasedOnURI(resolvedExcelDocumentUri, resolvedSheetName, resolvedDataObjectName,
							resolvedOutputFormat, propertiesMap, null, null, outputStream);			
				}else if (resolvedDataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.DYNAMIC_RANGE)) {
					officeFacade.getDynamicRangeBasedOnURI(resolvedExcelDocumentUri, resolvedSheetName, resolvedDataObjectName,
							resolvedOutputFormat, propertiesMap, null, null, outputStream);
				}else {
					throw new ExcelDataException(ExcelDataExceptionCodes.INVALID_DATA_OBJECT_TYPE, new String[]{resolvedExcelDocumentUri+"",resolvedDataObjectType});
				}
			} else {
				String resolvedContentType = resolveParameter(excelContentType, publishingContext);
				ContentInfo[] inData = publishingContext.getInputContentInfos("EXCEL_DOCUMENT");
				File inputFile = null;
				if (inData == null || inData.length ==  0) {
					return;
				}
				inputFile = inData[0].getFile();
				InputStream in = null;
				try {
					in = new FileInputStream(inputFile);
					WorksheetInfoList worksheetInfoList = officeFacade.getExcelWorksheetsBasedOnStreamContext(in, null);
					in.close();
					in = new FileInputStream(inputFile);
					WorksheetInfo worksheetInfo = worksheetInfoList.getWorksheetInfo().get(0);
					if(resolvedContentType.equalsIgnoreCase("Microsoft Excel Table")) {
						String rangeName = worksheetInfo.getNamedRangeInfoList().getNamedRangeInfo().get(0).getName();
						officeFacade.getNamedRangeBasedOnStream(in, worksheetInfo.getName(), rangeName, resolvedOutputFormat, propertiesMap, null, null, outputStream);
					} else if(resolvedContentType.equalsIgnoreCase("Microsoft Excel Chart")) {
						String chartName = worksheetInfo.getChartInfoList().getChartInfo().get(0).getName();
						officeFacade.getChartBasedOnStream(in, worksheetInfo.getName(), chartName, propertiesMap, null, null, outputStream);
					}
				} finally {
					if(in != null) {
						in.close();
					}
				}
			}
		} finally {
			if (outputStream != null) {
				outputStream.close();
			}
		}
		
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI("file://" + file.getAbsolutePath()), file);
		
		
		//Populate content info
		if (resolvedOutputFormat == null || resolvedOutputFormat.isEmpty()) {
			//Set default values so that file extension can be resolved properly 
			if (resolvedDataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.CHART)) {
				resolvedOutputFormat = ExcelDataOutputFormats.IMAGE;
			} else {
				resolvedOutputFormat = ExcelDataOutputFormats.SMARTTABLE;
			}
		}		
		//Identify file extension based on output format. Cannot use contentStructure Service as it does not provide file extension. 
		String outFileExtension = null;
		String outMimeType = null;
		if (resolvedOutputFormat.equalsIgnoreCase(ExcelDataOutputFormats.HTML)) {
			outFileExtension = "html";
			outMimeType = "text/html";
		} else if (resolvedOutputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XHTML)) {
			outFileExtension = "xhtml";
			outMimeType = "application/xhtml+xml";
		} else if (resolvedOutputFormat.equalsIgnoreCase(ExcelDataOutputFormats.SMARTTABLE)
				|| resolvedOutputFormat.equalsIgnoreCase(ExcelDataOutputFormats.CALS)
				|| resolvedOutputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XML)) {
			outFileExtension = "xml";
			outMimeType = "application/xml";
		} else {
			String imageFormat = null;
			if (propertiesMap != null) {
				imageFormat = propertiesMap.get(ImageOutputProperties.IMAGE_FORMAT);
			}
			if(imageFormat==null || imageFormat.isEmpty()){
				imageFormat = "png";
			}			
			outFileExtension = imageFormat.toLowerCase();
			if(imageFormat.equalsIgnoreCase("pdf")){
				outMimeType = "application/pdf";
			} else {
				outMimeType = "image/"+imageFormat.toLowerCase();
			}
		}

		contentInfo.setFileExtension(outFileExtension);
		contentInfo.setMimeType(outMimeType);
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}
	
	/**
	 * Creats a HashMap<String, String> from a string of properties defined in format of type property1=value1;property2=value2;property3=value3;...;
	 * @param outputFormatProperties
	 * @return
	 */
	private HashMap<String, String> createPropertiesMap(String outputFormatProperties) {
		HashMap<String, String> map = new HashMap<String, String>();
		if (outputFormatProperties != null) {
			String[] properties = outputFormatProperties.split(";");
			for (int i = 0; properties != null && i < properties.length; i++) {
				String[] nameValue = properties[i].split("=");
				if (nameValue != null && nameValue.length == 2) {
					String key = nameValue[0];
					String value = nameValue[1];
					map.put(key, value);
				}
			}
		}
		return map;
	}




}

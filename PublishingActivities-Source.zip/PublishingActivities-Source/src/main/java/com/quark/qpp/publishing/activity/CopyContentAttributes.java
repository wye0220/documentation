/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * This activity copies attributes from source content to the target content and output the target content with
 * copied attributes. The activity property {@link #attributeNames} refers to the list of
 * attributes to be copied from source to target content.
 * 
 * <p>
 * This activity requires the following input contents:
 * <li>Source content whose attributes are to be copied is represented by {@link #SOURCE_ASSET_CONTENT_NAME}</li>
 * <li>Target content for which the attributes are to be copied is represented by {@link #TARGET_ASSET_CONTENT_NAME} .It
 * consists of a file associated for which the attributes are to be copied.</li>
 * </p>
 * <br>
 * <p>
 * Output contents : The name with which this activity emits content is provided by {@link #OUTPUT_CONTENT_NAME}. The
 * output content will have target file associated and the attributes copied from source content.
 * </p>
 * 
 * 
 */
public class CopyContentAttributes extends AbstractActivity{
	/*
	 * Names with which this activity expects input contents.
	 */
	private static final String SOURCE_ASSET_CONTENT_NAME = "SourceAsset" ;
	
	private static final String TARGET_ASSET_CONTENT_NAME = "TargetAsset" ;
	
	/*
	 * Name with which this activity emits content
	 */
	private static final String OUTPUT_CONTENT_NAME = "AssetWithMetadata" ;
	
	private String activityName;

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	//list of attribute names to be copied from source to target content
	private List<String> attributeNames ;

	public void setAttributeNames(List<String> attributeNames) {
		this.attributeNames = attributeNames;
	}
	
	@Autowired
	private AttributeService attributeService;

	@Override
	public String getName() {
		return this.activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		//Nothing to validate in this activity
		
	}
	
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo sourceAssetContentInfo = publishingContext.getInputContentInfos(SOURCE_ASSET_CONTENT_NAME)[0];
		ContentInfo targetAssetContentInfo = publishingContext.getInputContentInfos(TARGET_ASSET_CONTENT_NAME)[0];
		
		//get target file 
		File targetFile = targetAssetContentInfo.getFile();
		
		//register output content info
		ContentInfo registeredOutputContentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, new URI("file", targetFile.getAbsolutePath(), null), targetFile);
		
		//copy only those attributes from source asset to target asset that are specified in attributeNames.
		HashMap<String, String> sourceAttributes = (HashMap<String, String>) sourceAssetContentInfo.getAttributes();
		Iterator<String> iterator = attributeNames.iterator();
		while (iterator.hasNext()) {
			String attributeName = iterator.next();
			String attributeValue = sourceAttributes.get(attributeName);
			Attribute attribute = attributeService.getAttributeByName(attributeName);
			attributeValue = sourceAttributes.get(attribute.getId()+"");
			if(attributeValue != null && !attributeValue.isEmpty()){
				registeredOutputContentInfo.setAttribute(String.valueOf(attribute.getId()), attributeValue);
			}
			
		}
	}

	@Override
	public void clean(String processId) {
		// Nothing to clean in this activity
	}

}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.List;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.filenet.api.core.Connection;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.VersionSeries;
import com.filenet.api.meta.ClassDescription;
import com.filenet.api.util.UserContext;
import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * Enables access to content located in Filenet for publishing. Resolves filenet URN and downloads content to local file.
 */
public class FileNetUriResolver implements URIResolver {

	private Logger logger = Logger.getLogger(FileNetUriResolver.class);
	private String scheme="filenet";

	private String stanza = "FileNetP8WSI";
	private List<String> ditaDocsClassNamesList;
	private String userName;
	private String userPassword;
	private String filenetUri;
	private FilenetReferenceHelper filenetReferenceHelper;

	public void setDitaDocsClassNamesList(List<String> ditaDocsClassNamesList) {
		this.ditaDocsClassNamesList = ditaDocsClassNamesList;
	}
	
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public void setFilenetUri(String filenetUri) {
		this.filenetUri = filenetUri;
	}

	public void setStanza(String stanza) {
		this.stanza = stanza;
	}

	public void setFilenetReferenceHelper(FilenetReferenceHelper filenetReferenceHelper) {
		this.filenetReferenceHelper = filenetReferenceHelper;
	}
	@Autowired
	private TempFileManager fileManager;

	@Override
	public void clean(String processId) throws Exception {
		fileManager.cleanup(processId);
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}

	@Override
	public File resolveToFile(URI assetUri, String processId) throws Exception {
		logger.debug("Resolving Filenet URI: " + assetUri + ", UserName: " + userName + ", Stanza: " + stanza + ", Filenet URI: ");

		CEConnection ceConnection = new CEConnection();
		ceConnection.establishConnection(userName, userPassword, stanza, filenetUri);
		logger.debug("Filenet connection established.");

		String objectId = getFilenetObjectId(assetUri);
		logger.debug("Object id : " + objectId);
		String assetVersion = getFilenetObjectVersion(assetUri);
		logger.debug("Object version : " + assetVersion);
		String assetName = getFilenetObjectName(assetUri, ceConnection);
		logger.debug("Object Name : " + assetName);
		String objectStoreName = getObjectStoreName(assetUri);
		logger.debug("Object store name : " + objectStoreName);

		ObjectStore assetOs = ceConnection.fetchOS(objectStoreName);
		Document filenetContent = Factory.Document.fetchInstance(assetOs, objectId, null);
		//File tempFile = fileManager.getTempFileWithGivenName(assetVersion + assetName.replaceAll(" ",""), processId);
		File tempFile = fileManager.getTemporaryFile(assetName.substring(assetName.lastIndexOf(".")), processId);
		if (isCurrentVersion(assetVersion)) {
			VersionSeries vs = filenetContent.get_VersionSeries();
			filenetContent = (Document) vs.get_CurrentVersion();
		}
		writeDocContentToFile(filenetContent, tempFile);
		logger.debug("Filenet content fetched.");
		
		/* Update relative references in XML documents to valid Filenet URN */
		if (isDitaDocument(filenetContent)) {
			filenetReferenceHelper.updateRelativeReferences(filenetContent, tempFile);
		}
		logger.debug("filenet URI: " + assetUri + " resolved to location " + tempFile.getAbsolutePath());
		return tempFile;
	}

	private boolean isDitaDocument(Document filenetDocument) {
		ClassDescription classDecription = filenetDocument.get_ClassDescription();
		if (classDecription != null) {
			return ditaDocsClassNamesList.contains(classDecription.get_Name());
		}
		return false;
	}

	@Override
	public String getResourceIdentity(URI contentUri) {

		String assetMajorVersion;
		String assetMinorVersion;

		String objectId = getFilenetObjectId(contentUri);
		String objectVersion = getFilenetObjectVersion(contentUri);

		CEConnection ceConnection = new CEConnection();
		logger.debug("UserName: " + userName + "  Stanza:" + stanza);
		ceConnection.establishConnection(userName, userPassword, stanza, filenetUri);
		logger.debug("Filenet connection established.");

		String objectStoreName = getObjectStoreName(contentUri);
		logger.debug("Object store name : " + objectStoreName);

		ObjectStore assetOs = ceConnection.fetchOS(objectStoreName);
		Document doc = Factory.Document.fetchInstance(assetOs, objectId, null);
		if (isCurrentVersion(objectVersion)) {
			VersionSeries vs = doc.get_VersionSeries();
			Document latestDoc = (Document) vs.get_CurrentVersion();
			assetMajorVersion = latestDoc.getProperties().get("majorversionnumber").getObjectValue() + "";
			assetMinorVersion = latestDoc.getProperties().get("minorversionnumber").getObjectValue() + "";
		} else {
			assetMajorVersion = objectVersion.substring(0, objectVersion.indexOf("."));
			assetMinorVersion = objectVersion.substring(objectVersion.indexOf(".") + 1);
		}

		String resourceIdentity = assetOs.get_Name() + ";" + objectId + ";" + assetMajorVersion + "." + assetMinorVersion + ";";
		return resourceIdentity;
	}

	private boolean isCurrentVersion(String assetVersion) {
		if (assetVersion.contains("@.@")) {
			return true;
		} else {
			return false;
		}
	}

	private String getFilenetObjectId(URI assetUri) {
		// fileNet:///{CBD1628A-2E9C-4E3A-988F-141D933A4D5F}/@.@/TARGET/272.1-0.3.1.jpg
		String uri = assetUri.getSchemeSpecificPart().toString();
		String assetId = uri.substring(uri.indexOf('{'), uri.indexOf('}') + 1);

		return assetId;
	}

	private String getFilenetObjectVersion(URI assetUri) {
		// fileNet:///{CBD1628A-2E9C-4E3A-988F-141D933A4D5F}/@.@/TARGET/272.1-0.3.1.jpg
		String uri = assetUri.getSchemeSpecificPart().toString();
		uri = uri.substring(uri.indexOf('}') + 1);
		String assetVersion = uri.substring(uri.indexOf('/') + 1, uri.indexOf('/', 1));

		return assetVersion;
	}

	private String getFilenetObjectName(URI assetUri, CEConnection ceConnection) {
		// fileNet:///{CBD1628A-2E9C-4E3A-988F-141D933A4D5F}/@.@/TARGET/272.1-0.3.1.jpg
		String uri = assetUri.getSchemeSpecificPart().toString();
		uri = uri.substring(uri.indexOf('}') + 1);
		uri = uri.substring(uri.indexOf('/', 1));
		uri = uri.substring(uri.indexOf('/', 1));
		String assetName = uri.substring(uri.indexOf('/') + 1);
		return assetName;
	}


	private String getObjectStoreName(URI assetUri) {
		// fileNet:///{CBD1628A-2E9C-4E3A-988F-141D933A4D5F}/@.@/TARGET/272.1-0.3.1.jpg
		String uri = assetUri.getSchemeSpecificPart().toString();
		uri = uri.substring(uri.indexOf('}') + 1);
		uri = uri.substring(uri.indexOf('/', 1));
		String objectStoreName = uri.substring(uri.indexOf('/') + 1, uri.indexOf('/', 1));
		return objectStoreName;
	}

	public void writeDocContentToFile(Document filenetObject, File tempFile) throws IOException {
		InputStream is = null;
		FileOutputStream out = null;
		byte[] buffer = new byte[4*1024];
		try {
			logger.debug("File Size : " + filenetObject.get_ContentSize());
			is = filenetObject.accessContentStream(0);
			out = new FileOutputStream(tempFile);
			int count = is.read(buffer);
			while (count > 0) {
				out.write(buffer, 0, count);
				count = is.read(buffer);
			}
		} finally {
			try {
				if (is != null)
					is.close();
				if (out != null)
					out.close();
			} catch (IOException e) {
				logger.warn("",e);
			}
		}
	}

	class CEConnection {
		private Connection con;
		private Domain dom;
		private UserContext uc;

		public CEConnection() {
			uc = UserContext.get();
		}

		/*
		 * Establishes connection with Content Engine using supplied username, password, JAAS stanza and CE Uri.
		 */
		public void establishConnection(String userName, String password, String stanza, String uri) {
			con = Factory.Connection.getConnection(uri);

			// set authentication data in UserContext
			Subject sub = UserContext.createSubject(con, userName, password, stanza);
			uc.pushSubject(sub);

			dom = Factory.Domain.fetchInstance(con, null, null);;
		}

		/*
		 * Returns ObjectStore object for supplied object store name.
		 */
		public ObjectStore fetchOS(String name) {
			ObjectStore os = Factory.ObjectStore.fetchInstance(dom, name, null);
			return os;
		}
	}
}


/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.dto.ContentIdentifier;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity converts a DITA document or DITA map to given render formats like PDF, XHTML, ODT etc..
 * depending upon the activity property {@link #renderFormat}.
 *
 * <p>
 * This activity requires following input contents :
 * <li>A DITA file specified by name defined in {@link #DITA_CONTENT_NAME}</li>
 * <li>Dependent files (for sub-topic, sub-task, images etc..) are specified by name {@link #DITA_DEPENDENT_CONTENT_NAME}. </li>
 * <li>DitaVal URI (e.g file:c:\abc.ditaval or qpp:assets\1 or any other supported URI) or ditaval xml </val> for conditional publishing.
 *
 * <br>
 * <br>
 * Name with which this activity emits content is {@link #OUT_CONTENT_NAME}. The out content will have rendered DITA file
 * in desired format.
 * </p>
 **/
public class DitaRenderer extends AbstractActivity {

	private String activityName;

	private Logger logger = Logger.getLogger(DitaRenderer.class);
	
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

	@Autowired
	private TempFileManager fileManager;

	/*
	 * Specify DITA-OT transtype like xhtml,pdf,etc...
	 */
	private String transtype = "JPG";
	
	private String ditaOTPatramaters;

	public void setDitaOTPatramaters(String ditaOTPatramaters) {
		this.ditaOTPatramaters = ditaOTPatramaters;
	}

	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}

	private String ditaHome;

	//uri of the dita val file or the actual dita val xml for conditional transformations
	private String ditaval;

	public void setDitaval(String ditaval) {
		this.ditaval = ditaval;
	}

	@Autowired
	private URIHandlerRegistry uRIHandlerRegistry;

	@Autowired
	private TempFileManager tempFileManager;

	@Autowired
	private ContentStructureService contentStructureService;



	/*
	 * Names with which this activity expects input content
	 */
	private String DITA_CONTENT_NAME = "DitaFile";
	private String DITA_DEPENDENT_CONTENT_NAME = "DependentFile";

	/*
	 * Name with which this activity emits content
	 */
	private String OUT_CONTENT_NAME = "DITA-OUT";



	public void setDitaHome(String ditaHome) {
		try {
			this.ditaHome =  new File(ditaHome).getCanonicalPath();
		} catch (IOException e) {
			logger.error("Error while initiating DITA-OT Renderer. The 'DITA_HOME' variable is not set properly.");
		}
	}



	private String outFolderName = "out";

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] contentInfos = publishingContext.getInputContentInfos(DITA_CONTENT_NAME);
		
		ContentInfo ditaContInfo = contentInfos[0];
		File ditaOrigContentFile = ditaContInfo.getFile();

		// Dita OT require doc type in the xml otherwise it throws error.
		populateDocType(ditaOrigContentFile);

		ContentInfo[] dependentContentInfos = publishingContext.getInputContentInfos(DITA_DEPENDENT_CONTENT_NAME);
		for (int i = 0; i < dependentContentInfos.length; i++) {
			//Populate appropriate doc type in the dependent files (sub-topic, sub-task etc..)
			populateDocType(dependentContentInfos[i].getFile());
		}

		String transType = resolveParameter(transtype, publishingContext).toLowerCase();

		String ditavalFilePath = getDitavalPath(publishingContext);

		String resolvedOutputFormatProperties = resolveParameter(ditaOTPatramaters, publishingContext);
		String[] extraParameters = null;
		if (resolvedOutputFormatProperties != null && resolvedOutputFormatProperties.length() > 0) {
			extraParameters = resolvedOutputFormatProperties.split(";");
		}
		
		String outFileName = generateRendition(ditaOrigContentFile.getCanonicalPath(), transType, ditavalFilePath, publishingContext.getProcessId(), extraParameters);
		URI uri = new URI("file:" + URLEncoder.encode(outFileName, "UTF-8"));
		ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, uri, new File(outFileName));
		setContentAttributes(outContentInfo, getFileExtensionFromFileName(new File(outFileName)));
	}

	private String getDitavalPath(PublishingContext publishingContext) throws Exception {
		//resolve the dita val parameter
		String ditavalResolved = resolveParameter(ditaval, publishingContext);
		String ditaValFilePath = null;

		if (ditavalResolved != null && !ditavalResolved.isEmpty()) {
			try {
				URI ditaValUri = convertInputToURI(ditavalResolved);
				if (ditaValUri.getScheme() != null) {
					// in case there is valid scheme, it implies user has given
					// ditaval file uri (classpath:abc.diataval or
					// file:c:/abc.ditaval or..)
					File ditaValFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), convertInputToURI(ditavalResolved));
					ditaValFilePath = ditaValFile.getAbsolutePath();
				}
			} catch (URISyntaxException e) {
				// in case of invalid uri of the ditaval file.
				// This is the scenario when user gives the ditaval actual xml and not ditaval uri.
				ditaValFilePath = createDitavalFile(ditavalResolved, publishingContext);
			}
		}
		return ditaValFilePath;
	}

	/*
	 * Creates a temporary .ditaval file & writes the given 'ditaValResolved' xml string into the file.
	 * This is being done because DITA-OT accepts ditaval xml through a file.
	 */
	private String createDitavalFile(String ditavalResolved/* the ditaval xml that will be written into file*/, PublishingContext publishingContext) throws IOException {
		File tempDitaValFile = tempFileManager.getTemporaryFile(".ditaval", publishingContext.getProcessId());
		ByteArrayInputStream byteArrayInputStream = null;
		FileOutputStream fileOutputStream = null;
		try {
			byteArrayInputStream = new ByteArrayInputStream(ditavalResolved.getBytes("UTF-8"));
			fileOutputStream = new FileOutputStream(tempDitaValFile);
			pipe(byteArrayInputStream, fileOutputStream);
		} finally  {
			if(byteArrayInputStream != null)
				byteArrayInputStream.close();
			if(fileOutputStream != null){
				fileOutputStream.close();
			}
		}
		return tempDitaValFile.getAbsolutePath();
	}


	private void setContentAttributes(ContentInfo contentInfo, String fileExtension) throws IOException, QppServiceException {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(contentInfo.getFile());
			byte[] initialBytes = new byte[4096];
			fis.read(initialBytes);
			ContentIdentifier contentIdentifier = contentStructureService.getContentIdentifier(fileExtension, null, null);
			String mimeType = contentIdentifier.getMimeType();
			contentInfo.setMimeType(mimeType);
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		contentInfo.setFileExtension(fileExtension);
		contentInfo.setResourceName(contentInfo.getFile().getName());
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		//Nothing to validate in this activity
	}

	@Override
	public void clean(String processId) {
		String processFolder = fileManager.getProcessIdFolder(processId);
		String outFolderPath = processFolder + "/"+outFolderName;
		if (outFolderPath != null) {
			File outDir = new File(outFolderPath);
			if (outDir != null && outDir.exists()) {
				try {
					FileUtils.deleteDirectory(outDir);
				} catch (IOException e) {
					logger.error("Unable to delete directory: " + outDir.getAbsolutePath());
				}
			}
		}
		fileManager.cleanup(processId);
	}

	private String generateRendition(String sourceFileName, String transType, String ditaValFilePath, String processId, String[] extraParameters ) throws Exception {

		File f = new File(sourceFileName);
		String outDirPath = fileManager.getProcessIdFolder(processId) + "/" +outFolderName;
		File outFolder = new File(outDirPath);
		boolean created = outFolder.mkdir();
		if(!created){
			logger.warn("Out folder cannot be created: "+outDirPath);
		}
		String fileName = f.getName();

		String sourceFileNameWithoutExtension = fileName.substring(0, fileName.lastIndexOf("."));

		String[] params = null;
		if(ditaValFilePath == null){
			params = new String[] { "--format="+transType, "--input="+sourceFileName, "--output="+ outDirPath};
		}else{
			params = new String[] { "--format="+transType, "--input="+sourceFileName, "--output="+ outDirPath, "--filter="+ditaValFilePath};
		}
		
		params = (String[])ArrayUtils.addAll(params, extraParameters);
		
		String ditaOTResponse = executeCommand(params);
		File[] responseFiles = outFolder.listFiles();
		String outputFilePath = null;
		if(responseFiles.length > 1){
			File zipOutFile = fileManager.getTempFileWithGivenName(sourceFileNameWithoutExtension+".zip", processId);
			createZip(outFolder.listFiles(), zipOutFile, sourceFileNameWithoutExtension);
			outputFilePath = zipOutFile.getAbsolutePath();
		}else if(responseFiles.length == 1){
			outputFilePath = responseFiles[0].getAbsolutePath();
		}
		StringBuilder paramsString = new StringBuilder();
		for (int i = 0; params != null && i < params.length; i++) {
			paramsString.append(params[i]+",");
		}
		if (outputFilePath == null || !new File(outputFilePath).exists()) {
			logger.error("Error while generating preview for: " + sourceFileName);
			logger.error("Error while executing DITA command: "+paramsString);
			logger.error("DITA-OT response for processId: " + processId + "\n" + ditaOTResponse);
		} else {
			logger.debug("Executed DITA command: " + paramsString);
			logger.debug("DITA-OT response for processId: " + processId + "\n" + ditaOTResponse);
		}
		if (outputFilePath == null || !new File(outputFilePath).exists()) {
			throw new Exception("DITA-OT Error. For details, see publishing framework logs for the processId: " + processId + ". ");
		}
		return outputFilePath;
	}


	private void populateDocType(File file) {
			String extension = getFileExtensionFromFileName(file);
			if (extension != null
					&& (extension.equalsIgnoreCase("xml") || extension.equalsIgnoreCase("dita") || extension.equalsIgnoreCase("ditamap"))) {
				FileOutputStream fos = null;
				try {
					if (file.exists()) {
						factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
						factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);  
						factory.setValidating(false);
						factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
						factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
						DocumentBuilder builder = factory.newDocumentBuilder();
						org.w3c.dom.Document doc = builder.parse(file);
						String rootNodeName = doc.getDocumentElement().getNodeName();
						Transformer tFormer = TransformerFactory.newInstance().newTransformer();
						String dtd = "ditabase.dtd";
						if(rootNodeName.equalsIgnoreCase("map")){
							dtd = "map.dtd";
						}
						tFormer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, this.ditaHome + "/plugins/org.oasis-open.dita.v1_3/dtd/technicalContent/dtd/"+dtd);
						Source source = new DOMSource(doc);
						fos = new FileOutputStream(file);
						Result result = new StreamResult(fos);
						tFormer.transform(source, result);
					}
				} catch (Exception e) {
					logger.error(e);
				} finally {
					if (fos != null) {
						try {
							fos.close();
						} catch (IOException e) {
							logger.error(e);
						}
					}
				}
			}
	}

	private String getFileExtensionFromFileName(File file) {
		if (file.isFile()) {
			String fileName = file.getName();
			int dotInd = fileName.lastIndexOf('.');
			if (dotInd > 0 && dotInd < fileName.length()) {
				String extension = fileName.substring(dotInd + 1);
				return extension;
			}
		}
		return null;
	}

	public String executeCommand(String[] params) {
		StringBuilder ditaOTResponse = new StringBuilder();
		try {
			// ant -f Mypdf.xml
			List<String> allParams = new ArrayList<String>();
			allParams.add(this.ditaHome + "/bin/dita.bat");
			
			for (int i = 0; i < params.length; i++) {
				allParams.add(params[i]);
			}

			logger.info("Dita Command: " + allParams.toString());

			ProcessBuilder builder = new ProcessBuilder(allParams);
			builder.redirectErrorStream(true);
			Process ditaProcess = builder.start();
			try {
				BufferedReader std = new BufferedReader(new InputStreamReader(ditaProcess.getInputStream()));
				String line;
				while (std != null && (line = std.readLine()) != null) {
					ditaOTResponse.append(line).append("\n");
				}
				ditaProcess.waitFor();
			} catch (InterruptedException interruptedException) {
				logger.error("InterruptedException:",interruptedException);
			}
		} catch (IOException exception) {
			logger.error("Error while executing DITA command." + exception.getMessage());
		}
		return ditaOTResponse.toString();
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	private void createZip(File[] files, File zipFile, String sourceFileNameWithoutExtension) throws IOException {
		ZipOutputStream zipOutputStream = null;
		try {
			zipOutputStream = new ZipOutputStream(new FileOutputStream(zipFile));

			boolean indexHtmlAlreadyExists = checkForIndexHtml(files);

			// Compress the files
			for (int i = 0; i < files.length; i++) {
					addFileToZip(files[i], zipOutputStream,"", sourceFileNameWithoutExtension, indexHtmlAlreadyExists);
			}
		} finally {
			if (zipOutputStream != null) {
				try {
					zipOutputStream.close();
				} catch (IOException e) {
					logger.error("Error closing zip stream");
				}
			}
		}
	}

	private boolean checkForIndexHtml(File[] files) {
		for (int i = 0; files != null&& i < files.length; i++) {
			File file = files[i];
			if(file.isFile()){
				if(file.getName().equalsIgnoreCase("index.html")){
					return true;
				}
			}
		}
		return false;
	}


	/**
	 * This method adds given file to ZipOutputStream in folder hierarchy as specified.
	 * If folder hierarchy is null/empty then the file is placed at the root directory of zip.
	 * @param file
	 * @param zipOutputStream
	 * @param folderHeirarchy folder hierarchy in which the file is to be added in zip. If empty the file will be added at the root hierarchy
	 * @param mainSourceFileName
	 * @param indexHtmlAlreadyExists
	 * @throws IOException
	 */
	private void addFileToZip(File file, ZipOutputStream zipOutputStream, String folderHeirarchy, String mainSourceFileName, boolean indexHtmlAlreadyExists) throws IOException{
		if(file.isFile()){
			byte[] buf = new byte[1024];
			FileInputStream fileInputStream = new FileInputStream(file);
			try {
				String fileName = file.getName();
				String targetFileName = "";

				if(!indexHtmlAlreadyExists && fileName.equalsIgnoreCase(mainSourceFileName+".html")){
					//Name main html file as index.html
					fileName = "index.html";
				}

				if (folderHeirarchy != null && !folderHeirarchy.isEmpty())
					targetFileName = folderHeirarchy + "/" + fileName;
				else{
					targetFileName = fileName;
				}

				// Add ZIP entry to output stream.
				zipOutputStream.putNextEntry(new ZipEntry(targetFileName));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = fileInputStream.read(buf)) > 0) {
					zipOutputStream.write(buf, 0, len);
				}
			} finally {
				// Complete the entry
				zipOutputStream.closeEntry();
				fileInputStream.close();
			}
		}else{
			File[] childFiles = file.listFiles();
			for (int j = 0; j < childFiles.length; j++) {
				if(folderHeirarchy != null && !folderHeirarchy.isEmpty()){
					addFileToZip(childFiles[j], zipOutputStream, folderHeirarchy+"/"+file.getName(), mainSourceFileName, indexHtmlAlreadyExists);
				}else{
					addFileToZip(childFiles[j], zipOutputStream, file.getName(), mainSourceFileName, indexHtmlAlreadyExists);
				}
			}
		}
	}
	
}



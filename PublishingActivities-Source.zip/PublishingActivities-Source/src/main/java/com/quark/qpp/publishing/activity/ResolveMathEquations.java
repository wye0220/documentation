/*****************************************************************************\
 **
 ** ©1990-2016 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.util.TempFileManager;
import com.wiris.editor.services.PublicServices;
import com.wiris.editor.services.ServicesException;

/**
 *
 * This activity fetches and replaces the math elements (that represent a math
 * equation) in the input XML file by its image output generated using WIRIS
 * editor's client libraries.
 *
 * <p>
 * Prerequisites:
 * <li>xpathBasedStylesMap: A map containing xpath is to style details such that
 * math nodes selected using an XPATH will have their image outputs styled as
 * per the mentioned style properties in the map value. <br>
 * For example- //math/.../some xpath.../.. = fontFamily=..;fontStyle=..;</li>
 * <li>defaultImageFormat: The default image format to be considered for the
 * generation of image output of a math equation. The default image format is
 * considered only when xpathBasedStylesMap does not contain imageFormat
 * property. Supported image formats are PDF, SVG, PNG, EPS and SWF.</li>
 * <li>namespacePrefixUriMap: A map containing prefix and URI mapping of the
 * namespaces being used.</li>
 * <br>
 * <br>
 *
 * <p>
 * Name with which this activity expects input content is specified by
 * {@link #INPUT_CONTENT_NAME}.The input content can be any valid XML document
 * for example - A SmartDocument containing math equations represented using the
 * math element(of MathML). <br>
 * The input content should have file associated.
 * </p>
 * <br>
 * This activity emits following two contents - <br>
 * <li>The images of math equations are emitted out by content name specified by
 * {@link #OUTPUT_IMAGE_CONTENT_NAME}.</li><br>
 * <li>The modified input XML document whose math elements have been replaced
 * with image elements will be emitted out with the new content name as specified by
 * {@link #OUTPUT_MODIFIED_XML_CONTENT_NAME}</li>
 * 
 * 
 **/
public class ResolveMathEquations extends AbstractActivity {

	private Logger logger = Logger.getLogger(this.getClass());

	private String activityName;

	private HashMap<String, String> xpathBasedStylesMap;

	private String defaultImageFormat = "png";

	private HashMap<String, String> namespacePrefixUriMap;

	private String INPUT_CONTENT_NAME = "XMLFile";

	private String OUTPUT_IMAGE_CONTENT_NAME = "MathEquationImage";

	private String OUTPUT_MODIFIED_XML_CONTENT_NAME = "ModifiedXML";

	@Autowired
	private TempFileManager tempFileManager;

	private final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setNamespacePrefixUriMap(HashMap<String, String> namespacePrefixUriMap) {
		this.namespacePrefixUriMap = namespacePrefixUriMap;
	}

	public void setDefaultImageFormat(String defaultImageFormat) {
		this.defaultImageFormat = defaultImageFormat;
	}

	public void setXpathBasedStylesMap(HashMap<String, String> xpathBasedStylesMap) {
		this.xpathBasedStylesMap = xpathBasedStylesMap;
	}

	@Override
	public String getName() {
		return activityName;
	}

	public ResolveMathEquations() throws ParserConfigurationException {
		documentBuilderFactory.setValidating(false);
		documentBuilderFactory.setNamespaceAware(true);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// Nothing to validate
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] inContentInfos = publishingContext.getInputContentInfos(INPUT_CONTENT_NAME);
		DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();

		String resolvedDefaultImageFormat = resolveParameter(defaultImageFormat, publishingContext);

		for (int i = 0; i < inContentInfos.length; i++) {
			File inFile = inContentInfos[i].getFile();
			Document doc = builder.parse(inFile);
			Iterator<String> xpathIterator = xpathBasedStylesMap.keySet().iterator();
			while (xpathIterator.hasNext()) {
				String xpath = xpathIterator.next();
				String specificXpathOutputProperties = xpathBasedStylesMap.get(xpath);
				Properties inProperties = createPropertiesMap(specificXpathOutputProperties);
				String imageFormat = (String) inProperties.get("imageFormat");
				if (imageFormat == null || imageFormat.trim().length() == 0) {
					imageFormat = resolvedDefaultImageFormat;
				}
				inProperties.remove("imageFormat");
				generateMathEquationImages(publishingContext, doc, imageFormat, inProperties, xpath);
			}
			/*
			 * Here, we are not producing any new output XML file.Rather the
			 * math nodes have been replaced by image nodes in the input XML
			 * file itself. This has been done because the file name of input
			 * XML file (for e.g. 1610_1.0.xml)) could have been used in
			 * conref's in some parent Smart Documents etc... and producing new
			 * file with the same name at given folder is not possible. But we
			 * are registering the modified input XML file under a new content
			 * name as OUTPUT_MODIFIED_XML_CONTENT_NAME
			 */
			File outFile = inFile;
			writeDocumentToFile(doc, outFile);
			publishingContext.registerOutputContentInfo(OUTPUT_MODIFIED_XML_CONTENT_NAME, convertInputToURI("file://" + inFile.getAbsolutePath()));
		}
	}

	private void generateMathEquationImages(PublishingContext publishingContext, Document doc, String resolvedImageFormat, Properties inProperties, String resolvedXpathExpression)
			throws ParserConfigurationException, SAXException, IOException, XPathFactoryConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError,
			TransformerException, Exception, PublishingException, URISyntaxException {
		NodeList nodeList = (NodeList) executeXPathOnDocument(doc, resolvedXpathExpression, XPathConstants.NODESET);
		for (int j = 0; nodeList != null && j < nodeList.getLength(); j++) {
			Node node = nodeList.item(j);
			String mathML = getXmlStringFromNode(node);
			Properties outProperties = new Properties();
			File mathEquationImageFile = generateMathEquationImage(mathML, resolvedImageFormat, inProperties, outProperties, publishingContext.getProcessId());
			Element imageElement = doc.createElement("image");
			imageElement.setAttribute("href", mathEquationImageFile.getAbsolutePath());
			Iterator<Object> iterator = outProperties.keySet().iterator();
			while (iterator.hasNext()) {
				String key = (String) iterator.next();
				String value = (String) outProperties.get(key);
				if (key.equals("width")) {
					imageElement.setAttribute("cx", outProperties.getProperty("width"));
				} else if (key.equals("height")) {
					imageElement.setAttribute("cy", outProperties.getProperty("height"));
				} else {
					imageElement.setAttribute(key, value);
				}
			}
			imageElement.setAttribute("type", "matheq");
			node.getParentNode().replaceChild(imageElement, node);
			publishingContext.registerOutputContentInfo(OUTPUT_IMAGE_CONTENT_NAME, convertInputToURI("file://" + mathEquationImageFile.getAbsolutePath()), mathEquationImageFile);
		}
		logger.trace("Number of nodes processed for xpath expression : " + resolvedXpathExpression + " are " + (nodeList == null ? 0 : nodeList.getLength()));
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	private String getXmlStringFromNode(Node node) throws TransformerFactoryConfigurationError, TransformerException {
		StringWriter writer = new StringWriter();
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.transform(new DOMSource(node), new StreamResult(writer));
		return writer.toString();
	}

	private File generateMathEquationImage(String mathML, String mathEquationImageFormat, Properties inProperties, Properties outProperties, String processId) throws Exception {
		if (mathEquationImageFormat.equalsIgnoreCase("SVG")) {
			File svgFile = tempFileManager.getTemporaryFile(".svg", processId);
			generateSvg(mathML, inProperties, outProperties, svgFile);
			return svgFile;
		} else if (mathEquationImageFormat.equalsIgnoreCase("PDF")) {
			File outputPDFFile = tempFileManager.getTemporaryFile(".pdf", processId);
			generatePdf(mathML, inProperties, outProperties, outputPDFFile);
			return outputPDFFile;
		} else if (mathEquationImageFormat.equalsIgnoreCase("PNG")) {
			File pngFile = tempFileManager.getTemporaryFile(".png", processId);
			generatePng(mathML, inProperties, outProperties, pngFile);
			return pngFile;
		} else if (mathEquationImageFormat.equalsIgnoreCase("SWF")) {
			File svgFile = tempFileManager.getTemporaryFile(".swf", processId);
			generateSwf(mathML, inProperties, outProperties, svgFile);
			return svgFile;
		} else if (mathEquationImageFormat.equalsIgnoreCase("EPS")) {
			File epsFile = tempFileManager.getTemporaryFile(".eps", processId);
			generateEps(mathML, inProperties, outProperties, epsFile);
			return epsFile;
		}
		return null;
	}

	/**
	 * Creates a java.util.Properties object from a string of properties defined
	 * in format of type property1=value1;property2=value2;property3=value3;...;
	 * 
	 * @param outputFormatProperties
	 * @return java.util.Properties object
	 */
	private Properties createPropertiesMap(String outputFormatProperties) {
		Properties inProperties = new Properties();
		if (outputFormatProperties != null) {
			String[] properties = outputFormatProperties.split(";");
			for (int i = 0; properties != null && i < properties.length; i++) {
				String[] nameValue = properties[i].split("=");
				if (nameValue != null && nameValue.length == 2) {
					String key = nameValue[0];
					String value = nameValue[1];
					inProperties.setProperty(key, value);
				} else {
					logger.warn("Invalid value for the property : " + properties[i]);
				}
			}
		}
		return inProperties;
	}

	/*
	 * Generates SVG output.
	 */
	private void generateSvg(String mathML, Properties inProperties, Properties outProperties, File outputSvgFile) throws ServicesException, UnsupportedEncodingException,
			IOException {
		String svg = PublicServices.getInstance().renderSvg(mathML, null, inProperties, outProperties);
		writeStringToFile(svg, outputSvgFile);
	}

	/*
	 * Generates PDF output.
	 */
	private void generatePdf(String mathML, Properties inProperties, Properties outProperties, File outputPDFFile) throws Exception {
		String pdfXml = PublicServices.getInstance().renderPdf(mathML, null, inProperties, outProperties);
		writeStringToFile(pdfXml, outputPDFFile);
	}

	/*
	 * Generates PNG output.
	 */
	private void generatePng(String mathML, Properties inProperties, Properties outProperties, File outputPngFile) throws Exception {
		byte[] pngBytes = PublicServices.getInstance().renderPng(mathML, null, inProperties, outProperties);
		writeBytesToFile(pngBytes, outputPngFile);
	}

	/*
	 * Generates SWF output.
	 */
	private void generateSwf(String mathML, Properties inProperties, Properties outProperties, File outputSwfFile) throws Exception {
		byte[] swfBytes = PublicServices.getInstance().renderSwf(mathML, null, inProperties, outProperties);
		writeBytesToFile(swfBytes, outputSwfFile);
	}

	/*
	 * Generates EPS output.
	 */
	private void generateEps(String mathML, Properties inProperties, Properties outProperties, File outputEpsFile) throws Exception {
		String eps = PublicServices.getInstance().renderEps(mathML, null, inProperties, outProperties);
		writeStringToFile(eps, outputEpsFile);
	}

	private void writeDocumentToFile(Document document, File file) throws TransformerException, IOException {
		FileOutputStream xmlOutputStream = null;
		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer();
			DOMSource source = new DOMSource(document);
			xmlOutputStream = new FileOutputStream(file);
			StreamResult result = new StreamResult(xmlOutputStream);
			transformer.transform(source, result);
		} finally {
			if (xmlOutputStream != null) {
				xmlOutputStream.close();
			}
		}
	}

	private void writeStringToFile(String string, File file) throws FileNotFoundException, IOException, UnsupportedEncodingException {
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		try {
			fileOutputStream.write(string.getBytes("UTF-8"));
		} finally {
			fileOutputStream.close();
		}
	}

	private void writeBytesToFile(byte[] bytes, File file) throws FileNotFoundException, IOException {
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		try {
			fileOutputStream.write(bytes);
		} finally {
			fileOutputStream.close();
		}
	}

	private Object executeXPathOnDocument(Document document, String xpathExpression, QName returnType) throws XPathFactoryConfigurationException, XPathExpressionException {
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		xpath.setNamespaceContext(new MathMLNamespaceContext());
		XPathExpression compTypeExpr;
		try {
			compTypeExpr = xpath.compile(xpathExpression);
			return compTypeExpr.evaluate(document, returnType);
		} catch (XPathExpressionException e) {
			logger.error("Error applying XPath on document. XPath Expr:" + xpathExpression + "; Exception:" + e + ", Reason:"
					+ (ExceptionUtils.getRootCause(e) != null ? ExceptionUtils.getRootCause(e).getMessage() : "unknown"));
			logger.debug("", e);
			return null;
		}
	}

	private class MathMLNamespaceContext implements NamespaceContext {

		private static final String MATHML_NS_URI = "http://www.w3.org/1998/Math/MathML";

		public String getNamespaceURI(String prefix) {
			if (namespacePrefixUriMap != null && namespacePrefixUriMap.get(prefix) != null) {
				return namespacePrefixUriMap.get(prefix);
			}
			return MATHML_NS_URI;
		}

		public String getPrefix(String namespaceURI) {
			return null;
		}

		@SuppressWarnings("rawtypes")
		public Iterator getPrefixes(String namespaceURI) {
			return null;
		}

	}
}
/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.apache.log4j.Logger;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;

/**
 * 
 * This activity sends content to FTP Server at the folder path defined in the
 * variable {@link #folderPath}. Name with which this activity expects input
 * content is defined in the variable {@link #SOURCE_CONTENT}. The input content
 * may have file(s)/folder(s) associated that are to be send to the FTP Server.
 * In case there already exists a file/folder with the same name at destination
 * folder , then it will be replaced with the new content only if 
 * {@link #overwriteExisting} variable is true else an exception will be thrown.
 * 
 * <p>
 * Prerequisites:
 * <li>serverName : name of the FTP Server where the input content is to be
 * send.</li>
 * <li>serverPort : port of the FTP Server.
 * <li>folderPath : folder path on FTP Server where contents are to be send.</li>
 * <li>useFTPS : boolean value to specify whether to connect with the FTP Server
 * over SSL.</li>
 * <li>userName : name of the authorized user in FTP Server.</li>
 * <li>password : password of the user.</li>
 * <li>overwriteExisting : boolean value to indicate whether to overwrite the existing contents.If this flag is true ,it will first delete the existing content completely
 * and then add the new content. But if this flag is false, and there already exists content at destination,then an exception will be thrown.</li>
 * 
 * </p>
 */
public class SendToFTPServer extends AbstractActivity {

	private String activityName;

	// name with which this activity expects input content
	private String SOURCE_CONTENT = "SourceContent";

	private String serverName;

	private String serverPort;

	private String folderPath;

	private String useFTPS;

	private String userName;

	private String password;
	
	private String outContentFileName;
	
	private String overwriteExisting;

	private Logger logger = Logger.getLogger(this.getClass());

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		checkForValue(serverName, publishingContext);
		checkForValue(serverPort, publishingContext);
		checkForValue(folderPath, publishingContext);
		checkForValue(useFTPS, publishingContext);
		checkForValue(userName, publishingContext);
		checkForValue(password, publishingContext);
		checkForValue(overwriteExisting, publishingContext);
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		// Array of ContentInfos that may have file/folder associated, that are
		// to be send to FTP Server
		ContentInfo[] inputContentInfos = publishingContext.getInputContentInfos(SOURCE_CONTENT);
		if (inputContentInfos == null || inputContentInfos.length <= 0) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Input content with name '" + SOURCE_CONTENT + "' not found." });
		}

		// resolve parameters
		String username = resolveParameter(userName, publishingContext);
		String pwd = resolveParameter(password, publishingContext);
		String server = resolveParameter(serverName, publishingContext);
		String portStr = resolveParameter(serverPort, publishingContext);
		int port = -1;
		if (portStr != null && !portStr.isEmpty()) {
            try{
                  port = Integer.valueOf(portStr);
            } catch (NumberFormatException e) {
            	throw new PublishingException("FTP port specified is invalid : "+ portStr);
            }
		}
		boolean useSecureConnection = Boolean.valueOf(resolveParameter(useFTPS, publishingContext));
		String resolvedFTPFolderPath = resolveParameter(folderPath, publishingContext);
		boolean overwriteExistingFiles = Boolean.valueOf(resolveParameter(overwriteExisting, publishingContext));

		FTPClient client = null;

		// instantiate the FTPClient
		if (useSecureConnection) {
			client = new FTPSClient();// since FTPSClient extends FTPClient
		} else {
			client = new FTPClient();
		}

		// connect to FTPServer
		if (port > 0) {
			client.connect(server, port);
		} else {
			client.connect(server);
		}
		try {
			// Login to FTP Server
			boolean loginSuccessful = client.login(username, pwd);

			if (loginSuccessful) {

				// Commons FTPClient defaults to ASCII file types. Set it to
				// Binary when dealing with binary data like a zip, image, pdf etc...
				client.setFileType(FTP.BINARY_FILE_TYPE);
				
				// ensure that ftpFolderPath exists or create the desired folder hierarchy
				/* The osSpecificFTPFolderPath will have all forward slashes(/) to ensure no error in file path operations on different OS like linux, windows,...
				 * Also the path will be of format a/b/c & not /a/b/c since such a path is considered as absolute directory in linux.*/
				String osSpecificFTPFolderPath = createFTPFolderHierarchy(resolvedFTPFolderPath, client);
				
				for (ContentInfo inputContent : inputContentInfos) {
					File inputFile = inputContent.getFile();
					if(!inputFile.exists()){
						throw new PublishingException("Input content doesnot exist : "+inputFile.getAbsolutePath());
					}
					
					String fileName = resolveDeliveryContentName(outContentFileName, publishingContext, inputContent);

					// construct the destination FTP file/folder path
					String ftpFilePath = null;
					if(osSpecificFTPFolderPath == null || osSpecificFTPFolderPath.isEmpty()) {
						ftpFilePath = fileName;
					}else{
						ftpFilePath = osSpecificFTPFolderPath + "/" + fileName;
					}
					if(overwriteExistingFiles){
						// ensure the existing content with the same (file/folder)
						// name is cleanly deleted before adding the new content.
						deleteExistingContent(ftpFilePath, inputFile.isFile(), client);
					}else {
						String[] fileNames = client.listNames(ftpFilePath);
						if(fileNames != null && fileNames.length > 0){
							//since overwrite existing is false & there already exists file/folder with the same name, thus throw exception
							throw new PublishingException("Cannot overwrite existing FTP file: " + ftpFilePath);
						}
					}
					
					// After successful delete, send the new content.
					sendContent(inputFile, fileName, osSpecificFTPFolderPath, client);
				}
			} else {
				throw new PublishingException(PublishingExceptionCodes.ERROR_WHILE_EXECUTING_ACTIVITY,
						new String[] { "Login to FTP Server was unsuccessful." });
			}
		} finally {
			client.disconnect();
			logger.info("FTP client disconnected.", null);
		}
	}

	private void deleteExistingContent(String ftpFilePath, boolean isFile, FTPClient client) throws IOException {
		if (isFile) {
			client.deleteFile(ftpFilePath);
		} else {
			deleteExistingDirectory(ftpFilePath, client);
		}
	}

	private void sendContent(File file, String fileName, String ftpFolderPath, FTPClient client) throws FileNotFoundException, IOException, PublishingException {
		
		if (file.isFile()) {
			FileInputStream fis = new FileInputStream(file);
			try {
				if (fileName == null || fileName.isEmpty()) {
					fileName = file.getName();
				}
				String filePath = ftpFolderPath + "/" + fileName;
				if(ftpFolderPath == null || ftpFolderPath.isEmpty()){
					filePath = fileName;
				}
				boolean fileStored = client.storeFile(filePath, fis);
				if(!fileStored){
					throw new PublishingException("File not stored successfully at path : "+filePath);
				}
			} finally {
				fis.close();
			}
		} else {
			String directoryName = null;
			if(fileName != null)
				directoryName = fileName;
			else
				directoryName = file.getName();
			String directoryPath = null;
			if (ftpFolderPath == null || ftpFolderPath.isEmpty()) {
				directoryPath = directoryName;
			} else {
				directoryPath = ftpFolderPath + "/" + directoryName;
			}
			client.makeDirectory(directoryPath);
			File[] children = file.listFiles();
			for (int i=0;children != null && i<children.length;i++) {
				File childFile = children[i];
				sendContent(childFile, null, directoryPath, client);
			}
		}
	}

	/**
	 * This method creates the folder path as specified in parameter: ftpFolderPath.
	 * The folder path returned will be of format a/b/c... and not /a/b/c because in linux FTP servers, path such as : /a/b/c will be considered as absolute path 
	 * that might lead to error while creating directory at root level.
	 */
	private String createFTPFolderHierarchy(String ftpFolderPath, FTPClient client) throws IOException {
		String parentDirectoryPath = null;
		StringTokenizer stringTokenizer = new StringTokenizer(ftpFolderPath,"\\|/");
		while(stringTokenizer.hasMoreElements()){
			String folderToBeCreated = (String) stringTokenizer.nextElement();
			if(parentDirectoryPath == null){
				client.makeDirectory(folderToBeCreated);
				parentDirectoryPath = folderToBeCreated;
			}else{
				client.makeDirectory(parentDirectoryPath+"/"+folderToBeCreated);
				parentDirectoryPath = parentDirectoryPath +"/"+folderToBeCreated;
			}
		}
		return parentDirectoryPath;
	}

	private void deleteExistingDirectory(String dirPath, FTPClient client) throws IOException {
		FTPFile[] ftpFiles = client.listFiles(dirPath);
		for (int i = 0; ftpFiles != null && i < ftpFiles.length; i++) {
			if (ftpFiles[i].isFile()) {
				client.deleteFile(dirPath + "/" + ftpFiles[i].getName());
			} else if (ftpFiles[i].isDirectory()) {
				deleteExistingDirectory(dirPath + "/" + ftpFiles[i].getName(), client);
			}
		}
		client.removeDirectory(dirPath);// In case the directory is not deleted,
										// it will simply merge the new contents
										// with existing contents.//TODO should we throw an exception??
	}

	@Override
	public void clean(String processId) {
		// nothing to clean in this activity
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUseFTPS(String useFTPS) {
		this.useFTPS = useFTPS;
	}

	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	
	public void setOverwriteExisting(String overwriteExisting) {
		this.overwriteExisting = overwriteExisting;
	}
	
	public void setOutContentFileName(String outContentFileName) {
		this.outContentFileName = outContentFileName;
	}

}
/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.transformation.service.impl.JawsTransformer;

/**
 * This activity renders the source image with the help of ImageMagic and returns the desired output file or error file
 * in case of error.
 * 
 * 
 * Prerequisites :
 * <li>srcFileExtension : file extension of the source content that is to be rendered</li>
 * <li>destFileName : file name for the rendered output.</li>
 * <li>imagickHome : path to ImageMagic Home.
 * <li>command : operation to be performed on source image eg. convert</li>
 * <li>commandParameters : list of command parameters required for executing a command </li>
 * <li>outputFileName : name with which the output file is to be registered in PublishingContent <li>
 * 
 * <p>
 * This activity requires input content with name specified in {@link #SOURCE_IMAGE}. The input content should have
 * source image associated that is to be rendered or its attributes to be fetched.
 * </p>
 * <br>
 * <p>
 * This activity will emit following contents :
 * <li>The desired output file with name specified by {@link #OUTPUT_FILE}</li>
 * <li>In case of an error, there will be an output content with name specified by {@link #ERROR_FILE}</li>
 * </p>
 */
public class ImageMagickRender extends AbstractActivity{

	private Map<String, List<File>> tempFilesMap = new HashMap<String, List<File>>();
	
	/*
	 * name with which this activity expects content
	 */
	private static String SOURCE_IMAGE = "SourceImage";
	
	/*
	 * names with which this activity emits output.
	 */
	private static String OUTPUT_FILE = "OutputFile";
	
	private static String ERROR_FILE = "ErrorFile";
	
	private String activityName;
	
	private String command;	
	private List<String> commandParameters;	
	private String imageMagickHome;	
	
	private String  outputFileName;
	private String sourceFileExtension;
	
	private String outputFileExtension;

	private String imagickHome;
	private Map<String, String> destFileNamesMap = new HashMap<String, String>();
	private Map<String, String> srcFileExtensionsMap = new HashMap<String, String>();
	
	@Autowired
	private TempFileManager tempFileManager;
	
	@Autowired 
	private JawsTransformer jawsTransformer;
	
	private Logger logger = Logger.getLogger(getClass());
	
	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		String processId = publishingContext.getProcessId();
		if (imageMagickHome.contains("param")) {
			imagickHome = resolveParameter(imageMagickHome, publishingContext);
		} else {
			imagickHome = imageMagickHome;
		}
		
		if (imagickHome == null || imagickHome.isEmpty()) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "ImageMagick Home is not valid." });
		}

		imagickHome = new File(imagickHome).getAbsoluteFile().getCanonicalPath();
		
		if(outputFileName.contains("param:")) {
			destFileNamesMap.put(processId, resolveParameter(outputFileName, publishingContext));
		} else {
			destFileNamesMap.put(processId, outputFileName);
		}
		if (sourceFileExtension.contains("param:")) {
			srcFileExtensionsMap.put(processId, resolveParameter(sourceFileExtension, publishingContext));
		} else {
			srcFileExtensionsMap.put(processId, sourceFileExtension);
		}
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		ContentInfo[] sourceImages = publishingContext.getInputContentInfos(SOURCE_IMAGE);

		if (sourceImages == null || sourceImages.length < 1) {
			return;
		}
		
		String processId = publishingContext.getProcessId();

		for (int i = 0; sourceImages != null && i < sourceImages.length; i++) {
			
		ContentInfo sourceImage = sourceImages[i];

		String sourceImageFilePath = sourceImage.getFile().getAbsolutePath();
		String sourceImageFileName = sourceImage.getFile().getName();
		
		String fileExtension = getFileExtension(sourceImage, publishingContext.getProcessId());
		if ( fileExtension.equalsIgnoreCase("eps")) {
			FileOutputStream outputStream = null;
			FileInputStream inputStream = null;
			try {
				inputStream = new FileInputStream(sourceImageFilePath);
				File outFile = tempFileManager.getTempFileWithGivenName(sourceImageFileName.substring(0, sourceImageFileName.lastIndexOf("."))+".jpg", publishingContext.getProcessId());
				outputStream = new FileOutputStream(outFile);
				jawsTransformer.transform(inputStream, "JPG", "eps", outputStream);
				inputStream.close();
				outputStream.close();
				ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUTPUT_FILE, new URI("file", outFile.getAbsolutePath(), null), outFile);
				outContentInfo.setMimeType("image/jpeg");
				outContentInfo.setFileExtension("jpeg");
				outContentInfo.setResourceName(outFile.getName());
			} finally {
				if (inputStream != null)
					inputStream.close();
				if (outputStream != null)
					outputStream.close();
			}
		}
		else {
		List<String> commandParamsList = new ArrayList<String>();
		commandParamsList.add(imagickHome + File.separator + command);
		commandParamsList.addAll(commandParameters);
		commandParamsList.add(fileExtension + ":" + sourceImageFilePath);
		String destFileName = destFileNamesMap.get(processId);
		if (destFileName == null || destFileName.isEmpty()) {
			destFileName = sourceImage.getFile().getName();
		}
		if(destFileName.contains("."))
			destFileName = destFileName.substring(0,destFileName.lastIndexOf("."));
		String desitinationFilePath = new File(sourceImageFilePath).getParent()+ "\\" + destFileName + "." + outputFileExtension;
		commandParamsList.add(desitinationFilePath);

		String[] commandParams = commandParamsList.toArray(new String[0]);
		logger.debug("ImageMagick Attributes Command: "+ Arrays.toString(commandParams));

		Process imageMagickProcess = Runtime.getRuntime().exec(commandParams,null, new File(imagickHome));

		try {
			InputStream std = imageMagickProcess.getInputStream();
			InputStream err = imageMagickProcess.getErrorStream();
			int exitStatus = imageMagickProcess.waitFor();

			logger.debug("Exit Status :: " + exitStatus);
			boolean outputRegistered = false;
			File temp = writeResult(std, destFileName + "."
					+ outputFileExtension, publishingContext.getProcessId());
			ContentInfo outContentInfo = null;
			if (temp != null) {
				outContentInfo = publishingContext.registerOutputContentInfo(OUTPUT_FILE,
						new URI("file", temp.getAbsolutePath(), null), temp);
				outputRegistered = true;
				outContentInfo.setResourceName(temp.getName());
			} else {
					String filePath = new File(sourceImageFilePath).getParent()+ "\\" + destFileName + "."+ outputFileExtension;
					File tempDestFile = new File(filePath);

					if (tempDestFile.exists()) {
						if (tempFilesMap.get(publishingContext.getProcessId()) == null) {
							tempFilesMap.put(publishingContext.getProcessId(), new ArrayList<File>());
						}
						tempFilesMap.get(publishingContext.getProcessId()).add(tempDestFile);
						outContentInfo = publishingContext.registerOutputContentInfo(
								OUTPUT_FILE,
								new URI("file", tempDestFile.getAbsolutePath(),
										null), tempDestFile);
						outputRegistered = true;
						outContentInfo.setResourceName(tempDestFile.getName());
					} 

			}
			
			temp = writeResult(err, ERROR_FILE + ".txt", publishingContext.getProcessId());
			
			//While extracting attributes from the image, imagemagick creates attributes and write output to the specified file and also writes following to error stream:			
			//identify.exe: unable to open image `C:\Users\NEERGU~1\AppData\Local\Temp\QppServer\Publishing\738df7f6-9aaa-4ef0-8852-15887d9471fd\output.txt': No such file or directory @ error/blob.c/OpenBlob/2692.
			//Where output.txt is the file provided in the command to write the image attributes. 
			//To avoid this case, the check is added that if the output is generated then ignore the error.
			if (temp != null && !outputRegistered){
				outContentInfo = publishingContext.registerOutputContentInfo(ERROR_FILE,
						new URI("file", temp.getAbsolutePath(), null), temp);				
				outContentInfo.setResourceName(temp.getName());
			}
			if(outContentInfo != null && outputFileExtension != null && !outputFileExtension.isEmpty()) {
				if(outputFileExtension.equalsIgnoreCase("txt")){
					outContentInfo.setMimeType("text/plain");	
				} else if(outputFileExtension!=null && !outputFileExtension.isEmpty()){
					outContentInfo.setMimeType("image/" + outputFileExtension);
				}
				outContentInfo.setFileExtension(outputFileExtension);
			}
		} catch (Exception e2) {
			throw e2;
		}
		}
		}
	}

	private String getFileExtension(ContentInfo sourceImage, String processId) {
		if (sourceImage.getFileExtension() != null && !sourceImage.getFileExtension().isEmpty()) {
			return sourceImage.getFileExtension();
		} else if (sourceImage.getFile().getName() != null && sourceImage.getFile().getName().lastIndexOf(".")>0) {
			String fileName = sourceImage.getFile().getName();
			return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());			
		} else if (srcFileExtensionsMap.get(processId) != null) {
			return srcFileExtensionsMap.get(processId);
		}
		return null;
	}

	private File writeResult(InputStream in, String fileName, String processId)
			throws Exception {
		if (in != null && in.available() > 0) {
			File temp = tempFileManager.getTempFileWithGivenName(fileName,
					processId);
			OutputStream os = new FileOutputStream(temp);
			pipe(in, os);
			os.close();
			logger.debug("File :: " + temp.getAbsolutePath());
			return temp;
		} else return null;
	}
	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
		destFileNamesMap.remove(processId);
		srcFileExtensionsMap.remove(processId);

		List<File> tempFilepathList = tempFilesMap.get(processId);
		if (tempFilepathList != null) {
			for (File file : tempFilepathList) {
				file.delete();
			}
		}

		tempFilesMap.remove(processId);
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public void setCommandParameters(List<String> commandParameters) {
		this.commandParameters = commandParameters;
	}

	public void setImageMagickHome(String imageMagickHome) {
		this.imageMagickHome = imageMagickHome;
	}

	public void setOutputFileExtension(String outputFileExtension) {
		this.outputFileExtension = outputFileExtension;
	}

	public void setSourceFileExtension(String sourceFileExtension) {
		this.sourceFileExtension = sourceFileExtension;
	}

	public void setOutputFileName(String outputFileName) {
		this.outputFileName = outputFileName;
	}
}

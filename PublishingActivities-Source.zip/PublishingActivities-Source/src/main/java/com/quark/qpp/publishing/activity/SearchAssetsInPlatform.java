/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.facade.QueryFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValue;
import com.quark.qpp.service.xmlBinding.AttributeValueList;

/**
 * This activity searches assets in the platform on the basis of either {@link #searchAttributes} or {@link #searchName}.
 * In case the {@link #getHighres} parameter is true, then the outcontent will be an array of {@link SearchAssetsInPlatform#OUT_CONTENT} elements where
 * each ContentInfo element will have HIGH_RES of a result element associated. But if {@link #getHighres} parameter is false, then the ContentInfo will will have asset's Metadata XML.
 * 
 * <p>
 *  Prerequisites:
 *  <li>queryName : name of the saved search to be included in this new search.</li>
 *  <li>searchAttributes : map of attribute name as key and attribute value. This map will be considered to create attribute conditions for search.
 *  <li>displayAttributes : list of attribute names to be displayed</li>
 *  <li>getHighres : boolean value to specify whether to return HIGH_RES of each result element( each result asset) or to simply return Metadata XML.</li> 
 *</p>
 *
 */
public class SearchAssetsInPlatform extends AbstractActivity {

	private String activityName;

	//name with which this activity emits content
	private String OUT_CONTENT = "OutContent";

	//name of the saved query to be included in search
	private String searchName;

	private HashMap<String, String> searchAttributes;

	private List<String> displayAttributes;

	private String getHighres;

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	@Autowired
	private QueryFacade queryFacade;

	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private TempFileManager tempFileManager;

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	
	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// nothing to validate
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		String processId = publishingContext.getProcessId();

		boolean getHighresVal = Boolean.valueOf(resolveParameter(getHighres, publishingContext));
		
		String queryNameVal = resolveParameter(searchName, publishingContext);

		HashMap<String, String> resolvedMap = getResolvedValuesMap(searchAttributes, publishingContext);
		
		if (queryNameVal != null && !queryNameVal.isEmpty()) {
			resolvedMap.put("query", queryNameVal);
		}

		// search for assets
		AssetInfoList assetInfoList = (AssetInfoList) queryFacade.searchAssets(null, true,
				displayAttributes.toArray(new String[0]), null, false, resolvedMap);

		if (assetInfoList != null) {
			List<AssetInfo> list = assetInfoList.getAssetInfo();
			if (list != null && list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					AssetInfo assetInfo = list.get(i);
					File outFile = null;
					if (!getHighresVal) {
						AttributeValueList attributeValueList = assetInfo.getAttributeValueList();
						outFile = tempFileManager.getTemporaryFile(".xml", publishingContext.getProcessId());
						Result metadataStreamResult = new StreamResult(outFile);
						jaxb2Marshaller.marshal(attributeValueList, metadataStreamResult);
					} else {
						long assetId = Long.valueOf(assetInfo.getId());
						String fileXtension = getFileXtensionForAsset(assetId);
						outFile = tempFileManager.getTemporaryFile("." + fileXtension, processId);
						FileOutputStream fileOutputStream = new FileOutputStream(outFile);
						try {
							// below call will stream the asset HIGH_RES in fileOutputStream
							assetFacade.getAsset(assetInfo.getId(), null/* majorVersion */, null/* minorVersion */, null/* attributes */,
									false/* includeChildren */, false/* includeParents */, null/* relationTypes */, null/* renditionType */,
									fileOutputStream, null/* layoutNumber */, null/* pageNumber */, false/*fetch draft*/);
						} finally {
							fileOutputStream.close();
						}
					}
					// register the HIGH_RES in out content info.
					ContentInfo outputContentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT,
							convertInputToURI(outFile.getAbsolutePath()), outFile);

					// set display attributes in out content info
					setDisplayAttibutes(outputContentInfo, assetInfo);
				}
			}
		}
	}

	private HashMap<String, String> getResolvedValuesMap(HashMap<String, String> attributesMap, PublishingContext publishingContext) {
		HashMap<String, String> resolvedValuesMap = new HashMap<String, String>();
		Iterator<String> iterator = attributesMap.keySet().iterator();
		while (iterator.hasNext()) {
			String key = iterator.next();
			String value = attributesMap.get(key);
			resolvedValuesMap.put(key, resolveParameter(value, publishingContext));
		}
		return resolvedValuesMap;
		
	}

	private void setDisplayAttibutes(ContentInfo outputContentInfo, AssetInfo assetInfo) throws AssetNotFoundException, QppServiceException,
			StreamingException {
		List<AttributeValue> list = assetInfo.getAttributeValueList().getAttributeValue();
		for (int i = 0; i < list.size(); i++) {
			AttributeValue attrValue = list.get(i);
			outputContentInfo.getAttributes().put(attrValue.getName(), attrValue.getValue());
		}
	}

	private String getFileXtensionForAsset(long assetId) throws AssetNotFoundException, QppServiceException, StreamingException {
		AssetInfo assetInfo = assetFacade.getAsset(assetId, null/* majorVersion */, null/* minorVersion */,
				new String[] { "file extension" }/* attributes */, false/* includeChildren */, false/* includeParents */, null/* relationTypes */,
				null/* renditionType */, null/* outputStream */, null/* layoutNumber */, null/* pageNumber */, false/*draft*/);
		String fileXtension = assetInfo.getAttributeValueList().getAttributeValue().get(0).getValue(); 
		return fileXtension;
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}
	

	public void setSearchAttributes(HashMap<String, String> searchAttributes) {
		this.searchAttributes = searchAttributes;
	}

	public void setDisplayAttributes(List<String> displayAttributes) {
		this.displayAttributes = displayAttributes;
	}

	public void setGetHighres(String getHighres) {
		this.getHighres = getHighres;
	}

}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.util.TempFileManager;

public class HttpUriResolver implements URIResolver {

	private String scheme;
	
	private Map<String, String> mimetypeToFileExtensionMap;


	private Logger logger = Logger.getLogger(HttpUriResolver.class);
	
	public void setMimetypeToFileExtensionMap(Map<String, String> mimetypeToFileExtensionMap) {
		this.mimetypeToFileExtensionMap = mimetypeToFileExtensionMap;
	}

	@Autowired
	private TempFileManager fileManager;

	private Map<String, Map<URI, File>> processURIFileRegistry;

	@PostConstruct
	public void init() {
		processURIFileRegistry = new HashMap<String, Map<URI, File>>();
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	@Override
	public void clean(String processId) throws Exception {
		processURIFileRegistry.remove(processId);
		fileManager.cleanup(processId);
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}
		
	@Override
	public File resolveToFile(URI resourceUri, String processId) throws Exception {
		
		Map<URI, File> uriFileMap = processURIFileRegistry.get(processId);
		File tempFile = null;
		if (uriFileMap != null) {
			tempFile = uriFileMap.get(resourceUri);
		} else {
			uriFileMap = new HashMap<URI, File>();
		}		
		
		if (tempFile == null) {
			String uri = resourceUri.getScheme() + ":"+resourceUri.getSchemeSpecificPart();
			logger.trace("Http URI to resolve: " + uri);
			GetMethod method = new GetMethod(uri);
			
			HttpClient client = new HttpClient();			
			
			int status = client.executeMethod(method);
			logger.trace("Response status code: " + status);
			String fileExtension = getFileExtension(method, resourceUri.getPath());
			if(fileExtension!=null){
				tempFile = fileManager.getTemporaryFile("."+fileExtension, processId);
			}
			else{
				tempFile = fileManager.getTemporaryFile(null, processId);
			}
			logger.trace("Temp file created: " + tempFile.getAbsolutePath());
			if (status == HttpStatus.SC_OK) {
				InputStream inputStream = method.getResponseBodyAsStream();
				OutputStream os = new FileOutputStream(tempFile);
				writeToFile(inputStream, os);
				logger.trace("Content written to the file: " + tempFile.getAbsolutePath());				
			}
			
			uriFileMap.put(resourceUri, tempFile);
		}
		processURIFileRegistry.put(processId, uriFileMap);
		return new File(tempFile.getAbsolutePath());
	}

	private String getFileExtension(GetMethod method, String schemeSpecificPart) {
		String contentType = null;
		if (method.getResponseHeader("content-type") != null) {
			contentType = method.getResponseHeader("content-type").getValue();
		}
		logger.trace("Content type header from the response: " + contentType);
		String fileExtension = mimetypeToFileExtensionMap.get(contentType);
		logger.trace("File Extension from mappings: " + fileExtension);
		if (fileExtension == null) {
			if(contentType != null && contentType.contains(";")){
				String firstPart = contentType.split(";")[0];
				fileExtension = mimetypeToFileExtensionMap.get(firstPart);
			}
		}
		if (fileExtension == null || fileExtension.isEmpty()) {
			fileExtension = getExtension(schemeSpecificPart);
		}
		return fileExtension;
	}

	private String getExtension(String schemeSpecificPart) {
		int index = schemeSpecificPart.lastIndexOf(".");
		if(index >= 0) {
			String ext = schemeSpecificPart.substring(index + 1);
			return ext;
		}
		return null;
	}
	
	private void writeToFile(InputStream inputStream, OutputStream out) throws IOException {
		try {
			int read = 0;
			byte[] bytes = new byte[1024];

			while ((read = inputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
				logger.trace("Block written to file: " + new String(bytes, "UTF-8"));
			}
			inputStream.close();
			out.flush();

		} catch (IOException e) {
			throw e;
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	@Override
	public String getResourceIdentity(URI inputContentUri) {
		if (inputContentUri != null) {
			String uri = inputContentUri.toString();
			if (uri.contains("#")) {
				return uri.substring(0, uri.lastIndexOf("#"));
			}
			return uri;
		}
		return null;
	}

}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import javax.security.auth.Subject;

import com.filenet.api.admin.DocumentClassDefinition;
import com.filenet.api.admin.PropertyDefinition;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.ObjectStoreSet;
import com.filenet.api.collection.PropertyDefinitionList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Containable;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.CustomObject;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.quark.qpp.common.utility.DateUtility;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * 
 * This activity checks-in the content with the name specified by
 * {@link #IN_CONTENT_NAME} into FileNet.
 * 
 * <p>
 * Prerequisites:
 * <li>userName: FileNet username to be used to check-In and access data in
 * FileNet.</li>
 * <li>password: Password of the FileNet user</li>
 * <li>connectionURI: connection URI for FileNet</li>
 * <li>folderPath: folder path in FileNet where the file is to be checked In</li>
 * <li>objectStore: FileNet object store to be referred for check-In</li>
 * 
 * <br>
 * Name with which this activity expects input content is defined in the
 * variable {@link #IN_CONTENT_NAME}.The input content should have the file
 * associated that is to be checked-In.
 * </p>
 */
public class CheckInToFileNet extends AbstractActivity {

	private Map<String, String> fnAttributesMap;

	private String activityName;

	private String objectStore;
	
	private String folderPath;
	
	private String connectionURI;
	
	private String userName;
	
	private String password;
	
	private String outContentFileName;
	
	

	/**
	 * Name with which this activity expects input content to be checked-In.
	 */
	private String IN_CONTENT_NAME = "SourceDocument";

	public void setFnAttributesMap(Map<String, String> fnAttributesMap) {
		this.fnAttributesMap = fnAttributesMap;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setObjectStore(String objectStore) {
		this.objectStore = objectStore;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	public void setConnectionURI(String connectionURI) {
		this.connectionURI = connectionURI;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setOutContentFileName(String outContentFileName) {
		this.outContentFileName = outContentFileName;
	}

	public static void setCeConnection(CEConnection ceConnection) {
		CheckInToFileNet.ceConnection = ceConnection;
	}
	
	private static CEConnection ceConnection = null;
	
	private static String stanza = "FileNetP8WSI";
	
	@Override
	public String getName() {
		return this.activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		checkForValue(userName, publishingContext);
		checkForValue(password, publishingContext);
		checkForValue(connectionURI, publishingContext);
		checkForValue(folderPath, publishingContext);
		checkForValue(objectStore, publishingContext);
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] contentInfos = publishingContext
				.getInputContentInfos(IN_CONTENT_NAME);
		if (contentInfos == null || contentInfos.length == 0) {
			return;
		}
		File f = contentInfos[0].getFile();

		ceConnection = new CEConnection();
		ceConnection.establishConnection(
				resolveParameter(userName, publishingContext),
				resolveParameter(password, publishingContext), stanza,
				resolveParameter(connectionURI, publishingContext));
		
		
		String docName = resolveDeliveryContentName(outContentFileName, publishingContext, contentInfos[0]);

		createDoc(f, resolveParameter(folderPath, publishingContext),
				resolveParameter(objectStore, publishingContext), docName,
				"Document", "text/plain", contentInfos[0]);
	}

	@Override
	public void clean(String processId) {
		// Nothing to clean in this activity
	}

	public CheckInToFileNet() {
		// Nothing to do in constructor
	}

	public void createDoc(File f, String fileFolder, String objectStoreName,
			String docTitle, String docClass, String mimeType,
			ContentInfo contentInfo) throws FileNotFoundException {
		ObjectStore os = ceConnection.fetchOS(objectStoreName);
		String conType = mimeType; // text/plain
		Document doc;
		DocumentClassDefinition dcf;

		if (f != null) {
			doc = createDocWithContent(f, conType, os, docTitle, docClass);
			doc.save(RefreshMode.REFRESH);
			System.out.println("Document saved with content");
		} else {
			doc = createDocNoContent(conType, os, docTitle, docClass);
			doc.save(RefreshMode.REFRESH);
			System.out.println("Document saved");
		}
		if (fileFolder != null) {
			ReferentialContainmentRelationship rcr = fileObject(os, doc,
					fileFolder);
			rcr.save(RefreshMode.REFRESH);
			ReferentialContainmentRelationship rcr1 = fileObject(os, doc,
					fileFolder);
			rcr1.save(RefreshMode.REFRESH);
			System.out.println("Document filed");
		}
		// check in doc
		doc = Factory.Document.fetchInstance(os, doc.get_Id().toString(), null);

		dcf = Factory.DocumentClassDefinition.fetchInstance(os, "Document",
				null);
		;
		setAttributesForDocument(contentInfo, doc, dcf);
		System.out.println("Documents Attribute set.");
		checkinDoc(doc);
	}

	public void setAttributesForDocument(ContentInfo contentInfo, Document doc,
			DocumentClassDefinition dcf) {
		if (fnAttributesMap != null) {
			Set<Entry<String, String>> attributeNames = fnAttributesMap
					.entrySet();

			PropertyDefinitionList defList = dcf.get_PropertyDefinitions();
			PropertyDefinition propDef = null;

			for (Entry<String, String> attribute : attributeNames) {
				String value = contentInfo.getAttributeValue(attribute
						.getValue());
				if (value != null) {
					String dcAttributeName = attribute.getKey();
					if (doc.getProperties().isPropertyPresent(dcAttributeName)) {
						// doc.getProperties().putValue(dcAttributeName,value);
						Iterator iter = defList.iterator();
						while (iter.hasNext()) {
							propDef = (PropertyDefinition) iter.next();
							if (propDef.get_SymbolicName().equalsIgnoreCase(dcAttributeName))
								break;
						}
						setAttributeValue(doc, propDef, dcAttributeName, value);

					}
				}
			}
		}
	}

	private void setAttributeValue(Document doc, PropertyDefinition propDef,
			String attributeName, String attributeValue) {
		try {
			propDef.get_DataType();
			if (propDef.get_DataType() == TypeID.DATE) {
				Date dateValue = DateUtility.parseISODate(attributeValue);
				doc.getProperties().putValue(attributeName, dateValue);
			}

			else if (propDef.get_DataType() == TypeID.STRING) {
				doc.getProperties().putValue(attributeName, attributeValue);
			}

			else if (propDef.get_DataType() == TypeID.GUID) {
				Id idValue = new Id(attributeValue);
				doc.getProperties().putValue(attributeName, idValue);
			}
			
			else if (propDef.get_DataType() == TypeID.LONG) {
				Integer intValue = Integer.parseInt(attributeValue);
				doc.getProperties().putValue(attributeName, intValue);
			}

			else if (propDef.get_DataType() == TypeID.BOOLEAN) {
				boolean attrValue;

				if (attributeValue.equalsIgnoreCase("true")) {
					attrValue = true;
				} else {
					attrValue = false;
				}

				doc.getProperties().putValue(attributeName, attrValue);
			}

			else if (propDef.get_DataType() == TypeID.DOUBLE) {
				Double doubleValue;
				doubleValue = Double.parseDouble(attributeValue);
				doc.getProperties().putValue(attributeName, doubleValue);
			}

		} catch (Exception e) {
			System.out.println("Error while setting value for attribute " + attributeName + ".");
		}
	}

	private ContentTransfer createContentTransfer(File f) throws FileNotFoundException {
		ContentTransfer ctNew = null;
		FileInputStream fis;
		try {
		if (f != null && f.exists()) {
			ctNew = Factory.ContentTransfer.createInstance();
			fis = new FileInputStream(f);
			ctNew.setCaptureSource(fis);
			ctNew.set_RetrievalName(f.getName());
		}
		return ctNew;
		}finally{
			
		}
	}

	/*
	 * Creates the ContentElementList from ContentTransfer object.
	 */
	private  ContentElementList createContentElements(File f) throws FileNotFoundException {
		ContentElementList cel = null;
		if (createContentTransfer(f) != null) {
			cel = Factory.ContentElement.createList();
			ContentTransfer ctNew = createContentTransfer(f);
			cel.add(ctNew);
		}
		return cel;
	}

	/*
	 * Creates the Document with content from supplied file.
	 */
	private Document createDocWithContent(File f, String mimeType,
			ObjectStore os, String docName, String docClass) throws FileNotFoundException {
		Document doc = null;
		if (docClass.equals(""))
			doc = Factory.Document.createInstance(os, null);
		else
			doc = Factory.Document.createInstance(os, docClass);
		doc.getProperties().putValue("DocumentTitle", docName);
		// doc.set_MimeType(mimeType);
		ContentElementList cel = createContentElements(f);
		if (cel != null)
			doc.set_ContentElements(cel);
		return doc;
	}

	/*
	 * Creates the Document without content.
	 */
	private Document createDocNoContent(String mimeType, ObjectStore os,
			String docName, String docClass) {
		Document doc = null;
		if (docClass.equals(""))
			doc = Factory.Document.createInstance(os, null);
		else
			doc = Factory.Document.createInstance(os, docClass);
		doc.getProperties().putValue("DocumentTitle", docName);
		doc.set_MimeType(mimeType);
		return doc;
	}

	/*
	 * Retrieves the Document object specified by path.
	 */
	public static Document fetchDocByPath(ObjectStore os, String path) {
		Document doc = Factory.Document.fetchInstance(os, path, null);
		return doc;
	}

	/*
	 * Retrieves the Document object specified by id.
	 */
	public static Document fetchDocById(ObjectStore os, String id) {
		Id id1 = new Id(id);
		Document doc = Factory.Document.fetchInstance(os, id1, null);
		return doc;
	}

	/*
	 * Checks in the Document object.
	 */
	public static void checkinDoc(Document doc) {
		doc.checkin(AutoClassify.AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
		doc.save(RefreshMode.REFRESH);
		doc.refresh();
	}

	/*
	 * Creates the CustomObject.
	 */
	public static CustomObject createCustomObject(ObjectStore os,
			String className) {
		CustomObject co = null;
		if (className.equals(""))
			co = Factory.CustomObject.createInstance(os, null);
		else
			co = Factory.CustomObject.createInstance(os, className);
		return co;
	}

	/*
	 * Retrieves the CustomObject object specified by path.
	 */
	public static CustomObject fetchCustomObjectByPath(ObjectStore os,
			String path) {
		CustomObject doc = Factory.CustomObject.fetchInstance(os, path, null);
		return doc;
	}

	/*
	 * Retrieves the CustomObject object specified by id.
	 */
	public static CustomObject fetchCustomObjectById(ObjectStore os, String id) {
		Id id1 = new Id(id);
		CustomObject doc = Factory.CustomObject.fetchInstance(os, id1, null);
		return doc;
	}

	/*
	 * Files the Containable object (i.e. Document, CustomObject) in specified
	 * folder.
	 */
	public static ReferentialContainmentRelationship fileObject(ObjectStore os,
			Containable o, String folderPath) {
		com.filenet.api.core.Folder fo = Factory.Folder.fetchInstance(os,
				folderPath, null);
		ReferentialContainmentRelationship rcr;
		if (o instanceof Document)
			rcr = fo.file((Document) o, AutoUniqueName.AUTO_UNIQUE,
					((Document) o).get_Name(),
					DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
		else
			rcr = fo.file((CustomObject) o, AutoUniqueName.AUTO_UNIQUE,
					((CustomObject) o).get_Name(),
					DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
		return rcr;
	}
}

class CEConnection {
	private Connection con;
	private Domain dom;
	private String domainName;
	private ObjectStoreSet ost;
	private Vector osnames;
	private boolean isConnected;
	private UserContext uc;

	/*
	 * constructor
	 */
	public CEConnection() {
		con = null;
		uc = UserContext.get();
		dom = null;
		domainName = null;
		ost = null;
		osnames = new Vector();
		isConnected = false;
	}

	/*
	 * Establishes connection with Content Engine using supplied username,
	 * password, JAAS stanza and CE Uri.
	 */
	public void establishConnection(String userName, String password,
			String stanza, String uri) {
		con = Factory.Connection.getConnection(uri);
		Subject sub = UserContext
				.createSubject(con, userName, password, stanza);
		uc.pushSubject(sub);
		dom = fetchDomain();
		domainName = dom.get_Name();
		ost = getOSSet();
		isConnected = true;
	}

	/*
	 * Returns Domain object.
	 */
	public Domain fetchDomain() {
		dom = Factory.Domain.fetchInstance(con, null, null);
		return dom;
	}

	/*
	 * Returns ObjectStoreSet from Domain
	 */
	public ObjectStoreSet getOSSet() {
		ost = dom.get_ObjectStores();
		return ost;
	}

	/*
	 * Returns vector containing ObjectStore names from object stores available
	 * in ObjectStoreSet.
	 */
	public Vector getOSNames() {
		if (osnames.isEmpty()) {
			Iterator it = ost.iterator();
			while (it.hasNext()) {
				ObjectStore os = (ObjectStore) it.next();
				osnames.add(os.get_DisplayName());
			}
		}
		return osnames;
	}

	/*
	 * Checks whether connection has established with the Content Engine or not.
	 */
	public boolean isConnected() {
		return isConnected;
	}

	/*
	 * Returns ObjectStore object for supplied object store name.
	 */
	public ObjectStore fetchOS(String name) {
		ObjectStore os = Factory.ObjectStore.fetchInstance(dom, name, null);
		return os;
	}

	/*
	 * Returns the domain name.
	 */
	public String getDomainName() {
		return domainName;
	}
}
/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang.StringUtils;

import com.quark.qpp.publishing.framework.Activity;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * AbstractActivity contains some utility methods which are commonly required by implementation of Activity 
 */
public abstract class AbstractActivity implements Activity {


	protected URI convertInputToURI(String uriStr) throws URISyntaxException {
		URI aUri = null;
		String[] uriStrParts = uriStr.split(":", 2);
		if (uriStrParts.length > 1) {
			aUri = new URI(uriStrParts[0], uriStrParts[1], null);
		}
		else{
			aUri = new URI(uriStrParts[0]);
		}
		return aUri;
	}
	
	protected void pipe(InputStream is, OutputStream os) throws IOException {
		try {
			byte[] buffer = new byte[64 * 1024];
			int count = is.read(buffer);
			while (count > 0) {
				os.write(buffer, 0, count);
				count = is.read(buffer);
			}
			os.flush();
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	protected String resolveParameter(String parameter, PublishingContext publishingContext) {
		if(parameter == null) {
			return null;
		}
		String resolvedValue;
		
		// Examine if the parameter value is absolute or a uri
		String[] expressions = parameter.split(":", 2);
		if(expressions.length > 1 && expressions[0].trim().equalsIgnoreCase("param")) {
			// scan context for parameter value.
			String parameterName =  StringUtils.stripStart(expressions[1],"/");
			resolvedValue = publishingContext.getParameterValue(parameterName);
		} else {
			// return absolute value
			resolvedValue = parameter.trim();
		}
		return resolvedValue;
	}
	

	protected void checkForValue(String input, PublishingContext context) throws Exception {
		if(input != null) {
			String value = resolveParameter(input, context);
			if(value == null) {
				throw new Exception("ACTIVITY VALIDATION FAILED : Channel parameter not defined for required input [" + input +"]");
			}
		}		
	}
	
	/*
	 * This method returns a string that will be used as file name for the delivery content.
	 */
	protected String resolveDeliveryContentName(String nameChannelParameter, PublishingContext publishingContext, ContentInfo contentInfo) {
		String resolvedOutPutFileName = resolveParameter(nameChannelParameter, publishingContext);
		String fileNameStr = null;
		if (resolvedOutPutFileName != null && !resolvedOutPutFileName.isEmpty()) {
			fileNameStr = resolvedOutPutFileName;
		} else if (contentInfo.getResourceName() != null && !contentInfo.getResourceName().isEmpty()) {
			fileNameStr = contentInfo.getResourceName();
		} else {
			fileNameStr = contentInfo.getFile().getName();
		}
		File contentInfoFile = contentInfo.getFile();
		//now validate the file extension
		if (contentInfoFile.isFile()) {
			String contentInfoFileExtensionAttribute = contentInfo.getFileExtension();
			String contentInfoFileName = contentInfoFile.getName();
			String contentInfoFileExtension = contentInfoFileName.substring(contentInfoFileName.lastIndexOf(".")+1, contentInfoFileName.length());
			
			//if there is no file extension appended, concatenate the file extension from ContentInfo object or from the actual file.
			if (fileNameStr.lastIndexOf(".") <= 0) {
				String fileExtension = null;
				if(contentInfoFileExtensionAttribute != null && !contentInfoFileExtensionAttribute.isEmpty()){
					fileExtension = contentInfoFileExtensionAttribute;
				}else{
					fileExtension = contentInfoFileExtension;
				}
				fileNameStr = fileNameStr.concat("."+fileExtension);
			}else{
				
				/*
				 * here we will compare the already appended file extension in file name with the file extension from the absolute file path or file extension
				 * from ContentInfo object.
				 * In case they differ, append the file extension from absolute file path or from ContentInfo object
				 */
				
				String appendedFileExtension = fileNameStr.substring(fileNameStr.lastIndexOf(".")+1);
				if(appendedFileExtension.equalsIgnoreCase(contentInfoFileExtensionAttribute) || appendedFileExtension.equalsIgnoreCase(contentInfoFileExtension)
						|| "tmp".equalsIgnoreCase(contentInfoFileExtension) ){
					//do nothing in case the appended file extension in fileNameStr is same as inputInfoFileExtension or actualFileExtension
				}else{
					//Remove its file extension and concatenate the evaluated one 
					fileNameStr = fileNameStr.substring(0,fileNameStr.lastIndexOf("."));
					if(contentInfoFileExtensionAttribute != null && !contentInfoFileExtensionAttribute.isEmpty())
						fileNameStr = fileNameStr.concat("."+contentInfoFileExtensionAttribute);
					else
						fileNameStr = fileNameStr.concat("."+contentInfoFileExtension);
				}
			}
		}
		return fileNameStr;
	}
	

}

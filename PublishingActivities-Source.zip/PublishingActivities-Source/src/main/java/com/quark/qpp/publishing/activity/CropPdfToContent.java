/*****************************************************************************\
 **
 ** �1990-2017 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.net.URI;
import java.net.URLEncoder;

import org.springframework.beans.factory.annotation.Autowired;

import com.aspose.pdf.Document;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity will crop the PDF in a way that only portion of PDF which
 * contains content will be the resultant.
 * 
 * <p>
 * Name with which this activity expects input content is specified by
 * {@link #SOURCE_CONTENT_NAME}. Name with which the activity emits output will
 * be specified by {@link #OUT_CONTENT_NAME}.
 * </p>
 *
 */

public class CropPdfToContent extends AbstractActivity {

	private String activityName;
	
	private String SOURCE_CONTENT_NAME = "SOURCE_PDF";
	
	private String OUT_CONTENT_NAME = "CROPPED_PDF";

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Override
	public String getName() {
		return activityName;
	}

	@Autowired
	private TempFileManager tempFileManager;
	
	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] contentInfos = publishingContext.getInputContentInfos(SOURCE_CONTENT_NAME);
		ContentInfo ditaContInfo = contentInfos[0];
		File ditaOrigContentFile = ditaContInfo.getFile();
		
		Document document = new Document(ditaOrigContentFile.getAbsolutePath());

		// get page to trim white space
		com.aspose.pdf.Page pdfPage = document.getPages().get_Item(1);

		// get the content boundaries
		com.aspose.pdf.Rectangle contentBBox = pdfPage.calculateContentBBox();

		// set Page CropBox and MedioBox as per content boundries to tirm white space
		pdfPage.setCropBox(contentBBox);
		pdfPage.setMediaBox(contentBBox);

		File outFile = tempFileManager.getTemporaryFile(".pdf", publishingContext.getProcessId());
		// save the resultant PDF
		document.save(outFile.getAbsolutePath());
		
		URI uri = new URI("file:" + URLEncoder.encode(outFile.getAbsolutePath(), "UTF-8"));
		ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, uri, outFile);
		outContentInfo.setMimeType("application/pdf");
		outContentInfo.setFileExtension("pdf");
		outContentInfo.setResourceName(outFile.getName());
		
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);		
	}

}

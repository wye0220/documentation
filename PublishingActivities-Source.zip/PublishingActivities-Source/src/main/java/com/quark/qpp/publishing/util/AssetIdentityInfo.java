package com.quark.qpp.publishing.util;

import java.util.HashMap;

import com.quark.qpp.core.asset.service.dto.AssetVersion;

public class AssetIdentityInfo {
	private long assetID = 0;
	private AssetVersion assetVersion = null;
	private String namingScheme = null;
	private boolean isExcel = false;
	private boolean isExcelChart = false;
	private boolean isExcelTable = false;
	private String chart = null;
	private String table = null;
	private String namedRange = null;
	private String dynamicRange = null;
	private String worksheet = null;
	private String uri = null;
	private String outputFormat = null;
	private String objectType = null;
	private boolean isDynamicChart = false;
	private String rendition = null;
	private Integer layoutNumber = null;
	private Integer pageNumber = null;
	private String fragment = null;
	private boolean isVisio = false;
	private String visioPageName = null;
	private boolean isPpt = false;	
	private long pptSlideId = 0;
	
	public Integer getLayoutNumber() {
		return layoutNumber;
	}

	public void setLayoutNumber(Integer layoutNumber) {
		this.layoutNumber = layoutNumber;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getRendition() {
		return rendition;
	}

	public void setRendition(String rendition) {
		this.rendition = rendition;
	}

	private String templateUri = null;
	private String sourceDataType = null;
	private HashMap<String, String> outputFormatProperties = new HashMap<String, String>();

	
	public boolean isDynamicChart() {
		return isDynamicChart;
	}

	public void setDynamicChart(boolean isDynamicChart) {
		this.isDynamicChart = isDynamicChart;
	}

	public String getTemplateUri() {
		return templateUri;
	}

	public void setTemplateUri(String templateUri) {
		this.templateUri = templateUri;
	}

	public String getSourceDataType() {
		return sourceDataType;
	}

	public void setSourceDataType(String sourceDataType) {
		this.sourceDataType = sourceDataType;
	}

	//Default constructor. It can only be instantiated from QppAssetsUriUtility.
	AssetIdentityInfo() {
	}

	public long getAssetID() {
		return assetID;
	}

	public void setAssetID(long assetID) {
		this.assetID = assetID;
	}

	public AssetVersion getAssetVersion() {
		return assetVersion;
	}

	public void setAssetVersion(AssetVersion assetVersion) {
		this.assetVersion = assetVersion;
	}

	public String getNamingScheme() {
		return namingScheme;
	}

	public void setNamingScheme(String namingScheme) {
		this.namingScheme = namingScheme;
	}

	public boolean isExcel() {
		return isExcel;
	}

	public void setExcel(boolean isExcel) {
		this.isExcel = isExcel;
	}
	
	public boolean isExcelChart() {
		return isExcelChart;
	}

	public void setExcelChart(boolean isExcelChart) {
		this.isExcelChart = isExcelChart;
	}

	public boolean isExcelTable() {
		return isExcelTable;
	}

	public void setExcelTable(boolean isExcelTable) {
		this.isExcelTable = isExcelTable;
	}
	
	public String getChart() {
		return chart;
	}

	public void setChart(String chart) {
		this.chart = chart;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getNamedRange() {
		return namedRange;
	}

	public void setNamedRange(String namedRange) {
		this.namedRange = namedRange;
	}

	public String getDynamicRange() {
		return dynamicRange;
	}

	public void setDynamicRange(String dynamicRange) {
		this.dynamicRange = dynamicRange;
	}

	public String getWorksheet() {
		return worksheet;
	}

	public void setWorksheet(String worksheet) {
		this.worksheet = worksheet;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getOutputFormat() {
		return outputFormat;
	}

	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	public HashMap<String, String> getOutputFormatProperties() {
		return outputFormatProperties;
	}

	public void setOutputFormatProperties(
			HashMap<String, String> outputFormatProperties) {
		this.outputFormatProperties = outputFormatProperties;
	}

	public String getFragment() {
		return fragment;
	}

	public void setFragment(String fragment) {
		this.fragment = fragment;
	}
	public boolean isVisio() {
		return isVisio;
	}

	public void setVisio(boolean isVisio) {
		this.isVisio = isVisio;
	}
	
	public String getVisioPageName() {
		return visioPageName;
	}

	public void setVisioPageName(String pageName) {
		this.visioPageName = pageName;
	}
	
	public boolean isPpt() {
		return isPpt;
	}

	public void setPpt(boolean isPpt) {
		this.isPpt = isPpt;
	}

	public long getPptSlideId() {
		return pptSlideId;
	}

	public void setPptSlideId(long pptSlideId) {
		this.pptSlideId = pptSlideId;
	}
	
}

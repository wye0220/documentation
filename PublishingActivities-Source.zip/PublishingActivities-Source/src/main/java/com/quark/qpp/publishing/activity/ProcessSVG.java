/*****************************************************************************\
 **
 ** �1990-2018 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * This activity processes any SVG file present in the input files to replace the 'id' attribute of SVG elements with a unique-id.
 * Different SVGs can have elements with same 'id' attribute because of which they are not rendered properly as inline-content in
 * an HTML such as when converting BusDoc or SmartDoc to HTML. The SVGs are processed as follows:
 * 
 * <li>It generates a unique-id per SVG file.</li>
 * <li>It prepends the unique-id to the 'id' attribute of clipPath element in the svg.</li>
 * <li>The 'id' attribute of clipPath element is referenced in 'clip-path' attribute of 'g' element.
 * So, 'clip-path' attribute is also updated accordingly.</li>
 * 
 * Prerequisites :
 * <p>Either the file-extension or the mime-type of the input files.</p>
 * 
 * <p>
 * This activity requires input content with name specified in {@link #INPUT_CONTENT_NAME}. The input content should have
 * the SVGs that are to be processed.
 * </p>
 * <br>
 * <p>
 * This activity will emit following contents :
 * <li>The desired output file with name specified by {@link #OUTPUT_CONTENT_NAME}</li>
 * </p>
 */

public class ProcessSVG extends AbstractActivity {

	private String activityName;
	
	private static final String INPUT_CONTENT_NAME = "InputFiles";
	
	private static final String OUTPUT_CONTENT_NAME = "ProcessedSvgFiles";
	
	private DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		
		ContentInfo[] sourceFiles = publishingContext.getInputContentInfos(INPUT_CONTENT_NAME);
		
		if (sourceFiles == null || sourceFiles.length < 1) {
			return;
		}
		
		for(ContentInfo sourceFile : sourceFiles) {
			if("svg".equals(sourceFile.getFileExtension()) || "image/svg+xml".equals(sourceFile.getMimeType()) || (sourceFile.getResourceName() != null && sourceFile.getResourceName().endsWith(".svg"))) {
				File svgFile = sourceFile.getFile();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.parse(svgFile);
				Element rootNode = document.getDocumentElement();
				
				String uniqueSvgId = UUID.randomUUID().toString();
				
				NodeList clipPathNodes = rootNode.getElementsByTagName("clipPath");
				for(int i = 0; i < clipPathNodes.getLength(); i++) {
					Node clipPathNode = clipPathNodes.item(i);
					Node clipPathIdAttribute = clipPathNode.getAttributes().getNamedItem("id");
					if(clipPathIdAttribute != null) {
						String clipPathId = uniqueSvgId + clipPathIdAttribute.getNodeValue();
						clipPathIdAttribute.setNodeValue(clipPathId);
					}
				}
				
				NodeList gNodes = rootNode.getElementsByTagName("g");
				for (int i = 0; i < gNodes.getLength(); i++) {
					Node gNode = gNodes.item(i);
					Node clipPathAttribute = gNode.getAttributes().getNamedItem("clip-path");
					if (clipPathAttribute != null) {
						String clipPathAttributeValue = clipPathAttribute.getNodeValue().replace("#", "#" + uniqueSvgId);
						clipPathAttribute.setNodeValue(clipPathAttributeValue);
					}
				}
				
				DOMSource source = new DOMSource(document);
				StreamResult result;
				OutputStream out = null;
				try {
					out = new FileOutputStream(svgFile); 
					result = new StreamResult(out);
					TransformerFactory transFactory = TransformerFactory.newInstance();
					Transformer transformer = transFactory.newTransformer();
					transformer.transform(source, result);
				} finally {
					out.close();
				}
				ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI("file://"+svgFile.getAbsolutePath()));
				contentInfo.setMimeType("image/svg+xml");
				contentInfo.setFileExtension("svg");	
				contentInfo.setResourceName(svgFile.getName());
			}
		}
	}
	
	@Override
	public void clean(String processId) {
		
	}
	
}

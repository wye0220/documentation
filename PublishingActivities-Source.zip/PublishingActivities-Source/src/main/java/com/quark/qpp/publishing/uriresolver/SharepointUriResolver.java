/*****************************************************************************
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 ****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.llom.util.AXIOMUtil;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties.Authenticator;
import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NTCredentials;
import org.apache.commons.httpclient.auth.AuthPolicy;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.quark.qpp.publishing.activity.ListsStub;
import com.quark.qpp.publishing.activity.ListsStub.GetListItems;
import com.quark.qpp.publishing.activity.ListsStub.GetListItemsResponse;
import com.quark.qpp.publishing.activity.ListsStub.QueryOptions_type0;
import com.quark.qpp.publishing.activity.ListsStub.Query_type0;
import com.quark.qpp.publishing.activity.ListsStub.ViewFields_type0;
import com.quark.qpp.publishing.activity.SiteDataStub;
import com.quark.qpp.publishing.activity.SiteDataStub.GetListCollection;
import com.quark.qpp.publishing.activity.SiteDataStub.GetListCollectionResponse;
import com.quark.qpp.publishing.activity.SiteDataStub.GetListResponse;
import com.quark.qpp.publishing.activity.SiteDataStub.GetWeb;
import com.quark.qpp.publishing.activity.SiteDataStub.GetWebResponse;
import com.quark.qpp.publishing.activity.VersionsStub;
import com.quark.qpp.publishing.activity.VersionsStub.GetVersions;
import com.quark.qpp.publishing.activity.VersionsStub.GetVersionsResponse;
import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * Enables access to content located in Sharepoint for publishing
 */
public class SharepointUriResolver implements URIResolver {

	private Logger logger = Logger.getLogger(SharepointUriResolver.class);
	private String scheme;

	// Login name of a user with access to Sharepoint sites containing contents required for publishing from Platform.
	String userName;
	// Domain of user specified above
	String spUserDomain;
	// Login Password of user specified above
	String spUserPassword;
	// URL of Sharepoint Site Collection which contains documents required during publishing
	String spSiteCollectionUrl;

	@Autowired
	private TempFileManager fileManager;

	@Override
	public void clean(String processId) throws Exception {
		fileManager.cleanup(processId);
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	/** Login name of a user with access to Sharepoint sites containing contents required for publishing from Platform. **/
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/** Domain of user specified above **/
	public void setUserDomain(String spUserDomain) {
		this.spUserDomain = spUserDomain;
	}

	/** Login Password of user specified above **/
	public void setUserPassword(String spUserPassword) {
		this.spUserPassword = spUserPassword;
	}

	/** URL of Sharepoint Site Collection which contains documents required during publishing **/
	public void setSiteCollectionUrl(String spSiteCollectionUrl) {
		this.spSiteCollectionUrl = spSiteCollectionUrl;
	}

	@Override
	public File resolveToFile(URI spContentUri, String processId) throws Exception {

		String spContentUriStr = spContentUri.toString();
		logger.debug("****** SharepointUriResolver ******* Input URI: " + spContentUriStr);

		String spUserName = spUserDomain + "\\" + userName;

		if (spSiteCollectionUrl != null && !spSiteCollectionUrl.endsWith("/")) {
			spSiteCollectionUrl = spSiteCollectionUrl + "/";
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Sharepoint config used = [UserName: " + spUserName + ", Password: " + spUserPassword + ", Domain: " + spUserDomain
					+ ", SiteCollection: " + spSiteCollectionUrl);
		}

		/*
		 * Use Sharepoint username and password to create a HTTP Authenticator with NTLM credentials.
		 * The authenticator shall be used for each WebService invocation on Sharepoint server.
		 */
		URI spSiteCollectionUri = new URI(spSiteCollectionUrl);
		Authenticator authenticator = getAuthenticator(spUserName, spUserPassword, spSiteCollectionUri.getHost(), spSiteCollectionUri.getPort(), "NTLM");

		/*
		 * Create an HttpClient object to make HTTP calls on Sharepoint server for downloading content.
		 * Use user's login name and password to initialize a NTLM credentials object which shall be used for every HTTP GET request.
		 */
		HttpClient client = new HttpClient();
		client.getParams().setAuthenticationPreemptive(true);
		Credentials httpCreds = new NTCredentials(userName, spUserPassword, spSiteCollectionUri.getHost(), spUserDomain);
		client.getState().setCredentials(new AuthScope(spSiteCollectionUri.getHost(), spSiteCollectionUri.getPort(), AuthScope.ANY_REALM), httpCreds);

		// Parse platform specific sharepoint uri string
		SharePointUri spUri = SpUriFactory.createSpUri(spContentUriStr);

		// Download content from sharepoint into a temporary file
		File tempFile = downloadFromSharepoint(spUri, authenticator, spSiteCollectionUri, processId, client);

		logger.debug("****** SharepointUriResolver ******* Completed resolution of URI: " + spContentUriStr);
		return tempFile;
	}

	/**
	 * Identify the HTTP URL for the resource specified using Platform specific Sharepoint URI format and download content using it.
	 * @throws Exception
	 */
	private File downloadFromSharepoint(SharePointUri spContentUri, Authenticator authenticator, URI spSiteCollectionUri, String processId,
			HttpClient httpClient) throws Exception {
		SharePointItemInfo itemInfo = null;
		if (spContentUri.isFileReference) {
			itemInfo = getContentInfoByFileRef(spContentUri, authenticator, spSiteCollectionUri);
		} else {
			itemInfo = getContentInfoById(spContentUri, authenticator, spSiteCollectionUri);
		}

		/* If uri specifies item of a specific version, then resolve http url of that specific version of item */
		String contentUrl = itemInfo.getUrl();
		if (spContentUri.isPinned) {
			contentUrl = getItemVersionUrl(spContentUri.pinnedToVersion, authenticator, contentUrl,spSiteCollectionUri);
			contentUrl = contentUrl.replace(" ", "%20");
			logger.debug("Item version " + spContentUri.pinnedToVersion + " http url: " + contentUrl);
		}

		/*
		 * Download content from sharepoint to a temporary file.
		 */
		File tempFile = fileManager.getTemporaryFile(itemInfo.getExtension(), processId);
		logger.trace("Downloading item to temp file: " + tempFile);
		OutputStream os = null;
		os = new FileOutputStream(tempFile);
		int size = httpDownload(contentUrl, httpClient, os);
		logger.debug("Downloaded " + size + " bytes from sharepoint to " + tempFile);

		return tempFile;
	}

	/**
	 * Create HTTP url and name of item in Sharepoint from sharepoint URI where site path is used to specify item in the uri string.<br>
	 * Sample Uri : sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:web:a199ebeb-597c-455f-a738-8c1d38dd636a:file:/sites/PanFarm/Shared%20Documents/SearchTest.xml:fi:1<br>
	 * 	or sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:pvl:0.2:web:a199ebeb-597c-455f-a738-8c1d38dd636a:file:/sites/PanFarm/Shared%20Documents/SearchTest.xml:fi:1<br>
	 */
	private SharePointItemInfo getContentInfoByFileRef(SharePointUri spContentUri, Authenticator authenticator, URI spSiteCollectionUri) throws Exception {

		String serverName = spSiteCollectionUri.getHost();
		int serverPort = spSiteCollectionUri.getPort();

		if (serverPort == -1) {
			serverPort = 80;
		}

		String itemUrl = "http://" + serverName + ":" + serverPort + spContentUri.spFilePath;
		logger.debug("Item http URL: " + itemUrl);

		int index = itemUrl.lastIndexOf(".");
		String fileExtension = null;
		if (index > 0) {
			fileExtension = itemUrl.substring(index);
		}
		return new SharePointItemInfo(itemUrl, fileExtension);
	}

	/**
	 * Create HTTP url and name of item in Sharepoint from sharepoint URI where site ID and item ID are used to specify item in the uri string.<br>
	 * Handle Sharepoint URI of following types. Resolves the uri to corresponding Sharepoint HTTP Url. Sample URI :<br?>
	 * sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:web:a199ebeb-597c-455f-a738-8c1d38dd636a:list:4fce303e-037f-4094-8500-7307925fe948:item:3,1
	 * <br>or<br>
	 * sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:pvl:0.2:web:a199ebeb-597c-455f-a738-8c1d38dd636a:list:4fce303e-037f-4094-8500-7307925fe948:item:2,1<br>
	 */
	private SharePointItemInfo getContentInfoById(SharePointUri spContentUri, Authenticator authenticator, URI spSiteUri) throws Exception {

		String siteUrl = findSiteWithId(spContentUri.webId, spSiteUri.toString(), authenticator);
		if (siteUrl == null) {
			throw new Exception("INVALID_WEB_ID_IN ASSETURI" + spContentUri.toString());
		}
		logger.debug("Found URL of site with id " + spContentUri.webId + " as: " + siteUrl);

		String listName = getSPListName(siteUrl, authenticator, spContentUri.listId);

		String itemUrl = getSPListItemUrl(siteUrl, authenticator, listName, spContentUri.itemId);
		logger.debug("ItemUrl: " + itemUrl);

		String serverName = spSiteUri.getHost();
		int serverPort = spSiteUri.getPort();

		if (serverPort == -1) {
			serverPort = 80;
		}

		String completeItemUrl = "http://" + serverName + ":" + serverPort + "/" + itemUrl;

		logger.debug("Item http URL: " + completeItemUrl);

		int index = completeItemUrl.lastIndexOf(".");
		String fileExtension = null;
		if (index > 0) {
			fileExtension = completeItemUrl.substring(index);
		}
		SharePointItemInfo sharePointItemInfo = new SharePointItemInfo(completeItemUrl, fileExtension);
		return sharePointItemInfo;
	}

	/**
	 * Get an HTTP URL corresponding to content of a specific version of a sharepoint document.
	 *
	 * @param itemVersion String identifying the version of document.
	 * @param authenticator
	 * @param contentHttpUrl HTTP url of a sharepoint document
	 * @param spSiteCollectionUri
	 * @return an HTTP URL string corresponding to a specific version of sharepoint item
	 * @throws Exception
	 */
	private String getItemVersionUrl(String itemVersion, Authenticator authenticator, String contentHttpUrl, URI spSiteCollectionUri) throws Exception {
		final String spVersionServiceRelativePath = "_vti_bin/Versions.asmx";

		// Extract file path from contentHttpUrl by stripping the spSiteCollectionUri part from it.
		String siteUrl = contentHttpUrl.replace(" ", "%20");
		siteUrl=siteUrl.replace(":80/","/");
		String filePath = siteUrl.replace(spSiteCollectionUri.toString(), "");
		// Create Service URL from spSiteCollectionUri by appending the servicerelative path
		String serviceUrl = spSiteCollectionUri.toString() + spVersionServiceRelativePath;
		serviceUrl=serviceUrl.replace(" ","%20");
		logger.trace("Getting version details for item version: " + itemVersion + " ServiceUrl: " + serviceUrl);
		/*
		 * Make WebService call to get details of all versions of required sharepoint document
		 */
		VersionsStub versionStub = (VersionsStub) initStub(new VersionsStub(serviceUrl), authenticator);
		GetVersions getVersions = new GetVersions();
		getVersions.setFileName(filePath);
		GetVersionsResponse getVersionsResponse = versionStub.GetVersions(getVersions);
		OMElement versionDetails = getVersionsResponse.getOMElement(GetListResponse.MY_QNAME, OMAbstractFactory.getOMFactory());
		/*
		 * Parse WebService response as XML to identify the version
		 */
		Document doc = parseXMLResponse(versionDetails);
		/*
		 * Scan XML DOM to identify required version's http url.
		 */
		NodeList nodeList = doc.getElementsByTagName("result");
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element aResult = (Element) nodeList.item(i);
			if (aResult.getAttribute("version").equals(itemVersion) | aResult.getAttribute("version").equals("@" + itemVersion)) {
				return aResult.getAttribute("url");
			}
		}
		throw new Exception("ASSET_VERSION_NOT_FOUND_ON_SHAREPOINT " + itemVersion + " for " + contentHttpUrl);
	}

	/**
	 * Get Name of list in Sharepoint with given ID.<br>
	 * The internal name of list may be different than the name used for http URL to the list.
	 *
	 * @param siteUrl URL of sharepoint site.
	 * @param authenticator
	 * @param listId Id of list whose name is required.
	 * @return Displayable name of the list.
	 * @throws Exception
	 */
	private String getSPListName(String siteUrl, Authenticator authenticator, String listId) throws Exception {
		final String siteDataUrl = siteUrl.replace(" ", "%20") + "/_vti_bin/SiteData.asmx";
		logger.trace("Getting List name for listId: " + listId + " ServiceUrl: " + siteDataUrl);
		SiteDataStub siteData = (SiteDataStub) initStub(new SiteDataStub(siteDataUrl), authenticator);
		GetListCollection getListCollection = new GetListCollection();
		GetListCollectionResponse getLcResponse = siteData.GetListCollection(getListCollection);
		OMElement listDetails = getLcResponse.getOMElement(GetListResponse.MY_QNAME, OMAbstractFactory.getOMFactory());
		/*
		 * Parse WebService response as XML to identify the version
		 */
		Document doc = parseXMLResponse(listDetails);
		String listName = getSPListNameFromResponse(doc, listId);
		return listName;
	}

	/**
	 * Get relative HTTP URL of list item in sharepoint with given list name and item id
	 *
	 * @return Name of Sharepoint List Item
	 * @throws Exception
	 */
	private String getSPListItemUrl(String siteUrl, Authenticator authenticator, String listName, String itemId) throws Exception {

		final String listDataServiceUrl = siteUrl.replace(" ", "%20") + "/_vti_bin/Lists.asmx";
		logger.trace("Getting Item name for itemId: " + itemId + " ServiceUrl: " + listDataServiceUrl);
		/*
		 * Make WebService call to sharepoint to get List details. Include a Query and resulting View as part of request
		 */
		ListsStub listStub = (ListsStub) initStub(new ListsStub(listDataServiceUrl), authenticator);
		GetListItems getList = new GetListItems();
		getList.setListName(listName);

		Query_type0 qtp = new Query_type0();
		String queryString = "<Query><Where><Eq><FieldRef Name=\"ID\" /> <Value Type=\"NUMBER\">" + itemId + "</Value></EQ></Where></Query>";
		OMElement queryElement = AXIOMUtil.stringToOM(queryString);
		qtp.setExtraElement(queryElement);
		getList.setQuery(qtp);

		QueryOptions_type0 qOptions = new QueryOptions_type0();
		String viewAttributes = "<QueryOptions><ViewAttributes Scope='RecursiveAll'/></QueryOptions>";
		OMElement queryOptionElement = AXIOMUtil.stringToOM(viewAttributes);
		qOptions.setExtraElement(queryOptionElement);
		getList.setQueryOptions(qOptions);

		ViewFields_type0 vFields = new ViewFields_type0();
		String viewFileds = "<ViewFields><FieldRef Name='Title' /></ViewFields>";
		OMElement viewElement = AXIOMUtil.stringToOM(viewFileds);
		vFields.setExtraElement(viewElement);
		getList.setViewFields(vFields);

		GetListItemsResponse getListItemResponse = listStub.GetListItems(getList);
		OMElement listDetails = getListItemResponse.getOMElement(GetListItemsResponse.MY_QNAME, OMAbstractFactory.getOMFactory());

		/*
		 * Parse WebService response XML to find ListItem's Name
		 */
		Document doc = parseXMLResponse(listDetails);
		String itemUrl = getSPListItemUrlFromResponse(doc, itemId);
		return itemUrl;
	}

	/**
	 * Recursively search within Sharepoint site hierarchy for a site with specified ID.
	 *
	 * @param webId Sharepoint ID of site to find.
	 * @param spSiteUrl URL of base site within which to search.
	 * @param authenticator
	 * @return URL of base site which has specified id
	 */
	private String findSiteWithId(String webId, String spSiteUrl, Authenticator authenticator) {
		final String siteDataWebServiceRelativeUrl = "/_vti_bin/SiteData.asmx";
		logger.debug("Scanning for site with id " + webId + " in site: " + spSiteUrl);
		Document doc = null;
		try {
			/*
			 * Invoke SiteData webservice on base site to get its details.
			 */
			String siteDataWebServiceUrl = spSiteUrl.replace(" ", "%20") + siteDataWebServiceRelativeUrl;
			logger.trace("Getting site details for siteId: " + webId + " ServiceUrl: " + siteDataWebServiceUrl);
			SiteDataStub siteData = (SiteDataStub) initStub(new SiteDataStub(siteDataWebServiceUrl), authenticator);
			GetWeb getWeb = new GetWeb();
			GetWebResponse getWebResponse = siteData.GetWeb(getWeb);
			OMElement getWebResponseElement = getWebResponse.getOMElement(GetListResponse.MY_QNAME, OMAbstractFactory.getOMFactory());
			/*
			 * Parse webservice response as XML
			 */
			doc = parseXMLResponse(getWebResponseElement);

			/*
			 * If ID of the site referred by the spSiteUrl is same as the one to find, then return true
			 */
			if (webId.equalsIgnoreCase(getSPWebIdFromResponse(doc))) {
				return spSiteUrl; // getSPWebTitle(doc);
			}
		} catch (Exception e) {
			// eat exception to continue search for site with given ID. exceptions like "Unauthorized/Access Denied" are possible.
			if (logger.isDebugEnabled()) {
				logger.warn("Error searching for site with id " + webId + " in site " + spSiteUrl, e);
			} else {
				logger.error("Error searching for site with id " + webId + " in site " + spSiteUrl + " " + e.getMessage());
			}
			return null;
		}

		// ID of main site does not match so continue searching within children sites.

		if (doc != null) {
			NodeList nodeList = doc.getElementsByTagNameNS("*", "_sWebWithTime");
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				NodeList child = node.getChildNodes();
				for (int j = 0; j < child.getLength(); j++) {
					if (child.item(j).getLocalName().equalsIgnoreCase("Url")) {
						String url = child.item(j).getTextContent();
						String aSiteUrl = findSiteWithId(webId, url, authenticator);
						if (aSiteUrl != null) {
							return aSiteUrl;
						}
					}
				}
			}
		}

		// no matching site found even among children site hierarchy
		return null;

	}

	/*************** Sharepoint WebService Response Parsing ***************/

	/**
	 * Find webId from GetWebResponse XML
	 */
	private String getSPWebIdFromResponse(Document doc) throws Exception {
		String webId = null;
		try {
			webId = doc.getElementsByTagNameNS("*", "WebID").item(0).getTextContent();
		} catch (Exception e) {
			throw new Exception("INVALID_SHAREPOINT_WEB_ID", e);
		}
		return webId.replace("{", "").replace("}", "");
	}

	/**
	 * Find list name(title) from GetListCollectionResponse XML with given ID
	 */
	private String getSPListNameFromResponse(Document doc, String theListId) throws Exception {
		String listUrlName = null;
		int found = 0;

		NodeList nodeList = doc.getElementsByTagNameNS("*", "_sList");
		for (int i = 0; i < nodeList.getLength(); i++) {
			if (found == 1) {
				break;
			}
			Node aListElement = nodeList.item(i);
			String internalName = ((Element) aListElement).getElementsByTagNameNS("*", "InternalName").item(0).getTextContent();
			internalName = internalName.replace("{", "").replace("}", "");
			if (internalName.equalsIgnoreCase(theListId)) {
				// list found
				String defaultViewUrl = ((Element) aListElement).getElementsByTagNameNS("*", "DefaultViewUrl").item(0).getTextContent();
				listUrlName = defaultViewUrl.substring(0, defaultViewUrl.indexOf("/Form"));
				listUrlName = listUrlName.substring(listUrlName.lastIndexOf("/") + 1);

				String listTitle = ((Element) aListElement).getElementsByTagNameNS("*", "Title").item(0).getTextContent();
				return listTitle;
			}
		}

		throw new Exception("INVALID_SHAREPOINT_LIST " + theListId);
	}

	/**
	 * Find URL of a list item with given IDfrom GetListItemsResponse XML
	 */
	private String getSPListItemUrlFromResponse(Document doc, String itemId) throws Exception {
		String itemUrl = null;
		NodeList nodeList = doc.getElementsByTagNameNS("*", "row");
		if (nodeList.getLength() > 0) {
			Element element = (Element) nodeList.item(0);
			itemUrl = element.getAttribute("ows_FileRef");
		}
		if (itemUrl == null) {
			throw new Exception("INVALID_ITEM_ID_IN_SP_LIST " + itemId);
		}
		return itemUrl.substring(itemUrl.indexOf('#') + 1);
	}

	/************** AXIS Integration Methods ***************/

	private org.apache.axis2.client.Stub initStub(org.apache.axis2.client.Stub webServiceStub, Authenticator authenticator) {
		webServiceStub._getServiceClient().getOptions().setProperty(HTTPConstants.AUTHENTICATE, authenticator);
		webServiceStub._getServiceClient().disengageModule("qpsSOAPRemotingHandler");
		return webServiceStub;
	}

	private Document parseXMLResponse(OMElement omElementResponse) throws Exception {
		String responseXML = omElementResponse.toString();
		logger.trace("Sharepoint WS Response:" + responseXML);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		ByteArrayInputStream bis = new ByteArrayInputStream(responseXML.getBytes("UTF-8"));
		Document doc = db.parse(bis);
		return doc;
	}

	private Authenticator getAuthenticator(String username, String password, String host, int port, String scheme) throws PublishingException {

		int index = username.indexOf("\\");
		if (index < 0) {
			throw new PublishingException("Username (" + username + ") is not wellformed. It must be in 'domain\\loginName' format.");
		}
		String domain = username.substring(0, index);
		username = username.substring(index + 1);
		Authenticator auth = new Authenticator();
		List<String> authPref = new ArrayList<String>();
		if (scheme.equalsIgnoreCase("NTLM")) {
			authPref.add(AuthPolicy.NTLM);
			auth.setAuthSchemes(authPref);
			auth.setUsername(username);
			auth.setPassword(password);
			auth.setHost(host);
			// In case port is not defined in URL, it will return -1
			if (port != -1) {
				auth.setPort(port);
			}
			auth.setDomain(domain);
			auth.setAllowedRetry(true);
		}
		return auth;
	}

	/************** HTTP helper methods ***************/

	/**
	 * Downloads content from given http url using GET method and streams into given output stream.
	 *
	 * @throws Exception
	 */
	private int httpDownload(String url, HttpClient client, OutputStream os) throws Exception {

		try {
			url = url.replace("%20", " ");
			url = encodeUrl(url);
			GetMethod getMethod = new GetMethod(url);
			int statusCode = client.executeMethod(getMethod);
			if (statusCode == HttpStatus.SC_OK) {
				InputStream is = getMethod.getResponseBodyAsStream();
				return pipe(is, os);
			} else {
				throw new Exception("HTTP Error; URL=" + url + "; Status code=" + statusCode);
			}
		} finally {
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception ex) {
				logger.warn("Error closing stream:", ex);
			}
		}
	}

	private String encodeUrl(String url) throws Exception {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < url.length(); i++) {
			char ch = url.charAt(i);
			if (ch == ' ') {
				sb.append("%20");
			} else if (ch == ':' || ch == '/') {
				sb.append(ch);
			} else {
				sb.append(URLEncoder.encode(ch + "", "UTF-8"));
			}
		}
		return sb.toString();
	}

	private int pipe(InputStream is, OutputStream os) throws IOException {
		try {
			byte[] buffer = new byte[64 * 1024];
			int count = is.read(buffer);
			int totalCount = count;
			while (count > 0) {
				os.write(buffer, 0, count);
				count = is.read(buffer);
				totalCount += count;
			}
			os.flush();
			return totalCount;
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (Exception ex) {
				logger.warn("Error closing stream:", ex);
			}
		}
	}

	@Override
	public String getResourceIdentity(URI inputContentUri) {
		if (inputContentUri != null) {
			String spContentUriStr = inputContentUri.toString();
			int lastCommaIndex = spContentUriStr.lastIndexOf(",");
			if (lastCommaIndex > 0) {
				return spContentUriStr.substring(0, lastCommaIndex);
			}
			return spContentUriStr;
		}
		return null;
	}
}

/**
 * {@link SharePointUri} generator factory. Parses string form of platform specific sharepoint URI to create a {@link SharePointUri} object.
 */
class SpUriFactory {

	private static final Pattern p = Pattern
			.compile("sp:([\\w-%]*)(:pvl:([\\d.]*))?(:site:[\\w-]*)?:web:([\\w-]*):((file:([\\w-%.\\\\/]*).*)|(list:([\\w-%.\\\\/]*):item:([\\d]*))).*");
	private static Logger logger = Logger.getLogger(SpUriFactory.class);

	/**
	 * Create SharePointUri from platform specific sharepoint URI string. The platform specific sharepoint URI string may be of following formats<br>
	 * Path Based : sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:web:a199ebeb-597c-455f-a738-8c1d38dd636a:file:/sites/PanFarm/Shared%20Documents/SearchTest.xml:fi:1"<br>
	 * Site Id based :
	 * sp:740c6a0b-85e2-48a0-a494-e0f1759d4aa7:pvl:0.2:site:b18c258b-4741-4f49-8df1-143fb2b2c32e:web:a199ebeb-597c-455f-a738-8c1d38dd636a:list:4fce303e-037f-4094-8500-7307925fe948:item:2,1<br>
	 * The (pvl:x.y) part is optional and specifies that the uri refers to specific pinned version.
	 * The site:(...) part is optional and currently neglected
	 *
	 * @throws Exception If input uri is invalid or cannot be parsed.
	 */
	static SharePointUri createSpUri(String uriString) throws Exception {
		Matcher m = p.matcher(uriString);
		if (m.matches()) {

			if (logger.isDebugEnabled()) {
				int groupCount = m.groupCount();
				StringBuilder sb = new StringBuilder();
				sb.append("Parsed regex groups in uri string (delimiter=*): ");
				for (int i = 1; i <= groupCount; i++) {
					sb.append(m.group(i));
					sb.append("*");
				}
				logger.debug(sb.toString());
			}

			SharePointUri spUri = new SharePointUri(m.group(3), m.group(5), m.group(8), m.group(10), m.group(11));
			spUri.setPlatformSpecificUri(uriString);
			return spUri;

		} else {
			throw new Exception("Invalid Sharepoint URI " + uriString);
		}
	}
}

/**
 * Class to abstract various parts of the Platform specific sharepoint URI
 */
class SharePointUri {
	boolean isPinned;
	String pinnedToVersion;
	String webId;
	boolean isFileReference;
	String spFilePath;
	String listId;
	String itemId;
	String platformSpecificUri;

	public SharePointUri(String pinnedToVersion, String webId, String fileId, String listId, String itemId) {

		if (pinnedToVersion != null) {
			this.isPinned = true;
			this.pinnedToVersion = pinnedToVersion;
		}
		this.webId = webId;

		if (fileId != null) {
			this.spFilePath = fileId;
			this.isFileReference = true;
		} else {
			this.listId = listId;
			this.itemId = itemId;
		}
	}

	public void setPlatformSpecificUri(String platformSpecificUri) {
		this.platformSpecificUri = platformSpecificUri;
	}

	public String toString() {
		return this.platformSpecificUri;
	}

}

/**
 * Name and URL of a Sharepoint ListItem
 */
class SharePointItemInfo {
	private String url;
	private String extension;

	public String getUrl() {
		return url;
	}

	public String getExtension() {
		return extension;
	}

	public SharePointItemInfo(String url, String extension) {
		super();
		this.url = url;
		this.extension = extension;
	}
}
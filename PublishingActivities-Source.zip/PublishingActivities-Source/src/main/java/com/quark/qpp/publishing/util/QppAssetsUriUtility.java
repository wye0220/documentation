/*****************************************************************************
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 ****************************************************************************/
package com.quark.qpp.publishing.util;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.AssetServiceExceptionCodes.AssetNotFoundExceptionCodes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetVersionList;

public class QppAssetsUriUtility {

	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private URIHandlerRegistry uriHandlerRegistry;
		
	/**
	 * Parses the given qpp URI and returns object of AssetIdentityInfo containing all  information contained in URI  
	 * @param assetUri
	 * @return
	 * @throws Exception
	 */
	public AssetIdentityInfo parseQppUri(URI assetUri) throws Exception{
		AssetIdentityInfo assetIdentityInfo = new AssetIdentityInfo();
		String authority = assetUri.getAuthority();
		String path = assetUri.getPath();
		String query = assetUri.getQuery();
		assetIdentityInfo.setFragment(assetUri.getFragment());
		// If it is not the conventional asset URI used in the platform, resolving it based on XA format and create supported asset URI.
		// Once the XA stop using this URI, the following if block can simple be removed.
		if (authority == null || (!authority.equalsIgnoreCase("assets") && !authority.equalsIgnoreCase("office") && !authority.equalsIgnoreCase("assetsbypath")) && !authority.equalsIgnoreCase("charts") && !authority.equalsIgnoreCase("chartsbypath")) {
			URI framedUri = getAssetURIFromXASpecificURI(assetUri.getSchemeSpecificPart());
			authority = framedUri.getAuthority();
			path = framedUri.getPath();
			query = framedUri.getQuery();
		}
		
		if(authority.equalsIgnoreCase("office")){
			String assetIDorPathString = path.replace("/excel/", "");
			assetIDorPathString = assetIDorPathString.replace("/excelbypath/", "");
			assetIDorPathString = assetIDorPathString.replace("/visio/", "");
			assetIDorPathString = assetIDorPathString.replace("/visiobypath/", "");
			assetIDorPathString = assetIDorPathString.replace("/powerpoint/", "");
			assetIDorPathString = assetIDorPathString.replace("/powerpointbypath/", "");
			assetIDorPathString = assetIDorPathString.replace("/excelchart/", "");
			assetIDorPathString = assetIDorPathString.replace("/excelchartbypath/", "");
			assetIDorPathString = assetIDorPathString.replace("/exceltable/", "");
			assetIDorPathString = assetIDorPathString.replace("/exceltablebypath/", "");
			try{
				long assetId = facadeUtility.getAssetId(assetIDorPathString);
				assetIdentityInfo.setAssetID(assetId);
			}catch(AssetNotFoundException e){
				//Return null if the given asset not found or assetid is not supplied				
			}
		}
		else if (authority != null && authority.equalsIgnoreCase("charts") || authority.equalsIgnoreCase("chartsbypath")) {
			String assetIDorPathString = path.replaceFirst("/", "");			
			try{
				long assetId = facadeUtility.getAssetId(assetIDorPathString);
				assetIdentityInfo.setAssetID(assetId);
			}catch(AssetNotFoundException e){
				//Return null if the given asset not found or assetid is not supplied				
			}			
		}
		else if (authority != null && (authority.equalsIgnoreCase("assets") || authority.equalsIgnoreCase("assetsbypath"))) {
			String assetIDorPathString = path.substring(1);
			long assetId = facadeUtility.getAssetId(assetIDorPathString);
			assetIdentityInfo.setAssetID(assetId);
		}
		else {
			throw new Exception("Unable to fetch asset information from URI:  " + assetUri);
		}
		
		long majorVersion = -1;
		long minorVersion = -1;
		if(query != null) {
			// In scenarios like ../../..?majorversion=1&minorversion=4 OR ../..?majorversion=2
			String[] parts = query.split("&");
			for (int i = 0; i < parts.length; i++) {
				String[] subparts = parts[i].split("=");
				if (subparts[0].equalsIgnoreCase("majorversion")) {
					majorVersion = Long.parseLong(subparts[1]);
				}
				else if (subparts[0].equalsIgnoreCase("minorversion")) {
					minorVersion = Long.parseLong(subparts[1]);
				}
				else if (subparts[0].equalsIgnoreCase("rendition")) {
					assetIdentityInfo.setRendition(subparts[1]);
				}
				else if (subparts[0].equalsIgnoreCase("layout")) {
					assetIdentityInfo.setLayoutNumber(Integer.parseInt(subparts[1]));
				}
				else if (subparts[0].equalsIgnoreCase("page")) {
					assetIdentityInfo.setPageNumber(Integer.parseInt(subparts[1]));
				}
			}
			if (majorVersion >= 0 || minorVersion >= 0) {
				assetIdentityInfo.setAssetVersion(new com.quark.qpp.core.asset.service.dto.AssetVersion(majorVersion, minorVersion));
			}
		}
		
		//Populate office and chart specific parameter
		populateOtherDataInfo(assetIdentityInfo, assetUri);
		
		return assetIdentityInfo;
	}
	
	/**
	 * Parses the given URI, evaluates other data pertaining to the URI (like version number, resolves the uri if any)and populate all data
	 * to the AssetIdentityInfo object.
	 * 
	 */
	public AssetIdentityInfo parseAndEvaluateQppUri(URI assetUri, String processId) throws Exception {
			
			//Step 1. Parse the given URI and set the information in AssetIdentityInfo object
			AssetIdentityInfo assetIdentityInfo = parseQppUri(assetUri);
			long majorVersion = -1; 
			long minorVersion = -1;
			if (assetIdentityInfo.getAssetVersion() != null) {
				majorVersion = assetIdentityInfo.getAssetVersion().getMajorVersion();
				minorVersion = assetIdentityInfo.getAssetVersion().getMinorVersion();
			}
			
			/*
			 * Step 2. Fetch the assetVersion from assetUri. Scenarios : 
			 * i. In case the query string is null, fetch the latest asset version.
			 * ii. In case major & minor version both are mentioned in query string, consider them. 
			 * iii. In case only the majorversion is mentioned, fetch for the latest minor version corresponding to the given major version.Eg..../../..?majorversion=2. 
			 * iv. In case only minor version is mentioned, it will not be honoured, instead the latest asset version will be considered.
			 */
			if (majorVersion >= 0) {
				if (minorVersion == -1) {
					minorVersion = getLatestMinorVersion(assetIdentityInfo.getAssetID(), majorVersion);
				}
				AssetVersion assetVersion = new AssetVersion();
				assetVersion.setMajorVersion(majorVersion);
				assetVersion.setMinorVersion(minorVersion);
				assetIdentityInfo.setAssetVersion(assetVersion);
			}
			
			/*
			 * Step 3. In case the query string is null or the query string is not null but major version is not mentioned.
			 */
			if(majorVersion == -1 && assetIdentityInfo.getAssetID() >0){
				// fetch latest asset version
				AssetInfo assetInfo = assetFacade.getAsset(assetIdentityInfo.getAssetID(), null, null, new String[] { DefaultAttributes.MAJOR_VERSION + "",
						DefaultAttributes.MINOR_VERSION + "" }, false, false, null, null, null, null, null, false);
				assetIdentityInfo.setAssetVersion(new AssetVersion(assetInfo.getAssetVersion().getMajorVersion(), assetInfo.getAssetVersion().getMinorVersion()));
			}
			
			
			//AssetInfo may be null in case the asset is not a Platform Asset and can be sourced from some valid URI. For example qpp://office/excel?uri=file://c:/temp/abc.xlsx&namedrange=....
			if (assetIdentityInfo != null) {
				assetIdentityInfo.setAssetID(assetIdentityInfo.getAssetID());
				if(assetIdentityInfo.getAssetVersion() != null) {
					assetIdentityInfo.setAssetVersion(new com.quark.qpp.core.asset.service.dto.AssetVersion(assetIdentityInfo.getAssetVersion().getMajorVersion(), assetIdentityInfo.getAssetVersion().getMinorVersion()));
				}
			}
			
			String namingScheme = getNamingScheme(assetUri.getFragment());
			assetIdentityInfo.setNamingScheme(namingScheme);

			//In case of parameter uri, resolve teh parameter, save the resource to temp local and convert the  uri to that local file uri.
			resolveAndPopulateSourceDataUri(assetIdentityInfo, assetUri, processId);
			
			return assetIdentityInfo; 
	}
	
	private String getNamingScheme(String fragment) {
		if (fragment != null) {
			String[] parts = fragment.split("=");
			String paramName = parts[0];
			if (paramName.equalsIgnoreCase("namingScheme")) {
				return parts[1];
			}
		}
		return null;
	}
	
	
	/**
	 * In case of parameter uri, resolve teh parameter, save the resource to temp local and convert the uri to that local file uri.
	 * 
	 * @param assetIdentityInfo
	 * @param assetUri
	 * @param processId
	 * @throws Exception
	 */
	private void resolveAndPopulateSourceDataUri(AssetIdentityInfo assetIdentityInfo, URI assetUri, String processId) throws Exception {
		String query = assetUri.getQuery();

		if (query != null) {
			String[] parts = query.split("&");
			for (int i = 0; i < parts.length; i++) {
				String[] subparts = parts[i].split("=", 2);
				if(subparts.length==2){
					String paramValue = URLDecoder.decode(subparts[1], "UTF-8");
					if (subparts[0].equalsIgnoreCase("uri")) {
						// Resolve the given URI here before using this as source URI of excel file.
						// This is done to solve the use case of live preview where XA sends the zip file containing XML and required excel
						// files. The XML refers to Excel object by URI qpp://office/excel?uri=file:ABC.xlsx&namedrange=MyRange..
						// In this case, uri that we get here is that of source excel file which is file:ABC.xlsx. This is resolved by
						// FileURIResolver which looks the given file the temp process folder as it has no absolute path. If we supply the
						// same URI (file:ABC.xlsx) to OfficeFacade, the process id changes and while resolving this uri the file is not found.
						URI aUri = null;
						String[] uriStrParts = paramValue.split(":", 2);
						if (uriStrParts.length > 1) {
							aUri = new URI(uriStrParts[0], uriStrParts[1], "namingScheme=dita" );
						}
						else{
							aUri = new URI(uriStrParts[0]);
						}
						File resolvedFile = uriHandlerRegistry.resolveToFile(processId, aUri);
						assetIdentityInfo.setUri("file://" + resolvedFile.getAbsolutePath());						
					}
				}
			}
		}		
	}
	
	/**
	 * Populate office and chart specific parameter
	 * @param assetIdentityInfo
	 * @param assetUri
	 * @throws Exception
	 */
	private void populateOtherDataInfo(AssetIdentityInfo assetIdentityInfo, URI assetUri) throws Exception {
		String authority = assetUri.getAuthority();
		String query = assetUri.getQuery();

		if (query != null) {
			if (authority.equalsIgnoreCase("office") && assetUri.getPath().startsWith("/excelchart")) {
				assetIdentityInfo.setExcelChart(true);
			}
			if (authority.equalsIgnoreCase("office") && assetUri.getPath().startsWith("/exceltable")) {
				assetIdentityInfo.setExcelTable(true);
			}
			if (authority.equalsIgnoreCase("office") && assetUri.getPath().startsWith("/excel")) {
				assetIdentityInfo.setExcel(true);
			}
			if (authority.equalsIgnoreCase("office") && assetUri.getPath().startsWith("/visio")) {
				assetIdentityInfo.setVisio(true);
			}
			if (authority.equalsIgnoreCase("office") && assetUri.getPath().startsWith("/powerpoint")) {
				assetIdentityInfo.setPpt(true);
			}
			else if (authority.equalsIgnoreCase("charts") || authority.equalsIgnoreCase("chartsbypath")) {
				assetIdentityInfo.setDynamicChart(true);
			}
			
			String[] parts = query.split("&");
			for (int i = 0; i < parts.length; i++) {
				String[] subparts = parts[i].split("=", 2);
				if(subparts.length==2){
					String paramValue = URLDecoder.decode(subparts[1], "UTF-8");
					if (subparts[0].equalsIgnoreCase("worksheet")) {
						assetIdentityInfo.setWorksheet(paramValue);
					} else if (subparts[0].equalsIgnoreCase("chart")) {
						assetIdentityInfo.setChart(paramValue);
					} else if (subparts[0].equalsIgnoreCase("table")) {
						assetIdentityInfo.setTable(paramValue);
					} else if (subparts[0].equalsIgnoreCase("namedrange")) {
						assetIdentityInfo.setNamedRange(paramValue);
					} else if (subparts[0].equalsIgnoreCase("dynamicrange")) {
						assetIdentityInfo.setDynamicRange(paramValue);
					} else if (subparts[0].equalsIgnoreCase("outputformat")) {
						assetIdentityInfo.setOutputFormat(paramValue);
					} else if (subparts[0].equalsIgnoreCase("objectType")) {
						assetIdentityInfo.setObjectType(paramValue);
					} else if (subparts[0].equalsIgnoreCase("sourcedatatype")) {
						assetIdentityInfo.setSourceDataType(paramValue);
					} else if (subparts[0].equalsIgnoreCase("templateuri")) {
						assetIdentityInfo.setTemplateUri(paramValue);
					} else if (subparts[0].equalsIgnoreCase("pagename")) {
						assetIdentityInfo.setVisioPageName(paramValue);
					} else if (subparts[0].equalsIgnoreCase("slideid")) {
						assetIdentityInfo.setPptSlideId(Long.parseLong(paramValue));
					} 
					else if (subparts[0].equalsIgnoreCase("uri")) {
						//Simply populate the value of parameter uri  
						assetIdentityInfo.setUri(paramValue);
					} 
					else {
						String key = subparts[0];
						String value = paramValue;
						HashMap<String, String> propertiesMap = assetIdentityInfo.getOutputFormatProperties();
						if (key.trim().length() > 0 && value.trim().length() > 0) {
							propertiesMap.put(key, value);
							assetIdentityInfo.setOutputFormatProperties(propertiesMap);
						}
					}
				}
			}
		
		}		
	}
	
	private long getLatestMinorVersion(long assetId, long majorVersion) throws QppServiceException {
		AssetVersionList assetVersions = assetFacade.getAssetVersionNumbers(assetId);
		for (int i = assetVersions.getAssetVersion().size() - 1; i >= 0; i--) {
			com.quark.qpp.service.xmlBinding.AssetVersion assetVersion = assetVersions.getAssetVersion().get(i);
			if (assetVersion.getMajorVersion() == majorVersion) {
				return assetVersion.getMinorVersion();
			}
		}
		throw new AssetNotFoundException(AssetNotFoundExceptionCodes.ASSET_VERSION_NOT_FOUND, new String[] { assetId + "", "Major version "+majorVersion+" not found." } );
	}
	
	private URI getAssetURIFromXASpecificURI(String assetIdVersionString) throws URISyntaxException {
		// href="qpp://localhost/QPS Home/30/1.0/0094.JPG"/>
		String[] parts = assetIdVersionString.split("/");
		String assetId = parts[parts.length - 3];
		String assetVersion = parts[parts.length - 2];

		int indx = assetVersion.indexOf(".");
		String assetMajorVersion = assetVersion.substring(0, indx);
		String assetMinorVersion = assetVersion.substring(indx + 1);
		AssetInfo assetInfo = new AssetInfo();
		if (assetMajorVersion.equals("@") && assetMinorVersion.equals("@")) {
			return new URI("qpp", "//assets/" + assetId, null);
		} else {
			assetInfo.setId(Long.parseLong(assetId));
			com.quark.qpp.service.xmlBinding.AssetVersion version = new com.quark.qpp.service.xmlBinding.AssetVersion();
			version.setMajorVersion(Long.parseLong(assetMajorVersion));
			version.setMinorVersion(Long.parseLong(assetMinorVersion));
			assetInfo.setAssetVersion(version);

			return new URI("qpp", "//assets/" + assetId + "?majorversion=" + assetMajorVersion + "&minorversion=" + assetMinorVersion, null);
		}
		
	}
}

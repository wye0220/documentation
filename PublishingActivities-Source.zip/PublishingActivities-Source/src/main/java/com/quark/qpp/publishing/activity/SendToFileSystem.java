/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;

/**
 * Copies all input contents with name specified by {@link #inContentName} in a directory specified in the property targetLocation. 
 * 
 * <p>
 * Prerequisites :
 * <li>targetLocation : target directory where the input content is to be copied.</li>
 * </p>
 * <br>
 * <p>
 * This activity expects input content(s) with name specified by {@link #inContentName}.The file or folder associated with each input content info will
 * be copied at the {@link #targetLocation}
 * </p>
 */
public class SendToFileSystem extends AbstractActivity {

	private String activityName;
	
	private String inContentName;

	private String targetLocation;
	
	private String outContentFileName;
	
	private String overWriteExisting = "false";
	
	public void setOverWriteExisting(String overWriteExisting) {
		this.overWriteExisting = overWriteExisting;
	}
	
	public void setInContentName(String inContentName) {
		this.inContentName = inContentName;
	}

	public void setTargetLocation(String targetLocation) {
		this.targetLocation = targetLocation;
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] inData = publishingContext.getInputContentInfos(inContentName);
		if (inData == null || inData.length < 0) {
			return;
		}
		
		for (ContentInfo inputInfo : inData) {
			File content = inputInfo.getFile();
			
			String targetLocationResolved = resolveParameter(targetLocation, publishingContext);
			targetLocationResolved = targetLocationResolved.replaceAll("\\\\", "/");
			File targetFile = new File(targetLocationResolved);
			String deliveryContentName = resolveDeliveryContentName(outContentFileName, publishingContext, inputInfo);
			
			if (content.isDirectory()) {
				validateAndHandleOverwrite(new File (targetLocationResolved+"/"+content.getName()), publishingContext);
				FileUtils.copyDirectory(content, new File(targetLocationResolved+"/"+deliveryContentName));
			} else {
				String targetFilePath = targetLocationResolved;
				if (!targetFile.exists()) {
					targetFile.mkdirs();
				}
				if (targetFile.isDirectory()) {
					
				
					targetFilePath = targetLocationResolved + "/" + deliveryContentName;						
					 
				} 
				validateAndHandleOverwrite(new File(targetFilePath), publishingContext);
				FileUtils.copyFile(content, new File(targetFilePath));
				
			}
		}
	}

	private void validateAndHandleOverwrite(File file, PublishingContext publishingContext) throws IOException, PublishingException {
		boolean overwriteResolved = Boolean.parseBoolean(resolveParameter(overWriteExisting, publishingContext));
		if (file.exists()) {
			if (overwriteResolved) {
				if (file.isDirectory()) {
					FileUtils.deleteDirectory(file);
				} else {
					file.delete();
				}
			} else {
				throw new PublishingException("Cannot overwrite existing file: " + file.getAbsolutePath());
			}
		}
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
	}

	@Override
	public void clean(String processId) {
		
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setOutContentFileName(String outContentFileName) {
		this.outContentFileName = outContentFileName;
	}
	

}

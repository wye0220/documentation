/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1990-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.publishing.activity;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * 
 * In case the render format is App Studio and the file has to be downloaded,
 * then this activity creates an issue.json file and appends this file to the
 * source asset. Else the input asset is returned unmodified.
 * 
 * <p>
 * Name with which this activity expects input content is specified by
 * {@link #SOURCE_ASSET}. The input content should have App Studio Article zip
 * file associated.
 * </p>
 * 
 * <p>
 * Name with which this activity emits content is specified by
 * {@link #OUTPUT_ASSET}. The output content will have zip file associated with
 * it. This zip will contain issue.json appended to the input file.
 * </p>
 * 
 */
public class AppStudioArticleToIssueConverter extends AbstractActivity {

	private String activityName;

	/*
	 * name with which this activity expects content
	 */
	private static final String SOURCE_ASSET = "AppStudioArticle";

	private String issueId;
	
	private String title;
	
	private String subTitle;
	
	private String publishedDate;
	
	private String direction;

	/*
	 * name with which this activity emits content
	 */
	private static final String OUTPUT_ASSET = "AppStudioIssuePackage";
	
	private static final Logger logger = Logger.getLogger(AppStudioArticleToIssueConverter.class);

	@Autowired
	private TempFileManager tempFileManager;

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public void setPublishedDate(String publishedDate) {
		this.publishedDate = publishedDate;
	}
	
	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}
	
	public void setIssueId(String issueId) {
		this.issueId = issueId;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		String processId = publishingContext.getProcessId();
		ContentInfo[] contentInfos = publishingContext.getInputContentInfos(SOURCE_ASSET);
		if (contentInfos == null || contentInfos.length > 1) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Input content with name '" + SOURCE_ASSET + "' not found." });
		}
		ContentInfo contentInfo = contentInfos[0];

		File sourceFile = contentInfo.getFile();
		ZipFile articleZipFile = new ZipFile(sourceFile);
		File packageFile = null;
		try {

			String uniqueId = UUID.randomUUID().toString();
			String destArticleDirName = "template_AppStudioHTML_" + uniqueId;

			File issueJsonFile = createIssueJsonFile(articleZipFile, processId, destArticleDirName, publishingContext);

			packageFile = createASPackage(articleZipFile, issueJsonFile, destArticleDirName, publishingContext);

		} finally {
			if (articleZipFile != null)
				articleZipFile.close();
		}

		ContentInfo outputContentInfo = publishingContext.registerOutputContentInfo(OUTPUT_ASSET,
				convertInputToURI("file:" + packageFile.getAbsolutePath()), packageFile);
		outputContentInfo.setFileExtension("aps");
		outputContentInfo.setMimeType("application/aps");
		outputContentInfo.setResourceName(packageFile.getName());

	}

	/*
	 * Copies the contents of zipFile to new zipOutputStream in specified
	 * destinationDirName.
	 */
	private File createASPackage(ZipFile articleZipFile, File jsonFile, String destinationDirName, PublishingContext publishingContext)
			throws Exception {

		File issueZipFile = tempFileManager.getTemporaryFile(".zip", publishingContext.getProcessId());
		ZipOutputStream packageZipOutputStream = null;
		try {
			packageZipOutputStream = new ZipOutputStream(new FileOutputStream(issueZipFile));
			try {
				// Add ZIP entry to output stream.
				packageZipOutputStream.putNextEntry(new ZipEntry("issue.json"));
				FileInputStream jsonInputStream = new FileInputStream(jsonFile.getAbsoluteFile());
				pipe(jsonInputStream, packageZipOutputStream);
			} finally {
				packageZipOutputStream.closeEntry();
			}

			Enumeration zipFileEntries = articleZipFile.entries();
			
			ArrayList<ZipEntry> zipFileEntriesList = Collections.list(zipFileEntries);
			  
			ArrayList<String> toBeRemovedFilesList = getFilesToBeRemoved(zipFileEntriesList);
			
			for (ZipEntry zipEntry : zipFileEntriesList) {
			
				try {
					
					InputStream in = articleZipFile.getInputStream(zipEntry);

					// Add ZIP entry to output stream.
					String entryName = zipEntry.getName();
					if (toBeRemovedFilesList.contains(entryName)) {
						continue;
					}
					if(entryName.contains("@2x.")){
						entryName = entryName.replace("@2x.", ".");
					}
					if (zipEntry.isDirectory()) {
						continue;
					} else {
						entryName = entryName.replace('\\', '/');
					}
					ZipEntry newEntry = new ZipEntry(destinationDirName + "/" + entryName);
					packageZipOutputStream.putNextEntry(newEntry);
					pipe(in, packageZipOutputStream);
				} finally {
					if (packageZipOutputStream != null)
						packageZipOutputStream.closeEntry();
				}
			}
		} finally {
			if (packageZipOutputStream != null) {
				packageZipOutputStream.close();
			}
		}
		return issueZipFile;
	}

	private ArrayList<String> getFilesToBeRemoved(ArrayList<ZipEntry> zipFileEntriesList) {
		ArrayList<String> allFiles = new ArrayList<String>();
		for (ZipEntry zipEntry : zipFileEntriesList) {
			
			String entryName = zipEntry.getName();
			allFiles.add(entryName);
		}
 		
 		ArrayList<String> tobeRemoved = new ArrayList<String>();
 		for (ZipEntry zipEntry : zipFileEntriesList) {
			String entryName = zipEntry.getName();
			
			if(entryName.contains("@2x.")){
				entryName = entryName.replace("@2x.", ".");
				if(allFiles.contains(entryName)){
					tobeRemoved.add(entryName);
				}
			}			
		}
 		return tobeRemoved;
	}

	/*
	 * Creates issue json file from given App Studio Zip.
	 */
	private File createIssueJsonFile(ZipFile zipFile, String processId, String destArticleDirName, PublishingContext publishingContext) throws JsonProcessingException, IOException {
		InputStream issueTemplateStream = getClass().getClassLoader().getResourceAsStream("IssueTemplate.json");
		try {
			// initialize the JsonFactory
			JsonFactory factory = new JsonFactory();
			ObjectMapper objectMapper = new ObjectMapper(factory);
			JsonNode treeNode = objectMapper.readTree(issueTemplateStream);

			// fetch orientation node from JSON file
			ArrayNode variantsNode = (ArrayNode) treeNode.path("variants");
			Iterator<JsonNode> variantsIterator = variantsNode.elements();
			int arrayIndex = 0;
			ArrayList<Integer> removalList = new ArrayList<Integer>();
			while (variantsIterator.hasNext()) {
				JsonNode orientationNode = variantsIterator.next();
				ObjectNode orientationObjectNode = (ObjectNode) orientationNode;
				
				String orientation = orientationNode.path("orientation").asText();

				// fetch thumbnail images for given orientation from the zip
				// file
				String[] thumbnailImages = getThumbnailImagesForOrientation(zipFile, orientation);
				if (thumbnailImages == null || thumbnailImages.length == 0) {
					removalList.add(arrayIndex);
				} else {
					ArrayNode pagesArrayNode = objectMapper.createArrayNode();
					int counter = 0;
					for (String thumbnailImage : thumbnailImages) {
						ObjectNode pageNode = objectMapper.createObjectNode();

						// create id node
						pageNode.put("id", UUID.randomUUID().toString());

						// create thumb nail node
						pageNode.put("thumbnail", destArticleDirName + "/" + thumbnailImage);

						// create contents node
						ArrayNode contentsNode = objectMapper.createArrayNode();
						ObjectNode contentsChildNode = objectMapper.createObjectNode();
						contentsChildNode.put("pageRef", ++counter);
						contentsChildNode.put("href", "#template");
						contentsNode.add(contentsChildNode);
						pageNode.put("contents", contentsNode);

						// create properties node
						ObjectNode propertiesNode = objectMapper.createObjectNode();
						propertiesNode.put("height", "");
						pageNode.put("properties", propertiesNode);
						pageNode.put("url", destArticleDirName + "/" + orientation + counter + ".html");

						pagesArrayNode.add(pageNode);
					}

					orientationObjectNode.put("pages", pagesArrayNode);
				}
				arrayIndex++;
			}
			
			for (Integer index : removalList) {
				//Remove orientation object if it has no pages  
				variantsNode.remove(index);
			}

			ObjectNode treeObjectNode = (ObjectNode) treeNode;
			String issueIdResolved = resolveParameter(issueId, publishingContext);
			issueIdResolved = issueIdResolved.replaceAll("\\$GUID", UUID.randomUUID().toString());
			// create id node
			treeObjectNode.put("id", issueIdResolved);
			
			treeObjectNode.put("title", resolveParameter(title, publishingContext));
			treeObjectNode.put("subtitle", resolveParameter(subTitle, publishingContext));
			treeObjectNode.put("direction", resolveParameter(direction, publishingContext));
			
			String pubDateResolved = resolveParameter(publishedDate, publishingContext);
			if (pubDateResolved != null && !pubDateResolved.isEmpty()) {
				treeObjectNode.put("publishedDate", pubDateResolved);
			} else {
				treeObjectNode.put("publishedDate", getCurrentGMTDateTime());
			}
			
			String issueJson = objectMapper.writeValueAsString(treeNode);
			File issueJsonFile = tempFileManager.getTemporaryFile(".json", processId);
			FileOutputStream fileOutputStream = null;
			try {
				fileOutputStream = new FileOutputStream(issueJsonFile);
				fileOutputStream.write(issueJson.getBytes("UTF-8"));
			} finally {
				if (fileOutputStream != null)
					fileOutputStream.close();
			}
			return issueJsonFile;
		} finally {
			if (issueTemplateStream != null) {
				try {
					issueTemplateStream.close();
				} catch (IOException e) {
					logger.error("Error", e);
				}
			}
		}
	}

	/**
	 * Returns current GMT
	 * 
	 * @return
	 */
	private String getCurrentGMTDateTime() {
		long milliSeconds = System.currentTimeMillis();
		String GMT_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(GMT_DATE_TIME_FORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		String strDate = sdf.format(new Date(milliSeconds));
		return strDate + "Z";
	}

	/*
	 * Fetch thumbnail images from zipFile for given orientation.
	 * 
	 * @param zipFile
	 * 
	 * @param orientation
	 * 
	 * @return
	 */
	private String[] getThumbnailImagesForOrientation(ZipFile zipFile, String orientation) {
		Enumeration<? extends ZipEntry> zipFileEntries = zipFile.entries();
		
		ArrayList<String> thumbnailImages = new ArrayList<String>();
		while (zipFileEntries.hasMoreElements()) {
			ZipEntry zipEntry = zipFileEntries.nextElement();
			String zipEntryName = zipEntry.getName();
			if (zipEntry.getName().contains(orientation) && zipEntry.getName().contains("thumbnail")) {
				thumbnailImages.add(zipEntryName);
			}
		}
		
		ArrayList<ThumbnailFileName> thumbnailNamesList = new ArrayList<ThumbnailFileName>();
		for(String s : thumbnailImages)
		        thumbnailNamesList.add(new ThumbnailFileName(s));
		
		 Collections.sort(thumbnailNamesList);
		  
		ArrayList<String> thumbnailImagesSorted = new ArrayList<String>();
		for (ThumbnailFileName thmbnailFileName : thumbnailNamesList) {
			thumbnailImagesSorted.add(thmbnailFileName.repr);
		}
		
		return thumbnailImagesSorted.toArray(new String[0]);
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	
	class ThumbnailFileName implements Comparable<ThumbnailFileName>
	{
	    int valN;
	    String valS;
	    String repr;

	    public String toString() {
	    return repr;
	    }

	    public ThumbnailFileName(String s) {
	    int l = 0;
	    char data[] = new char[s.length()];
	    repr = s;
	    valN = 0;
	    for (char c : s.toCharArray()) {
	        if(Character.isDigit(c))
	        valN = valN * 10 + (c - '0');
	        else
	        data[l++] = c;
	    }

	    valS = new String(data, 0, l);
	    }

	    public int compareTo(ThumbnailFileName b) {
	    int r = valS.compareTo(b.valS);
	    if (r != 0)
	        return r;

	    return valN - b.valN;
	    }

	}
}

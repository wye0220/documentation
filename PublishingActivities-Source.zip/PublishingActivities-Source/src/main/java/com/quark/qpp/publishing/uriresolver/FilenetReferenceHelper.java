/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.InitializingBean;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.SAXException;

import com.filenet.api.collection.ComponentRelationshipSet;
import com.filenet.api.constants.ComponentRelationshipType;
import com.filenet.api.core.ComponentRelationship;
import com.filenet.api.core.Document;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.PropertyFilter;

/**
 * Helper class used by FileNetUriResolver to update component references in XML files sourced from Filenet
 *
 */
public class FilenetReferenceHelper implements InitializingBean {

	private static DocumentBuilderFactory documentBuilderFactory;
	private static final XPathFactory xpathFactory = XPathFactory.newInstance();

	private String scheme = "filenet";

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public void afterPropertiesSet() throws Exception {
		documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setValidating(false);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
	}

	/**
	 * Update references in XML document to valid URN format.
	 * By default references are relative which are converted to absolute filenet URN.
	 * @param fileNetDoc
	 * @param xmlFile
	 */
	public void updateRelativeReferences(Document fileNetDoc, File xmlFile) throws Exception,XPathExpressionException, SAXException, IOException, ParserConfigurationException {
		ComponentRelationshipSet comRelSet = fileNetDoc.get_ChildRelationships();
		ObjectStore childObjectStore;
		String childObjectStoreName;

		org.w3c.dom.Document contentDoc = documentBuilderFactory.newDocumentBuilder().parse(xmlFile);

		Iterator<ComponentRelationship> itr = comRelSet.iterator();
		while (itr.hasNext()) {
			ComponentRelationship comRel = itr.next();
			boolean isPinned = false;
			if (comRel == null) {
				continue;
			}
			String childReferenceId = comRel.getProperties().getStringValue("ReferenceId");
			childObjectStore = comRel.get_ChildComponent().getObjectStore();
			int childMajorVersion = comRel.get_ChildComponent().get_MajorVersionNumber();
			int childMinorVersion = comRel.get_ChildComponent().get_MinorVersionNumber();
			String childName = comRel.get_ChildComponent().get_Name();
			childObjectStore.fetchProperties(new PropertyFilter());
			childObjectStoreName = childObjectStore.get_Name();
			if (comRel.get_ComponentRelationshipType() == ComponentRelationshipType.STATIC_CR) {
				isPinned = true;
			} else {
				isPinned = false;
			}
			String componentUrn = generateFilenetUrn(comRel.get_ChildComponent().get_Id().toString(), childMajorVersion, childMinorVersion, childObjectStoreName, childName, isPinned);
			updateReferenceInXML(contentDoc, childReferenceId, componentUrn);
		}

		DOMImplementationLS domImplementationLS = (DOMImplementationLS) contentDoc.getImplementation().getFeature("LS", "3.0");
		LSOutput lsOutput = domImplementationLS.createLSOutput();
		FileOutputStream outputStream = new FileOutputStream(xmlFile);
		lsOutput.setByteStream(outputStream);
		LSSerializer lsSerializer = domImplementationLS.createLSSerializer();
		lsSerializer.write(contentDoc, lsOutput);
		outputStream.close();
	}

	/**
	 * Creates Filenet URN based on input data
	 * e.g. fileNet:///{CBD1628A-2E9C-4E3A-988F-141D933A4D5F}/@.@/TARGET/272.1-0.3.1.jpg
	 */
	private String generateFilenetUrn(String docId, int majorVersion, int minorVersion, String objectStoreName, String assetName, boolean isPinned) {
		StringBuilder urn = new StringBuilder(scheme).append(":///");
		if (isPinned) {
			urn.append(docId).append("/").append(majorVersion).append(".").append(minorVersion).append("/");
		} else {
			urn.append(docId).append("/@.@/");
		}
		urn.append(objectStoreName).append("/").append(assetName);
		return urn.toString();
	}

	/**
	 * Replace reference attribute's value of the node specified by input Xpath with input value.
	 * @param doc
	 * @param xpathToReferenceNode
	 * @param value
	 */
	private void updateReferenceInXML(org.w3c.dom.Document doc, String xpathToReferenceNode, String value) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, Exception {
		XPath xpath = xpathFactory.newXPath();
		XPathExpression xPathExpression = xpath.compile(xpathToReferenceNode);
		NodeList nodeList = (NodeList) xPathExpression.evaluate(doc, XPathConstants.NODESET);
		for (int index = 0; index < nodeList.getLength(); index++) {
			Node node = nodeList.item(index);
//			if (node.getNodeName().equalsIgnoreCase("image") || node.getNodeName().equalsIgnoreCase("xref")) {
//				NamedNodeMap attributes = node.getAttributes();
//				Node hrefAttr = attributes.getNamedItem("href");
//				hrefAttr.setTextContent(value);
//			} else {
//				NamedNodeMap attributes = node.getAttributes();
//				Node hrefAttr = attributes.getNamedItem("conref");
//				hrefAttr.setTextContent(value);
//			}
			NamedNodeMap attributes = node.getAttributes();
			Node hrefAttr = attributes.getNamedItem("href");
			Node conRefAttr = attributes.getNamedItem("conref");
			if (hrefAttr != null)
			{
				String referredElementId =  getReferredElementId(hrefAttr.getTextContent());
				hrefAttr.setTextContent(value+referredElementId);
			}
			else if (conRefAttr != null )
			{
				String referredElementId =  getReferredElementId(conRefAttr.getTextContent());
				conRefAttr.setTextContent(value+referredElementId);
			}
			else
			{
				throw new Exception("REFERENCE_ATTRIBUTE_NOT_FOUND xpath=" + xpathToReferenceNode);
			}
			
			
		}
		
	}
	private String getReferredElementId(String refValue) {
		String referredId = "";
		int index = refValue.lastIndexOf("#");
		if (index >= 0) {
			referredId = refValue.substring(index);
		}
		return referredId;
	}
	
}

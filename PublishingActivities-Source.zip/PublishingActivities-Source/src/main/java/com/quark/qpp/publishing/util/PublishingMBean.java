/*****************************************************************************\
 **
 ** �1990-2015 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/

package com.quark.qpp.publishing.util;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.ServerContext;
import com.quark.qpp.publishing.activity.QxpsModifyRender;
import com.quark.qpp.publishing.activity.QxpsRender;
import com.quark.qpp.publishing.activity.ResolveXADocReferences;
import com.quark.qpp.publishing.framework.Publisher;

public class PublishingMBean {
	
	private List<QxpsModifyRender> qxpsModifyRenders;
	
	private List<QxpsRender> qxpsRenders;
	
	private List<ResolveXADocReferences> resolveXADocReferences;
	
	@Autowired 
	private List<TempFileManager> tempFileManagers;
	
	@Autowired 
	private Publisher publisher;
	
	private boolean savePublishingDataOnError;
	
	public boolean isSavePublishingDataOnError() {
		return savePublishingDataOnError;
	}

	public void setSavePublishingDataOnError(boolean savePublishingDataOnError) {
		this.savePublishingDataOnError = savePublishingDataOnError;
		publisher.setSavePublishingDataOnError(savePublishingDataOnError);		
	}
		
	private boolean deleteDocpoolFolderOnCompletion = true;

	private boolean deleteProcessTempFolderOnCompletion = true;
	
	private int referenceResolutionMaxParallelism;

	private String rescueFolderPath;
	
	/**
	 * Returns the max parallelism value to be used while resolving references of an XML document.
	 * In case there is no default value configured in PublishingUtilContext.xml then the value returned here 
	 * is picked from the first instance of ResolveXADocReferences activity's getMaxParallelism(...) API which is twice the number of processors.
	 * In order to set maxParallelism, globally for all the instances of ResolveXADocReferences, use setReferenceResolutionMaxParallelism(...) API but the value set using this API will get lost on server restart.
	 * @return
	 */
	public int getReferenceResolutionMaxParallelism() {
		if (referenceResolutionMaxParallelism <= 0) {
			Map<String, ResolveXADocReferences> resolveXADocReferencesMap = ServerContext.getContext().getBeansOfType(ResolveXADocReferences.class);
			resolveXADocReferences = Arrays.asList(resolveXADocReferencesMap.values().toArray(new ResolveXADocReferences[0]));
			if (resolveXADocReferences != null && resolveXADocReferences.size() > 0) {
				referenceResolutionMaxParallelism = Integer.valueOf(resolveXADocReferences.get(0).getMaxParallelism());
			}
		} 
		return referenceResolutionMaxParallelism;
	}

	public boolean isDeleteDocpoolFolderOnCompletion() {
		return deleteDocpoolFolderOnCompletion;
	}

	
	public boolean isDeleteProcessTempFolderOnCompletion() {
		return deleteProcessTempFolderOnCompletion;
	}

	public void setDeleteDocpoolFolderOnCompletion(
			boolean deleteDocpoolFolderOnCompletion) {
		Map<String, QxpsRender> qxpsRenderMap = ServerContext.getContext().getBeansOfType(QxpsRender.class);
		qxpsRenders = Arrays.asList(qxpsRenderMap.values().toArray(new QxpsRender[0]));
      
		Map<String, QxpsModifyRender> qxpsModifyRenderMap = ServerContext.getContext().getBeansOfType(QxpsModifyRender.class);
		qxpsModifyRenders = Arrays.asList(qxpsModifyRenderMap.values().toArray(new QxpsModifyRender[0]));
		
		for (int i = 0; i < qxpsModifyRenders.size(); i++) {
			QxpsModifyRender qxpsModifyRender = qxpsModifyRenders.get(i);
			qxpsModifyRender.setClearDocpool(deleteDocpoolFolderOnCompletion);
		}
		
		for (int i = 0; i < qxpsRenders.size(); i++) {
			QxpsRender qxpsRender = qxpsRenders.get(i);
			qxpsRender.setClearDocpool(deleteDocpoolFolderOnCompletion);
		}
		
		this.deleteDocpoolFolderOnCompletion = deleteDocpoolFolderOnCompletion;
	}
	
	public void setDeleteProcessTempFolderOnCompletion(boolean deleteProcessTempFolderOnCompletion){
		for (int i = 0; i < tempFileManagers.size(); i++) {
			TempFileManager tfm = tempFileManagers.get(i);
			tfm.setDeleteTempFolder(deleteProcessTempFolderOnCompletion);
		}
		
		this.deleteProcessTempFolderOnCompletion = deleteProcessTempFolderOnCompletion;
	}
	
	public void setReferenceResolutionMaxParallelism(int referenceResolutionMaxParallelism) {
		Map<String, ResolveXADocReferences> resolveXADocReferencesMap = ServerContext.getContext().getBeansOfType(ResolveXADocReferences.class);
		resolveXADocReferences = Arrays.asList(resolveXADocReferencesMap.values().toArray(new ResolveXADocReferences[0]));
		
		for (int i = 0; resolveXADocReferences != null && i < resolveXADocReferences.size(); i++) {
			ResolveXADocReferences resXADocReferences = resolveXADocReferences.get(i);
			resXADocReferences.setMaxParallelism(referenceResolutionMaxParallelism+"");
		}
		
		this.referenceResolutionMaxParallelism = referenceResolutionMaxParallelism;
	}

	public String getRescueFolderPath() {
		return rescueFolderPath;
	}

	public void setRescueFolderPath(String rescueFolderPath) {	
		if(rescueFolderPath == null || rescueFolderPath.trim().length() == 0) {
			rescueFolderPath = System.getProperty("user.dir") + File.separator + "PublishingRescueFolder";
		}
		this.rescueFolderPath = rescueFolderPath;
		publisher.setRescueFolderPath(rescueFolderPath);
	}

//	public void setActivityProperty(String processName, String activityName, String propertyName, String propertyValue) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
//
//		Object beanObject = ServerContext.getContext().getBean(processName+"."+activityName);
//		PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(beanObject.getClass(), propertyName);
//		Method method = pd.getWriteMethod();
//		
//		method.invoke(beanObject, new Object[]{new Boolean(propertyValue)});
//	}
	
	
	
}
/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.net.URI;

import org.apache.log4j.Logger;

import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * This activity fetches file/folder from the file system. Content can be fetched either by specifying the parentFolder and fileName OR
 * absoluteFilePath.
 * 
 */
public class GetContentFromFileSystem extends AbstractActivity {

	private String parentFolder;
	
	private String fileName;
	
	private String absoluteFilePath;

	private String activityName;
	
	private String outContentName; 
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setParentFolder(String parentFolder) {
		this.parentFolder = parentFolder;
	}

	public void setOutContentName(String outContentName) {
		this.outContentName = outContentName;
	}

	public void setAbsoluteFilePath(String absoluteFilePath) {
		this.absoluteFilePath = absoluteFilePath;
	}
	
	private Logger logger = Logger.getLogger(getClass());

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		String parentFolderResolved = resolveParameter(parentFolder, publishingContext);
		String fileNameResolved = resolveParameter(fileName, publishingContext);
		File targetFile = null;
		if (parentFolderResolved != null && fileNameResolved != null) {
			targetFile = new File(parentFolderResolved, fileNameResolved);
		} else {
			String absoluteFilePathResolved = resolveParameter(absoluteFilePath, publishingContext);
			targetFile = new File(absoluteFilePathResolved);
		}
		
		publishingContext.registerOutputContentInfo(outContentName,  new URI("file", targetFile.getAbsolutePath(), null) ,targetFile);
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
	}

	@Override
	public void clean(String processId) {
		
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


}

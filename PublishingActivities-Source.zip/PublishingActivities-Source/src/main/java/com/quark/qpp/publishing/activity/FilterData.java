/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentIdentifier;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;

/**
 * This activity categorizes the given data in  
 * 
 *
 */
public class FilterData extends AbstractActivity  {
	
	private String activityName;
	
	private List<String> mimeTypesExclusions;
	private List<String> htmlDependencies;
	
	public void setHtmlDependencies(List<String> htmlDependencies) {
		this.htmlDependencies = htmlDependencies;
	}

	public void setMimeTypesExclusions(List<String> mimeTypesExclusions) {
		this.mimeTypesExclusions = mimeTypesExclusions;
	}

	@Autowired
	private URIHandlerRegistry uRIHandlerRegistry;
	
	@Autowired
	private ContentStructureService contentStructureService;

	private static final String INPUT_CONTENT_NAME = "INPUT_CONTENT";
		
	private static final String CONTENT_PDF = "PDF";
	
	private static final String CONTENT_NON_PDF = "NON_PDF";
	
	private static final String CONTENT_DONOT_REQUIRES_CONVERSION = "CONTENT_DONOT_REQUIRES_CONVERSION";
	
	private static final String CONTENT_HTML_DEPENDENCIES = "HTML_DEPENDENCIES";
	
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		
		ContentInfo[] contentToConvert = publishingContext.getInputContentInfos(INPUT_CONTENT_NAME);
		
		for (int i = 0; contentToConvert != null && i < contentToConvert.length; i++) {
			File file = contentToConvert[i].getFile();
			
			ContentIdentifier contentIdentifier = getContentIdentifier(file);
			
			if ((contentIdentifier.getContentTypeId() == DefaultContentTypes.PICTURE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.PICTURE, contentIdentifier.getContentTypeId())) && !mimeTypesExclusions.contains(contentIdentifier.getMimeType())) {
				
				ContentInfo contentInfo = null;
				if("application/pdf".equalsIgnoreCase(contentIdentifier.getMimeType())){
					contentInfo = publishingContext.registerOutputContentInfo(CONTENT_PDF, convertInputToURI("file://"+file.getAbsolutePath()));	
				}
				else {
					contentInfo = publishingContext.registerOutputContentInfo(CONTENT_NON_PDF, convertInputToURI("file://"+file.getAbsolutePath()));	
				}
				
				contentInfo.setMimeType(contentIdentifier.getMimeType());
				contentInfo.setFileExtension(getFileExtension(file.getName()));
				
				contentInfo.setResourceName(file.getName());
			}else{
				ContentInfo contentInfo = publishingContext.registerOutputContentInfo(CONTENT_DONOT_REQUIRES_CONVERSION, convertInputToURI("file://"+file.getAbsolutePath()));
				contentInfo.setMimeType(contentIdentifier.getMimeType());
				contentInfo.setFileExtension(getFileExtension(file.getName()));	
				contentInfo.setResourceName(file.getName());
			}
		}

		if (htmlDependencies != null) {
			for (String htmlDependeny : htmlDependencies) {
				File aFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), convertInputToURI(htmlDependeny));
				ContentInfo contentInfo = publishingContext.registerOutputContentInfo(CONTENT_HTML_DEPENDENCIES,
						convertInputToURI("file://" + aFile.getAbsolutePath()));
				contentInfo.setFileExtension(getFileExtension(aFile.getName()));
				contentInfo.setResourceName(aFile.getName());
			}
		}
	}

	private String getFileExtension(String fileName) {
		String fileExtension = "";
		if (fileName != null && fileName.indexOf(".") != -1) {
			fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1,
					fileName.length());
		}
		return fileExtension;
	}
	
	private ContentIdentifier getContentIdentifier(File sourceFile) throws IOException, QppServiceException {
		FileInputStream fis = null;
		try {
			String fileExtension = null;
			if(sourceFile.getName().lastIndexOf(".") >0){
				fileExtension = sourceFile.getName().substring(sourceFile.getName().lastIndexOf(".")); 	
			}
			
			fis = new FileInputStream(sourceFile);
			byte[] initialBytes = new byte[4096];
			fis.read(initialBytes);
			
			ContentIdentifier contentIdentifier = contentStructureService.getContentIdentifier(fileExtension, null, initialBytes);
			return contentIdentifier;
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
	}


	@Override
	public void clean(String processId) {
		//Nothing to do
	}
	
	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// Nothing to validate in this activity
	}
}

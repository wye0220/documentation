/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.dto.ContentIdentifier;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity is used for zipping all the content specified by the name
 * {@link #CONTENT_TO_ZIP}, and emits content with name specified by
 * {@link #OUTPUT_CONTENT_NAME}.<br>
 * Additionally, it has option to exclude certain
 * content, based on the mime-type, to be added to the resultant ZIP file using {@link #mimeTypesExclusions}.
 * 
 * <p>
 * Therefore, this activity requires input content with name
 * {@link #CONTENT_TO_ZIP}. <br>
 * <br>
 * This activity emits content with name {@link #OUTPUT_CONTENT_NAME}
 * </p>
 * 
 */
public class CreateZip extends AbstractActivity  {
	
	private String activityName;
	
	//Content of following mime-types will not be included in the ZIP file being created
	private List<String> mimeTypesExclusions;
	
	public void setMimeTypesExclusions(List<String> mimeTypesExclusions) {
		this.mimeTypesExclusions = mimeTypesExclusions;
	}
	
	/*
	 * Name with which this activity expects input content
	 */
	private static final String CONTENT_TO_ZIP = "CONTENT_TO_ZIP";
		
	/*
	 * Name with which this activity emits content
	 */
	private static final String OUTPUT_CONTENT_NAME = "ZIP_CONTENT";
	
	private Logger logger = Logger.getLogger(CreateZip.class);
	
	@Autowired
	private TempFileManager fileManager;
	
	@Autowired
	private ContentStructureService contentStructureService;

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		File zipFile = fileManager.getTemporaryFile(".zip", publishingContext.getProcessId());
		ContentInfo[] contentToZip = publishingContext.getInputContentInfos(CONTENT_TO_ZIP);
		ArrayList<File> filesToBeZipped = new ArrayList<File>();
		for (int i = 0; contentToZip != null && i < contentToZip.length; i++) {
			File file = contentToZip[i].getFile();			
			if (mimeTypesExclusions == null || mimeTypesExclusions.size() == 0) {
				//If there is no mime-type exclusions specified, simply add to zip.
				filesToBeZipped.add(file);
			}
			else {
				//First get the mime-type from content info if it set.
				String mimeType = contentToZip[i].getMimeType();
				logger.debug("Mime type from content info: " + mimeType);
				
				//If the mime-type  is not defined with the input content, then only detect the content mime-type 
				if (mimeType == null || mimeType.trim().isEmpty()) {
					ContentIdentifier contentIdentifier = getContentIdentifier(file);
					mimeType = contentIdentifier.getMimeType();
					logger.debug("Mime type detected using ContentIdentifier: " + mimeType);
				}
				
				if(mimeTypesExclusions != null && !mimeTypesExclusions.contains(mimeType)){
					filesToBeZipped.add(file);	
				}
			}
		}
		createZip(filesToBeZipped.toArray(new File[0]), zipFile);
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI("file://"+zipFile.getAbsolutePath()));
		contentInfo.setMimeType("application/zip");
		contentInfo.setFileExtension("zip");	
		contentInfo.setResourceName(zipFile.getName());
	}
	

	@Override
	public void clean(String processId) {
		//Nothing to do
	}
	
	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	private void createZip(File[] files, File zipFile) throws IOException {
		ZipOutputStream zipOutputStream = null;
		try {
			zipOutputStream = new ZipOutputStream(new FileOutputStream(zipFile));
			ArrayList<String> filesAddedToZip = new ArrayList<String>();
			for (int i = 0; files!= null && i < files.length; i++) {
				String fileAbsolutePath = files[i].getAbsolutePath().toLowerCase();
				//If same files are there multiple times, adding  only one entry to the zip.
				if(!filesAddedToZip.contains(fileAbsolutePath)){
					addFileToZip(files[i], zipOutputStream, ""/*folder hierarchy in zip where the file will be placed*/);
					filesAddedToZip.add(fileAbsolutePath);
				}
			}
		} finally {
			if (zipOutputStream != null) {
				try {
					zipOutputStream.close();
				} catch (IOException e) {
					logger.error("Error closing zip stream");
				}
			}
		}
	}

	private void addFileToZip(File file, ZipOutputStream zipOutputStream, String folderHeirarchy) throws IOException {
		if(file.isFile()){
			byte[] buf = new byte[1024];
			FileInputStream in = new FileInputStream(file);
			try {
				String originalFileName = file.getName();
				String targetFileName = null;
				if(folderHeirarchy != null && !folderHeirarchy.isEmpty()){
					targetFileName = folderHeirarchy+"/"+originalFileName;
				}else{
					targetFileName = originalFileName;
				}
					
				// Add ZIP entry to output stream.
				zipOutputStream.putNextEntry(new ZipEntry(targetFileName));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					zipOutputStream.write(buf, 0, len);
				}
			} finally {
				// Complete the entry
				zipOutputStream.closeEntry();
				in.close();
			}
		}else{
			File[] childFiles = file.listFiles();
			for (int j = 0; childFiles != null && j < childFiles.length; j++) {
				if(folderHeirarchy != null && !folderHeirarchy.isEmpty()){
					addFileToZip(childFiles[j], zipOutputStream, folderHeirarchy+"/"+file.getName());
				}else{
					addFileToZip(childFiles[j], zipOutputStream, file.getName());
				}
			}
		}
	}


	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// Nothing to validate in this activity
	}
	
	private ContentIdentifier getContentIdentifier(File sourceFile) throws IOException, QppServiceException {
		FileInputStream fis = null;
		try {
			String fileExtension = null;
			if(sourceFile.getName().lastIndexOf(".") >0){
				fileExtension = sourceFile.getName().substring(sourceFile.getName().lastIndexOf(".")); 	
			}
			
			fis = new FileInputStream(sourceFile);
			byte[] initialBytes = new byte[4096];
			fis.read(initialBytes);
			
			ContentIdentifier contentIdentifier = contentStructureService.getContentIdentifier(fileExtension, null, initialBytes);
			return contentIdentifier;
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
	}
}

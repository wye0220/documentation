/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.charting.service.constants.ChartingOutputFormats;
import com.quark.qpp.charting.service.constants.ChartingOutputProperties;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.AssetServiceExceptionCodes.AssetNotFoundExceptionCodes;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.office.service.constants.ExcelDataOutputFormats;
import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.constants.PowerPointDataOutputFormats;
import com.quark.qpp.office.service.constants.VisioDataOutputFormats;
import com.quark.qpp.office.service.exceptions.ExcelDataException;
import com.quark.qpp.office.service.exceptions.ExcelOutputException;
import com.quark.qpp.office.service.exceptions.PowerPointDataException;
import com.quark.qpp.office.service.exceptions.PowerPointOutputException;
import com.quark.qpp.office.service.exceptions.VisioDataException;
import com.quark.qpp.office.service.exceptions.VisioOutputException;
import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.util.AssetIdentityInfo;
import com.quark.qpp.publishing.util.QppAssetsUriUtility;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.facade.ChartingFacade;
import com.quark.qpp.service.facade.OfficeFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;

public class QppUriResolver implements URIResolver {
	
	private String scheme;
	
	@Autowired
	private Map<String,FileNamingScheme> fileNamingSchemeMap;
	
	@Autowired
	private TempFileManager fileManager;
	
	@Autowired
	private QppAssetsUriUtility qppAssetsUriUtility;
	
	@Autowired 
	private AssetFacade assetFacade;
	
	@Autowired
	private OfficeFacade officeFacade;
	
	@Autowired
	private ChartingFacade chartingFacade;
	
	private Map<String,Map<URI,File>> processURIFileRegistry;
	
	@PostConstruct
	public void init()
	{
		processURIFileRegistry = Collections.synchronizedMap(new HashMap<String,Map<URI,File>>());
	}
	
	public void setFileNamingSchemeMap(Map<String, FileNamingScheme> fileNamingSchemeMap) {
		this.fileNamingSchemeMap = fileNamingSchemeMap;
	}
	
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	@Override
	public void clean(String processId) throws Exception {
		processURIFileRegistry.remove(processId);
		fileManager.cleanup(processId);	
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}
	
	@Override
	public File resolveToFile(URI assetUri, String processId) throws Exception {
		FileOutputStream fos = null;
		try{
			File tempFile = null;
			/*
			 * Following block needs to be synchronized as there can occur a
			 * scenario wherein two threads in parallel try to initialize a new
			 * uriFileMap that might lead to overriding of the map created by
			 * the second thread.
			 */
			synchronized (this) {
				Map<URI, File> uriFileMap = processURIFileRegistry.get(processId);
				if (uriFileMap != null) {
					tempFile = uriFileMap.get(assetUri);
				} else {
					/*
					 * Two parallel threads might override a map entry, thus,
					 * the map needs to be synchronized.
					 */
					uriFileMap = Collections.synchronizedMap(new HashMap<URI, File>());
					processURIFileRegistry.put(processId, uriFileMap);
				}
			}
	
			if (tempFile == null) {
	
				AssetIdentityInfo assetIdentityInfo = qppAssetsUriUtility.parseAndEvaluateQppUri(assetUri, processId);
	
				// Get asset Data stream from QPP
				String fileName = null;
				FileNamingScheme fileNamingScheme = getFileNamingScheme(assetIdentityInfo.getNamingScheme());
				if (assetIdentityInfo.getAssetID() > 0) {
					if (fileNamingScheme == null) {
						fileName = getAssetName(assetIdentityInfo.getAssetID());
					} else {
						fileName = fileNamingScheme.resolveFileName(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion());
					}
				}
				if (assetIdentityInfo.isExcelChart() || assetIdentityInfo.isExcelTable()) {
					if (fileName == null && assetIdentityInfo.getUri() != null) {
						fileName = createValidFileName(assetIdentityInfo.getUri());						
					}
					String fileExtension = getFileExtension(assetIdentityInfo);
					fileName = createValidFileName(fileName);				
					fileName = fileName+"."+fileExtension;
					fileName.replaceAll("&", "");
				} else if (assetIdentityInfo.isExcel()) {
					if (fileName == null && assetIdentityInfo.getUri() != null) {
						fileName = createValidFileName(assetIdentityInfo.getUri());						
					}
					String excelDataObjectName = getExcelDataObjectName(assetIdentityInfo);
					String fileExtension = getFileExtension(assetIdentityInfo);
					fileName = createValidFileName(fileName += "_" + assetIdentityInfo.getWorksheet() + "_" + excelDataObjectName );
					fileName = fileName+"."+fileExtension;
					fileName.replaceAll("&", "");
				} else if (assetIdentityInfo.isDynamicChart()) {
					if (fileName == null && assetIdentityInfo.getUri() != null) {
						fileName = createValidFileName(assetIdentityInfo.getUri());						
					}
					String fileExtension = getFileExtension(assetIdentityInfo);
					fileName = createValidFileName(fileName += "_" + assetIdentityInfo.getTemplateUri() );
					fileName = fileName+"."+fileExtension;
					fileName.replaceAll("&", "");
				}
				else if(assetIdentityInfo.isVisio()) {
					if (fileName == null && assetIdentityInfo.getUri() != null) {
						fileName = createValidFileName(assetIdentityInfo.getUri());						
					}
					String visioDataObjectName = getVisioDataObjectName(assetIdentityInfo);
					String fileExtension = getFileExtension(assetIdentityInfo);
					fileName = createValidFileName(fileName += "_" + assetIdentityInfo.getVisioPageName() + "_" + visioDataObjectName );
					fileName = fileName+"."+fileExtension;
					fileName.replaceAll("&", "");	
				}	
				else if(assetIdentityInfo.isPpt()) {
					if (fileName == null && assetIdentityInfo.getUri() != null) {
						fileName = createValidFileName(assetIdentityInfo.getUri());						
					}
					String pptDataObjectName = getPptDataObjectName(assetIdentityInfo);
					String fileExtension = getFileExtension(assetIdentityInfo);
					if(assetIdentityInfo.getPptSlideId() > 0){
						fileName = createValidFileName(fileName += "_" + assetIdentityInfo.getPptSlideId() + "_" + pptDataObjectName );
					}
					fileName = fileName+"."+fileExtension;
					fileName.replaceAll("&", "");
				
				}	
				fileName = getStringWithSpecialCharsRemoved(fileName);
				tempFile = fileManager.getTempFileWithGivenName(fileName, processId);
				fos = new FileOutputStream(tempFile);

				if (assetIdentityInfo.isExcel()) {
					getExcelDatObject(assetIdentityInfo, fos);
				}
				else if (assetIdentityInfo.isVisio()) {
					getVisioDatObject(assetIdentityInfo, fos);
				}
				else if (assetIdentityInfo.isPpt()) {
					getPptDatObject(assetIdentityInfo, fos);
				}
				else if (assetIdentityInfo.isDynamicChart()) {
					getDynamicChart(assetIdentityInfo, fos);
				} 
				else {
						assetFacade.getAsset(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(), assetIdentityInfo.getAssetVersion().getMinorVersion(), null, false, false, null, assetIdentityInfo.getRendition(), fos, assetIdentityInfo.getLayoutNumber(), assetIdentityInfo.getPageNumber(), false);
				}
				
				processURIFileRegistry.get(processId).put(assetUri, tempFile);
			}
			return new File(tempFile.getAbsolutePath());
		}
		catch (AssetNotFoundException e) {
			if(e.getExceptionCode().equalsIgnoreCase(AssetNotFoundExceptionCodes.ASSET_NOT_ACCESSIBLE)){
				throw new PublishingException(PublishingExceptionCodes.DATA_NOT_ACCESSIBLE, new String[]{" URI:"+assetUri}, e);	
			}
			throw new PublishingException(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI, new String[]{" URI:"+assetUri}, e);
		}
		catch (Exception e) {
			throw new PublishingException(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI, new String[]{" URI:"+assetUri}, e);			
		}
		finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * Creates filename from last 10 characters of the given String  
	 * @param uri
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	private String createValidFileName(String fileName) throws UnsupportedEncodingException {
		if (fileName == null || fileName.length() == 0) {
			return fileName;
		}
		Base64 base64Encoder = new Base64();
	
		fileName = new String(base64Encoder.encode(fileName.getBytes("UTF-8")), "UTF-8");
		
		int maxFileNameLimit = 100;
		if(fileName.length() > maxFileNameLimit) {
			fileName = UUID.randomUUID().toString();
		}
		return fileName;
	}
	
	private void getExcelDatObject(AssetIdentityInfo assetIdentityInfo, FileOutputStream fos) throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {

		String outputFormat = assetIdentityInfo.getOutputFormat();
		
		if(assetIdentityInfo.getAssetID()>0){
			if (assetIdentityInfo.getChart() != null && assetIdentityInfo.getChart().trim().length() > 0) {
				officeFacade.getChart(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getWorksheet(), assetIdentityInfo.getChart(),
						assetIdentityInfo.getOutputFormatProperties(), null, null, fos);						
			} else if (assetIdentityInfo.getTable() != null && assetIdentityInfo.getTable().trim().length() > 0) {
				officeFacade.getTable(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getWorksheet(), assetIdentityInfo.getTable(),
						outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if (assetIdentityInfo.getNamedRange() != null && assetIdentityInfo.getNamedRange().trim().length() > 0) {
				officeFacade.getNamedRange(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getWorksheet(),
						assetIdentityInfo.getNamedRange(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if (assetIdentityInfo.getDynamicRange() != null && assetIdentityInfo.getDynamicRange().trim().length() > 0) {
				officeFacade.getDynamicRange(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getWorksheet(),
						assetIdentityInfo.getDynamicRange(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if(assetIdentityInfo.isExcelChart()) {
				officeFacade.getExcelChart(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(), 
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if(assetIdentityInfo.isExcelTable()) {
				officeFacade.getExcelTable(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(), 
						assetIdentityInfo.getAssetVersion().getMinorVersion(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			}
		}
		else if(assetIdentityInfo.getUri() != null){
			if (assetIdentityInfo.getChart() != null && assetIdentityInfo.getChart().trim().length() > 0) {
				officeFacade.getChartBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getWorksheet(), assetIdentityInfo.getChart(),
						assetIdentityInfo.getOutputFormatProperties(), null, null, fos);						
			} else if (assetIdentityInfo.getTable() != null && assetIdentityInfo.getTable().trim().length() > 0) {
				officeFacade.getTableBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getWorksheet(), assetIdentityInfo.getTable(),
						outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if (assetIdentityInfo.getNamedRange() != null && assetIdentityInfo.getNamedRange().trim().length() > 0) {
				officeFacade.getNamedRangeBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getWorksheet(),
						assetIdentityInfo.getNamedRange(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if (assetIdentityInfo.getDynamicRange() != null && assetIdentityInfo.getDynamicRange().trim().length() > 0) {
				officeFacade.getDynamicRangeBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getWorksheet(),
						assetIdentityInfo.getDynamicRange(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			}  else if(assetIdentityInfo.isExcelChart()) {
				officeFacade.getExcelChartBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			} else if(assetIdentityInfo.isExcelTable()) {
				officeFacade.getExcelTableBasedOnURI(assetIdentityInfo.getUri(), outputFormat, assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
			}
		}
	}
	

	private void getDynamicChart(AssetIdentityInfo assetIdentityInfo, FileOutputStream fos) throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		if (assetIdentityInfo.getAssetID() > 0) {
			chartingFacade.getChart(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),
						assetIdentityInfo.getAssetVersion().getMinorVersion(), assetIdentityInfo.getSourceDataType(), assetIdentityInfo.getTemplateUri(), assetIdentityInfo.getOutputFormat(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
		}
		else if(assetIdentityInfo.getUri() != null){
			chartingFacade.getChartBasedOnUri(assetIdentityInfo.getUri(), assetIdentityInfo.getSourceDataType(), assetIdentityInfo.getTemplateUri(), assetIdentityInfo.getOutputFormat(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);
		}
	}

	private String getFileExtension(AssetIdentityInfo assetIdentityInfo) {
		String fileExtension = null;
			String outputFormat = assetIdentityInfo.getOutputFormat();
		
		String imageFormat = null;
		if(assetIdentityInfo.isExcel()){
			imageFormat = assetIdentityInfo.getOutputFormatProperties().get(ImageOutputProperties.IMAGE_FORMAT);
			if (outputFormat == null || outputFormat.isEmpty()) {
				//Set the default output format.
				outputFormat = ExcelDataOutputFormats.IMAGE;
			}
		}
		else if(assetIdentityInfo.isDynamicChart()){
			imageFormat = assetIdentityInfo.getOutputFormatProperties().get(ChartingOutputProperties.IMAGE_FORMAT);
			if (outputFormat == null || outputFormat.isEmpty()) {
				//Set the default output format.
				outputFormat = ChartingOutputFormats.IMAGE;
			}
		} else if(assetIdentityInfo.isVisio()){
			imageFormat = assetIdentityInfo.getOutputFormatProperties().get(ImageOutputProperties.IMAGE_FORMAT);
			if (outputFormat == null || outputFormat.isEmpty()) {
				//Set the default output format.
				outputFormat = VisioDataOutputFormats.IMAGE;
			}
		}
		else if(assetIdentityInfo.isPpt()){
			imageFormat = assetIdentityInfo.getOutputFormatProperties().get(ImageOutputProperties.IMAGE_FORMAT);
			if (outputFormat == null || outputFormat.isEmpty()) {
				//Set the default output format.
				outputFormat = PowerPointDataOutputFormats.IMAGE;
			}
		}
		
		if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.IMAGE) || outputFormat.equalsIgnoreCase(ChartingOutputFormats.IMAGE)
			|| outputFormat.equalsIgnoreCase(PowerPointDataOutputFormats.IMAGE) || outputFormat.equalsIgnoreCase(VisioDataOutputFormats.IMAGE) ){
			if (imageFormat != null && imageFormat.trim().length() > 0) {
				fileExtension = imageFormat;
			}else{
				fileExtension = "png";
			}
		}
		else if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.HTML) || outputFormat.equalsIgnoreCase(ChartingOutputFormats.HTML)) {
			fileExtension = "htm";
		} else if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XHTML)) {
			fileExtension = "xhtml";
		} else if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.CALS) || outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XML) || outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.SMARTTABLE)) {
			fileExtension = "xml";
		}
		return fileExtension;
	}

	private FileNamingScheme getFileNamingScheme(String scheme) throws PublishingException {
		Iterator<FileNamingScheme> resolverIterator = fileNamingSchemeMap.values().iterator();
		while (resolverIterator.hasNext()) {
			FileNamingScheme fileNamingScheme = resolverIterator.next();
			String supportedScheme = fileNamingScheme.getSupportedNamingScheme();
			if (supportedScheme != null && supportedScheme.equals(scheme)) {
				return fileNamingScheme;
			}
		}
		return null;
	}
		
	private String getAssetName(long assetId) throws Exception{
		AssetInfo assetInfo = assetFacade.getAsset(assetId, null, null,
				new String[] { String.valueOf(DefaultAttributes.NAME)},
				false, false, null, null, null, null, null, false);
		return assetInfo.getAttributeValueList().getAttributeValue().get(0).getValue();
	}

	@Override
	public String getResourceIdentity(URI inputContentUri) throws AssetNotFoundException, InvalidAttributeException, PublishingException,
			QppServiceException, StreamingException, URISyntaxException {
		return inputContentUri.toString();		
	}
	
	/**
	 * Returns string after replacing the special characters(which can not be used in filename) with the _
	 * @param string
	 * @return
	 */
	private String getStringWithSpecialCharsRemoved(String string) {
		//replacing characters <  > : " / \ | ? * which can not be used in filename.
		String uriWithSpecialCharRemoved = string.replaceAll("<|>|:|\"|/|\\\\|\\||\\?|\\*", "_");
		return uriWithSpecialCharRemoved;
	}

	private String getExcelDataObjectName(AssetIdentityInfo assetIdentityInfo) {
		String name = null;
		if (assetIdentityInfo.getTable() != null) {
			name = assetIdentityInfo.getTable();
		} else if (assetIdentityInfo.getChart() != null) {
			name = assetIdentityInfo.getChart();
		} else if (assetIdentityInfo.getNamedRange() != null) {
			name = assetIdentityInfo.getNamedRange();
		} else if (assetIdentityInfo.getDynamicRange() != null) {
			name = assetIdentityInfo.getDynamicRange();
		}
		return name;
	}
	private void getVisioDatObject(AssetIdentityInfo assetIdentityInfo, FileOutputStream fos) throws AssetNotFoundException, InvalidAssetException, VisioDataException, VisioOutputException, QppServiceException, StreamingException, IOException {

		String outputFormat = assetIdentityInfo.getOutputFormat();
		
		if (assetIdentityInfo.getAssetID() > 0) {
			 if (assetIdentityInfo.getVisioPageName() != null && assetIdentityInfo.getVisioPageName().trim().length() > 0) {
				officeFacade.getVisioPageOutput(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),assetIdentityInfo.getAssetVersion().getMinorVersion(), outputFormat,
						assetIdentityInfo.getVisioPageName(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);	
			} 
		}
		else if(assetIdentityInfo.getUri() != null){
			if (assetIdentityInfo.getVisioPageName() != null && assetIdentityInfo.getVisioPageName().trim().length() > 0) {
				officeFacade.getVisioPageOutputBasedOnURI(assetIdentityInfo.getUri(), outputFormat,
						assetIdentityInfo.getVisioPageName(), assetIdentityInfo.getOutputFormatProperties(), null, null, fos);	
			} 
	}
	}
	
	private String getVisioDataObjectName(AssetIdentityInfo assetIdentityInfo) {
		String name = null;
		if (assetIdentityInfo.getVisioPageName() != null) {
			name = assetIdentityInfo.getVisioPageName();
		} 
		return name;
	}
	
	private String getPptDataObjectName(AssetIdentityInfo assetIdentityInfo) {
		String name = null;
		if (assetIdentityInfo.getPptSlideId() > 0 ) {
			return String.valueOf(assetIdentityInfo.getPptSlideId());
		} 		
		return name;
	}
	private void getPptDatObject(AssetIdentityInfo assetIdentityInfo, FileOutputStream fos) throws AssetNotFoundException, InvalidAssetException, PowerPointDataException, PowerPointOutputException, QppServiceException, StreamingException, IOException {

		String outputFormat = assetIdentityInfo.getOutputFormat();
		
		if (assetIdentityInfo.getAssetID() > 0) {
			if ((assetIdentityInfo.getPptSlideId() > 0) ) {
				officeFacade.getPowerPointSlideOutput(assetIdentityInfo.getAssetID(), assetIdentityInfo.getAssetVersion().getMajorVersion(),assetIdentityInfo.getAssetVersion().getMinorVersion(),assetIdentityInfo.getPptSlideId(), outputFormat,
						 assetIdentityInfo.getOutputFormatProperties(), null, null, fos);					
			} 
		}
		else if(assetIdentityInfo.getUri() != null){
			if (assetIdentityInfo.getPptSlideId() > 0) {
				officeFacade.getPowerPointSlideOutputBasedOnURI(assetIdentityInfo.getUri(), assetIdentityInfo.getPptSlideId(), outputFormat,
						 assetIdentityInfo.getOutputFormatProperties(), null, null, fos);					
			} 
	}
	}
}


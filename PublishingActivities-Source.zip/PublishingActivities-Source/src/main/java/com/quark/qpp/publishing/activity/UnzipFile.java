/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity unzip's the file associated with input content and returns
 * unzipped content.
 * 
 * <p>
 * Name with which this activity expects input content is specified by
 * {@link #SOURCE_CONTENT}.The input content should have ZIP file associated.
 * </p>
 * 
 * <p>
 * Name with which this activity emits content is specified by
 * {@link #OUTPUT_FOLDER}. The output content will have unzipped folder
 * associated with it.
 * </p>
 * 
 */
public class UnzipFile extends AbstractActivity {

	private String activityName;

	/*
	 * name with which this activity expects content
	 */
	private static final String SOURCE_CONTENT = "ZipFile";

	/*
	 * name with which this activity emits content
	 */
	private static final String OUTPUT_FOLDER = "UnZippedFolder";

	@Autowired
	private TempFileManager tempFileManager;

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
	}

	private static Logger logger = Logger.getLogger(UnzipFile.class);

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		ContentInfo[] contentInfos = publishingContext.getInputContentInfos(SOURCE_CONTENT);
		if (contentInfos == null || contentInfos.length > 1) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Input content with name '" + SOURCE_CONTENT + "' not found." });
		}
		ContentInfo contentInfo = contentInfos[0];
		File sourceZipFile = contentInfo.getFile();
		String unzippedFilePath = unzipGivenFile(sourceZipFile, publishingContext);
		URI uri = convertInputToURI("file:"+unzippedFilePath);
		publishingContext.registerOutputContentInfo(OUTPUT_FOLDER, uri, new File(unzippedFilePath));
	}

	private String unzipGivenFile(File file, PublishingContext publishingContext) throws IOException {
		ZipFile zipFile = null;
		FileOutputStream out = null;
		InputStream in = null;
		try {
			zipFile = new ZipFile(file);
			String destFolder = "unzippedfiles/" + file.getName();
			Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
			while (enumeration.hasMoreElements()) {
				ZipEntry zipEntry = enumeration.nextElement();
				if(zipEntry.isDirectory()){
					continue;
				}
				File targetFile = tempFileManager.getTempFileWithGivenName( destFolder + "/" + zipEntry.getName(),
						publishingContext.getProcessId());
				try {
					in = zipFile.getInputStream(zipEntry);
					out = new FileOutputStream(targetFile);
					pipe(in, out);
				} finally {
					if (out != null)
						out.close();
				}
			}			
			return tempFileManager.getProcessIdFolder(publishingContext.getProcessId())+"/"+destFolder;
		} finally {
			try {
				if (zipFile != null)
					zipFile.close();
			} catch (IOException ioException) {
				logger.error("Error while closing streams.", ioException);
			}
		}
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

}

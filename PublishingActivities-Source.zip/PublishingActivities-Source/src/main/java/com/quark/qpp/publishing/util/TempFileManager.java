/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

public class TempFileManager {
	
	Map<String, List<File>> tempFileRegistry = new HashMap<String, List<File>>();
	private Logger logger = Logger.getLogger(getClass());
	private String systemTempDirectory;
	
	private boolean deleteTempFolder = true;
	
	public void setDeleteTempFolder(boolean deleteTempFolder) {
		this.deleteTempFolder = deleteTempFolder;
	}

	@PostConstruct
	public void init() {		
		systemTempDirectory = System.getProperty("java.io.tmpdir");		
		systemTempDirectory = systemTempDirectory +"/QppServer/Publishing";
	}
	
	
	/* Create a temporary file. Unique directory are used for each task */
	public File getTemporaryFile(String suffix, String processId) throws IOException {

		File baseTaskDir  = new File(systemTempDirectory+"/"+processId);
		
		if(!baseTaskDir.exists()) {
			baseTaskDir.mkdirs();
		}
		
		File temp = File.createTempFile("tmp", suffix, new File(systemTempDirectory+"/"+processId) );
		
		/*
		 * There can occur a case where in two threads in parallel create a new
		 * taskFileList because there doesn't exist a taskFileList for given
		 * process ID. Without synchronization block one of the taskFileList
		 * will be overridden by the second thread's taskFileList thus a file
		 * gets missed from being registered.This eventually leads to files in
		 * publishing folder not getting cleaned because on process cleanup, the
		 * files mentioned in taskFileList for a process are deleted and
		 * the process folder will be deleted only if its empty.
		 */
		synchronized (tempFileRegistry) {
			// record for book keeping
			List<File> taskFileList = tempFileRegistry.get(processId);
			if (taskFileList == null) {
				taskFileList = new ArrayList<File>();
				tempFileRegistry.put(processId, taskFileList);
			}
			taskFileList.add(temp);
		}
		logger.debug(temp.getAbsolutePath() + " is created");
		return temp;
	}
	
	public void cleanup(String processId) {
		if(deleteTempFolder){
			List<File> taskFileList = tempFileRegistry.get(processId);
			if(taskFileList!=null) {
				for(File f : taskFileList) {
					if(f.exists() && f.isDirectory()){
						deleteFolder(f);
					}
					if(f.exists() && !f.delete())
						logger.warn("Unable to delete file :: "+f.getAbsolutePath());
				}
			}
			
			//Finally delete the process folder
			String processFolderPath = getProcessIdFolder(processId);
			File processFolder = new File(processFolderPath);
			if (processFolder.exists() && processFolder.list() != null && !containFiles(processFolder)) {
					deleteFolder(processFolder);
					tempFileRegistry.remove(processId);
			}
		}
	}
	
	private boolean containFiles(File folder) {
		if(folder.isDirectory()){			 
			if(folder.list().length>0){
				File[] files = folder.listFiles();
				for (int i = 0; i < files.length; i++) {
					if(files[i].isDirectory()){
						if(containFiles(files[i])){
							return true;
						}
					}
					else{
						return true;
					}
				}				
			}else{
				return false;
			}
	 
		}else{
	 		return false;
		}
		return false;
	}


	private void deleteFolder(File f) {
		File[] files = f.listFiles();
		for (File tempFile : files) {
			if (tempFile.isDirectory()) {
				deleteFolder(tempFile);
			}
			tempFile.delete();
		}
		f.delete();
	}


	/* Create a temporary file. Unique directory are used for each task */
	public File getTempFileWithGivenName(String fileName, String processId) throws IOException {

		File baseTaskDir  = new File(systemTempDirectory+"/"+processId);
		
		if(!baseTaskDir.exists()) {
			baseTaskDir.mkdirs();
		}
		
		File temp = new File(systemTempDirectory+"/"+processId+"/"+fileName);
		
		// This would be useful if someone wants file to be created in the folder. In this case the filename contains folder name also in
		// which the file with the given name is to created. 
		if (!temp.getParentFile().exists()) {
			temp.getParentFile().mkdirs();
		}

		/*
		 * There can occur a case where in two threads in parallel create a new
		 * taskFileList because there doesn't exist a taskFileList for given
		 * process ID. Without synchronization block one of the taskFileList
		 * will be overridden by the second thread's taskFileList thus a file
		 * gets missed from being registered.This eventually leads to files in
		 * publishing folder not getting cleaned because on process cleanup, the
		 * files mentioned in taskFileList for a process are deleted and
		 * the process folder will be deleted only if its empty.
		 */
		synchronized (tempFileRegistry) {
			// record for book keeping
			List<File> taskFileList = tempFileRegistry.get(processId);
			if (taskFileList == null) {
				// taskFileList should be synchronized data structure else all
				// files are not populated in taskFileList leading to process folder
				// not being deleted.
				taskFileList = new ArrayList<File>();
				tempFileRegistry.put(processId, taskFileList);
			}
			taskFileList.add(temp);
		}
		
		
		return temp;
	}
	
	public String getProcessIdFolder(String processId){
		return systemTempDirectory+"/"+processId;
	}

}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.quark.qpp.publishing.framework.ChannelParameter;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity outputs an XML by transforming source XML using an XSLT.
 *  <p>
 * Prerequisites : 
 * <li>xslUri : URI of the XSL to be considered for transforming source XML into desired XML</li>
 * <br><br>
 *
 * Name with which this activity expects input content is represented by {@link #INPUT_CONTENT_NAME}.The input content
 * should have the XML file associated that is to be transformed.
 * <br>
 * Name with which this activity emits content is represented by {@link #OUTPUT_CONTENT_NAME}.The out content will have
 * the modified XML file associated with it.
 * </p>
 * 
 */
public class XslTransform extends AbstractActivity {

	//name with which this activity expects input content
	private static final String INPUT_CONTENT_NAME = "XMLFile";
	
	//name with which this activity emits content
	private static final  String OUTPUT_CONTENT_NAME = "ModifiedXML";
	
	//name with which this activity expects XSL parameters file
	private static final String INPUT_CONTENT_XSL_PARAM_FILE = "XSLParametersFile";
	
	private String outFolderName = null; 
	
	private String outFileName;

	private String activityName;
	
	private Logger logger = Logger.getLogger(XslTransform.class); 
	
	@Autowired
	private TempFileManager tempFileManager;

	//URI of the xsl to be used for transforming source XML
	private URI xslUri;
	
	private Map<String, URI> resolvedXSLUrisMap = new HashMap<String, URI>();;
		
	private String factoryClassName;

	private TransformerFactory transformerFactory;
		
	private final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();	
		
	private boolean passChannelParametersToXsl = false;

	/**
	 * used to pass parameters name and related XPath 
	 */
	private Map<String, String> xslParamNamesToXpathMap = new HashMap<String, String>();

	/**
	 * used to pass namespaces and their prefixes used in XML
	 */
	private Map<String, String> namespacePrefixUriMap = new HashMap<String, String>();

	public void setPassChannelParametersToXsl(boolean passChannelParametersToXsl) {
		this.passChannelParametersToXsl = passChannelParametersToXsl;
	}

	public void setXslParamNamesToXpathMap(Map<String, String> xslParamNamesToXpathMap) {
		this.xslParamNamesToXpathMap = xslParamNamesToXpathMap;
	}

	public void setNamespacePrefixUriMap(Map<String, String> namespacePrefixUriMap) {
		this.namespacePrefixUriMap = namespacePrefixUriMap;
	}

	@Autowired
	private URIHandlerRegistry uRIHandlerRegistry;

	public void setFactoryClassName(String factoryClassName) {
		this.factoryClassName = factoryClassName;
	}
	public void setOutFolderName(String outFolderName) {	
		this.outFolderName = outFolderName;
	}
	
	public void init() throws ParserConfigurationException{
		transformerFactory = TransformerFactory.newInstance(factoryClassName, null);
		
		documentBuilderFactory.setValidating(false);
		documentBuilderFactory.setNamespaceAware(true);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);  
		documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
	}
	
	public void setOutFileName(String outFileName) {
		this.outFileName = outFileName;
	}

	public void setXslt(String xslt) throws URISyntaxException {
		xslUri = convertInputToURI(xslt);	
	}
	
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] inData = publishingContext.getInputContentInfos(INPUT_CONTENT_NAME);

		if (inData == null || inData.length ==  0) {
			return;
		}
		
		for (int i = 0; i < inData.length; i++) {
			// Get Source XML on which transformation to be applied
			File xmlFile = inData[i].getFile();
			if (xslUri == null) {
				throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
						new String[] { "XSL URI is not valid." });
			}

			File xslFile = uRIHandlerRegistry.resolveToFile(publishingContext.getProcessId(), resolvedXSLUrisMap.get(publishingContext.getProcessId()));

			File outFile = null;
			if (outFolderName != null) {
				String outPutFileName = null;
				if(outFileName != null && !outFileName.isEmpty()){
					outPutFileName = outFileName;
				}else{
					outPutFileName = xmlFile.getName();
				}
				outFile = tempFileManager.getTempFileWithGivenName( outFolderName + "/" + outPutFileName , publishingContext.getProcessId());
			} else {
				if(outFileName != null && !outFileName.isEmpty()){
					outFile = tempFileManager.getTempFileWithGivenName( outFileName , publishingContext.getProcessId());
				}else{
					outFile = tempFileManager.getTemporaryFile( ".xml" , publishingContext.getProcessId());
				}
			}

			//get XSL parameters XML file
			ContentInfo[] xslParamSourceData = publishingContext.getInputContentInfos(INPUT_CONTENT_XSL_PARAM_FILE);

			File xslParamsXmlFile = null;
			// Checking parameter XML file is passed or not.
			if (xslParamSourceData != null && xslParamSourceData.length > 0) {
				xslParamsXmlFile = xslParamSourceData[0].getFile();
			}
			
			Map<String, Object> xslParamsMap = prepareXslParams(xslParamsXmlFile, passChannelParametersToXsl ? publishingContext.getAllChannelPublishingParameters() : null);
			xslTransform(xmlFile, xslParamsMap, xslFile, outFile);
			
			if(logger.isDebugEnabled()) {
				logDebugXML(xmlFile,outFile);				
			}
			
			URI uri = new URI("file", outFile.getAbsolutePath(), null);

			ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, uri, outFile);
			
			outContentInfo.setMimeType("text/xml");
			outContentInfo.setFileExtension("xml");	
			outContentInfo.setResourceName(outFile.getName());
		}
	}
	private void logDebugXML(File xmlFile, File outFile) throws FileNotFoundException, UnsupportedEncodingException, IOException {
		// if debug, then print input XML and transformed XML
		FileInputStream input = new FileInputStream(xmlFile);
		BufferedReader inputReader = new BufferedReader(new InputStreamReader(input,"UTF-8") );
		StringBuilder sb = new StringBuilder();
		String aLine = inputReader.readLine() ;
		while (aLine != null) {
			sb.append(aLine);
			aLine = inputReader.readLine();
		}
		logger.debug("Input XML:       " + sb.toString());
		inputReader.close();

		FileInputStream transformedStream = new FileInputStream(outFile);
		BufferedReader transformedXMLReader = new BufferedReader(new InputStreamReader(transformedStream, "UTF-8"));
		sb = new StringBuilder();
		aLine = transformedXMLReader.readLine();
		while (aLine != null) {
			sb.append(aLine);
			aLine = transformedXMLReader.readLine();
		}
		logger.debug("Transformed XML: " + sb.toString());
		transformedXMLReader.close();
	}

	
	public static void main(String[] args) {
		try{
	 	File xmlFile = new File("C:/temp/XA4.xml");
	 	File xslFile = new File("C:/temp/xsl/XACleanUp.xsl");
				
		BufferedReader reader = null;
		BufferedWriter writer = null;
		Transformer xmlToTextTransformer = null;

		TransformerFactory transformerFactory = TransformerFactory.newInstance("net.sf.saxon.TransformerFactoryImpl", null);
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();	
		try {
			xmlToTextTransformer = transformerFactory.newTransformer(new StreamSource(new FileInputStream(xslFile)));
		} catch (TransformerConfigurationException e) {
			throw new Exception("Error creating XSL Transformer.", e);
		}

		File file = new File("C:/out.xml");
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		try {
			InputStreamReader xmlReader = new InputStreamReader(new FileInputStream(xmlFile), "UTF-8");
			int firstChar = xmlReader.read();
			//If it is BOM ignore
			if(firstChar !=  65279){
				xmlReader = new InputStreamReader(new FileInputStream(xmlFile), "UTF-8");
			}
			reader = new BufferedReader(xmlReader);
			InputSource inputSource = new InputSource(reader);
			org.w3c.dom.Document doc = documentBuilderFactory.newDocumentBuilder().parse(inputSource);

			OutputStreamWriter textWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
			writer = new BufferedWriter(textWriter);
//			xmlToTextTransformer.setParameter("dependenciesFolder", xmlFile.getParent());
			xmlToTextTransformer.transform(new DOMSource(doc), new StreamResult(writer));
			writer.flush();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			try {
				reader.close();
			} catch (Exception e) {		
				e.printStackTrace();
			}
			try {
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
	
	private void xslTransform(File xmlFile, Map<String, Object> xslParamsMap, File xslFile, File outFile) throws Exception {
		BufferedReader reader = null;
		BufferedWriter writer = null;
		Transformer xmlToTextTransformer = null;

		try {
			InputStreamReader xslReader = new InputStreamReader(new FileInputStream(xslFile), "UTF-8");
//			transformerFactory.setFeature("encoding", true);
			xmlToTextTransformer = transformerFactory.newTransformer(new StreamSource(xslReader));
		} catch (TransformerConfigurationException e) {
			throw new Exception("Error creating XSL Transformer.", e);
		}
		
		FileOutputStream fileOutputStream = new FileOutputStream(outFile);
		InputStreamReader xmlReader = null;
		InputStream xmlFileInputStream = new FileInputStream(xmlFile);
		try {
			xmlReader = new InputStreamReader(xmlFileInputStream, "UTF-8");
			int firstChar = xmlReader.read();
			//If it is BOM ignore
			if(firstChar !=  65279){
				xmlFileInputStream.close();
				xmlFileInputStream = new FileInputStream(xmlFile);
				xmlReader = new InputStreamReader(xmlFileInputStream, "UTF-8");
			}
			reader = new BufferedReader(xmlReader);
			InputSource inputSource = new InputSource(reader);
			org.w3c.dom.Document doc = documentBuilderFactory.newDocumentBuilder().parse(inputSource);
			
			OutputStreamWriter textWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
			writer = new BufferedWriter(textWriter);
			String parentFolder =  xmlFile.getParent();//tempFileManager.getProcessIdFolder(processId);
			//Replace all backslash with forward slashes backslash does not work in XSL 
			parentFolder = parentFolder.replace('\\', '/');
			//Add XSL parameters
			if (xslParamsMap != null) {
				for (Entry<String, Object> param : xslParamsMap.entrySet()) {
					xmlToTextTransformer.setParameter(param.getKey(), param.getValue());
				}
			}
			xmlToTextTransformer.setParameter("dependenciesFolder", parentFolder+"/");
			xmlToTextTransformer.transform(new DOMSource(doc), new StreamResult(writer));
			writer.flush();
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
				if (xmlReader != null) {
					xmlReader.close();
				}
				if (xmlFileInputStream != null) {
					xmlFileInputStream.close();
				}
			} catch (Exception e) {		
				logger.error("Error closing stream: ",e);
			}
			try {
				if (writer != null) {
					writer.close();
				}
			} catch (Exception e) {
				logger.error("Error closing stream: ",e);
			}
		}		
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		URI resolvedXSLUri = null;
		String scheme = xslUri.getScheme();
		if(scheme.equalsIgnoreCase("param")){
			String paramName = resolveParameter(xslUri.toString(), context);
			if (paramName == null || paramName.isEmpty()) {
				throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER);
			}
			resolvedXSLUri = convertInputToURI(paramName);
		}
		else{
			resolvedXSLUri = xslUri;
		}
		resolvedXSLUrisMap.put(context.getProcessId(), resolvedXSLUri);
		
	}
	@Override
	public void clean(String processId) {
		try {
			uRIHandlerRegistry.clean(processId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		tempFileManager.cleanup(processId);
		resolvedXSLUrisMap.remove(processId);
	}
	
	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * Method for preparing XSL parameters
	 * @param paramsXmlFile
	 * @param channelParameters
	 * @return
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws XPathFactoryConfigurationException 
	 * @throws XPathExpressionException 
	 */
	private Map<String, Object> prepareXslParams(File xslParamsXmlFile, ChannelParameter[] channelParameters) throws XPathExpressionException, XPathFactoryConfigurationException, SAXException, IOException, ParserConfigurationException {
		Map<String, Object> xslParams = new HashMap<String, Object>();
		if (xslParamsXmlFile != null) {
			xslParams.putAll(extractXslParameters(xslParamsXmlFile));
		}

		if (channelParameters != null) {
			for (ChannelParameter channelParameter : channelParameters) {
				xslParams.put(channelParameter.getName(), channelParameter.getValue());
			}
		}
		return xslParams;
	}
	
	/**
	 * Method for retrieving XSL parameters using respective XPath from XML file
	 * 
	 * @param paramsXmlFile
	 * @return
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws XPathExpressionException 
	 * @throws XPathFactoryConfigurationException 
	 */
	private Map<String, Object> extractXslParameters(File xslParamsXmlFile) throws IOException, ParserConfigurationException, XPathExpressionException, XPathFactoryConfigurationException, SAXException {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		FileInputStream paramsFileStream = null;
		try {
			XPathFactory xPathfactory = XPathFactory.newInstance();
			paramsFileStream = new FileInputStream(xslParamsXmlFile);
			Document document = documentBuilderFactory.newDocumentBuilder().parse(paramsFileStream);
			XPath xPath = xPathfactory.newXPath();
			xPath.setNamespaceContext(new XaDocNamespaceContext(getDocumentNamespaces(document)));
			for (Map.Entry<String, String> paramXPath : xslParamNamesToXpathMap.entrySet()) {
				NodeList nodeList = (NodeList) xPath.compile(paramXPath.getValue()).evaluate(document.getDocumentElement(), XPathConstants.NODESET);
				paramsMap.put(paramXPath.getKey(), nodeList);
			}
		}
		finally {
			if (paramsFileStream != null) {
				paramsFileStream.close();
			}
		}
		return paramsMap;
	}

	

	public Map<String, String> getDocumentNamespaces(Document document) throws XPathFactoryConfigurationException, XPathExpressionException {
		Map<String, String> namespaceMap = new HashMap<String, String>();

		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();

		XPathExpression xpathExprs = xpath.compile("//namespace::*");
		NodeList nodeList = (NodeList) xpathExprs.evaluate(document, XPathConstants.NODESET);

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if (!namespaceMap.containsKey(node.getLocalName())) {
				namespaceMap.put(node.getLocalName(), node.getNodeValue());
			}
		}
		return namespaceMap;
	}
	
	private class XaDocNamespaceContext implements NamespaceContext {

		private Map<String, String> namespacesMap;
		
		public XaDocNamespaceContext(Map<String, String> namespacesMap) {
			this.namespacesMap = namespacesMap;			
		}

		public String getNamespaceURI(String prefix) {
			if (namespacesMap != null && namespacesMap.containsKey(prefix)) {
				return namespacesMap.get(prefix);
			} else if (namespacePrefixUriMap != null && namespacePrefixUriMap.get(prefix) != null) {
				return namespacePrefixUriMap.get(prefix);
			}
			return null;
		}

		public String getPrefix(String namespaceURI) {
			return null;
		}

		public Iterator getPrefixes(String namespaceURI) {
			return null;
		}

	}
}
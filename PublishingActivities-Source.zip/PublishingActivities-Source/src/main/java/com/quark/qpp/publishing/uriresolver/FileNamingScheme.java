/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import com.quark.qpp.core.asset.service.dto.AssetVersion;

public interface FileNamingScheme {

	String getSupportedNamingScheme();
	
	String resolveFileName(long assetId, AssetVersion assetVersion);

}

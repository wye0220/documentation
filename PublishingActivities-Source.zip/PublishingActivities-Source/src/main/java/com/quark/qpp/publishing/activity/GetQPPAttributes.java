/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateTimeValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.MeasurementValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.TimeValue;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;

/**
 * This activity retrieves the specified QPP attributes of an asset.
 * 
 * Prerequisites :
 * <li>assetIdValue : id of the asset whose attributes are to be retrieved. </li>
 * <li>attributeNames : list of attribute names to be retrieved.</li>
 * <p>
 * Name with which this activity expects input content is specified by {@link #SOURCE_ASSET}.The input content should
 * have asset file associated.
 * </p>
 * 
 * <p>
 * Name with which this activity emits content is specified by {@link #OUTPUT_ASSET}. The output content will have asset
 * file associated and the attributes fetched.
 * </p>
 * 
 */
public class GetQPPAttributes extends AbstractActivity{

	private String activityName;
	
	/*
	 * name with which this activity expects content
	 */
	private static final String SOURCE_ASSET = "Asset";
	
	/*
	 * name with which this activity emits content
	 */
	private static final String OUTPUT_ASSET = "AssetWithAttributes";
	private String assetId;
	
	/*
	 * list of attribute names whose values are to be retrieved
	 */
	private List<String> attributeNames;
	
	private Map<String, Long> assetIdValuesMap =  new HashMap<String, Long>();
	
	@Autowired
	private AssetService assetService;
	
	@Autowired
	private AttributeService attributeService;
	
	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void clean(String processId) {
		assetIdValuesMap.remove(processId);
	}
	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		long assetIdValue	= Long.parseLong(resolveParameter(assetId, publishingContext));
		assetIdValuesMap.put(publishingContext.getProcessId(), assetIdValue);
		if(attributeNames == null) {
			attributeNames = new ArrayList<String>(0);
		}
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		String processId = publishingContext.getProcessId();
		ContentInfo[] contentInfos = publishingContext
				.getInputContentInfos(SOURCE_ASSET);
		if (contentInfos == null || contentInfos.length > 1) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Input content with name '" + SOURCE_ASSET
							+ "' not found." });
		}
		ContentInfo asset = contentInfos[0];

		Map<Long,String> attributeIdNamesMap =  new HashMap<Long, String>(attributeNames.size());
		long[] attributeIds = new long[attributeNames.size()];
		int index = 0;
		for (String attributeName : attributeNames) {
			Attribute attribute = attributeService.getAttributeByName(attributeName);
			attributeIds[index++] = attribute.getId();
			attributeIdNamesMap.put(attribute.getId(), attributeName);
		}
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetIdValuesMap.get(processId), attributeIds);

		ContentInfo newAsset = publishingContext.registerOutputContentInfo(OUTPUT_ASSET, asset.getUri(), asset.getFile());

		for (AttributeValue attributeValue : attributeValues) {
			
			String value = "";
			int type = attributeValue.getType();
			
			switch (type) {
			case AttributeValueTypes.NUMERIC:
				value = ((NumericValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.TEXT:
				value = ((TextValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.BOOLEAN:
				value = ((BooleanValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.DATE:
				value = ((DateValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.DOMAIN:
				value = ((DomainValue) attributeValue.getAttributeValue()).getName();
				break;
			case AttributeValueTypes.DATETIME:
				value = ((DateTimeValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.TIME:
				value = ((TimeValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.MEASUREMENT:
				value = ((MeasurementValue) attributeValue.getAttributeValue()).getValue()+"";
				break;
			default:
				break;
			}
			newAsset.setAttribute(attributeValue.getAttributeId() + "", value);
			newAsset.setAttribute(attributeIdNamesMap.get(attributeValue.getAttributeId()) + "", value);
		}
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setAttributeNames(List<String> attributeNames) {
		this.attributeNames = attributeNames;
	}

	
}

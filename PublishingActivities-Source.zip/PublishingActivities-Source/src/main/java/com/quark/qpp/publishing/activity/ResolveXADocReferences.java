/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinPool.ForkJoinWorkerThreadFactory;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.quark.qpp.common.context.SessionContextHolder;
import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentIdentifier;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.relation.service.constants.DefaultRelationTypes;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.office.service.constants.ExcelDataObjectTypes;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.util.AssetIdentityInfo;
import com.quark.qpp.publishing.util.QppAssetsUriUtility;
import com.quark.qpp.publishing.util.TempFileManager;


/**
 * An activity to resolve XA document references. References are resolved in two ways:
 * <li> By parsing the XML file and looking for href/conref.
 * <li> If the AssetID parameter is provided, then resolving the references using QPP relations.
 * <BR/>  <BR/>
 * <p>
 * Prerequisites :
 * <li>assetId : id of the XA asset if the references are to be resolved from the relations in QPP Server.</li>
 * <li>attachmentAttributeNames : names of the QPP attributes to be retrieved for attachments</li>
 * <br><br>
 * This activity requires XA document content with the name specified by {@link #inContentName}.
 * <br><br>
 * This activity emits content with the names :
 * <li>Updated main XA document with name specified by {@link #OUT_UPDATED_MAIN_DOC_NAME}</li>
 * <li>XML attachments that are represented by {@link #OUT_XML_ATTACHMENT_NAME}</li>
 * <li>Non XML attachments that are represented by {@link #OUT_NON_XML_ATTACHMENT_NAME} </li>
 * </p>
 *
 */
public class ResolveXADocReferences extends AbstractActivity {

	private Logger logger = Logger.getLogger(ResolveXADocReferences.class);

	/*
	 * XPATH used to find all elements having references to other XML.
	 * The references are obtained from elements having values for attribute 'href' or 'conref'.
	 * In case of 'xref' element, the reference is considered for further resolution only if
	 * either format attribute is not present or @format value is 'dita' or 'ditamap'
	 */
	private String xpathExpression = "//*[@href][not(local-name()='xref')] | //*[@conref] | //xref[not(@format) or @format='dita' or @format='ditamap']";

	private String[] referenceFileExtensions = { ".xml", ".dita", ".xls", ".xlt", ".xla", ".ppt", ".pps", ".ppa", ".pot", ".vsd", ".vst", ".vss", ".vdx", ".vtx", ".vsx", ".vdw" };

	private List<String>  referenceAttributesList = null;
	
	/*
	 * Map of image rendering parameters map for Charts image, Excel image, Visio image and PowerPoint image.
	 * These parameters are overridden in all the excel, visio or powerpoint data or charts referred URLs
	 */
	private Map<String, Map<String, String>> dataRenderingParametersMap;

	public void setDataRenderingParametersMap(
			Map<String, Map<String, String>> dataRenderingParametersMap) {
		this.dataRenderingParametersMap = dataRenderingParametersMap;
	}

	private Map<String, String> namespacePrefixUriMap = null;

	private String activityName;

	private Map<String, String> xpathToFileExtMapForBinaryImages = new HashMap<String, String>();

	private String binaryImageRefAttribute = "href"; //default value

	//Charts image rendering parameters map. These parameters are overridden in all the charts data referred URLs 
	private Map<String, String> chartRenderingParametersMap;
	
	/*
	 * Max parallelism count refers to 
	 * 1. the maximum number of parallel threads to resolve URIs into files [FixedPoolTasks] and 
	 * 2. the maximum number of parallel threads for ResolveFileReferences tasks [ForkJoinTasks]
	 * 
	 * By default, equal to twice the number of available processors.
	 */
	private String maxParallelism = String.valueOf(2 * availableProcessors);
	
	public String getMaxParallelism() {
		return maxParallelism;
	}

	public void setChartRenderingParametersMap(
			Map<String, String> chartRenderingParametersMap) {
		this.chartRenderingParametersMap = chartRenderingParametersMap;
	}
	
	public void setMaxParallelism(String maxParallelism) {
		this.maxParallelism = maxParallelism;
	}

	//Excel data image rendering parameters map. These parameters are overridden in all the excel data referred URLs 
	private Map<String, String> excelDataRenderingParametersMap;
	
	public void setExcelDataRenderingParametersMap(Map<String, String> excelDataRenderingParametersMap) {
		this.excelDataRenderingParametersMap = excelDataRenderingParametersMap;
	}

	public void setBinaryImageRefAttribute(String binaryImageRefAttribute) {
		this.binaryImageRefAttribute = binaryImageRefAttribute;
	}

	@Autowired
	private TempFileManager fileManager;

	@Autowired
	private QppAssetsUriUtility qppAssetsUriUtility;

	@Autowired
	AssetService assetService;

	@Autowired
	ContentStructureService contentStructureService;

 	@Autowired
	private AttributeService attributeService;

	private String namingScheme;

	private String assetId;
	
	private String resolveQppRelations;
	
	/*
	 * Evaluate availableProcessors in order to use this value for spawning reference resolution threads.
	 */
	private static final int availableProcessors = Runtime.getRuntime().availableProcessors();
	
	public void setResolveQppRelations(String resolveQppRelations) {
		this.resolveQppRelations = resolveQppRelations;
	}

	private String removeCdataSection ;

	public void setRemoveCdataSection(String removeCdataSection) {
		this.removeCdataSection = removeCdataSection;
	}

	private Map<String, Long> resolvedAssetIdsMap = new HashMap<String, Long>();

	private List<String> attachmentAttributeNames;

	@Autowired
	private URIHandlerRegistry uRIHandlerRegistry;

	public void setXpathToFileExtMapForBinaryImages(Map<String, String> xpathToFileExtMapForBinaryImages) {
		this.xpathToFileExtMapForBinaryImages = xpathToFileExtMapForBinaryImages;
	}

	public void setXpathExpression(String xpathExpression) {
		this.xpathExpression = xpathExpression;
	}

	public void setNamespacePrefixUriMap(Map<String, String> namespacePrefixUriMap) {
		this.namespacePrefixUriMap = namespacePrefixUriMap;
	}

	public void setReferenceAttributesList(List<String> referenceAttributesList) {
		this.referenceAttributesList = referenceAttributesList;
	}

	/*
	 * name with which this activity expects content
	 */
	private static final String inContentName = "XaDoc";

	/*
	 * name with which this activity emits content
	 */
	private static final String OUT_UPDATED_MAIN_DOC_NAME = "UpdatedXaDoc";
	private static final String OUT_XML_ATTACHMENT_NAME = "XmlAttachment";
	private static final String OUT_NON_XML_ATTACHMENT_NAME = "NonXmlAttachment";

	private final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public void setNamingScheme(String namingScheme) {
		this.namingScheme = namingScheme;
	}

	public void setAttachmentAttributeNames(List<String> attachmentAttributeNames) {
		this.attachmentAttributeNames = attachmentAttributeNames;
	}
	
	static{
		Logger logger = Logger.getLogger(ResolveXADocReferences.class);
		logger.info("The number of processors available: " + Runtime.getRuntime().availableProcessors());
	}

	public ResolveXADocReferences() throws ParserConfigurationException {
		documentBuilderFactory.setValidating(false);
		documentBuilderFactory.setNamespaceAware(true);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);  
		documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

	}

	@Override
	public void execute(PublishingContext publishingContext) throws InvalidAssetException, QppServiceException, Exception {

		FileOutputStream fos = null;
		FileInputStream origContentStream = null;
		try {
			long assetId = resolvedAssetIdsMap.get(publishingContext.getProcessId());
			ContentInfo[] inData = publishingContext.getInputContentInfos(inContentName);
			if (inData == null || inData.length == 0) {
				// No attachments available for the given asset
				return;
			}
			// get first input from array
			ContentInfo inputXmlInfo = inData[0];

			if (inputXmlInfo == null) {
				throw new Exception("REQUIRED CONTENT NOT FOUND");
			}

			String fileExtension = null;

			long contentType = getContentType(inputXmlInfo.getFile());
			if(contentType == DefaultContentTypes.DITA_MAP || contentStructureService.isValidAncestor(DefaultContentTypes.DITA_MAP, contentType)){
				fileExtension = "ditamap";
			}else if(contentType == DefaultContentTypes.XML || contentStructureService.isValidAncestor(DefaultContentTypes.XML, contentType)){
				fileExtension = "xml";
			}else{
				throw new PublishingException(PublishingExceptionCodes.INVALID_CONTENT);
			}

			// Copy data to temp location first to change references - href & conref
			File ditaUpdatedFile = fileManager.getTemporaryFile("." + fileExtension, publishingContext.getProcessId());
			fos = new FileOutputStream(ditaUpdatedFile);
			origContentStream = new FileInputStream(inputXmlInfo.getFile());
			pipe(origContentStream, fos);
			fos.close();
			origContentStream.close();

			removeCDataSection(ditaUpdatedFile, publishingContext);
			
			boolean resolveQppRelationsBoolean = true;
			String resolveQppRelationsValue = resolveParameter(resolveQppRelations, publishingContext);
			if(resolveQppRelationsValue != null && !resolveQppRelationsValue.trim().isEmpty()){
				resolveQppRelationsBoolean = Boolean.parseBoolean(resolveQppRelationsValue);
			}
						
			/*
			 * Reference resolution through Parallelism ...
			 */
			int maxParallelism = resolveMaxParallelism(publishingContext);
			
			FixedPoolThreadFactory fixedPoolThreadFactory = new FixedPoolThreadFactory(publishingContext.getProcessId());
			ForkJoinThreadFactory forkJoinPoolThreadFactory = new ForkJoinThreadFactory(publishingContext.getProcessId());
			
			ExecutorService fixedThreadPool = null;
			ForkJoinPool forkJoinPool = null;
			try {
				
				//The fixed thread pool will be used only to resolve given URIs to files.
				fixedThreadPool = Executors.newFixedThreadPool(maxParallelism, fixedPoolThreadFactory);
				
				/*
				 * Set the asyncMode to true only when the tasks are independent
				 * of each other i.e. no fork/join processing required.
				 * http://stackoverflow.com/questions/5640046/what-is-forkjoinpool-async-mode
				 */
				
				// The ForkJoinPool will be used to initiate a task to resolve a
				// file's references and recursively initiating subtasks to
				// resolve references in references.
				forkJoinPool = new ForkJoinPool(maxParallelism, forkJoinPoolThreadFactory, null, false/*asyncMode*/);
				
				String referredURI = "";
				
				if (assetId > 0 && resolveQppRelationsBoolean) {
					
					URI inputContentURI = inputXmlInfo.getUri();
					
					AssetIdentityInfo assetIdentityInfo = qppAssetsUriUtility.parseQppUri(inputContentURI);
					
					Asset asset = null;
					
					if (assetIdentityInfo.getAssetVersion() != null) {
						// Asset version has been picked from the QPP URI supplied
						asset = assetService.getAssetVersion(assetId, assetIdentityInfo.getAssetVersion());
					} else {
						//There are scenarios where assetVersion is not populated in AssetIdentityInfo.
						asset = assetService.getAsset(assetId);
					}
					
					//we need to create referredURI because relations are processed only for QPP uris's.
					referredURI = "qpp://assets/" + assetId + "?majorversion=" + asset.getAssetVersion().getMajorVersion() + "&minorversion="
							+ asset.getAssetVersion().getMinorVersion();
				}
				
				initiateReferencesResolution(ditaUpdatedFile, publishingContext, forkJoinPool, fixedThreadPool, true, referredURI, resolveQppRelationsBoolean );
			} finally {
				if (fixedThreadPool != null) {
					fixedThreadPool.shutdown();
				}
				if (forkJoinPool != null) {
					forkJoinPool.shutdown();
				}
			}
			ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUT_UPDATED_MAIN_DOC_NAME,
					convertInputToURI("file://" + ditaUpdatedFile.getAbsolutePath()), ditaUpdatedFile);

			outContentInfo.setMimeType("text/xml");
			outContentInfo.setFileExtension(fileExtension);
			outContentInfo.setResourceName(ditaUpdatedFile.getName());

		} finally {
			if (fos != null)
				fos.close();
			if (origContentStream != null)
				origContentStream.close();
		}
	}

	private void initiateReferencesResolution(File ditaUpdatedFile, PublishingContext publishingContext, ForkJoinPool forkJoinPool, ExecutorService executorService, boolean isXMLDoc, String referredURI, boolean resolveQppRelationsBoolean) {
		/*
		 * Map containing list of already resolve URIs
		 */
		Map<String, File> resolvedURIsMap = Collections.synchronizedMap(new HashMap<String, File>());
		/*
		 * In case a URI does not exist in resolved URI map, there may be a
		 * chance that two parallel threads might begin at the same time to
		 * resolve a URI for a process. Thus to avoid this, tasksAlreadyCreated
		 * map ensures no two ResolveFileReferencesTask are initiated for the
		 * same URI.
		 */
		Map<String, ResolveFileReferencesTask> tasksAlreadyCreated = Collections.synchronizedMap(new HashMap<String, ResolveFileReferencesTask>());
		ResolveFileReferencesTask resolveTask = new ResolveFileReferencesTask(ditaUpdatedFile, publishingContext, resolvedURIsMap, executorService, tasksAlreadyCreated, SessionContextHolder.getSessionContext(), isXMLDoc, referredURI, resolveQppRelationsBoolean);
		
		logger.trace("Initiating references resolution process for process ID : " + publishingContext.getProcessId());
		
		//A ForkJoinPool provides the entry point for submissions from non-ForkJoinTask clients.
		forkJoinPool.invoke(resolveTask);
		
	}

	/*
	 * The number of threads to run in parallel for ResolveURITask and
	 * ResolveFileReferencesTask. By default, equal to twice the number of
	 * available processors
	 */
	private int resolveMaxParallelism(PublishingContext publishingContext) {
		String maxParallelismStr = resolveParameter(maxParallelism, publishingContext);
		int maxParallelism = (int) (2 * availableProcessors);
		if (maxParallelismStr != null && maxParallelismStr.trim().length() > 0) {
			try {
				if (Integer.valueOf(maxParallelismStr) > 0) {
					maxParallelism = Integer.valueOf(maxParallelismStr);
				} else {
					logger.error("The input maxParallelism count is not a valid number.Therefore maxParallelism has been set to : " + maxParallelism + " for Process ID : "
							+ publishingContext.getProcessId());
				}
			} catch (NumberFormatException e) {
				logger.error("The input maxParallelism count is not a valid number.Therefore maxParallelism has been set to : " + maxParallelism + " for Process ID : "
						+ publishingContext.getProcessId(), e);
			}
		}
		logger.debug("The maxParallelism count has been set to " + maxParallelism);
		return maxParallelism;
	}

	private void removeCDataSection(File file, PublishingContext publishingContext) throws Exception {
		String resolvedCdataRemovalFlag = resolveParameter(removeCdataSection, publishingContext);
		
		//resolvedCdataRemovalFlag null means legacy behavior - which should be true
		if(resolvedCdataRemovalFlag != null && "false".equalsIgnoreCase(resolvedCdataRemovalFlag)){
			return;
		}
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(file);
			DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
			Document doc = builder.parse(inputStream);
			// Use XPATH to find all references to other XML.
			NodeList nodelist = (NodeList) executeXPathOnDocument(doc, "//*/text()", XPathConstants.NODESET);
			for (int j = 0; j < nodelist.getLength(); j++) {
				Node node = nodelist.item(j);

				if (node != null && node.getNodeType()== Node.CDATA_SECTION_NODE ){
					node.getParentNode().removeChild(node);
				}
			}
			writeDocumentToFile(doc, file);
		}
		finally{
			if (inputStream != null)
				inputStream.close();
		}
	}

	public static void main(String[] args) {
		try {
			ResolveXADocReferences g = new ResolveXADocReferences();
			g.resolveAndUpdateReferences(new File("C:\\\\temp\\map.xml"),  null, null, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method does the following:
	 * - Reads the given source XML for any href/conref and resolve them using framework's uri-resolver capabilities.
	 * - For qpp URIs, resolve references using relations in QPP and update the XML with appropriate qpp URIs.
	 * - This method is called recursively for resolving the references either qpp or non-qpp and update the hrefs/conrefs of the given XML with the local file paths as resolved by the underlying URI resolver.
	 *
	 * @param file
	 *            Source XML file whose references need to be resolved.
	 * @param publishingContext
	 * @param resolvedUriMap
	 *            Map of URI against local resolved File, which are already
	 *            resolved, to avoid any cyclic dependencies
	 * @param executorService
	 *            an instance of Executor to resolve references
	 * @param tasksAlreadyCreated
	 *            map containing list of reference resolution tasks already
	 *            forked to prevent duplicate tasks for a URI.
	 * @param refAssetId
	 *            the referred Asset ID
	 * @throws Exception
	 */
	private void resolveAndUpdateReferences(File file, PublishingContext publishingContext, Map<String, File> resolvedUriMap, ExecutorService executorService,
			Map<String, ResolveFileReferencesTask> tasksAlreadyCreated) throws Exception {
			Document doc = createDocumentFromFile(file, publishingContext.getProcessId());
			// Use XPATH to find all references to other XML.
			NodeList conrefNodeList = (NodeList) executeXPathOnDocument(doc, xpathExpression, XPathConstants.NODESET);
			ArrayList<ReferredAttrNodeInfo> refAttrNodesInfoList =  createReferredNodesInfoList(publishingContext, conrefNodeList);
		
			//unique set of URIs to be resolved
			ArrayList<URI> urisToBeResolved = new ArrayList<URI>();
			
			//Map to maintain mapping of referredFileIdentity with index of future object to be explored for resolved file.
			HashMap<String, Integer> referredFileIdentityVsFutureIndexMap = new HashMap<String, Integer>();
			int index = 0;
			for (int j = 0; refAttrNodesInfoList != null && j < refAttrNodesInfoList.size(); j++) {
				 String referredFileIdentity = refAttrNodesInfoList.get(j).referedFileIdentity;
				 if(resolvedUriMap.get(referredFileIdentity) == null){
					 //check if this file has not been already added for resolving.If not only then add to urisToBeResolved list.
					if (!referredFileIdentityVsFutureIndexMap.containsKey(referredFileIdentity)) {
						URI uri = refAttrNodesInfoList.get(j).uriObject;
						//add to the list to resolve uri
						urisToBeResolved.add(uri);
						//add to the map the index of future object to be looked later for resolved file.
						referredFileIdentityVsFutureIndexMap.put(referredFileIdentity, index);
						index = index +1;
					}
				 }
			}
			
			//resolve uri's to files through parallelism via FixedPool
			List<Future<File>> futures = resolveURIs(publishingContext.getProcessId(), urisToBeResolved, executorService);
			ArrayList<ResolveFileReferencesTask> childTasksForked = new ArrayList<ResolveXADocReferences.ResolveFileReferencesTask>();
			
			ArrayList<ReferredAttrNodeInfo> pendingNodes = refAttrNodesInfoList;
			
			while (pendingNodes.size() > 0) {
				ArrayList<ReferredAttrNodeInfo> processedNodes = new ArrayList<ResolveXADocReferences.ReferredAttrNodeInfo>();
				for (int i = 0; i < refAttrNodesInfoList.size(); i++) {
					ReferredAttrNodeInfo referredAttrNodeInfo = refAttrNodesInfoList.get(i);
					long refAssetId = referredAttrNodeInfo.refAsset==null?-1:referredAttrNodeInfo.refAsset.getAssetID();
					boolean processed = processReferredNode(publishingContext, resolvedUriMap, executorService, tasksAlreadyCreated, referredFileIdentityVsFutureIndexMap, futures,
							referredAttrNodeInfo, childTasksForked, refAssetId);
					if (processed) {
						processedNodes.add(referredAttrNodeInfo);
					}
				}
				for (int i = 0; i < processedNodes.size(); i++) {
					pendingNodes.remove(processedNodes.get(i));
				}
			}
			
			resolveAndUpdateDocumentWithBinaryImages(doc, publishingContext);
			writeDocumentToFile(doc, file);
			
			for (int j = 0; j < childTasksForked.size(); j++) {
				//join() that doesn't proceed until the task's result has been computed
				childTasksForked.get(j).join();
			}
			
	}

	private void processChildren(long refAssetID, File referredFile, ReferredAttrNodeInfo referredAttrNodeInfo, PublishingContext publishingContext, Map<String, ResolveFileReferencesTask> tasksAlreadyCreated, 
			Map<String,File> resolvedUriMap, ExecutorService executorService, ArrayList<ResolveFileReferencesTask> childTasksForked) throws Exception {
		
		boolean isXMLDoc = false;
		long contentTypeId = getContentType(referredFile);
		if (isXMLDocument(contentTypeId)) {
			isXMLDoc = true;					
		}
		
		String contentName = null;
		if (isXMLDoc) {
			/*
			 * Following synchronized block ensures no two threads at
			 * the same time submit ResolveFileReferencesTask for the
			 * same referred file.
			 * 
			 * Use the synchronized map "tasksAlreadyCreated" to check
			 * whether there already exists a task for the referred file
			 * or not.
			 */
			synchronized (tasksAlreadyCreated) {
				String referedFileIdentity = referredAttrNodeInfo.referedFileIdentity;
				if (!tasksAlreadyCreated.containsKey(referedFileIdentity)) {
					String referredURI = referredAttrNodeInfo.referredURI;
					ResolveFileReferencesTask resolveFileRefsTask = new ResolveFileReferencesTask(referredFile, publishingContext, resolvedUriMap, executorService, tasksAlreadyCreated, SessionContextHolder.getSessionContext(), isXMLDoc, referredURI, true);
					resolveFileRefsTask.fork();
					logger.trace("Forked a new ResolveFileReferencesTask for ProcessID: "+publishingContext.getProcessId()+" URI: "+referredURI);
					childTasksForked.add(resolveFileRefsTask);
					tasksAlreadyCreated.put(referedFileIdentity, resolveFileRefsTask);
				}
			}
			contentName = OUT_XML_ATTACHMENT_NAME;
		} else {
			contentName = OUT_NON_XML_ATTACHMENT_NAME;
		}

		
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(contentName, convertInputToURI("file://" + referredFile.getAbsolutePath()),
				referredFile);

		//If QPP asset then set QPP attributes specified in the config
		if (refAssetID > 0) {
			setQPSAttributes(refAssetID, contentInfo);
		}
		
	}

	private Document createDocumentFromFile(File file, String processID) throws ParserConfigurationException, FileNotFoundException, SAXException, IOException {
		Document doc = null;
		InputStream inputStream = null;
		DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
		try {
			inputStream = new FileInputStream(file);
			doc = builder.parse(inputStream);
		} finally {
			inputStream.close();
		}
		return doc;
	}

	private boolean processReferredNode(PublishingContext publishingContext, Map<String, File> resolvedUriMap, ExecutorService executorService, 
			Map<String, ResolveFileReferencesTask> tasksAlreadyCreated, HashMap<String, Integer> referredFileIdentityVsFutureIndexMap, List<Future<File>> futures, ReferredAttrNodeInfo referredAttrNodeInfo, ArrayList<ResolveFileReferencesTask> childTasksForked, long refAssetID) throws PublishingException {
		Node n = referredAttrNodeInfo.attrNode;
		String referredElementId = referredAttrNodeInfo.referredElementId;
		String referedFileIdentity = referredAttrNodeInfo.referedFileIdentity;
		String hrefValue = n.getNodeValue();
		try {
			//There could have been an exception while creating referred node.If there was an exception, exit by throwing.
			if(referredAttrNodeInfo.exception != null){
				throw referredAttrNodeInfo.exception;
			}
			
			File referredFile = null;
			
			// If File containing URI content is available in the map, use it.
			if ((referredFile = resolvedUriMap.get(referedFileIdentity)) != null) {
				n.setNodeValue(referredFile.getAbsolutePath() + referredElementId);
					return true;
				}

			int futureIndex = referredFileIdentityVsFutureIndexMap.get(referedFileIdentity);
		    
			if (futures.get(futureIndex).isDone()) {
				referredFile = futures.get(futureIndex).get();
				if (referredFile == null || !referredFile.exists() || referredFile.length() <= 0) {
					return true;
				}
			} else {
				return false;
			}
			
			
			n.setNodeValue(referredFile.getAbsolutePath() + referredElementId);
			// Cache resolved File and URI into a map for efficient retrieval later and to prevent cycles.
			resolvedUriMap.put(referedFileIdentity, referredFile);
			
			processChildren(refAssetID, referredFile, referredAttrNodeInfo, publishingContext, tasksAlreadyCreated, resolvedUriMap, executorService, childTasksForked);
			
			return true;			
			
		} catch (URISyntaxException e) {
			logger.error("Error converting reference string to URI : "+hrefValue, e);
		} catch (PublishingException e) {
			if (e.getExceptionCode().equalsIgnoreCase(PublishingExceptionCodes.DATA_NOT_ACCESSIBLE)) {
				logger.error("Error while accesssing data for URI : "+hrefValue, e);
				n.setNodeValue(PublishingExceptionCodes.DATA_NOT_ACCESSIBLE+":"+hrefValue);	
			}
			else if (e.getExceptionCode().equalsIgnoreCase(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI)) {
				logger.error("Error while resolving URI : "+hrefValue,e);
				n.setNodeValue(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI+":"+hrefValue);	
			}
			// If there is no URI Resolver found for this URI - simply ignore and proceed ahead. In case of any exception propagate the exception.
			else if (!e.getExceptionCode().equalsIgnoreCase(PublishingExceptionCodes.NO_URI_RESOLVER_FOUND)) {
				throw e;
			}
		}
		catch (Exception e) {
			//In case of any unknown exception thrown by the resolver - don't fail publishing of the whole document, rather fail this reference rendering and keep on resolving other references.
			logger.error("Unknown exception by the resolver while processing the URI : "+hrefValue,e);
			n.setNodeValue(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI+":"+hrefValue);	
		}
		return true;
	}

	/**
	 * Resolve URIs through parallelism.
	 * 
	 * @param publishingProcesId
	 *            Id of the publishing process
	 * @param urisToBeResolved
	 *            unique list of URIs to be resolved
	 * @param executorService
	 *            an instance of Executor
	 * @return List of future objects holding tasks results.
	 */
	private List<Future<File>> resolveURIs(String publishingProcesId, ArrayList<URI> urisToBeResolved, ExecutorService executorService) {
		List<Future<File>> futures = new ArrayList<Future<File>>();
		if (urisToBeResolved != null && urisToBeResolved.size() > 0) {
			SessionContext sessionContext = SessionContextHolder.getSessionContext();
			for (int i = 0; i < urisToBeResolved.size(); i++) {
				ResolveURITask resolveURITask = new ResolveURITask(publishingProcesId, urisToBeResolved.get(i), sessionContext);
				// Used submit as it is a non blocking call to resolve a
				// reference.
				Future<File> future = executorService.submit(resolveURITask);
				futures.add(future);
			}
		}
		return futures;
	}

	/**
	 * Creates list of href/conref/... attribute nodes corresponding to the referred nodes.
	 */
	private ArrayList<ReferredAttrNodeInfo> createReferredNodesInfoList(PublishingContext publishingContext, NodeList conrefNodeList) throws Exception {
		ArrayList<ReferredAttrNodeInfo> refAttrNodesInfoList = new ArrayList<ReferredAttrNodeInfo>();

		for (int j = 0; conrefNodeList != null && j < conrefNodeList.getLength(); j++) {
			Node node = conrefNodeList.item(j);
			Node refAttributeNode = getReferredAttributeNode(node);
			if (refAttributeNode == null) {
				// If there is no corresponding reference attribute then this
				// node would be null. In this case we need to go ahead and
				// ignore this. Fixed as a part of IHS issue.
				continue;
			}
			String referredElementId = null;
			String referredURI = null;
			String referedFileIdentity = null;
			URI uriObject = null;
			Exception exception = null;
			try {
				URI referredURIObject = null;
				String hrefValue = refAttributeNode.getNodeValue();
				referredElementId = getReferredElementId(hrefValue);
				referredURI = getReferredURI(hrefValue, publishingContext);
				referredURIObject = convertInputToURI(referredURI);
				String scheme = referredURIObject.getScheme();

				/**If there is no scheme, use file as the default scheme. This is done to solve following two cases:
				 * 1. XA used to set the file name in href/conref when the local files are refereed at client side and all of the dependent files are sent in the zip.
				 * 2. When related QPP asset is deleted and hence its relation, but reference to that content is still there in the document physical file with its asset name.
				 * Here case1 should be successfully resolved whereas case2 should print error code in that href/conref.
				**/
				if (scheme == null || scheme.trim().isEmpty()) {
					referredURI = "file://" + referredURI;
					referredURIObject = convertInputToURI(referredURI);
				}

				referedFileIdentity = uRIHandlerRegistry.getResourceIdentity(referredURIObject);

				if (referredURI.startsWith("qpp:")) {
					URI uri = convertInputToURI(referredURI);
					uriObject = new URI(uri.getScheme(), uri.getSchemeSpecificPart(), "namingScheme=" + namingScheme);
				} else {
					uriObject = convertInputToURI(referredURI);
				}
			} catch (Exception e) {
				// Preserve the exception here, so that while processing each
				// refAttributeNode later, we need to throw this exception if
				// an exception has occurred.
				exception = e;
			}
			ReferredAttrNodeInfo referredAttrNodeInfo = new ReferredAttrNodeInfo(refAttributeNode, referredURI, referredElementId, referedFileIdentity, uriObject, publishingContext, exception);
			refAttrNodesInfoList.add(referredAttrNodeInfo);
		}
		return refAttrNodesInfoList;
	}

	private Node getReferredAttributeNode(Node node) throws XPathFactoryConfigurationException, XPathExpressionException {
		Node referenceNode = null;
		for (Iterator iterator = referenceAttributesList.iterator(); iterator.hasNext();) {
			String  attribute= (String) iterator.next();

			String namespaceUri = null;
			String attrName = null;

			String[] parts = attribute.split(":");
			if(parts.length == 2){
				String attrPrefix = parts[0];
				namespaceUri = getNameSpaceURIFromPrefix(node.getOwnerDocument(), attrPrefix);;
				attrName = parts[1];
			}else if(parts.length == 1){
				attrName = parts[0];
			}

			if(namespaceUri != null){
				referenceNode = node.getAttributes().getNamedItemNS(namespaceUri, attrName);
			}else{
				referenceNode = node.getAttributes().getNamedItem(attrName);
			}
			if (referenceNode != null) {
				return referenceNode;
			}
		}
		return null;
	}

	private String getNameSpaceURIFromPrefix(Document document, String attrPrefix) throws XPathFactoryConfigurationException,
			XPathExpressionException {
		Map<String, String> map = getDocumentNamespaces(document);
		// first try to get the namespaceuri from the namespaces found in the source document. If not fpound then look for namespaceuri in
		// map namespacePrefixUriMap which can be defined in the beans's declaration xml file as a map property having prefix to namespaceuri entries.
		if (map.get(attrPrefix) != null) {
			return map.get(attrPrefix);
		} else {
			if (namespacePrefixUriMap != null) {
				return namespacePrefixUriMap.get(attrPrefix);
			} else {
				return null;
			}
		}
	}

	private long getContentType(File file) throws IOException, QppServiceException {
		FileInputStream fis = null;
		byte[] initialBytes = null;
		try {
			fis = new FileInputStream(file);
			initialBytes = new byte[4096];
			fis.read(initialBytes);
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		ContentIdentifier contentIdentifier = contentStructureService.getContentIdentifier(null, null, initialBytes);
		return contentIdentifier.getContentTypeId();
	}

	private void resolveAndUpdateDocumentWithBinaryImages(Document doc, PublishingContext publishingContext) throws IOException,
			PublishingException, URISyntaxException, XPathFactoryConfigurationException, XPathExpressionException {
		if (xpathToFileExtMapForBinaryImages != null && xpathToFileExtMapForBinaryImages.size() > 0) {
			for (String xpathExpression : xpathToFileExtMapForBinaryImages.keySet()) {
				String fileExtension = xpathToFileExtMapForBinaryImages.get(xpathExpression);
				executeXpathAndUpdateDocForBinaryImages(xpathExpression, fileExtension, doc, publishingContext);
			}
		}else{
			//If the xpath map is not defined, resolve any equation image written by XA.
			//This is just a fallback incase activity definition does not the property xpathToFileExtMapForBinaryImages
			executeXpathAndUpdateDocForBinaryImages("//image[not(@href) and @content-type='gif']", "gif", doc, publishingContext);
		}
	}

	private void executeXpathAndUpdateDocForBinaryImages(String xpathExpression, String fileExtension, Document doc,
			PublishingContext publishingContext) throws XPathFactoryConfigurationException, XPathExpressionException, IOException,
			PublishingException, URISyntaxException {
		NodeList refNodeList = (NodeList) executeXPathOnDocument(doc, xpathExpression, XPathConstants.NODESET);
		for (int j = 0; refNodeList != null && j < refNodeList.getLength(); j++) {
			Node imageNode = refNodeList.item(j);
			String nodeData = imageNode.getTextContent();
			if (nodeData != null) {
				// Write data to file
				File imageFile = fileManager.getTemporaryFile("." + fileExtension, publishingContext.getProcessId());

				Base64 base64Decoder = new Base64();
				writeToFile(base64Decoder.decode(nodeData.getBytes(Charset.forName("UTF-8"))), imageFile);
				
				// Create reference attribute and populate it with the path of the image file created from the data.
				Attr referenceAttribute = null;
				String namespaceUri = null;
				String attrName = null;
				String[] parts = binaryImageRefAttribute.split(":");

				if (parts.length == 2) {
					// If the attribute defined contains some prefix then try to find the corresponding namespace uri and create attribute
					// with the appropriate namespace
					String attrPrefix = parts[0];
					namespaceUri = getNameSpaceURIFromPrefix(doc, attrPrefix);
					;
					attrName = parts[1];
				} else if (parts.length == 1) {
					attrName = parts[0];
				}

				if (namespaceUri == null) {
					referenceAttribute = doc.createAttribute(attrName);
				} else {
					referenceAttribute = doc.createAttributeNS(namespaceUri, attrName);
				}

				referenceAttribute.setNodeValue(imageFile.getName());
				((Element) imageNode).setAttributeNode(referenceAttribute);
				imageNode.setTextContent("");
				publishingContext.registerOutputContentInfo(OUT_NON_XML_ATTACHMENT_NAME,
						convertInputToURI("file://" + imageFile.getAbsolutePath()), imageFile);
			}
		}
	}

	private void writeToFile(byte[] imageBytes, File imageFile) throws IOException {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(imageFile);
			fos.write(imageBytes);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	private String getReferredElementId(String refValue) {
		String referredId = "";
		if(refValue != null && refValue.contains("#")) {
			for(int i = 0; i < referenceFileExtensions.length; i++) {
				int extensionIndex = refValue.lastIndexOf(referenceFileExtensions[i]);
				if (extensionIndex >= 0) {
					refValue = refValue.substring(extensionIndex);
					break;
				}
			}
			int index = refValue.lastIndexOf("#");
			if (index >= 0) {
				referredId = refValue.substring(index);
			}
		}
		return referredId;
	}

	private String getReferredURI(String referenceString, PublishingContext publishingContext) {
		String uriWithoutHash = referenceString;
		if(referenceString.contains("#")) {
			uriWithoutHash = referenceString.substring(0, referenceString.lastIndexOf("#"));
		}		
		
		if (uriWithoutHash.startsWith("qpp://office/excel") && excelDataRenderingParametersMap != null) {
			uriWithoutHash = replaceParams(uriWithoutHash, publishingContext, excelDataRenderingParametersMap);
		} else if (uriWithoutHash.startsWith("qpp://charts") && chartRenderingParametersMap != null) {
			uriWithoutHash = replaceParams(uriWithoutHash, publishingContext, chartRenderingParametersMap);
		} else {
			if(dataRenderingParametersMap != null) {
				String[] dataRenderingParametersMapType = dataRenderingParametersMap.keySet().toArray(new String[0]);
				for(int i = 0; i < dataRenderingParametersMapType.length; i++) {
					if (uriWithoutHash.startsWith(dataRenderingParametersMapType[i])) {
						uriWithoutHash = replaceParams(uriWithoutHash, publishingContext, dataRenderingParametersMap.get(dataRenderingParametersMapType[i]));
						break;
					} 
				}
			}
		}
		return uriWithoutHash;
	}

	private String replaceParams(String uriWithoutHash, PublishingContext publishingContext, Map<String, String> parametersMap) {
		String queryString = uriWithoutHash.substring(uriWithoutHash.indexOf('?') + 1);
		String[] params = queryString.split("&");
		StringBuilder newQueryString = new StringBuilder();
		
		//Reconstruct the URL after overriding the publishing parameters.   
		ArrayList<String> addedParameters = new ArrayList<String>();			
		for (int i = 0; i < params.length; i++) {
			String[] subparts = params[i].split("=", 2);
			String paramName = subparts[0];
			String paramValue = subparts[1];
			String publishingOverrideValue = null;
			if (parametersMap != null) {
				publishingOverrideValue = resolveParameter(parametersMap.get(paramName), publishingContext);
			}
			if (i > 0) {
				newQueryString.append("&");
			}
			newQueryString.append(paramName + "=");
			if (publishingOverrideValue!=null && !publishingOverrideValue.trim().isEmpty()){
				addedParameters.add(paramName);
				newQueryString.append(publishingOverrideValue);	
			}
			else {
				newQueryString.append(paramValue);
			}
		}
		
		//There might be a case when the parameter is not supplied in the href URL, but it has to be overridden during the publishing.
		if (parametersMap != null && parametersMap.size() > 0) {
			Iterator<String> paramNames = parametersMap.keySet().iterator();
			while (paramNames.hasNext()) {
				String paramName = paramNames.next();
				if (!addedParameters.contains(paramName)) {
					String paramValue = resolveParameter(parametersMap.get(paramName), publishingContext);
					if (paramValue != null && !paramValue.isEmpty()) {
						newQueryString.append("&");
						newQueryString.append(paramName);
						newQueryString.append("=");
						newQueryString.append(paramValue);
					}
				}
			}

		}

		return uriWithoutHash.substring(0, uriWithoutHash.indexOf('?') + 1) + newQueryString;
	}

	private void writeDocumentToFile(Document document, File file) throws TransformerException, IOException {
		FileOutputStream xmlOutputStream = null;
		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer();

			DOMSource source = new DOMSource(document);
			xmlOutputStream = new FileOutputStream(file);
			StreamResult result = new StreamResult(xmlOutputStream);
			transformer.transform(source, result);


			xmlOutputStream.close();

		} finally {
			if (xmlOutputStream != null) {
				xmlOutputStream.close();
			}
		}
	}

	private Object executeXPathOnDocument(org.w3c.dom.Document document, String xpathExpression, QName returnType) throws XPathFactoryConfigurationException, XPathExpressionException {
		XPathFactory xPathfactory = XPathFactory.newInstance();
		
		String documentNSUri = document.getDocumentElement().getNamespaceURI();
		
		XPath xpath = xPathfactory.newXPath();

		xpath.setNamespaceContext(new XaDocNamespaceContext(getDocumentNamespaces(document), documentNSUri));

		// xpath.setNamespaceContext();
		XPathExpression compTypeExpr;
		try {
			compTypeExpr = xpath.compile(xpathExpression);
			return compTypeExpr.evaluate(document, returnType);
		} catch (XPathExpressionException e) {
			logger.error("Error applying XPath on document. XPath Expr:" + xpathExpression + "; Exception:" + e + ", Reason:"
					+ (ExceptionUtils.getRootCause(e) != null ? ExceptionUtils.getRootCause(e).getMessage() : "unknown"));
			logger.debug("", e);
			return null;
		}
	}

	private void setQPSAttributes(long assetId,ContentInfo contentInfo) throws Exception
	{
		if(attachmentAttributeNames == null || attachmentAttributeNames.size() == 0){
			//Do nothing if there is no  attribute specified
			return;
		}
		long[] attributeIds = new long[attachmentAttributeNames.size()];
		int index = 0;
		for (String attributeName : attachmentAttributeNames) {
			Attribute attribute = attributeService.getAttributeByName(attributeName);
			attributeIds[index++] = attribute.getId();
		}
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, attributeIds);

		for (AttributeValue attributeValue : attributeValues) {

			String value = "";
			int type = attributeValue.getType();

			switch (type) {
			case AttributeValueTypes.NUMERIC:
				value = ((NumericValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.TEXT:
				value = ((TextValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.BOOLEAN:
				value = ((BooleanValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.DATE:
				value = ((DateValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.DOMAIN:
				value = ((DomainValue) attributeValue.getAttributeValue()).getName();
				break;
			default:
				break;
			}
			contentInfo.setAttribute(attributeValue.getAttributeId() + "", value);
			}
	}

	private boolean isXMLDocument(long contentTypeId) throws InvalidContentTypeException, QppServiceException {
		return (contentTypeId == DefaultContentTypes.XML || contentStructureService.isValidAncestor(DefaultContentTypes.XML, contentTypeId));
	}

	private String getXPath(AttributeValue[] attributeValues) {
		for (int i = 0; i < attributeValues.length; i++) {
			AttributeValue attrValue = attributeValues[i];
			if (attrValue.getAttributeId() == DefaultAttributes.XPATH) {
				return ((TextValue) attrValue.getAttributeValue()).getValue();
			}
		}
		return null;
	}


	/**
	 * This method fetches the given asset relations from the QPP and updates hrefs pertaining to given relations with the appropriate QPP URIs.
	 *
	 * @param file xml file to be updated
	 * @param assetId asset id of the given XML file
	 * @param assetVersion asset version of the given XML file
	 * @throws Exception
	 */
	private void updateRefrencesFromQppRelations(File file, String processId, long assetId, AssetVersion assetVersion)
			throws Exception {
			logger.trace("Started resolving relations for processID: "+processId+" file: " + file.getAbsolutePath()+ " and assetId: " + assetId);
			Document doc = createDocumentFromFile(file, processId);
			AssetRelation[] assetRelations = assetService.getChildAssetRelationsVersion(assetId, assetVersion);
			for (int i = 0; i < assetRelations.length; i++) {
				String xpathExpression = getXPath(assetRelations[i].getRelationAttributes());
				Node referenceNode = null;
				if(xpathExpression != null){
					referenceNode = (Node) executeXPathOnDocument(doc, xpathExpression, XPathConstants.NODE);
				}
				long childAsetId = assetRelations[i].getChildAssetId();
				if (referenceNode == null) {
					/* The Xpath may not select any matching node if content and relations are not in sync.
					 * Such scenario may happen if asset with multiple references is reverted to an old version with fewer references. */
					continue;
				}

				Node n = getReferredAttributeNode(referenceNode);

				if (n == null) {
					//If there is no corresponding reference attribute then this node would be null. In this case we need to go ahead and ignore this. Fixed as a part of IHS issue.
					continue;
				}

				String hrefValue = n.getNodeValue();
				String referredId = getReferredElementId(hrefValue);

				boolean isPinned=  assetRelations[i].isLockedToChildVersion();
				String referredFileValue = null;
				String qppURI = "qpp://";
				if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.EXCEL_DATA_OBJECT_REFERENCE){
					String dataObjectType = getAttributeValue(assetRelations[i].getRelationAttributes(), DefaultAttributes.EXCEL_DATA_OBJECT_TYPE);
					String dataObjectName = getAttributeValue(assetRelations[i].getRelationAttributes(), DefaultAttributes.EXCEL_DATA_OBJECT_NAME);
					//If dataobject name is not specified, consider this as a case of "Microsoft Excel Table" or "Microsoft Excel Chart" based on the dataObjectType provided
					if(dataObjectName == null && dataObjectType != null){
						if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.TABLE)){
							qppURI+="office/exceltable/" + childAsetId;
						}
						else if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.CHART)){
							qppURI+="office/excelchart/" + childAsetId;
						}
					}
					else {
						qppURI+="office/excel/" + childAsetId;
					}
				} else if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.VISIO_DATA_OBJECT_REFERENCE){
					qppURI+="office/visio/" + childAsetId;
				} else if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.POWERPOINT_DATA_OBJECT_REFERENCE){
					qppURI+="office/powerpoint/" + childAsetId;
				}else{
					qppURI+="assets/" + childAsetId;
				}

				if (isPinned) {
					referredFileValue = qppURI + "?majorversion=" + assetRelations[i].getChildAssetVersion().getMajorVersion() + "&minorversion="
							+ assetRelations[i].getChildAssetVersion().getMinorVersion();
				}
				else{
					referredFileValue = qppURI;
				}

				String dataParams = null;
				if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.EXCEL_DATA_OBJECT_REFERENCE){
					dataParams = constructExcelParamsQuery(assetRelations[i]);
				} else if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.VISIO_DATA_OBJECT_REFERENCE){
					dataParams = constructVisioParamsQuery(assetRelations[i]);
				} else if(assetRelations[i].getRelationTypeId() == DefaultRelationTypes.POWERPOINT_DATA_OBJECT_REFERENCE){
					dataParams = constructPowerPointParamsQuery(assetRelations[i]);
				}
				if (dataParams != null) {
					if(referredFileValue.contains("?")){
						referredFileValue += "&";
					}else{
						referredFileValue += "?";
					}
					referredFileValue += dataParams;
				}
				
				n.setNodeValue(referredFileValue + referredId);
			}

			writeDocumentToFile(doc, file);
			
			logger.trace("Finished resolving relations for processID: "+processId+" file: " + file.getAbsolutePath()+ " and assetId: " + assetId);
	}

	private String constructExcelParamsQuery(AssetRelation assetRelation) throws UnsupportedEncodingException {
		ArrayList<String> excelDataParams = new ArrayList<String>();
		AttributeValue[] attributeValues = assetRelation.getRelationAttributes();
		String worksheetName = getAttributeValue(attributeValues, DefaultAttributes.EXCEL_WORKSHEET_NAME);
		if(worksheetName != null) {
			worksheetName = URLEncoder.encode(worksheetName, "UTF-8");
		}
		String dataObjectType = getAttributeValue(attributeValues, DefaultAttributes.EXCEL_DATA_OBJECT_TYPE);
		if(dataObjectType != null){
			dataObjectType = URLEncoder.encode(dataObjectType, "UTF-8");
		}
		String dataObjectName = getAttributeValue(attributeValues, DefaultAttributes.EXCEL_DATA_OBJECT_NAME);
		if (dataObjectName != null) {
			dataObjectName = URLEncoder.encode(dataObjectName, "UTF-8");
		}
		
		String outputFormat = getAttributeValue(attributeValues, DefaultAttributes.EXCEL_OUTPUT_FORMAT);
		String outputFormatProperties = getAttributeValue(attributeValues, DefaultAttributes.EXCEL_OUTPUT_FORMAT_PROPERTIES);
		if(dataObjectName != null){
			if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.TABLE)){
				excelDataParams.add("table="+ dataObjectName);
			} else if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.CHART)){
				excelDataParams.add("chart="+dataObjectName);
			} else if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.NAMED_RANGE)){
				excelDataParams.add("namedrange="+dataObjectName);
			} else if(dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.DYNAMIC_RANGE)){
				excelDataParams.add("dynamicrange="+dataObjectName);
			}
		}
		if (worksheetName != null && !worksheetName.isEmpty()) {
			excelDataParams.add("worksheet=" + worksheetName);
		}
		if (outputFormat != null && !outputFormat.isEmpty()) {
			excelDataParams.add("outputformat="+outputFormat);
		}
		HashMap<String, String> propertiesMap = createPropertiesMap(outputFormatProperties);
		Iterator<String> keySetItr = propertiesMap.keySet().iterator();
		while(keySetItr.hasNext()){
			String key = keySetItr.next();
			String value = URLEncoder.encode(propertiesMap.get(key), "UTF-8");
			if (key != null && value!=null){
				excelDataParams.add(key+"="+value);
			}
		}
		
		StringBuilder paramsBuilder = new StringBuilder();
		for (String param : excelDataParams) {
			paramsBuilder.append(param+"&");
		}
		if(paramsBuilder.length() > 0){
			paramsBuilder.deleteCharAt(paramsBuilder.length()-1);
		}
		return paramsBuilder.toString();
	}
	private String constructVisioParamsQuery(AssetRelation assetRelation) throws UnsupportedEncodingException {
		String visioDataParams = "";
		AttributeValue[] attributeValues = assetRelation.getRelationAttributes();
		String pageName = URLEncoder.encode(getAttributeValue(attributeValues, DefaultAttributes.VISIO_PAGE_NAME), "UTF-8");
		String outputFormat = getAttributeValue(attributeValues, DefaultAttributes.VISIO_OUTPUT_FORMAT);
		String outputFormatProperties = getAttributeValue(attributeValues, DefaultAttributes.VISIO_OUTPUT_FORMAT_PROPERTIES);

		visioDataParams+="pagename="+pageName;
		visioDataParams+="&outputformat="+outputFormat;
		HashMap<String, String> propertiesMap = createPropertiesMap(outputFormatProperties);
		Iterator<String> keySetItr = propertiesMap.keySet().iterator();
		while(keySetItr.hasNext()){
			String key = keySetItr.next();
			String value = URLEncoder.encode(propertiesMap.get(key), "UTF-8");
			if (key != null && value!=null){
				visioDataParams+="&"+key+"="+value;
			}
		}
		return visioDataParams;
	}
	private String constructPowerPointParamsQuery(AssetRelation assetRelation) throws UnsupportedEncodingException {
		String powerPointDataParams = "";
		AttributeValue[] attributeValues = assetRelation.getRelationAttributes();
		long slideId = Long.parseLong(getAttributeValue(attributeValues, DefaultAttributes.POWERPOINT_SLIDE_ID));
		String outputFormat = getAttributeValue(attributeValues, DefaultAttributes.POWERPOINT_OUTPUT_FORMAT);
		String outputFormatProperties = getAttributeValue(attributeValues, DefaultAttributes.POWERPOINT_OUTPUT_FORMAT_PROPERTIES);
		powerPointDataParams+="slideid=" + slideId;
		powerPointDataParams+="&outputformat="+outputFormat;
		HashMap<String, String> propertiesMap = createPropertiesMap(outputFormatProperties);
		Iterator<String> keySetItr = propertiesMap.keySet().iterator();
		while(keySetItr.hasNext()){
			String key = keySetItr.next();
			String value = URLEncoder.encode(propertiesMap.get(key), "UTF-8");
			if (key != null && value!=null){
				powerPointDataParams+="&"+key+"="+value;
			}
		}
		return powerPointDataParams;
	}

	private String getAttributeValue(AttributeValue[] attributeValues, long attributeId) {
		for (int i = 0; i < attributeValues.length; i++) {
			AttributeValue attrValue = attributeValues[i];
			if (attrValue.getAttributeId() == attributeId) {
				if(attrValue.getType() == AttributeValueTypes.NUMERIC) {
					return ((NumericValue) attrValue.getAttributeValue()).getValue() + "";
				} else {
					return ((TextValue) attrValue.getAttributeValue()).getValue();
				}
			}
		}
		return null;
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		long assetId = getParameterValueAsLong(context, this.assetId);
		resolvedAssetIdsMap.put(context.getProcessId(), assetId);

		if(attachmentAttributeNames == null)
			attachmentAttributeNames = new ArrayList<String>(0);

	}

	private long getParameterValueAsLong(PublishingContext publishingContext,
			String parameterKey) throws InvalidActivityParameterException {
		String valueAsString = resolveParameter(parameterKey, publishingContext);

		long valueAsLong = 0;
		try {
			valueAsLong = Long.parseLong(valueAsString);
		} catch (NumberFormatException e1) {
			//resolvedAssetId would remain to be 0
		}
		return valueAsLong;
	}

	/**
	 * Creats a HashMap<String, String> from a string of properties defined in format of type property1=value1;property2=value2;property3=value3;...;
	 * @param outputFormatProperties
	 * @return
	 */
	private HashMap<String, String> createPropertiesMap(String outputFormatProperties) {
		HashMap<String, String> map = new HashMap<String, String>();
		if (outputFormatProperties != null) {
			String[] properties = outputFormatProperties.split(";");
			for (int i = 0; properties != null && i < properties.length; i++) {
				String[] nameValue = properties[i].split("=");
				if (nameValue != null && nameValue.length == 2) {
					String key = nameValue[0];
					String value = nameValue[1];
					map.put(key, value);
				}
			}
		}
		return map;
	}

	@Override
	public void clean(String processId) {
		resolvedAssetIdsMap.remove(processId);
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	private AssetIdentityInfo resolveAssetUri(String uri, String processId) throws Exception{
		URI assetUri = convertInputToURI(uri);
		return qppAssetsUriUtility.parseAndEvaluateQppUri(assetUri, processId);
	}

	public Map<String, String> getDocumentNamespaces(Document document) throws XPathFactoryConfigurationException, XPathExpressionException {
		Map<String, String> namespaceMap = new HashMap<String, String>();

		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();

		XPathExpression	xpathExprs = xpath.compile("//namespace::*");
		NodeList nodeList = (NodeList)xpathExprs.evaluate(document, XPathConstants.NODESET);

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if(!namespaceMap.containsKey(node.getLocalName())){
				namespaceMap.put(node.getLocalName(), node.getNodeValue());
			}
		}
		return namespaceMap;
	}

	private class XaDocNamespaceContext implements NamespaceContext {

		private Map<String, String> namespacesMap;
		private static final String NSURI_SMART_CONTENT = "http://quark.com/smartcontent/4.0";
		private static final String NSPREFIX_SMART_CONTENT = "smart";
		private String docRootNamespace = null;

		public XaDocNamespaceContext(Map<String, String> namespacesMap, String docRootNamespace) {
			this.namespacesMap = namespacesMap;
			this.docRootNamespace = docRootNamespace;
		}

		public String getNamespaceURI(String prefix) {

			// TODO: Special handling for a known prefix used by Kestrel
			if (NSPREFIX_SMART_CONTENT.equals(prefix)) {
				if (docRootNamespace != null) {
					return docRootNamespace;
				} else {
					return NSURI_SMART_CONTENT;
				}
			}

			if (namespacesMap.containsKey(prefix)) {
				return namespacesMap.get(prefix);
			} else if (namespacePrefixUriMap != null && namespacePrefixUriMap.get(prefix) != null) {
				return namespacePrefixUriMap.get(prefix);
			}
			return null;
		}

		public String getPrefix(String namespaceURI) {
			return null;
		}

		public Iterator getPrefixes(String namespaceURI) {
			return null;
		}

	}
	
	private class ReferredAttrNodeInfo {
		public ReferredAttrNodeInfo(Node n, String referredURI2,
				String referredElementId2, String referedFileIdentity, URI uriObject, PublishingContext publishingContext, Exception exception) {
			this.attrNode = n;
			this.referredURI = referredURI2;
			this.referredElementId = referredElementId2;
			this.referedFileIdentity = referedFileIdentity;
			this.uriObject = uriObject;
			this.exception = exception;
			if(referredURI.startsWith("qpp:")){
				try {
					refAsset = resolveAssetUri(referredURI, publishingContext.getProcessId());
				} catch (Exception e) {
					logger.error("Error occured while resolving URI "+referredURI+" for processID: "+publishingContext.getProcessId(), e);
				}
			}
		}
		private AssetIdentityInfo refAsset = null;
		private Node attrNode = null;
		private String referredElementId = null;
		private String referredURI = null;
		private String referedFileIdentity = null;
		private URI uriObject = null;
		private Exception exception = null;		
	}
	
	/*
	 * A recursive fork join task that resolves references in the given file and 
	 * initiates the recursive reference resolution process for references.
	 * In detail the following tasks are performed for the input file in a ResolveFileReferencesTask:
	 * 1. Create list of Referred Nodes
	 * 2. From referred nodes list, figure out list of unique URIs to be resolved
	 * 3. Invoke FixedThreadPool to resolve URIs into files
	 * 4. Replace QPP URI/HTTP URI/.... with the absolute file path.
	 * 5. For each resolved file, fork the ResolveFileReferencesTask again.
	 */
	class ResolveFileReferencesTask extends RecursiveAction {

		private static final long serialVersionUID = -6425864076666220439L;

		private File file;
		
		private String referredURI;
		
		private boolean isXMLDoc;
		
		private PublishingContext publishingContext;

		private Map<String, File> resolvedUriMap;

		private ExecutorService executorService;
		
		private Map<String, ResolveFileReferencesTask> resolveFileRefTasksAlreadyCreated;
		
		private SessionContext sessionContext;
		
		private boolean resolveQPPRelations;
		
		public ResolveFileReferencesTask(File file, PublishingContext publishingContext, Map<String, File> resolvedUriMap, ExecutorService executorService, Map<String, ResolveFileReferencesTask> tasksAlreadyCreated, SessionContext sessionContext, boolean isXMLDoc, String referredURI, boolean resolveQppRelationsBoolean) {
			this.file = file;
			this.publishingContext = publishingContext;
			this.resolvedUriMap = resolvedUriMap;
			this.executorService = executorService;
			this.resolveFileRefTasksAlreadyCreated = tasksAlreadyCreated;
			this.sessionContext = sessionContext;
			this.isXMLDoc = isXMLDoc;
			this.referredURI = referredURI;
			this.resolveQPPRelations = resolveQppRelationsBoolean;
		}

		@Override
		protected void compute() {
			try {
				/*
				 * Set session context else future.get(...) invocation leads to
				 * java.util.concurrent.ExecutionException:
				 * java.lang.IllegalArgumentException: Only non-null
				 * SecurityContext instances are permitted
				 */
				SessionContextHolder.setSessionContext(sessionContext);
				
				long refAssetID = -1;
				//Resolve Platform relations if the given asset is sourced from Platform   
				if (referredURI.startsWith("qpp:") && resolveQPPRelations) {
					
					AssetIdentityInfo refAsset = resolveAssetUri(referredURI, publishingContext.getProcessId());
					//refAsset will be null if the URI does not refer to the Platform Asset. This will be case of excel object URI. For example: qpp://office/excel?uri={a_valid_uri}&namedrange=....
					if(refAsset != null){
						refAssetID = refAsset.getAssetID();
					}
					if (isXMLDoc) {
						//If the referred asset lies in the Platform then look for its relations in the platform
						if(refAsset != null && refAsset.getAssetID() > 0){
							AssetVersion refAssetVersion = new AssetVersion(refAsset.getAssetVersion().getMajorVersion(), refAsset.getAssetVersion().getMinorVersion());
							
							String processId = publishingContext.getProcessId();
							
							updateRefrencesFromQppRelations(file, processId, refAssetID, refAssetVersion);
							
							logger.trace("Updated references from Platform relations for ProcessID: "+publishingContext.getProcessId()+" URI : "+referredURI);
						}
					}
				} 
				
				
				resolveAndUpdateReferences(file, publishingContext, resolvedUriMap, executorService, resolveFileRefTasksAlreadyCreated);
			} catch (Exception e) {
				logger.error("Error occured while executing ResolveFileReferencesTask for processID: "+publishingContext.getProcessId()+" file : "+file.getAbsolutePath(), e);
			}

		}

	}
	
	/*
	 * Task to resolve a referred URI.
	 */
	class ResolveURITask implements Callable<File> {

		String processId;

		URI inputContentUri;

		SessionContext sessionContext;

		public ResolveURITask(String publishingProcessId, URI uri, SessionContext sessionContext) {
			this.processId = publishingProcessId;
			this.inputContentUri = uri;
			this.sessionContext = sessionContext;
		}

		@Override
		public File call() throws Exception {
			SessionContextHolder.setSessionContext(sessionContext);
			return uRIHandlerRegistry.resolveToFile(processId, inputContentUri);
		}
	}
	
	/*
	 * Thread factory to be used by ForkJoinPool.
	 */
	class ForkJoinThreadFactory implements ForkJoinWorkerThreadFactory {

		AtomicInteger counter = new AtomicInteger();

		String threadNamePrefix = "Publish_Resolve_References_";

		String processId;

		public ForkJoinThreadFactory(String processId) {
			this.processId = processId;
		}

		@Override
		public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
			String THREAD_NAME_PATTERN = "%s_%d";
			ForkJoinWorkerThread worker = ForkJoinPool.defaultForkJoinWorkerThreadFactory.newThread(pool);
			String threadName = String.format(THREAD_NAME_PATTERN, threadNamePrefix + processId, counter.incrementAndGet());
			worker.setName(threadName + "_" + worker.getName());
			logger.trace("Created new publish fork worker thread : " + threadName);
			return worker;
		}
	};
	
	/**
	 * Implemented ThreadFactory in order to create Publish reference resolving
	 * threads with thread names in format like
	 * Publish_Ref_Resolver_ProcessID_0.
	 *
	 */
	class FixedPoolThreadFactory implements ThreadFactory {

		AtomicInteger counter = new AtomicInteger();

		String threadNamePrefix = "Publish_Resolve_File_";

		String processId;

		private final ThreadGroup group;

		public FixedPoolThreadFactory(String processId) {
			this.processId = processId;

			// Refer java.util.concurrent.Executors.DefaultThreadFactory
			SecurityManager s = System.getSecurityManager();
			group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
		}

		public Thread newThread(Runnable runnable) {
			String THREAD_NAME_PATTERN = "%s_%d";
			String threadName = String.format(THREAD_NAME_PATTERN, threadNamePrefix + processId, counter.incrementAndGet());
			Thread thread = new Thread(group, runnable, threadName, 0);
			
			// Refer java.util.concurrent.Executors.DefaultThreadFactory
			thread.setDaemon(false);
			if (thread.getPriority() != Thread.NORM_PRIORITY)
				thread.setPriority(Thread.NORM_PRIORITY);
			logger.trace("Created new publish reference resolving thread : " + threadName);
			return thread;
		}
	}	
}

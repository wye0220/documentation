package com.quark.qpp.publishing.activity;

import java.util.Map;
import java.util.Set;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;

/**
 * This Activity reads content from the given URI (available as channel/activity parameter) and make it available for other Activities. 
 */
public class SetAssetMetadata extends AbstractActivity {

	/*
	 * Name with which this activity emits content 
	 */
	private String OUTPUT_CONTENT_NAME = "CONTENT_WITH_METADATA";
	
	private String IN_CONTENT_NAME = "IN_CONTENT";


	private Map<String, String> attributesMap;

	public void setAttributesMap(Map<String, String> attributesMap) {
		this.attributesMap = attributesMap;
	}

	protected String activityName;


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}	

	public String getName() {
		return activityName;
	}
	
	
	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {	
		ContentInfo[] contentInfos =	publishingContext.getInputContentInfos(IN_CONTENT_NAME);
		
		if(contentInfos==null || contentInfos.length==0){
			throw new PublishingException(PublishingExceptionCodes.INVALID_CONTENT);
		}
		
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, contentInfos[0].getUri(), contentInfos[0].getFile());
		
		//Set Asset Metadata in content info ads key value pairs
		Set<String> keySet = attributesMap.keySet();
		for (String key : keySet) {
			contentInfo.setAttribute(key, attributesMap.get(key));	
		}
		
	}

	@Override
	public void clean(String processId) {
		
	}

}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.relation.service.constants.DefaultRelationTypes;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.xmlBinding.ArticleComponentInfo;
import com.quark.qpp.service.xmlBinding.ArticleComponentInfoList;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetRelationInfo;
import com.quark.qpp.service.xmlBinding.AssetRelationInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValue;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qxpsm.Component;
import com.quark.qxpsm.CopyDeskRequest;
import com.quark.qxpsm.Project;
import com.quark.qxpsm.QContentData;
import com.quark.qxpsm.QException;
import com.quark.qxpsm.QRequestContext;
import com.quark.qxpsm.QxpsmStreamingService;
import com.quark.qxpsm.RequestService;
import com.quark.qxpsm.XMLRequest;

/**
 * This activity serializes asset metadata from the content specified by name {@link #ASSET_WITH_METADATA} to a XML file.
 * The relations metadata will be processed & serialized only in case the input content is Quark XPress project or a Quark CopyDesk Article. <br>
 *
 * <p>
 * This activity requires the following input contents :
 * <li>Input content with name specified by {@link #ASSET_WITH_METADATA}.This input content should have asset file
 * associated and attributes that are to be serialized to XML.In case the source asset is of type Quark XPress Project or Quark CopyDesk Article,
 * then the source file is processed to identify relations.</li>
 * <li>Child assets related to above input content with name specified by {@link #RELATED_ASSET}.The related asset
 * should have asset id and version attributes declared using id as key.The child asset attributes are processed to
 * create relations XML.</li>
 * </p>
 * <br>
 * <p>
 * This activity emits the following contents:<br>
 * <li>The asset metadata XML as output content with the name specified by {@link #METADATA_XML}</li>
 * <li>The relations XML as output content with the name specified by {@link #RELATIONS_XML}. This xml is produced only in case the input content is Quark XPress project.</li>
 * </p>
 *
 */
public class MetadataSerializer extends AbstractActivity {

	/*
	 *  Names with which this activity expects input content
	 */
	private static final String ASSET_WITH_METADATA = "AssetWithMetadata";

	private static final String RELATED_ASSET = "RelatedAsset";

	/*
	 *  Names with which this activity expects output content
	 */
	private static final String METADATA_XML = "MetadataXML";

	private static final String RELATIONS_XML = "RelationsXML";

	private String activityName;

	private Logger logger = Logger.getLogger(getClass());

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	@Autowired
	private TempFileManager fileManager;

	@Autowired
	private QxpsmStreamingService qxpsmStreamingService;

	@Autowired
	private RequestService qxpsService;

	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private ContentStructureService contentStructureService;
	
	private DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Override
	public String getName() {
		return this.activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// Nothing to validate in this activity
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		ContentInfo[] inputContentInfos = publishingContext.getInputContentInfos(ASSET_WITH_METADATA);
		if (inputContentInfos != null && inputContentInfos.length > 0) {
			ContentInfo sourceAssetWithAttributes = inputContentInfos[0];
			// Create platform attribute values from ContentInfo attributes.
			AttributeValueList attributeValueList = createAttributeValuesList(sourceAssetWithAttributes.getAttributes());
			//
			AssetInfo assetInfo = new AssetInfo();
			assetInfo.setAttributeValueList(attributeValueList);

			String fileXtension = sourceAssetWithAttributes.getFileExtension();
			if(fileXtension == null || fileXtension.isEmpty()){
				String fileName = sourceAssetWithAttributes.getFile().getName();
				int lastIndex = fileName.lastIndexOf(".");
				fileXtension = sourceAssetWithAttributes.getFile().getName().substring(lastIndex+1, fileName.length());
			}
			String mimeType = sourceAssetWithAttributes.getMimeType();
			long sourceContentType = contentStructureService.detectContentType(fileXtension, mimeType, null);

			if (sourceContentType == DefaultContentTypes.QUARK_XPRESS_PROJECT) {
				// Assume the source asset is referred through file
				createAndRegisterRelationsXML(publishingContext, sourceAssetWithAttributes.getFile(), false);
			} else if (sourceContentType == DefaultContentTypes.QCD_ARTICLE) {
				/* In case of QCD article use specific logic for metadata extraction.
				 * In addition to asset's metadata, article component's metadata is also extracted and provided as output in METADATA_XML */
				File deconstructXml = createAndRegisterRelationsXML(publishingContext, sourceAssetWithAttributes.getFile(), true);
				ArticleComponentInfoList componentInfoList = new ArticleComponentInfoList();
				componentInfoList.getArticleComponentInfo().addAll(getArticleComponents(deconstructXml));
				assetInfo.setArticleComponentInfoList(componentInfoList);
			}

			File metadataXmlFile = fileManager.getTemporaryFile(".xml", publishingContext.getProcessId());
			Result metadataStreamResult = new StreamResult(metadataXmlFile);
			jaxb2Marshaller.marshal(assetInfo, metadataStreamResult);
			publishingContext.registerOutputContentInfo(METADATA_XML, new URI("file", metadataXmlFile.getAbsolutePath(), null), metadataXmlFile);

		}
	}

	/**
	 * Deconstruct input content and generate relation information from deconstructed XML. The relation information is in form of an AssetRelationInfoList
	 * object which is then JAXB serialized and resulting stream/file is registered as an output ContentInfo by name RELATIONS_XML.
	 *
	 * @returns A File object corresponding to deconstructed XML of input content.
	 */
	private File createAndRegisterRelationsXML(PublishingContext publishingContext, File quarkContentFile, boolean isCopyDesk) throws QException, SAXException,
			IOException, ParserConfigurationException, AssetNotFoundException, QppServiceException, StreamingException, Exception, PublishingException,
			URISyntaxException {
		File deconstructXml = getDeconstructXML(quarkContentFile, isCopyDesk);
		// Parse deconstructed XML
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.parse(deconstructXml);
		ContentInfo[] relatedAssets = publishingContext.getInputContentInfos(RELATED_ASSET);
		if (relatedAssets != null && relatedAssets.length > 0) {
			AssetRelationInfoList assetRelationInfoList = getAssetRelationInfoList(document, relatedAssets, isCopyDesk);
			appendRelationsForInteractiveAttachments(document, relatedAssets, assetRelationInfoList);
			File relationXmlFile = fileManager.getTemporaryFile(".xml", publishingContext.getProcessId());
			Result relationsStreamResult = new StreamResult(relationXmlFile);
			jaxb2Marshaller.marshal(assetRelationInfoList, relationsStreamResult);
			publishingContext.registerOutputContentInfo(RELATIONS_XML, new URI("file", relationXmlFile.getAbsolutePath(), null), relationXmlFile);
		}
		return deconstructXml;
	}

	/** Read deconstruct XML file of a QCD article and extract component info from it **/
	private List<ArticleComponentInfo> getArticleComponents(File deconstructXmlFile) throws Exception {
		// Read file
		String deconstructXml = new Scanner(deconstructXmlFile,"UTF-8").useDelimiter("\\Z").next();
		logger.trace("QCD XML: " + deconstructXml);
		// Parse file into objects
		Project project = qxpsService.getXPressDOMFromXML(deconstructXml);
		// extract components
		return extractArticleComponents(project);
	}

	/** Extract article component details from Project object corresponding to a QCD's deconstruct XML **/
	private List<ArticleComponentInfo> extractArticleComponents(Project project) {
		List<ArticleComponentInfo> componentInfoList = new ArrayList<ArticleComponentInfo>();
		Component[] components = project.getLayouts()[0].getArticles()[0].getComponents();
		for (int i = 0; i < components.length; i++) {
			logger.trace("Extracted QCD Component {Id:" + components[i].getUID() + ", Type:" + components[i].getComponentType() + ", Name: " + components[i].getName() + "}");

			ArticleComponentInfo componentInfo = new ArticleComponentInfo();
			componentInfo.setComponentId(0L);

			AttributeValueList componentAttValList = new AttributeValueList();
			AttributeValue nameAttrVal = new AttributeValue();
			nameAttrVal.setId(DefaultAttributes.COMPONENT_NAME);
			nameAttrVal.setValue(components[i].getName());
			componentAttValList.getAttributeValue().add(nameAttrVal);

			AttributeValue qcdCompIdAttrVal = new AttributeValue();
			qcdCompIdAttrVal.setId(DefaultAttributes.ARTICLE_COMPONENT_ID);
			qcdCompIdAttrVal.setValue(components[i].getUID());
			componentAttValList.getAttributeValue().add(qcdCompIdAttrVal);

			AttributeValue qcdCompTypeAttrVal = new AttributeValue();
			qcdCompTypeAttrVal.setId(DefaultAttributes.CONTENT_TYPE);
			if(components[i].getComponentClass().equalsIgnoreCase("CT_PICT") ) {
				qcdCompTypeAttrVal.setValue("System;Article Component;Picture Component;"+components[i].getComponentType());
			} else {
				qcdCompTypeAttrVal.setValue("System;Article Component;Text Component;"+components[i].getComponentType());
			}
			componentAttValList.getAttributeValue().add(qcdCompTypeAttrVal);
			componentInfo.setAttributeValueList(componentAttValList);
			componentInfoList.add(componentInfo);
		}
		return componentInfoList;
	}



	private Element getParentBoxNode(Node node) {
		Element parentNode = (Element) node.getParentNode();
		if(parentNode.getNodeName().equalsIgnoreCase("BOX")){
			return parentNode;
		}else{
			return getParentBoxNode(parentNode);
		}
	}

	private AssetVersion getChildAssetVersion(Long childAssetId, ContentInfo[] relatedAssets) {
		AssetVersion assetVersion = new AssetVersion();
		for (int j = 0; j < relatedAssets.length; j++) {
			ContentInfo relatedAsset = relatedAssets[j];
			if(relatedAsset.getAttributeValue(String.valueOf(DefaultAttributes.ID)).equals(String.valueOf(childAssetId))){
				String majorVersion =relatedAsset.getAttributeValue(String.valueOf(DefaultAttributes.MAJOR_VERSION));
				if(majorVersion != null){
					assetVersion.setMajorVersion(Long.valueOf(majorVersion ));
				}
				String minorVersion =relatedAsset.getAttributeValue(String.valueOf(DefaultAttributes.MAJOR_VERSION));
				if(minorVersion != null){
					assetVersion.setMajorVersion(Long.valueOf(minorVersion ));
				}
				break;
			}
		}
		return assetVersion;
	}

	private Object executeXPathOnDocument(org.w3c.dom.Document document, String xpathExpression, QName returnType) {
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();

		XPathExpression compTypeExpr;
		try {
			compTypeExpr = xpath.compile(xpathExpression);
			return compTypeExpr.evaluate(document, returnType);
		} catch (XPathExpressionException e) {
			return null;
		}
	}

	private AttributeValueList createAttributeValuesList(Map<String, String> attributesMap) {
		AttributeValueList attributeValueList = new AttributeValueList();
		Iterator<String> keysIterator = attributesMap.keySet().iterator();
		while(keysIterator.hasNext()){
			String key = keysIterator.next();
			String value = attributesMap.get(key);
			AttributeValue attributeValue = new AttributeValue();
			attributeValue.setId(Long.valueOf(key));
			attributeValue.setValue(value);

			attributeValueList.getAttributeValue().add(attributeValue);
		}
		return attributeValueList;
	}

	@Override
	public void clean(String processId) {
		// Nothing to clean in this activity

	}

	/**
	 * Parses deconstructed XML of a XPress or CopyDesk content to identify relations of document, corresponding to input XML, with other images and article
	 * assets.<BR>
	 * Scans the XML to find references to other images and articles. It is assumed that all references are for assets in Platform Server.
	 * @returns {@link AssetRelationInfoList} describing all asset relations between document corresponding to input XML with other assets in Platform.
	 */
	protected AssetRelationInfoList getAssetRelationInfoList(Document document, ContentInfo[] relatedAssets, boolean isCopyDesk) throws SAXException, IOException,
			ParserConfigurationException, AssetNotFoundException, QppServiceException, StreamingException {
		logger.trace("getAssetRelationInfoList() : isCopyDesk = " + isCopyDesk);
		HashMap<String, String> boxIdLayoutIdMap = new HashMap<String, String>();
		HashMap<String, String> boxIdPageIndexMap = new HashMap<String, String>();
		HashMap<String, String> boxIdPageNameMap = new HashMap<String, String>();

		AssetRelationInfoList assetRelationInfoList = new AssetRelationInfoList();

		NodeList layoutNodeList = document.getElementsByTagName("LAYOUT");

		// Traverse and scan XML to identify Picture Boxes and BOxes belonging to a article.
		for (int i = 0; i < layoutNodeList.getLength(); i++) {
			Element layoutNode = (Element) layoutNodeList.item(i);
			String layoutId = layoutNode.getAttribute("LAYOUT_ID");

			// Iterate over spreads
			NodeList layoutChildren = layoutNode.getChildNodes();
			for (int j = 0; j < layoutChildren.getLength(); j++) {
				if (layoutChildren.item(j).getNodeName().equals("SPREAD")) {
					Node spreadNode = layoutChildren.item(j);
					NodeList spreadChildren = spreadNode.getChildNodes();
					String pageName = null;
					String pageIndex = null;
					for (int k = 0; k < spreadChildren.getLength(); k++) {
						if (spreadChildren.item(k).getNodeName().equals("PAGE")) {
							// If spread child is page
							Element pageNode = (Element) spreadChildren.item(k);
							pageName = pageNode.getAttribute("FORMATTEDNAME");
							pageIndex = ((Element) pageNode.getFirstChild()).getAttribute("UID");
						} else if (spreadChildren.item(k).getNodeName().equals("BOX")) {
							// If spread child is box
							Element boxNode = (Element) spreadChildren.item(k);
							String boxType = boxNode.getAttribute("BOXTYPE");
							NodeList boxChildNodeList = boxNode.getChildNodes();
							long childAssetId = -1;
							String boxId = null;

							for (int m = 0; m < boxChildNodeList.getLength(); m++) {
								Element anElement = (Element) boxChildNodeList.item(m);
								logger.trace("Box Child Element : " + anElement.getNodeName());
								// Store box ID for later use.
								if (anElement.getNodeName().equalsIgnoreCase("ID")) {
									boxId = anElement.getAttribute("UID");
								} else if (anElement.getNodeName().equalsIgnoreCase("CONTENT") && boxType.equalsIgnoreCase("CT_PICT")) {
									// referenced picture
									Element boxContentNode = anElement;
									String contentNodeValue = boxContentNode.getTextContent();
									logger.trace("Picture Content Reference: " + contentNodeValue);
									childAssetId = getReferencedPictureAssetId(relatedAssets, contentNodeValue);
									// If referred image is a Platform asset. Add relation to the image
									if (childAssetId > 0) {
										AssetVersion childAssetVersion = getChildAssetVersion(childAssetId, relatedAssets);
										AssetRelationInfo assetRelationInfo = new AssetRelationInfo();
										assetRelationInfo.setChildAssetId(childAssetId);
										assetRelationInfo.setChildAssetMajorVersion(childAssetVersion.getMajorVersion());
										assetRelationInfo.setChildAssetMinorVersion(childAssetVersion.getMinorVersion());
										assetRelationInfo.setLockedToChildVersion(false);
										if (isCopyDesk) {
											assetRelationInfo.setRelationTypeId(Long.valueOf(DefaultRelationTypes.ARTICLE_COMP_REFERENCE));
											String articleId = getArticleId(document);
											String articleComponentId = getComponentIdForBox(boxId, document);
											logger.trace("Relation Metadata:{ Type:ARTICLE_COMP_REFERENCE, ARTICLE_ID:" +articleId+", ARTICLE_COMPONENT_ID:" + articleComponentId +" }");
											if (articleComponentId != null) {
												AttributeValueList relationAttrValueList = createArticleReferenceAttributes(articleId, articleComponentId);
												assetRelationInfo.setAttributeValueList(relationAttrValueList);
											}
										} else {
											logger.trace("Relation Metadata:{ Type:SECONDARY_ATTACHMENT, LAYOUT_ID:" + layoutId + ", PAGE_INDEX:" + pageIndex
													+ ", PAGE_NAME:+" + pageName + ", BOX_ID:" + boxId + " }");
											assetRelationInfo.setRelationTypeId(Long.valueOf(DefaultRelationTypes.SECONDARY_ATTACHMENT));
											AttributeValueList relationAttrValueList = createSecondaryAttachmentAttributes(layoutId, pageIndex, pageName, boxId);
											assetRelationInfo.setAttributeValueList(relationAttrValueList);
										}
										assetRelationInfoList.getAssetRelationInfo().add(assetRelationInfo);
									}
								}
								if (layoutId != null && pageIndex != null && pageName != null && boxId != null) {
									boxIdLayoutIdMap.put(boxId, layoutId);
									boxIdPageIndexMap.put(boxId, pageIndex);
									boxIdPageNameMap.put(boxId, pageName);
								}
							}
						}
					}
				}
			}
		}

		if(!isCopyDesk) {
			// Handle Article attachments of a XPress Document
			NodeList articleNodeList = document.getElementsByTagName("ARTICLE");

			for (int i = 0; i < articleNodeList.getLength(); i++) {
				Node articleNode = articleNodeList.item(i);
				Node idNode = articleNode.getFirstChild();
				String articleName = idNode.getAttributes().getNamedItem("NAME").getNodeValue();

				long childAssetId = -1;
				for (int l = 0; l < relatedAssets.length; l++) {
					String attachmentName = relatedAssets[l].getAttributeValue(DefaultAttributes.NAME + "");
					if (articleName.equalsIgnoreCase(attachmentName)) {
						childAssetId = Long.parseLong(relatedAssets[l].getAttributeValue(DefaultAttributes.ID + ""));
					}
				}

				Element componentNode = (Element) articleNode.getLastChild();
				String projectBoxId = componentNode.getAttribute("BOXUID");
				AssetInfo articleInfo = assetFacade.getAsset(childAssetId, null, null, new String[0], false, false, new String[0], null, null, null, null, false);
				AssetVersion childAssetVersion = getChildAssetVersion(childAssetId, relatedAssets);

				AssetRelationInfo assetRelationInfo = new AssetRelationInfo();
				assetRelationInfo.setChildAssetId(articleInfo.getId());
				assetRelationInfo.setChildAssetMajorVersion(childAssetVersion.getMajorVersion());
				assetRelationInfo.setChildAssetMinorVersion(childAssetVersion.getMinorVersion());
				assetRelationInfo.setLockedToChildVersion(false);
				assetRelationInfo.setRelationTypeId(Long.valueOf(DefaultRelationTypes.SECONDARY_ATTACHMENT));

				AttributeValueList relationAttrValueList = createSecondaryAttachmentAttributes(boxIdLayoutIdMap.get(projectBoxId),
						boxIdPageIndexMap.get(projectBoxId), boxIdPageNameMap.get(projectBoxId), projectBoxId);
				assetRelationInfo.setAttributeValueList(relationAttrValueList);

				if (assetRelationInfoList == null) {
					assetRelationInfoList = new AssetRelationInfoList();
				}

				assetRelationInfoList.getAssetRelationInfo().add(assetRelationInfo);
			}
		}
		return assetRelationInfoList;
	}

	private void appendRelationsForInteractiveAttachments(Document deconstructDoc, ContentInfo[] relatedAssets, AssetRelationInfoList assetRelationInfoList)
			throws Exception {
		String xpathExpression = "//BOX//INTERACTIVITY//fileSource[@path!='']";
		appendRelationsForInteractiveAttachments(deconstructDoc, xpathExpression, relatedAssets, assetRelationInfoList);
		xpathExpression = "//BOX//INTERACTIVITY//sourceid";
		appendRelationsForInteractiveAttachments(deconstructDoc, xpathExpression, relatedAssets, assetRelationInfoList);
		return;
	}

	private void appendRelationsForInteractiveAttachments(Document doc, String xpathExpression, ContentInfo[] relatedAssets,
			AssetRelationInfoList assetRelationInfoList) throws IOException, ParserConfigurationException, SAXException {
		NodeList nodeList = (NodeList) executeXPathOnDocument(doc, xpathExpression, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node fileSourceNode = nodeList.item(i);
			Long childAssetId = null;
			String assetId = fileSourceNode.getTextContent();
			if (assetId == null || assetId.isEmpty()) {
				Node pathNode = nodeList.item(i).getAttributes().getNamedItem("path");
				if (pathNode != null) {
					assetId = pathNode.getNodeValue();
				}
			}

			if (assetId != null) {
				try {
					childAssetId = Long.parseLong(assetId);
				} catch (NumberFormatException e) {
					// Suppress exception as it is some other non-qpp asset
					continue;
				}
			}

			if (childAssetId != null) {
				Element boxNode = getParentBoxNode(fileSourceNode);
				String boxId = ((Element)boxNode.getFirstChild()).getAttribute("UID");
				Node spreadNode = boxNode.getParentNode();
				NodeList spreadChildNodes = spreadNode.getChildNodes();
				String pageName = null;
				String pageIndex = null;
				for (int j = 0; j < spreadChildNodes.getLength(); j++) {
					Element spreadChildNode = (Element) spreadChildNodes.item(j);
					if (spreadChildNode.getNodeName().equals("PAGE")) {
						pageName = spreadChildNode.getAttribute("FORMATTEDNAME");
						pageIndex = ((Element)spreadChildNode.getFirstChild()).getAttribute("UID");
					}
				}
				Element layoutNode = (Element) spreadNode.getParentNode();
				String layoutId = layoutNode.getAttribute("LAYOUT_ID");

				AssetVersion childAssetVersion = getChildAssetVersion(childAssetId, relatedAssets);
				logger.trace("Relation Metadata:{ Type:OVERLAY_ATTACHMENT, LAYOUT_ID:" + layoutId + ", PAGE_INDEX:" + pageIndex + ", PAGE_NAME:+" + pageName
						+ ", BOX_ID:" + boxId + " }");
				AttributeValueList attributeValueList = createSecondaryAttachmentAttributes(layoutId, pageIndex, pageName, boxId);
				AssetRelationInfo assetRelationInfo = new AssetRelationInfo();
				assetRelationInfo.setChildAssetId(childAssetId);
				assetRelationInfo.setChildAssetMajorVersion(childAssetVersion.getMajorVersion());
				assetRelationInfo.setChildAssetMinorVersion(childAssetVersion.getMinorVersion());
				assetRelationInfo.setAttributeValueList(attributeValueList);
				// audio and video attachments are secondary attachments in QXP.
				assetRelationInfo.setRelationTypeId(Long.valueOf(DefaultRelationTypes.OVERLAY_ATTACHMENT));

				assetRelationInfoList.getAssetRelationInfo().add(assetRelationInfo);
			}
		}
		return;
	}

	/**
	 * Identify platform asset from a set of child assets of existing platform relations based on picture reference used in deconstructed XML.
	 *
	 * @param relatedAssets ContentInfo[] and array of all asset relations which possibly refer to referenced picture
	 * @param pictureContentText Text extracted from <CONTENT> node in deconstructed XML corresponding to a picture box
	 * @return ID of Picture asset related to the document and referenced in deconstructed XML using input text.
	 * 		 -1 if no asset could be determined based on input.
	 */
	protected long getReferencedPictureAssetId(ContentInfo[] relatedAssets, String pictureContentText) {
		long childAssetId = -1;
		int lastIndex = pictureContentText.lastIndexOf(File.separator);
		String pictureName = pictureContentText.substring(lastIndex + 1);
		int firstIndex = pictureName.indexOf("_");
		// the picture child asset is usually referred as C:\QuarkXPress Server Documents\33_1.0.jpg
		if (firstIndex != -1) {
			String pictureId = pictureName.substring(0, firstIndex);
			try {
				childAssetId = Long.parseLong(pictureId);
			} catch (NumberFormatException e) {
				// Suppress exception as it is some other non-qpp asset
			}
		}
		if (childAssetId <= 0) {
			// If asset is not found as per the naming pattern, then look for asset with the name(in platform).
			// This would be the case only if the the QXP template used is provisioned from the QPP
			childAssetId = getAssetIdFromContentMetadata(relatedAssets, pictureName);
		}
		return childAssetId;
	}

	private String getArticleId(Document document) {
		String articleIDXpath = "//ARTICLE/ID/@UID";
		try {
			String articleId = (String) executeXPathOnDocument(document, articleIDXpath, XPathConstants.STRING);
			if (articleId != null && articleId.length()>0) {
				return articleId;
			}
		} catch (Exception ex) {
			return null;
		}
		return null;
	}

	private String getComponentIdForBox(String boxId, Document document) {
		String componentIDXpath = "//ARTICLE/COMPONENT[@BOXUID='" + boxId + "']/@UID";

		try {
			String componentId = (String) executeXPathOnDocument(document, componentIDXpath, XPathConstants.STRING);
			if (componentId != null && componentId.length()>0) {
				return componentId;
			}
		} catch (Exception ex) {
			logger.error("",ex);
			return null;
		}
		return null;
	}

	private long getAssetIdFromContentMetadata(ContentInfo[] relatedAssets, String pictureName) {
		long assetID = 0;
		for (int l = 0; l < relatedAssets.length; l++) {
			String name = relatedAssets[l].getAttributeValue(DefaultAttributes.NAME + "");
			if (pictureName.equals(name)) {
				try {
					// The id, for the given name, has been set by the previous activities in case of template attachment in QPP.
					assetID = Long.parseLong(relatedAssets[l].getAttributeValue(DefaultAttributes.ID + ""));
					break;
				} catch (NumberFormatException e) {
					// Suppress exception as it is some other non-qpp asset
				}
			}
		}
		return assetID;
	}

	private AttributeValueList createSecondaryAttachmentAttributes(String layoutId, String pageIndex, String pageName, String boxId) {
		AttributeValueList relationAttValList = new AttributeValueList();

		AttributeValue attachedLayoutAttrVal = new AttributeValue();
		attachedLayoutAttrVal.setId(DefaultAttributes.ATTACHED_LAYOUT_ID);
		attachedLayoutAttrVal.setValue(layoutId);
		relationAttValList.getAttributeValue().add(attachedLayoutAttrVal);

		AttributeValue pageIndexAttrVal = new AttributeValue();
		pageIndexAttrVal.setId(DefaultAttributes.PAGE_INDEX);
		pageIndexAttrVal.setValue(pageIndex);
		relationAttValList.getAttributeValue().add(pageIndexAttrVal);

		AttributeValue pageNameAttrVal = new AttributeValue();
		pageNameAttrVal.setId(DefaultAttributes.PAGE_NAME);
		pageNameAttrVal.setValue(pageName);
		relationAttValList.getAttributeValue().add(pageNameAttrVal);

		AttributeValue boxIdAttrVal = new AttributeValue();
		boxIdAttrVal.setId(DefaultAttributes.BOX_ID);
		boxIdAttrVal.setValue(boxId);
		relationAttValList.getAttributeValue().add(boxIdAttrVal);

		return relationAttValList;
	}

	private AttributeValueList createArticleReferenceAttributes( String articleId, String articleComponentId) {
		AttributeValueList relationAttValList = new AttributeValueList();

		AttributeValue articleIdAttrVal = new AttributeValue();
		articleIdAttrVal.setId(DefaultAttributes.ARTICLE_ID);
		articleIdAttrVal.setValue(articleId);
		relationAttValList.getAttributeValue().add(articleIdAttrVal);

		AttributeValue articleComponentIdAttrVal = new AttributeValue();
		articleComponentIdAttrVal.setId(DefaultAttributes.ARTICLE_COMPONENT_ID);
		articleComponentIdAttrVal.setValue(articleComponentId);
		relationAttValList.getAttributeValue().add(articleComponentIdAttrVal);

		return relationAttValList;
	}

	protected File getDeconstructXML(File file, boolean isCopyDesk) throws QException {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(file.getName());
		XMLRequest xmlRequest = new XMLRequest();

		if(isCopyDesk) {
			CopyDeskRequest cdr = new CopyDeskRequest();
			cdr.setRequest(xmlRequest);
			rc.setRequest(cdr);
		} else {
			rc.setRequest(xmlRequest);
		}

		rc.setResponseAsURL(true);
		QContentData qc = qxpsmStreamingService.processRequest(rc, new File[] { file });
		return new File(qc.getResponseURL());
	}

	protected AttributeValue getAttributeValue(long id, String value) {
		AttributeValue attributeValue = new AttributeValue();
		attributeValue.setId(id);
		attributeValue.setValue(value);
		return attributeValue;
	}

}

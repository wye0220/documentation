package com.quark.qpp.publishing.activity;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.core.URIHandlerRegistry;

/**
 * This Activity reads content from the given URI (available as channel/activity parameter) and make it available for other Activities. 
 */
public class FetchContentFromHttpURL extends AbstractActivity {

	/*
	 * Name with which this activity emits content 
	 */
	private String OUTPUT_CONTENT_NAME = "CONTENT_FETCHED";
	
	@Autowired
	private URIHandlerRegistry handlerRegistry;

	private String contentUrl;

	private Logger logger = Logger.getLogger(FetchContentFromHttpURL.class);
	
	protected String activityName;

	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}	

	public String getName() {
		return activityName;
	}
	
	
	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {	
		String resolvedSourceUri = resolveParameter(contentUrl, publishingContext);
		if (resolvedSourceUri == null || resolvedSourceUri.isEmpty()) {
			logger.warn("URI: " + contentUrl + " cannot be resolved as it is not provided.");
			return;
		}		
		File uriContent = handlerRegistry.resolveToFile(publishingContext.getProcessId(), convertInputToURI(resolvedSourceUri));
		if (uriContent != null) {
			publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI(resolvedSourceUri), uriContent);
		}else{
			logger.warn("URI: " + contentUrl + " cannot be resolved.");
		}
	}

	@Override
	public void clean(String processId) {
		
	}

}

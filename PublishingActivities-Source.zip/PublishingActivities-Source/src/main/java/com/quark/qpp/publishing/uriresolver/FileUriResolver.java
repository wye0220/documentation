/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.File;
import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

public class FileUriResolver implements URIResolver {
	
	private String scheme;
	
	@Autowired
	private TempFileManager tempFileManager;
	
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	@Override
	public void clean(String processId) throws Exception {
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}
	
	@Override
	public File resolveToFile(URI inputContentUri, String processId) throws Exception
	{
		String filePath = inputContentUri.getSchemeSpecificPart();
		File file = new File(filePath);
		
		// If file does not exist, try to find it in the process folder. Since TempFileManager is used across publishing for creating
		// process folder and temp files within the process
		if (file != null && !file.exists()) {
			file = tempFileManager.getTempFileWithGivenName(filePath, processId);
		}
		
		if (file == null || !file.exists()) {
			throw new PublishingException(PublishingExceptionCodes.ERROR_IN_RESOLVING_URI, new String[] { " URI:" + inputContentUri });
		}
		return file;
	}

	@Override
	public String getResourceIdentity(URI inputContentUri) {
		if (inputContentUri != null) {
			String uri = inputContentUri.toString();
			if (uri.contains("#")) {
				return uri.substring(0, uri.lastIndexOf("#"));
			}
			return uri;
		}
		return null;
	}
}

/**
 * 
 */
package com.quark.qpp.publishing.activity;

import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.TooManyQueriesException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.facade.QueryFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValue;
import com.quark.qpp.service.xmlBinding.AttributeValueList;

/**
 * This activity checks in the referred data in desired format.The corresponding Excel Data content info is also updated with the actual checked in Platform asset.
 * 
 * <p>
 * This activity requires the following input contents :
 * <li>Input content with name specified by {@link #INPUT_CONTENT_NAME}.This input content should have NON-XML attachment file
 * associated with generated rendition. Then NON-XML attachment, generated using Excel Data, are checked into Platform to create a relation with Resulting QXP.
 * Once new assets are checked into platform then existing ContentInfo of that content is updated with with new checked-in asset information.</li>
 * </p>
 * 
 */
public class CheckinReferedExcelData extends AbstractActivity {

	private String activityName;

	/**
	 * Name with which this activity expects input content of main asset's metadata XML.
	 */
	private static final String INPUT_CONTENT_NAME = "RelatedAsset";

	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private AssetService assetService;

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private QueryFacade queryFacade;

	private List<String> attributeNames ;

	public void setAttributeNames(List<String> attributeNames) {
		this.attributeNames = attributeNames;
	}

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] inputContentInfos = publishingContext.getInputContentInfos(INPUT_CONTENT_NAME);
		if (inputContentInfos != null && inputContentInfos.length > 0) {
			for(ContentInfo relatedAssetContentInfo : inputContentInfos){
				Map<String, String> attributeMap = relatedAssetContentInfo.getAttributes();
				
				if(attributeMap.containsKey(String.valueOf(DefaultAttributes.ID))){
					long assetId = Long.valueOf(attributeMap.get(String.valueOf(DefaultAttributes.ID)));

					if(isExcel(assetId) ) { 
						AttributeValueList attributeValueList = new AttributeValueList();
						List<AttributeValue> attrList = (ArrayList<AttributeValue>) attributeValueList.getAttributeValue();
						String contentInfoFileName = relatedAssetContentInfo.getFile().getName();
						String contentInfoFileExtension = contentInfoFileName.substring(contentInfoFileName.lastIndexOf(".")+1);

						Iterator<String> iterator = attributeNames.iterator();
						while (iterator.hasNext()) {
							String attributeName = iterator.next();
							Attribute attribute = attributeService.getAttributeByName(attributeName);

							if (!attributeMap.isEmpty() && attributeMap.containsKey(String.valueOf(attribute.getId()))) {
								String attrValue = null;
								if (DefaultAttributes.NAME == attribute.getId()) {
									attrValue = contentInfoFileName;
								} else if (DefaultAttributes.FILE_EXTENSION == attribute.getId()) {
									attrValue = contentInfoFileExtension;
								} else {
									attrValue = attributeMap.get(String.valueOf(attribute.getId()));
								}
								createAndAddAttributeValue(attribute.getId(), attribute.getName(), attrValue, attrList);
							}
						}
						// New Asset in checked into Platform using existing attributes of source Asset 
						AssetInfo assetInfo = checkinAsset(relatedAssetContentInfo , attributeValueList);

						// Related ContentInfo Attributes are updated with newly checked in asset's attributes
						AttributeValueList returnedAttributeValueList = assetInfo.getAttributeValueList();
						List<AttributeValue> attributeValues = returnedAttributeValueList.getAttributeValue();
						for (AttributeValue attributeValue : attributeValues){
							if ( attributeMap.containsKey(String.valueOf(attributeValue.getId()))) {
								relatedAssetContentInfo.setAttribute(String.valueOf(attributeValue.getId()), attributeValue.getValue());
							}
						}
					}
				}
			}
		}

	}

	/** Create AttributeValue object and add it to AttributeValue list */
	private void createAndAddAttributeValue(long attributeId, String attributeName, String value, List<AttributeValue> list) {
		AttributeValue attributeValue = new AttributeValue();
		attributeValue.setId(attributeId);
		attributeValue.setName(attributeName);
		attributeValue.setValue(value);
		list.add(attributeValue);
	}


	private AssetInfo checkinAsset(ContentInfo assetContentInfo, AttributeValueList attributeValueList) throws Exception {
		FileInputStream fileInputStream = new FileInputStream(assetContentInfo.getFile());

		AssetInfo assetInfo = null;
		AttributeValueList validatedAttributeValueList = validateAndUpdateAttributes(attributeValueList, assetContentInfo);

		long assetId = -1;
		try {
			// query for asset with name and collection as given in attributeValueList.
			// In case an asset with given name and collection doesn't exist, then it will be a case of new checkIn
			// else checkout and then check in the asset.
			assetId = queryForAsset(validatedAttributeValueList);
			if (assetId < 0) {
				// new checkIn scenario
				String assetName = getAttributeValue(DefaultAttributes.NAME, validatedAttributeValueList);
				assetInfo = assetFacade.checkInNew(fileInputStream, assetName, validatedAttributeValueList, null, false);
			} else {
				// asset already exists, thus checkout and then checkIn the asset.
				AttributeValueList checkOutAttributes = createAssetCheckOutAttributes();
				assetFacade.checkOut(assetId, checkOutAttributes, null);
				assetInfo = assetFacade.checkIn(fileInputStream, assetId, validatedAttributeValueList, null, false);
			}
		} catch (Exception e) {
			// In case there is an exception then abort checkOut the asset
			if (assetId > 0) {
				AssetInfo aInfo = assetFacade.getAsset(assetId, null, null,
						new String[] { String.valueOf(DefaultAttributes.IS_CHECKED_OUT) }, false, false, null, null, null, null, null, false);
				boolean assetCheckedOut = Boolean.valueOf(aInfo.getAttributeValueList().getAttributeValue().get(0).getValue());
				if (assetCheckedOut) {
					assetFacade.abortCheckout(assetId);
				}
			}
			throw e;
		} finally {
			fileInputStream.close();
		}
		return assetInfo;
	}

	private AttributeValueList validateAndUpdateAttributes(AttributeValueList attributeValueList, ContentInfo assetContentInfo)
			throws InvalidQueryDefinitionException, InvalidQueryDisplayException, TooManyQueriesException, QppServiceException,
			IllegalAccessException, InvocationTargetException {

		//@TODO Both of these maps can be combined to single map by keeping AttributeValue object as value.
		//Attribute id to values map.
		HashMap<Long, String> attributeValuesMap = new HashMap<Long, String>();
		//Attribute Ids to valueId map. Applicable only for domain values 
		HashMap<Long, Long> attributeValueIdsMap = new HashMap<Long, Long>();
		
		List<AttributeValue> attributeValues = attributeValueList.getAttributeValue();
		for (int i = 0; i < attributeValues.size(); i++) {
			long attributeId = attributeValues.get(i).getId();
			String attributeName = attributeValues.get(i).getName();
			String attributeValue = attributeValues.get(i).getValue();
			long valueId = attributeValues.get(i).getValueId();
			if (attributeName != null && attributeName.trim().length() > 0) {
				Attribute attribute = attributeService.getAttributeByName(attributeName);
				attributeId = attribute.getId();
			}
			attributeValuesMap.put(attributeId, attributeValue);
			attributeValueIdsMap.put(attributeId, valueId);
		}

		// check if collection path is supplied, convert it to collection attribute
		if (!attributeValuesMap.containsKey(DefaultAttributes.COLLECTION)) {
			String collectionPath = attributeValuesMap.get(DefaultAttributes.COLLECTION_PATH);
			if (collectionPath != null && !collectionPath.isEmpty()) {
				attributeValuesMap.put(DefaultAttributes.COLLECTION, collectionPath);
			}
		}
		
		//Should be removed in all scenarios because it is a server modifiable attribute
		attributeValuesMap.remove(DefaultAttributes.COLLECTION_PATH);
		
		String fileXtension = assetContentInfo.getFileExtension();
		if (fileXtension == null) {
			fileXtension = attributeValuesMap.get(DefaultAttributes.FILE_EXTENSION);
		}
		String mimeType = assetContentInfo.getMimeType();

		if (!attributeValuesMap.containsKey(DefaultAttributes.FILE_EXTENSION) && fileXtension != null) {
			attributeValuesMap.put(DefaultAttributes.FILE_EXTENSION, fileXtension);
		}

		if (!attributeValuesMap.containsKey(DefaultAttributes.CONTENT_TYPE)) {
			if (fileXtension != null || mimeType != null) {
				long contentType = contentStructureService.detectContentType(fileXtension, mimeType, null);
				attributeValueIdsMap.put(DefaultAttributes.CONTENT_TYPE, contentType);
				attributeValuesMap.put(DefaultAttributes.CONTENT_TYPE, "");
			}
		}

		if (attributeValuesMap.containsKey(DefaultAttributes.NAME)) {
			String assetName = attributeValuesMap.get(DefaultAttributes.NAME);
			int lastIndex = assetName.lastIndexOf(".");
			if (lastIndex > 0) {
				String subString = assetName.substring(lastIndex + 1, assetName.length());
				if (fileXtension != null && !subString.equalsIgnoreCase(fileXtension)) {
					String newName = attributeValuesMap.get(DefaultAttributes.NAME).substring(0, lastIndex) + "." + fileXtension;
					attributeValuesMap.put(DefaultAttributes.NAME, newName);
					if (!attributeValuesMap.containsKey(DefaultAttributes.ORIGINAL_FILENAME)) {
						attributeValuesMap.put(DefaultAttributes.ORIGINAL_FILENAME, newName);
					}
				}
			}
		}

		AttributeValueList newAttributeValueList = new AttributeValueList();
		Iterator<Long> keysIterator = attributeValuesMap.keySet().iterator();
		while (keysIterator.hasNext()) {
			long key = keysIterator.next();
			AttributeValue attributeValue = new AttributeValue();
			attributeValue.setId(key);
			attributeValue.setValue(attributeValuesMap.get(key));
			attributeValue.setValueId(attributeValueIdsMap.get(key));
			newAttributeValueList.getAttributeValue().add(attributeValue);
		}
		return newAttributeValueList;
	}

	// query for asset with given name and collection
	private long queryForAsset(AttributeValueList attributeValueList) throws Exception {
		String assetName = getAttributeValue(DefaultAttributes.NAME, attributeValueList);
		String collection = getAttributeValue(DefaultAttributes.COLLECTION, attributeValueList);
		HashMap<String, String> parametersMap = new HashMap<String, String>();
		parametersMap.put("Name", assetName);
		AssetInfoList assetInfoList = (AssetInfoList) queryFacade.searchAssets(new String[]{collection}, true, null, null, false, parametersMap);
		if (assetInfoList != null && assetInfoList.getAssetInfo() != null && assetInfoList.getAssetInfo().size() > 0) {
			return assetInfoList.getAssetInfo().get(0).getId();
		}
		return -1;
	}

	private String getAttributeValue(long attributeId, AttributeValueList attributeValueList) {
		List<AttributeValue> attributeValues = attributeValueList.getAttributeValue();
		for (int i = 0; i < attributeValues.size(); i++) {
			AttributeValue attributeValue = attributeValues.get(i);
			if (attributeValue.getId() == attributeId) {
				if(attributeValue.getValue() != null && attributeValue.getValue().trim().length() > 0){
					return attributeValue.getValue();
				}else{
					return attributeValue.getId()+"";
				}
			}
		}
		return null;
	}

	// create attributeValueList for asset checkOut
	private AttributeValueList createAssetCheckOutAttributes() {
		AttributeValue filePathAttribute = new AttributeValue();
		filePathAttribute.setId(DefaultAttributes.CHECKED_OUT_FILE_PATH);
		filePathAttribute.setValue(" ");

		AttributeValue checkedOutApplicationAttribute = new AttributeValue();
		checkedOutApplicationAttribute.setId(DefaultAttributes.CHECKED_OUT_APPLICATION);
		checkedOutApplicationAttribute.setValue("Publishing Activity");

		AttributeValueList attributeValueList = new AttributeValueList();
		attributeValueList.getAttributeValue().add(filePathAttribute);
		attributeValueList.getAttributeValue().add(checkedOutApplicationAttribute);

		return attributeValueList;
	}

	@Override
	public void clean(String processId) {

	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	private boolean isExcel(long assetId) throws QppServiceException {
		com.quark.qpp.core.attribute.service.dto.AttributeValue contentTypeAttr = assetService.getAttributeValues(assetId, new long[] {DefaultAttributes.CONTENT_TYPE})[0];
		long assetContentTypeId = ((DomainValue)contentTypeAttr.getAttributeValue()).getId();

		return (DefaultContentTypes.MICROSOFT_EXCEL == assetContentTypeId) || contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_EXCEL, assetContentTypeId)
				|| (DefaultContentTypes.MICROSOFT_EXCEL_TEMPLATE == assetContentTypeId) || contentStructureService.isValidAncestor(DefaultContentTypes.MICROSOFT_EXCEL_TEMPLATE, assetContentTypeId);
	}
}

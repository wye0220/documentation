/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;

import com.quark.qpp.publishing.framework.URIResolver;
import com.quark.qpp.publishing.util.TempFileManager;

public class ClasspathUriResolver implements URIResolver {
	
	private String scheme;
	
	@Autowired
	private TempFileManager fileManager;
	
	private Map<String,Map<URI,File>> processURIFileRegistry;
	
	@PostConstruct
	public void init() {
		processURIFileRegistry = new HashMap<String,Map<URI,File>>();
	}
	
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	@Override
	public void clean(String processId) throws Exception {
		processURIFileRegistry.remove(processId);
		fileManager.cleanup(processId);	
	}

	@Override
	public String getSupportedScheme() {
		return scheme;
	}
	
	@Override
	public File resolveToFile(URI inputContentUri, String processId) throws Exception
	{
		String filePath = inputContentUri.getSchemeSpecificPart();
		ClassPathResource classPathResource = new ClassPathResource(filePath);
		
		try {
			return classPathResource.getFile();
		} catch (FileNotFoundException fex) {
			// If resource is within a jar, it will not have corresponding file.			
			// In such case read content from classpath and create a temp file out of it.			
			return downloadResourceToTemp(inputContentUri, processId, classPathResource);	
		}
	}

	private File downloadResourceToTemp(URI inputContentUri, String processId, ClassPathResource classPathResource) 
		throws IOException, FileNotFoundException {
		
		// check if resource is already available in a file.
		Map<URI, File> uriFileMap = processURIFileRegistry.get(processId);
		File tempFile = null;
		if (uriFileMap != null) {
			tempFile = uriFileMap.get(inputContentUri);
		} else {
			uriFileMap = new HashMap<URI, File>();
			processURIFileRegistry.put(processId, uriFileMap);
		}
		
		if (tempFile == null) {
			// copy classpath resource to temp location
			InputStream resourceStream = classPathResource.getInputStream();
			
			String fileExtension = getExtension(inputContentUri.getSchemeSpecificPart());
			tempFile = fileManager.getTemporaryFile(fileExtension, processId);
			FileOutputStream fos = new FileOutputStream(tempFile);
			pipe(new BufferedInputStream(resourceStream), new BufferedOutputStream(fos));
			
			uriFileMap.put(inputContentUri, tempFile);
		}			
		
		return tempFile;
	}
	
	private String getExtension(String schemeSpecificPart) {
		int index = schemeSpecificPart.lastIndexOf(".");
		if(index >= 0) {
			String ext = schemeSpecificPart.substring(index);
			return ext;
		}		
		return null;
	}

	private void pipe(InputStream is, OutputStream os) throws IOException {

		byte[] buffer = new byte[64*1024];
		int count = 0;
		try {
			do {
				count = is.read(buffer);
				if(count > 0) {
					os.write(buffer, 0, count);
				}
			} while (count > 0);
		} finally {
			is.close();
			os.close();
		}
	}

	@Override
	public String getResourceIdentity(URI inputContentUri) {
		if (inputContentUri != null) {
			String uri = inputContentUri.toString();
			if (uri.contains("#")) {
				return uri.substring(0, uri.lastIndexOf("#"));
			}
			return uri;
		}
		return null;
	}
}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileTypeMap;
import javax.annotation.PostConstruct;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.llom.util.AXIOMUtil;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties.Authenticator;
import org.apache.commons.httpclient.auth.AuthPolicy;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.common.utility.DateUtility;
import com.quark.qpp.http.authentication.KerberosLoginModule;
import com.quark.qpp.publishing.activity.CopyStub.CopyIntoItems;
import com.quark.qpp.publishing.activity.CopyStub.CopyIntoItemsResponse;
import com.quark.qpp.publishing.activity.CopyStub.CopyResult;
import com.quark.qpp.publishing.activity.CopyStub.CopyResultCollection;
import com.quark.qpp.publishing.activity.CopyStub.DestinationUrlCollection;
import com.quark.qpp.publishing.activity.CopyStub.FieldInformation;
import com.quark.qpp.publishing.activity.CopyStub.FieldInformationCollection;
import com.quark.qpp.publishing.activity.CopyStub.FieldType;
import com.quark.qpp.publishing.activity.CopyStub.Guid;
import com.quark.qpp.publishing.activity.ListsStub.CheckInFile;
import com.quark.qpp.publishing.activity.ListsStub.CheckInFileResponse;
import com.quark.qpp.publishing.activity.ListsStub.CheckOutFile;
import com.quark.qpp.publishing.activity.ListsStub.CheckOutFileResponse;
import com.quark.qpp.publishing.activity.ListsStub.GetListItems;
import com.quark.qpp.publishing.activity.ListsStub.GetListItemsResponse;
import com.quark.qpp.publishing.activity.ListsStub.Query_type0;
import com.quark.qpp.publishing.activity.ListsStub.UpdateListItems;
import com.quark.qpp.publishing.activity.ListsStub.UpdateListItemsResponse;
import com.quark.qpp.publishing.activity.ListsStub.Updates_type1;
import com.quark.qpp.publishing.activity.ListsStub.ViewFields_type0;
import com.quark.qpp.publishing.activity.SiteDataStub.GetList;
import com.quark.qpp.publishing.activity.SiteDataStub.GetListResponse;
import com.quark.qpp.publishing.activity.SiteDataStub._sProperty;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;

/**
 * 
 * This activity will check-In the input content with name specified in {@link #SOURCE_FILE} into SharePoint. 
 * <p>
 * Prerequisites:
 * <li>destinationPathUri : URI of the SharePoint document library or folder, to be used for check-in data</li>
 * <li>authenticationScheme : Authentication scheme to be used to access and check-in data. It can be either Kerberos or
 * NTLM.</li>
 * <li>userName : SharePoint User name to used to be access and check-in data. It is required only for NTLM
 * authentication scheme</li>
 * <li>password : Password of SharePoint user.</li>
 * <li>fileName: File Name to be used to check-in input content into SharePoint.</li>
 * </p>
 * <br>
 * <p>
 * Name with which the input content is expected is specified by variable {@link #SOURCE_FILE}.The file associated with this
 * content info will be checked into SharePoint.
 * </p>
 * 
 */
public class CheckInToSharePoint extends AbstractActivity{
	
	/**
	 * Name with which this activity expects input content
	 */
	private static final String SOURCE_FILE = "SourceImage";
	
	private String activityName; 

	private String spCopyServiceRelativePath = "_vti_bin/Copy.asmx";

	private String spListsServiceRelativePath = "_vti_bin/Lists.asmx";

	private String spSiteDataServiceRelativePath = "_vti_bin/SiteData.asmx";

	private String destinationPathUri;
	
	private String authenticationScheme;
	
	private String userName;
	
	private String password;
	
	private String fileName;

	private Map<String, String> spAttributesMap;

	private Map<String, String> documetLibraryNameMap = new HashMap<String, String>();
	
	private Map<String, String> serverUrlMap = new HashMap<String, String>();
	
	private Map<String, String> assetNameMap = new HashMap<String, String>();
	
	private Map<String, URI> spCopyServiceMap = new HashMap<String, URI>();

	private Map<String, URI> spListsServiceMap = new HashMap<String, URI>();

	private Map<String, URI> spSiteDataServiceMap = new HashMap<String, URI>();
	
	private final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

	private Map<String, String> propertyTypeMap;

	private Map<String, String> propertyNameMap;

	private File fileToBeCheckedIn;

	private Map<String, String> taxonomyAttributes = new HashMap<String, String>();

	private Map<String, Authenticator> authenticatorMap = new HashMap<String, Authenticator>();

	private Logger logger = Logger.getLogger(getClass());

	private ListsStub listStub;

	private SiteDataStub siteDataStub;

	private CopyStub copyStub;
	
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setAuthenticationScheme(String authenticationScheme) {
		this.authenticationScheme = authenticationScheme;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setDestinationPathUri(String destinationPathUri) {
		this.destinationPathUri = destinationPathUri;
	}

	@Override
	public String getName() {
		return activityName;
	}
	
	@PostConstruct
	private void init() throws ParserConfigurationException{
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
	}
	
	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

		String tempPath = resolveParameter(destinationPathUri,publishingContext);
		if (tempPath.endsWith("/")){
			tempPath = tempPath.substring(0, tempPath.length() - 1);
		}
		String libraryName = tempPath.substring(tempPath.lastIndexOf('/') + 1);
		
		String  serverUrl = tempPath.substring(0, tempPath.lastIndexOf('/') + 1);
		
		serverUrl=serverUrl.replaceAll(" ","%20");
			
		URI spCopyService = new URI(serverUrl + spCopyServiceRelativePath);
		logger.info("spcopyservice : " + spCopyService.toString());
		
		URI spListsService = new URI(serverUrl + spListsServiceRelativePath);
		logger.info("spListsService : " + spListsService.toString());

		URI spSiteDataService = new URI(serverUrl+ spSiteDataServiceRelativePath);
		logger.info("spSiteDataService : " + spSiteDataService.toString());

		String assetName = resolveParameter(fileName, publishingContext);
		String authScheme = resolveParameter(authenticationScheme,publishingContext);

		if (authScheme == null
				|| !(authScheme.equalsIgnoreCase(SharePointAuthSchemes.NTLM) 
				|| authScheme.equalsIgnoreCase(SharePointAuthSchemes.NEGOTIATE))) {

			throw new PublishingException("Authentication scheme is ("
					+ authScheme + ")is not valid. It can be either "
					+ SharePointAuthSchemes.NTLM + "or "
					+ SharePointAuthSchemes.NEGOTIATE + ".");
		}

		String user = resolveParameter(userName, publishingContext);
		String pass = resolveParameter(password, publishingContext);

		URI serverUri = null;
		try {
			serverUri = new URI(serverUrl);
		} catch (Exception e) {
			throw new PublishingException("Destination Path (" + tempPath+ ")is not valid,.");
		}
		Authenticator authenticator = getAuthenticator(user, pass,serverUri.getHost(), serverUri.getPort(),authScheme);
		serverUrlMap.put(publishingContext.getProcessId(), serverUrl);		
		documetLibraryNameMap.put(publishingContext.getProcessId(), libraryName);
		spCopyServiceMap.put(publishingContext.getProcessId(), spCopyService);
		spListsServiceMap.put(publishingContext.getProcessId(), spListsService);
		spSiteDataServiceMap.put(publishingContext.getProcessId(),spSiteDataService);
		assetNameMap.put(publishingContext.getProcessId(), assetName);
		authenticatorMap.put(publishingContext.getProcessId(), authenticator);
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		ContentInfo[] contentInfos = publishingContext.getInputContentInfos(SOURCE_FILE);

		if (contentInfos == null || contentInfos.length < 1) {
			return;
		}
		String processId = publishingContext.getProcessId();
		logger.info("Process Id : " + processId);

		this.copyStub = new CopyStub(spCopyServiceMap.get(processId).toString());
		this.copyStub = (CopyStub) initStub(copyStub, processId);
		
		
		this.listStub = new ListsStub(spListsServiceMap.get(processId).toString());
		this.listStub = (ListsStub) initStub(listStub, processId);

		this.siteDataStub = new SiteDataStub(spSiteDataServiceMap.get(processId).toString());
		this.siteDataStub = (SiteDataStub) initStub(siteDataStub, processId);

		CopyIntoItems copyIntoItems = null;
		for (ContentInfo contentInfo : contentInfos) {

			fileToBeCheckedIn = contentInfo.getFile();
			String name = assetNameMap.get(processId);
			logger.info("Name : " + name);

			if (name == null)
				name = fileToBeCheckedIn.getName();

			DestinationUrlCollection desUrlCollection = new DestinationUrlCollection();
			
			String serverUrl = serverUrlMap.get(publishingContext.getProcessId());
			String libraryName  = documetLibraryNameMap.get(publishingContext.getProcessId());
			String docLibUrl = serverUrl+ URLEncoder.encode(libraryName, "utf-8").replace("+", "%20");

			if (docLibUrl == null || docLibUrl.isEmpty()) {
				throw new PublishingException("Destination Path (" + serverUrl+ ")is not valid,.");
			}
			logger.info("docLibUrl : " + docLibUrl);

			String filePath = docLibUrl.endsWith("/") ? docLibUrl + name: docLibUrl + "/" + name;			
			logger.info("Filepath : " + filePath);
			
			desUrlCollection.addString(filePath);
			
			// Get all attributes in the library along with types
			// Add them to a map for quick search

			logger.info("libraryName : " + libraryName);
			GetList listRequest = new GetList();
			listRequest.setStrListName(libraryName);
			GetListResponse getListResponse = siteDataStub.GetList(listRequest);

			OMElement listDetails = getListResponse.getOMElement(GetListResponse.MY_QNAME,
					OMAbstractFactory.getOMFactory());
			logger.info("listDetails.toString() : " + listDetails.toString());

			DocumentBuilder db = documentBuilderFactory.newDocumentBuilder();
			ByteArrayInputStream bis = new ByteArrayInputStream(listDetails
					.toString().getBytes("UTF-8"));
			Document doc = db.parse(bis);
			String listLibraryName = doc
					.getElementsByTagName("ns1:DefaultViewUrl").item(0)
					.getTextContent();
			
			listLibraryName = listLibraryName.substring(1,listLibraryName.lastIndexOf("/Forms/"));
			listLibraryName = listLibraryName.substring(listLibraryName.lastIndexOf("/")+1);
			listLibraryName = URLEncoder.encode(listLibraryName, "utf-8").replace("+", "%20");


			copyIntoItems = new CopyIntoItems();
			copyIntoItems.setDestinationUrls(desUrlCollection);
			// This is a dummy call, needs a parameter.
			// this is changed to "+", so that parameter is passed
			// setsourceurl is mandatory parameter which needs the file from
			// which the newly created file is to be copied.
			// passing a junk value, satisfies the mandatory condition and does
			// not set the parent file, hence solving our issue.
			copyIntoItems.setSourceUrl("+");
			String destUrl= null;

			logger.info("listLibraryName : " + listLibraryName);
			if (!listLibraryName.equalsIgnoreCase(URLEncoder.encode(
					libraryName, "utf-8").replace("+", "%20"))) {
				logger.info("Negative Case");
				destUrl = serverUrl + listLibraryName + "/" + name;
				DestinationUrlCollection desUrlCollectionNew = new DestinationUrlCollection();
				desUrlCollectionNew.addString(destUrl);
				copyIntoItems.setDestinationUrls(desUrlCollectionNew);
			} else {
				destUrl = filePath;
			}

			_sProperty[] properties = getListResponse.getVProperties().get_sProperty();
			propertyTypeMap = new HashMap<String, String>();
			propertyNameMap = new HashMap<String, String>();			
			for (_sProperty property : properties) {
				logger.debug("Name :: "+property.getName()+" Title :: "+property.getTitle()+" Type :: "+property.getType());
				propertyTypeMap.put(property.getTitle(), property.getType());
				propertyNameMap.put(property.getTitle(), property.getName());
			}
			
			// checkout file if already exists
			logger.info("destUrl : " + destUrl);
			CheckOutFile checkOutspFile = new CheckOutFile();
			checkOutspFile.setPageUrl(destUrl);
			checkOutspFile.setCheckoutToLocal("false");
			checkOutspFile.setLastmodified("");
			CheckOutFileResponse chkOutResponse = null;
			try {
				chkOutResponse = listStub.CheckOutFile(checkOutspFile);
			} catch (Exception e) {
			}

			if (chkOutResponse != null&& chkOutResponse.getCheckOutFileResult()) {
				logger.info("File checked out..");
			}

			// continue with checkin
			InputStreamDataSource dataSource = null;
			CopyIntoItemsResponse response = null;
			try {
				dataSource = new InputStreamDataSource(fileToBeCheckedIn);

				DataHandler dataHandler = new DataHandler(dataSource);

				copyIntoItems.setStream(dataHandler);

				FieldInformationCollection collection = getAttributesToSet(contentInfo, propertyTypeMap, propertyNameMap);
				if (collection != null) {
					copyIntoItems.setFields(collection);
				}
				response = copyStub.CopyIntoItems(copyIntoItems);
			} finally {
				if (dataSource != null) {
					dataSource.close();
				}
			}

			CopyResultCollection resultCollection = response.getResults();

			CopyResult[] results = resultCollection.getCopyResult();
		
			for (CopyResult copyResult : results) {
				logger.info(response.getCopyIntoItemsResult() + " "
						+ copyResult.getDestinationUrl() + " "
						+ copyResult.getErrorMessage() + " "
						+ copyResult.getErrorCode());

				if (copyResult.getErrorMessage() != null) {
					throw new QppServiceException(copyResult.getErrorMessage());
				}
			}

			// Try to get list items here
			// Set TAxonomy fields here
			int methodId = 1;
			boolean processUpdate = false;
			Iterator<Entry<String,String>> taxonomyIterator = taxonomyAttributes.entrySet().iterator();
			String fileId = getSpAssetId(name, listLibraryName,libraryName);
			String updateString = "";
			while (taxonomyIterator.hasNext()) {
				Entry<String,String> pairs = taxonomyIterator.next();
				logger.debug(pairs.getKey() + " = " + pairs.getValue()+" Name :: "+propertyNameMap.get(pairs.getKey()));
			
				updateString += "<Method Cmd=\"Update\" ID=\"" + methodId
						+ "\"><Field Name=\"ID\">" + fileId + "</Field>";
				updateString += "<Field Name=\""
						+ propertyNameMap.get(pairs.getKey()) + "\">"
						+ pairs.getValue() + "</Field></Method>";
				taxonomyIterator.remove(); // avoids a ConcurrentModificationException
				methodId++;
				processUpdate = true;
			}

			if (processUpdate) {
				updateTaxonomyAttributes(updateString,libraryName);
			}
			CheckInFile checkInSpFile = new CheckInFile();

			// CheckinType A string representation of the values 0, 1 or 2,
			// where 0 = MinorCheckIn, 1 = MajorCheckIn, and
			// 2 = OverwriteCheckIn.
			checkInSpFile.setCheckinType("1");

			// pageUrl : A string that contains the full path to the document to
			// check in.
			checkInSpFile.setPageUrl(destUrl);

			// comment : A string containing optional check-in comments.
			checkInSpFile.setComment("Checkin from Platform");

			CheckInFileResponse checkinSPfileResponse = listStub.CheckInFile(checkInSpFile);

			if (checkinSPfileResponse.getCheckInFileResult()) {
				logger.info("Checked in");
			} else {
				logger.info("Already Checked in");
			}

		}
	}

	public void updateTaxonomyAttributes(String updateString,String libraryName) throws Exception {

		String batchString = "<Batch ListVersion=\"0\" OnError=\"Continue\" ViewName=\"\">"
				+ updateString + "</Batch>";
		logger.info("updateString : " + updateString);
		UpdateListItems upd = new UpdateListItems();

		upd.setListName(libraryName);
		OMElement updateElement = AXIOMUtil.stringToOM(batchString);

		Updates_type1 upt = new Updates_type1();
		upt.setExtraElement(updateElement);

		upd.setUpdates(upt);
		UpdateListItemsResponse myResp = listStub.UpdateListItems(upd);
		logger.info(myResp.getUpdateListItemsResult().getExtraElement()
				.toString());
	}

	private String getSpAssetId(String fileName, String listLibraryName,String libraryName)
			throws Exception {
		GetListItems getList = new GetListItems();
		getList.setListName(libraryName);

		Query_type0 qtp = new Query_type0();

		String queryString = "<Query><Where><Contains><FieldRef Name=\"FileRef\" /> <Value Type=\"Text\">"
				+ fileName + "</Value></Contains></Where></Query>";
		OMElement queryElement = AXIOMUtil.stringToOM(queryString);

		qtp.setExtraElement(queryElement);
		getList.setQuery(qtp);

		ViewFields_type0 vFields = new ViewFields_type0();
		String viewFileds = "<ViewFields><FieldRef Name='Title' /></ViewFields>";
		OMElement viewElement = AXIOMUtil.stringToOM(viewFileds);

		vFields.setExtraElement(viewElement);
		getList.setViewFields(vFields);

		GetListItemsResponse getListItemResponse = listStub.GetListItems(getList);
		OMElement listDetails = getListItemResponse.getOMElement(GetListItemsResponse.MY_QNAME,
				OMAbstractFactory.getOMFactory());
		logger.info(listDetails.toString());

		DocumentBuilder db = documentBuilderFactory.newDocumentBuilder();
		ByteArrayInputStream bis = new ByteArrayInputStream(listDetails
				.toString().getBytes("UTF-8"));
		Document doc = db.parse(bis);
		NodeList ndList = doc.getElementsByTagName("z:row");// ;.item(0).getAttributes().getNamedItem("ows_FileRef").getTextContent();
		String fileId = null;
		for (int i = 0; i < ndList.getLength(); i++) {
			Node aNode = ndList.item(i);
			if ((aNode.getAttributes().getNamedItem("ows_FileRef")
					.getTextContent().contains(libraryName + "/" + fileName))
					|| (aNode.getAttributes().getNamedItem("ows_FileRef")
							.getTextContent().contains(listLibraryName + "/"
							+ fileName))) {
				fileId = aNode.getAttributes().getNamedItem("ows_ID")
						.getTextContent();
			}
		}
		return fileId;

	}

	private FieldInformationCollection getAttributesToSet(
			ContentInfo contentInfo, Map<String, String> propertyTypeMap,
			Map<String, String> propertyNameMap) {
		FieldInformationCollection fieldInformationCollection = null;
		/**
		 * In spAttributesMap, key represents SharePoint attribute name and
		 * value represents its corresponding attribute in source file.
		 */
		if (spAttributesMap != null) {
			fieldInformationCollection = new FieldInformationCollection();
			Set<Entry<String, String>> attributeNames = spAttributesMap
					.entrySet();
			for (Entry<String, String> attribute : attributeNames) {
				String value = contentInfo.getAttributeValue(attribute
						.getValue());
				if (value != null) {
					FieldInformation fieldInformation = new FieldInformation();
					String spAttributeName = attribute.getKey();

					fieldInformation.setDisplayName(spAttributeName);

					logger.info(spAttributeName + " = "
							+ propertyTypeMap.get(spAttributeName));

					if (!(propertyTypeMap.get(spAttributeName) == null)
							&& propertyTypeMap.get(spAttributeName)
									.equalsIgnoreCase("DateTime")) {
						fieldInformation.setType(new FieldType(propertyTypeMap
								.get(spAttributeName), true));
						String qppDateTime = convertToLocalDate(contentInfo
								.getAttributeValue(attribute.getValue()));

						fieldInformation.setValue(qppDateTime);
					} else if (!(propertyTypeMap.get(spAttributeName) == null)
							&& propertyTypeMap.get(spAttributeName)
									.equalsIgnoreCase("invalid")) {

						if (!(propertyTypeMap.get(spAttributeName + "_0") == null)
								&& propertyTypeMap.get(spAttributeName + "_0")
										.equalsIgnoreCase("Note")) {

							taxonomyAttributes.put(spAttributeName + "_0",
									contentInfo.getAttributeValue(attribute
											.getValue()));
							fieldInformation.setType(FieldType.Note);
						} else {
							logger.info("column renamed...");
							String originalName = propertyNameMap
									.get(spAttributeName);
							String originalAttributeTitle = originalName
									.replace("_x0020_", " ");

							taxonomyAttributes.put(originalAttributeTitle
									+ "_0", contentInfo
									.getAttributeValue(attribute.getValue()));
							fieldInformation.setType(FieldType.Note);

						}

					}

					else if (!(propertyTypeMap.get(spAttributeName) == null)
							&& !propertyTypeMap.get(spAttributeName)
									.equalsIgnoreCase("invalid")) {
						fieldInformation.setType(new FieldType(propertyTypeMap
								.get(spAttributeName), true));
						fieldInformation.setValue(contentInfo
								.getAttributeValue(attribute.getValue()));

					} else {
						fieldInformation.setType(FieldType.Text);
						fieldInformation.setValue(contentInfo
								.getAttributeValue(attribute.getValue()));
					}

					Guid id = new Guid();
					id.setGuid("00000000-0000-0000-0000-000000000000");
					if (fieldInformation.getId() == null) {
						fieldInformation.setId(id);
					}
					logger.info("Attribute Name :: '" + attribute.getValue()
							+ "', SharePointt Attribute Name :: '"
							+ spAttributeName + "' Value ::'" + value + "'");
					fieldInformationCollection
							.addFieldInformation(fieldInformation);
				}
			}
		}

		return fieldInformationCollection;
	}

	@Override
	public void clean(String processId) {
		serverUrlMap.remove(processId);
		documetLibraryNameMap.remove(processId);
		spCopyServiceMap.remove(processId);
		spListsServiceMap.remove(processId);
		spSiteDataServiceMap.remove(processId);
		authenticatorMap.remove(processId);
		assetNameMap.remove(processId);
	}

	private String convertToLocalDate(String strServerDate) {
		SimpleDateFormat sdf = null;
		SimpleDateFormat inputDateFormat = null;
		Date currDate = null;
		try {
			currDate = DateUtility.parseISODate(strServerDate);
			
			sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			if (currDate == null)
			{
				inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				currDate = inputDateFormat.parse(strServerDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sdf.format(currDate);
	}

	private Authenticator getAuthenticator(String username, String password,
			String host, int port, String scheme) throws PublishingException {

		logger.info("username : " + username+" scheme : "+scheme);
		Authenticator auth = new Authenticator();
		List<String> authPref = new ArrayList<String>();
		if (scheme.equalsIgnoreCase(SharePointAuthSchemes.NTLM)) {
			
		int index = username.indexOf("\\");
		if (index < 0) {
			throw new PublishingException(
					"Given user ("
							+ username
							+ ")is not welformed.It should be in 'domain\\loginName' format.");
		}
			
		String domain = username.substring(0, index);
		username = username.substring(index + 1);
			authPref.add(AuthPolicy.NTLM);
			auth.setAuthSchemes(authPref);
			auth.setUsername(username);
			auth.setPassword(password);
			auth.setHost(host);
			// In case port is not defined in URL, it will return -1
			if (port != -1) {
				auth.setPort(port);
			}
			auth.setDomain(domain);
			auth.setAllowedRetry(true);
			//TODO SharePointAuthSchemes
		}else if(scheme.equalsIgnoreCase(SharePointAuthSchemes.NEGOTIATE)){			
			
			int index = username.indexOf("@");
			if (index < 0) {
				throw new PublishingException(
						"Given user ("
								+ username
								+ ")is not welformed.It should be in 'shortname@realm' format e.g. jsmith@FOO.BAR.COM.");
			}
			authPref.add(SharePointAuthSchemes.NEGOTIATE);
			auth.setAuthSchemes(authPref);
			auth.setUsername(username==null?"":username);
			auth.setPassword(password==null?"":password);            
			// SetThread Local variables.
            KerberosLoginModule.SetUserNameAndPassword(username, password);		
		}
		return auth;
	}

	private org.apache.axis2.client.Stub initStub(org.apache.axis2.client.Stub webServiceStub, String processId) {
		webServiceStub._getServiceClient().getOptions().setProperty(HTTPConstants.AUTHENTICATE, authenticatorMap.get(processId));
		/*
		 * we need to disengage this model because the RequestHandler class of this module sets SessionContext to null/empty values
		 * in case of a non logOn call/or a call without session id attribute.
		 * Thus subsequent calls to platform server fail with USER_NOT_LOGGED_ON exception.
		 */
		webServiceStub._getServiceClient().disengageModule("qpsSOAPRemotingHandler");
		return webServiceStub;
	}
	
	static class SharePointAuthSchemes {
		public static final String NTLM = "Ntlm";
		public static final String BASIC = "Basic";
		public static final String NEGOTIATE = "Negotiate";
	}

	public void setSpAttributesMap(Map<String, String> spAttributesMap) {
		this.spAttributesMap = spAttributesMap;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}

/**
 * Custom implementation of stream based DataSource as FileDatasource, being used earlier, does not close the stream.
 * 
 **/
class InputStreamDataSource implements DataSource {
	
	private InputStream inputStream;
	
	private File file;
	
	private Logger logger = Logger.getLogger(getClass());
	
	public InputStreamDataSource(File f) {
		this.file = f;
	}

	/**
	 * Since the getInputStream of the DataSource must return a new InputStream every time it is called - thus previous inputstream is first
	 * closed and then new inputstream is being returned
	 **/
	@Override
	public InputStream getInputStream() throws IOException {
		if (inputStream != null) {
			inputStream.close();
		}
		inputStream = new FileInputStream(this.file);
		return inputStream;
	}
	
	/**
	 * Closing the last created inputstream.
	 */
	public void close(){
		try {
			inputStream.close();
		} catch (IOException e) {
			logger.error("Unable to close stream", e);
		}
	}

	@Override
	public OutputStream getOutputStream() throws IOException {
		throw new UnsupportedOperationException("Not implemented");
	}

	@Override
	public String getContentType() {
		return FileTypeMap.getDefaultFileTypeMap().getContentType(this.file);
	}

	@Override
	public String getName() {
		return "InputStreamDataSource";
	}
}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity renders a PDF to generate previews. There will be image generated for each PDF page in the desired
 * height, width and image format. This activity outputs the preview images as zip.
 * <p>
 * Prerequisites :
 * <li>previewHeight : desired height of the preview (image)</li>
 * <li>previewWidth : desired width of the preview (image)</li>
 * <li>previewFileType : desired file type format of preview (e.g. jpg)</li>
 * <li>jawsHome : Jaws Home path</li>
 * </p>
 * <BR>
 * <p>
 * Name with which this activity expects input content is specified by {@link #IN_CONTENT_NAME}. The input content
 * should have PDF file associated with it.
 * </p>
 * <p>
 * Name with which this activity emits content is specified by {@link #OUT_CONTENT_NAME}. The output content will have a
 * zip file of previews associated with it.
 * </p>
 */
public class JawsRenderer extends AbstractActivity {
	
	private String activityName;
	
	private String maxPagesToRender;

	private String previewHeight;

	private String previewWidth;

	private String previewFileType;
	
	private String resolutionInDpi = "200";
	
	public void setResolutionInDpi(String resolutionInDpi) {
		this.resolutionInDpi = resolutionInDpi;
	}

	private Map<String, String[]> tempFilesMap = new HashMap<String, String[]>();

	private String jawsHome;
	
	private boolean createZip = true;
	
	public void setCreateZip(boolean createZip) {
		this.createZip = createZip;
	}

	//Name with which this activity requires input content
	private static final String IN_CONTENT_NAME = "PDF";
	
	//Name with which this activity emits content
	private static final String OUT_CONTENT_NAME = "PREVIEWS";

	@Autowired
	private TempFileManager fileManager;

	private Logger logger = Logger.getLogger(JawsRenderer.class);

	public void setJawsHome(String jawsHome) {
		this.jawsHome = jawsHome.replace("/", File.separator);
	}
	
	public void setMaxPagesToRender(String maxPagesToRender) {
		this.maxPagesToRender = maxPagesToRender;
	}

	public void setPreviewHeight(String previewHeight) {
		this.previewHeight = previewHeight;
	}

	public void setPreviewWidth(String previewWidth) {
		this.previewWidth = previewWidth;
	}

	public void setPreviewFileType(String previewFileType) {
		this.previewFileType = previewFileType;
	}

	@Override
	public void execute(PublishingContext publishingContext) throws InvalidAssetException, QppServiceException, Exception {

		ContentInfo[] inData = publishingContext.getInputContentInfos(IN_CONTENT_NAME);
		if (inData == null || inData.length == 0) {
			return;
		}
		
		for (int i = 0; i < inData.length; i++) {
		
		ContentInfo contentInfo = inData[i];

		String sourcePath = contentInfo.getFile().getAbsolutePath();
		int numOfPages = -1 ;
		
		try {
			numOfPages = getNumberOfpages(sourcePath, publishingContext);
		} catch (Exception ex) {
			logger.error("Error identifying number of pages. Attempt generating image for first page only.", ex);
			// Set default number of pages to one to continue preview generation.
			numOfPages = 1;
		}
		int maxPages = -1; 
				
		try {
			maxPages = Integer.parseInt(resolveParameter(maxPagesToRender, publishingContext));
		} catch ( NumberFormatException nex) {			
			logger.error("Invalid configuration for parameter maxPagesToRender:" + maxPagesToRender, nex );
		}
		
		if ((maxPages > 0) && (numOfPages > maxPages)) {
			// Limit number of PDF pages to generate preview for to that specified
			numOfPages = maxPages;
		}
		
		String destFileName = null;
		if(!createZip){
			String sourceFileName = contentInfo.getFile().getName();
			destFileName = sourceFileName.substring(0, sourceFileName.lastIndexOf("."));
		}
		
		String[] previewPagesPaths = generatePreview(sourcePath, numOfPages, contentInfo.getFile().getParent(), publishingContext, destFileName);

		tempFilesMap.put(publishingContext.getProcessId(), previewPagesPaths);
		
		if(!createZip){
			//If createZip flag is false consider 1st page and name it as per the source file
			File outputFile = new File(previewPagesPaths[0]);
		    
		    ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, convertInputToURI("file:"+outputFile.getAbsolutePath()), outputFile);

			outContentInfo.setMimeType("image/jpeg");
			outContentInfo.setFileExtension("jpg");	
			outContentInfo.setResourceName(outputFile.getName());
		}
		else{
			File zipFile = fileManager.getTemporaryFile(".zip", publishingContext.getProcessId());
			try {
				createZip(previewPagesPaths, zipFile);
			} catch (Exception ex ) {
				logger.error("Error creating zip archive." + ex.getMessage());
				throw ex;
			}
			ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(OUT_CONTENT_NAME, convertInputToURI("file:"+zipFile.getAbsolutePath()), zipFile);
	
			outContentInfo.setMimeType("application/zip");
			outContentInfo.setFileExtension("zip");	
			outContentInfo.setResourceName(zipFile.getName());
		}
		}
	}

	private void createZip(String[] filenames, File zipFile) throws IOException {
		ZipOutputStream out = null;
		try {
			out = new ZipOutputStream(new FileOutputStream(zipFile));
			byte[] buf = new byte[1024];
			// Compress the files
			for (int i = 0; i < filenames.length; i++) {
				FileInputStream in = new FileInputStream(filenames[i]);

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(getFileName(filenames[i])));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Complete the entry
				out.closeEntry();
				in.close();
			}
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					logger.error("Error closing zip stream.", e);
				}
			}
		}
	}
	
	private String getFileName(String fileName) {
		File f = new File(fileName);
		try {
			String[] parts = f.getName().split("\\.");

			int i = Integer.parseInt(parts[0]);
			String fileExtension = parts[1];
			if (i < 10)
				return String.valueOf("00" + i) + "." + fileExtension;
			if (i >= 10 && i < 100)
				return String.valueOf("0" + i) + "." + fileExtension;
			return String.valueOf(i) + "." + fileExtension;
		} catch (Exception e) {
			// In case of any exception simply return the filename that was provided
			return f.getName();
		}
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		// Nothing to validate in this activity
	}

	@Override
	public void clean(String processId) {
		fileManager.cleanup(processId);
		
		String[] tempFilepaths = tempFilesMap.get(processId);
		for (int i = 0; tempFilepaths!= null && i < tempFilepaths.length; i++) {
			new File(tempFilepaths[i]).delete();
		}
		tempFilesMap.remove(processId);
	}


	public int getNumberOfpages(String sourcePath, PublishingContext publishingContext) throws Exception {

		String tempDirPath = new File(sourcePath).getParent();

		String[] params = new String[] { "PDF", tempDirPath, sourcePath, tempDirPath + File.separator + "Preview.%d.jpg", "ATTRIBUTES",
				resolveParameter(previewWidth, publishingContext) + "X" + resolveParameter(previewHeight, publishingContext), resolveParameter(resolutionInDpi, publishingContext), "1"  };

		String strAttributes = executeAttributesCommand(params);
		int numberOfPages = Integer.parseInt(strAttributes);
		logger.debug("File Attributes : Number of Pages=" + numberOfPages);
		return numberOfPages;
	}

	public String executeAttributesCommand(String[] params) throws Exception {
		int exitStatus = -1;
		String strStdOutput = "";
		String[] allParams = null;
		try {
			String strCommand = jawsHome + File.separator + "JAWSWrapper";

			allParams = new String[params.length + 1];

			allParams[0] = strCommand;
			System.arraycopy(params, 0, allParams, 1, params.length);

			// Log only if debug level is enabled
			if (logger.isDebugEnabled()) {
				StringBuilder commandStr = new StringBuilder();
				for (int i = 0; i < allParams.length; i++) {
					commandStr.append(allParams[i]);
					commandStr.append(" ");
				}
				logger.debug("Jaws Attributes Command: " + commandStr);
			}

			Process attributeGenerationProcess = Runtime.getRuntime().exec(allParams);
			String strStdError = "";
			try {
				InputStream std = attributeGenerationProcess.getInputStream();
				InputStream err = attributeGenerationProcess.getErrorStream();
				
				StreamReader stdStream = new StreamReader(std);
				stdStream.start();
				StreamReader errStream = new StreamReader(err);
				errStream.start();
				
				exitStatus = attributeGenerationProcess.waitFor();

				strStdOutput = stdStream.strOutput;
				strStdError = errStream.strOutput;
				
			} catch (InterruptedException e2) {
				logger.error(e2);
			}

			if (exitStatus != 0) {
				logger.error("Jaws : Error extracting attributes. Exit code " + exitStatus + "; Error Output:" + strStdError);
				throw new Exception("Jaws : Attribute Extraction Error. Exit code " + exitStatus);
			}
			
			if (strStdOutput.equals("")) {
				logger.error("Jaws : Jaws failed to return attribute information. Exit code " + exitStatus + "; Error Output:" + strStdError);
				throw new Exception("Jaws : Attribute Extraction Error. Exit code " + exitStatus);
			} else {
				logger.debug("Jaws : Success Response :" + strStdOutput);
			}
		} catch (IOException exception) {
			StringBuilder commandStr = new StringBuilder();
			for (int i = 0; i < allParams.length; i++) {
				commandStr.append(allParams[i]);
				commandStr.append(" ");
			}
			logger.error("Jaws : Error launching Jaws command: " + commandStr, exception);
			throw new Exception("Jaws : Attribute Extraction Error. Exit code " + exitStatus);
		}
		return strStdOutput.trim();
	}

	public String[] generatePreview(String sourcePath, int numberOfPages, String tempDirPath, PublishingContext pubContext, String targetFileName) throws Exception {

		List<String> destinationFileList = new ArrayList<String>();
		String parentFolder = new File(sourcePath).getParent();
		String destinationPath = null;
		//Single page if targetFileName is provided
		if (targetFileName != null) {
			destinationPath = parentFolder + "/" + targetFileName + "." + previewFileType;
		} else {
			destinationPath = parentFolder + "/%d." + previewFileType;
		}
		

		String[] params = new String[] { "PDF", 
										tempDirPath, 
										sourcePath, 
										destinationPath, 
										"PREVIEW", 
										resolveParameter(previewWidth, pubContext) + "X" + resolveParameter(previewHeight,pubContext),
										resolveParameter(resolutionInDpi, pubContext),
										String.valueOf(numberOfPages) 
									};
		// Execute Jaws command and throw error if not successful
		executePreviewCommand(params);

		//Single page if targetFileName is provided
		if (targetFileName != null) {
			String filePath = destinationPath;
			destinationFileList.add(filePath);
		}
		else{
			// Collect page preview images generated by Jaws. Delete images generated beyond required number of pages (if any) 
			int counter = 0;
			while (true) {
				String filePath = parentFolder + "/" + counter + "." + previewFileType;
	
				File tempDestFile = new File(filePath);
				if (tempDestFile.exists()) {
					if (counter >= numberOfPages) {
						tempDestFile.delete();
					} else {
						destinationFileList.add(filePath);
					}
					counter++;
				} else {
					// exit when file is not found.
					break;
				}
			}
		}

		String[] destinationFilePath = destinationFileList.toArray(new String[0]);
		return destinationFilePath;

	}

	public void executePreviewCommand(String[] params) throws Exception {

		int exitStatus = -1;
		String[] allParams = null;
		try {
			String strCommand = jawsHome + File.separator + "JAWSWrapper";

			allParams = new String[params.length + 1];

			allParams[0] = strCommand;
			System.arraycopy(params, 0, allParams, 1, params.length);

			// Log only if debug level is enabled
			if (logger.isDebugEnabled()) {
				StringBuilder commandStr = new StringBuilder();
				for (int i = 0; i < allParams.length; i++) {
					commandStr.append(allParams[i]);
					commandStr.append(" ");
				}
				logger.debug("Jaws Preview Command: " + commandStr);
			}

			Process previewGenerationProcess = Runtime.getRuntime().exec(allParams);

			String strStdOutput = "";
			String strStdError = "";

			try {
				InputStream std = previewGenerationProcess.getInputStream();
				InputStream err = previewGenerationProcess.getErrorStream();
				
				StreamReader stdStream = new StreamReader(std);
				stdStream.start();
				StreamReader errStream = new StreamReader(err);
				errStream.start();
				
				exitStatus = previewGenerationProcess.waitFor();

				strStdOutput = stdStream.strOutput;
				strStdError = errStream.strOutput;
			} catch (InterruptedException e2) {
				logger.error(e2);
			}
			
			if (exitStatus != 0) {
				logger.error("Jaws : Error generating preview. Exit code " + exitStatus + "; Error Output:" + strStdError);
				throw new Exception("Jaws : Preview Generation Error. Exit code " + exitStatus);
			}

			if (!strStdOutput.equals("")) {
				logger.debug("Jaws : success text :" + strStdOutput);
			}
			if (!strStdError.equals("")) {
				logger.error("Jaws : error text :" + strStdError);
			}

		} catch (IOException exception) {
			StringBuilder commandStr = new StringBuilder();
			for (int i = 0; i < allParams.length; i++) {
				commandStr.append(allParams[i]);
				commandStr.append(" ");
			}
			logger.error("Jaws : Error launching Jaws command: " + commandStr, exception);
			throw new Exception("Jaws : Preview Generation Error. Exit code " + exitStatus);
		}
	}
	
	@Override
	public String getName() {
	return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	class StreamReader extends Thread {
		private String strOutput = "";

		private InputStream inputStream;

		public StreamReader(InputStream stream) {
			inputStream = stream;
		}

		@Override
		public void run() {
			BufferedReader bReader;
			try {
				bReader = new BufferedReader((new InputStreamReader(inputStream, "UTF-8")));
				if (inputStream != null) {
					String temp = bReader.readLine();
					while (temp != null) {
						strOutput += temp + "\n";
						temp = bReader.readLine();
						
					}
				}
			} catch (Exception e) {
				logger.error("Error while reading stream data", e);
			}			
		}
	}
}

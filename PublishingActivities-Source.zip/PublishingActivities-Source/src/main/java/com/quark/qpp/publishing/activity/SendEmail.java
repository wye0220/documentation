/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;

/**
 * This activity sends email based on the various parameters supplied. Files associated with input content of name specified by {@link #INPUT_FILE_NAME} are
 * sent as email attachments if {@link #sendFileAsAttachment} is set to true.<br>
 * 
 * <p>
 * Prerequisites:
 * <li>exchangeServer : id of the mail server to be used for exchanging mail</li>
 * <li>senderEmailId : the sender mail Id</li>
 * <li>recipientEmailIds : list of recipient mail id's</li>
 * <li>messageBody: message body</li>
 * <li>messageSubject: subject of the mail</li>
 * <li>sendFileAsAttachment: boolean flag to indicate whether the input content is to be send as attachment or the mail is to
 * be sent without content attachments.</li>
 * <br>
 * Name with which this activity expects content is represented by {@link #INPUT_FILE_NAME}.
 * 
 * </p>
 * 
 * 
 * 
 */
public class SendEmail extends AbstractActivity{
	
	//name with which this activity expects input content.
	private static String INPUT_FILE_NAME = "MailAttachment";
	
	private String activityName;
	
	private String exchangeServer;
	
	private String senderEmailId;
	
	private String messageBody;
	private String messageSubject;
	
	private String sendFileAsAttachment;
	
	private String outContentFileName;
	
	private List<String> recipientEmailIds; 

	private Map<String, String> messageBodyMap = new HashMap<String, String>();
	private Map<String, String> subjectMap = new HashMap<String, String>();
	private Map<String, String> mailServersMap = new HashMap<String, String>();
	private Map<String, String> fromMap = new HashMap<String, String>();
	private Map<String, Boolean> useAttachmentMap =new HashMap<String, Boolean>();
	
	private Map<String, List<String>> toMap = new HashMap<String, List<String>>();
	
	private Logger logger = Logger.getLogger(getClass());

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		String from = null;
		if (senderEmailId.contains("param")) {
			from = resolveParameter(senderEmailId, publishingContext);
		} else {
			from = senderEmailId;
		}
		if (from == null || from.isEmpty()) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "Sender email id is either null or not valid." });
		}
		fromMap.put(publishingContext.getProcessId(), from);

		String mailServer = null;
		if (exchangeServer.contains("param")) {
			mailServer = resolveParameter(exchangeServer, publishingContext);
		} else {
			mailServer = exchangeServer;
		}
		if (mailServer == null || mailServer.isEmpty()) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "Excnahge Server is either null or not valid." });
		}
		mailServersMap.put(publishingContext.getProcessId(), mailServer);
		
		List<String> to = null;
		String key = recipientEmailIds.get(0);
		if (key.contains("param")) {
			String receiverEmailIds = resolveParameter(key, publishingContext);
			if (receiverEmailIds == null || receiverEmailIds.isEmpty()) {
				throw new InvalidActivityParameterException(
						InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
						new String[] { "Recipients Email ids  are either null or not valid." });
			}
			// Expect receiverEmailIds in comma (;) seprated list.
			String[] emailIds = receiverEmailIds.split(";");
			to = new ArrayList<String>(emailIds.length);
			for (String string : emailIds) {
				if (!string.isEmpty()) {
					to.add(string);
				}
			}
		} else {
			to = recipientEmailIds;
		}
		
		if (to.size() == 0) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "Recipients Email ids  are either null or not valid." });
		}
		
		toMap.put(publishingContext.getProcessId(), to);
		
		String messageBo = null;
		if (messageBody.contains("param")) {
			messageBo = resolveParameter(messageBody, publishingContext);
		} else {
			messageBo = messageBody;
		}
		messageBodyMap.put(publishingContext.getProcessId(), messageBo);
		
		String subject = null;
		if (messageSubject.contains("param")) {
			subject = resolveParameter(messageSubject, publishingContext);
		} else {
			subject = messageSubject;
		}
		subjectMap.put(publishingContext.getProcessId(), subject);
		
		
		String attachment = null;
		if(sendFileAsAttachment.contains("param"))
		{
			attachment = resolveParameter(sendFileAsAttachment, publishingContext);
		} 
		Boolean useAttachment = attachment == null || attachment.equalsIgnoreCase("true");
		useAttachmentMap.put(publishingContext.getProcessId(), useAttachment);
	}
	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		
		String processId = publishingContext.getProcessId();
		ContentInfo[] filesToSend = publishingContext.getInputContentInfos(INPUT_FILE_NAME);
		if(filesToSend == null || filesToSend.length < 1)
		{
			logger.warn("No file found.");
			return;
		}
		// Get system properties
		Properties properties = System.getProperties();

		// Setup mail server
		properties.setProperty("mail.smtp.host", mailServersMap.get(processId));

		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties);
		
		for (String toEmailId : toMap.get(processId)) {
			try {
				// Create a default MimeMessage object.
				MimeMessage message = new MimeMessage(session);

				// Set From: header field of the header.
				message.setFrom(new InternetAddress(fromMap.get(processId)));

				// Set To: header field of the header.
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmailId));
				
				// Set Subject: header field
				message.setSubject(subjectMap.get(processId));

				if(useAttachmentMap.get(processId)) {
					// Create the message part
					BodyPart messageBodyPart = new MimeBodyPart();
	
					// Fill the message
					messageBodyPart.setContent(messageBodyMap.get(processId),"text/html");
	
					
					// Create a multipar message
					Multipart multipart = new MimeMultipart();
	
					// Set text message part
					multipart.addBodyPart(messageBodyPart);
					
					for (ContentInfo contentInfo : filesToSend) {
						// Part two is attachment
						messageBodyPart = new MimeBodyPart();
						String filename = contentInfo.getFile().getAbsolutePath();
						DataSource source = new FileDataSource(filename);
						messageBodyPart.setDataHandler(new DataHandler(source));
						String deliveryContentName = resolveDeliveryContentName(outContentFileName, publishingContext, contentInfo);
						messageBodyPart.setFileName(deliveryContentName);
						multipart.addBodyPart(messageBodyPart);
					}
					// Send the complete message parts
					message.setContent(multipart);
				} else {
					message.setContent(messageBodyMap.get(processId), "text/html");
				}
				// Send message
				Transport.send(message);
				logger.debug("Sent message successfully....");
			} catch (MessagingException mex) {
				mex.printStackTrace();
			}
		}
	}

	@Override
	public void clean(String processId) {
		toMap.remove(processId);
		fromMap.remove(processId);
		subjectMap.remove(processId);
		mailServersMap.remove(processId);
		messageBodyMap.remove(processId);
		useAttachmentMap.remove(processId);		
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setExchangeServer(String exchangeServer) {
		this.exchangeServer = exchangeServer;
	}

	public void setSenderEmailId(String senderEmailId) {
		this.senderEmailId = senderEmailId;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public void setRecipientEmailIds(List<String> recipientEmailIds) {
		this.recipientEmailIds = recipientEmailIds;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public void setSendFileAsAttachment(String sendFileAsAttachment) {
		this.sendFileAsAttachment = sendFileAsAttachment;
	}
	
	public void setOutContentFileName(String outContentFileName) {
		this.outContentFileName = outContentFileName;
	}
}

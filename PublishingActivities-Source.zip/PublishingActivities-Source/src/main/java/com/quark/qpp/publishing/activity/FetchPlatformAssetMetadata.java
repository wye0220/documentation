/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;

import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;

/**
 * This activity retrieves the metadata of the Platform asset.
 * 
 * Prerequisites : <li>Channel parameter ASSET_ID</li> 
 * 
 * 
 */
public class FetchPlatformAssetMetadata extends AbstractActivity {

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	private String activityName;

	@Autowired
	private TempFileManager tempFileManager;

	/*
	 * name with which this activity emits content
	 */
	private static final String OUTPUT_ASSET = "AssetMetadata";
	private String assetId;

	@Autowired
	private AssetFacade assetFacade;

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		String resolvedAssetId = resolveParameter(assetId, publishingContext);
		if (resolvedAssetId != null) {
			long assetIdParsed = 0;
			try{
				assetIdParsed = Long.parseLong(resolvedAssetId);
			}catch(NumberFormatException e){
				//Return if the asset id supplied is not a valid number
				return;
			}

			AssetInfo assetInfo = assetFacade.getAsset(assetIdParsed, null,
					null, new String[] { "all" }, false, false, null, null,
					null, null, null);
			File file = tempFileManager.getTemporaryFile(".xml", publishingContext.getProcessId());
			FileOutputStream outputStream = null;
			try {
				outputStream = new FileOutputStream(file);
				StreamResult streamResult = new StreamResult(outputStream);
				jaxb2Marshaller.marshal(assetInfo, streamResult);
			} finally {
				if (outputStream != null) {
					outputStream.close();
				}
			}
			
			ContentInfo outContent = publishingContext
					.registerOutputContentInfo(
							OUTPUT_ASSET,
							convertInputToURI("file://"
									+ file.getAbsolutePath()), file);
			outContent.setMimeType("text/xml");
			outContent.setFileExtension("xml");
			outContent.setResourceName(file.getName());
		}
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {

	}

}

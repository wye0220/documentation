/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * This activity gets file/folder from FTP Server depending upon the {@link #folderPath} and {@link #fileName} parameter values.
 * In case the {@link #fileName} variable is undefined/null, it is assumed that the folder at {@link #folderPath} is to be returned.
 * Else to get a file, both the variables {@link #fileName} & {@link #folderPath} should be defined appropriately. 
 * Name with which this activity emits content is specified in {@link #OUT_CONTENT};
 *
 * <p>
 * Prerequisites:
 * <li>serverName : name of the FTP Server</li>
 * <li>serverPort : port of the FTP Server</li>
 * <li>useFTPS : boolean value to specify whether to connect with the FTP Server over SSL</li>
 * <li>userName : name of the authorized user in FTP Server</li>
 * <li>password : password of the user</li>
 * <li>folderPath : FTP folder path from where contents are to be retrieved. If folderPath is empty it is assumed to refer to the root directory of FTP Server.</li>
 * <li>fileName : name of the file to be retrieved from the folder specified in {@link #folderPath}.</li>
 * </p>
 * 
 */
public class GetContentFromFTPServer extends AbstractActivity{

	private String activityName;

	//name with which this activity emits content
	private String OUT_CONTENT = "OutContent";

	private String serverName;

	private String serverPort;

	private String useFTPS;

	private String userName;

	private String password;

	private String folderPath;
	
	private String fileName;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private TempFileManager tempFileManager;

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		checkForValue(serverName, publishingContext);
		checkForValue(serverPort, publishingContext);
		checkForValue(folderPath, publishingContext);
		checkForValue(useFTPS, publishingContext);
		checkForValue(userName, publishingContext);
		checkForValue(password, publishingContext);
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		
		String processId = publishingContext.getProcessId();

		//resolve parameters
		String username = resolveParameter(userName, publishingContext);
		String pwd = resolveParameter(password, publishingContext);
		String server = resolveParameter(serverName, publishingContext);
		String portStr = resolveParameter(serverPort, publishingContext);
		int port = -1;
		if (portStr != null && !portStr.isEmpty()) {
            try{
                  port = Integer.valueOf(portStr);
            } catch (NumberFormatException e) {
            	throw new PublishingException("FTP port specified is invalid : "+ portStr);
            }
		}

		boolean useSecureConnection = Boolean.valueOf(resolveParameter(useFTPS, publishingContext));
		String ftpFolderPath = resolveParameter(folderPath, publishingContext);
		if(ftpFolderPath != null && ftpFolderPath.length() > 0){
			char firstChar = ftpFolderPath.charAt(0);
			/*
			 * In case the folderpath begins with forward slash, it will assumed as an absolute path in case of linux & mac.
			 * But the folder path is assumed to be relative to the root directory to which the ftp client has connected. 
			 * Thus remove the forward/backward slash.  
			 */
			if(firstChar == new Character('/')){
				ftpFolderPath = ftpFolderPath.replaceFirst("/", "");
			}else if(firstChar == new Character('\\')){
				ftpFolderPath = ftpFolderPath.replaceFirst("\\\\", "");
			} 
		}

		FTPClient client = null;
		
		//instantiate the FTPClient
		if (useSecureConnection) {
			client = new FTPSClient();//since FTPSClient extends FTPClient
		} else {
			client = new FTPClient();
		}
		
		//connect to FTPServer 
		if (port > 0) {
			client.connect(server, port);
		} else {
			client.connect(server);
		}
		try {
			//Login on to FTP Server
			boolean loginSuccessful = client.login(username, pwd);
			
			if (loginSuccessful) {
				
				// Commons FTPClient defaults to ASCII file types. Set it to Binary
				// when dealing with binary data like a zip, image, pdf etc...
				client.setFileType(FTP.BINARY_FILE_TYPE);
				String fileNameVal = resolveParameter(fileName, publishingContext);
				
				if (fileNameVal != null && !fileNameVal.isEmpty()) {
					String ftpFilePath = ftpFolderPath + "/" + fileNameVal;
					File tempFile = tempFileManager.getTempFileWithGivenName(fileNameVal, processId);
					FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
					try {
						boolean success = client.retrieveFile(ftpFilePath, fileOutputStream);
						
						// Throw exception in case file not retrieved successfully.
						if(!success){
							throw new PublishingException(PublishingExceptionCodes.ERROR_WHILE_EXECUTING_ACTIVITY,
									new String[]{"The file from FTP Server could not be retrieved successfully."+ftpFilePath});
						}
					} finally {
						fileOutputStream.close();
					}
					publishingContext.registerOutputContentInfo(OUT_CONTENT, convertInputToURI(tempFile.getAbsolutePath()), tempFile);
				} else {
					String[] fileNames = client.listNames(ftpFolderPath);
					if (fileNames == null || fileNames.length == 0) {
						throw new PublishingException("FTP folder is either empty or doesnot exist : " + ftpFolderPath);
					}
					String processFolder = tempFileManager.getProcessIdFolder(processId);
					String copiedLocation = copyContents(ftpFolderPath, publishingContext.getProcessId(), processFolder, client);
					publishingContext.registerOutputContentInfo(OUT_CONTENT, convertInputToURI(copiedLocation), new File(copiedLocation));
				}
			} else {
				throw new PublishingException(PublishingExceptionCodes.ERROR_WHILE_EXECUTING_ACTIVITY, new String[]{"Login to FTP Server was unsuccessful."});
			}
		} finally {
			client.disconnect();
			logger.debug("FTP client disconnected.");
		}
	}

	private String copyContents(String ftpFolderPath, String processId, String processFolder, FTPClient client) throws IOException, PublishingException {
		String directory = processFolder+"/"+ftpFolderPath;
		File destFolder = new File(directory);
		destFolder.mkdirs();
		FTPFile[] ftpFiles = client.listFiles(ftpFolderPath);
		for(int i=0; ftpFiles!= null && i<ftpFiles.length; i++){
			FTPFile ftpFile = ftpFiles[i];
			if(ftpFile.isFile()){
				String fileName = ftpFile.getName();
				String ftpFilePath = ftpFolderPath+"/"+fileName;
				File tempFile = tempFileManager.getTempFileWithGivenName(ftpFolderPath+"/"+fileName, processId);
				FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
				try {
					boolean success = client.retrieveFile(ftpFilePath, fileOutputStream);
					// Throw exception in case file not retrieved successfully 
					if(!success){
						throw new PublishingException(PublishingExceptionCodes.ERROR_WHILE_EXECUTING_ACTIVITY,
								new String[]{"The file from FTP Server could not be retrieved successfully."+ftpFilePath});
					}
				} finally {
					fileOutputStream.close();
				}
			}else if(ftpFile.isDirectory()){
				String childFTPFolderPath = ftpFolderPath+"/"+ftpFile.getName();
				copyContents(childFTPFolderPath, processId, processFolder, client);
			}
		}
		return directory;
	}
	
	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUseFTPS(String useFTPS) {
		this.useFTPS = useFTPS;
	}
	
	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}

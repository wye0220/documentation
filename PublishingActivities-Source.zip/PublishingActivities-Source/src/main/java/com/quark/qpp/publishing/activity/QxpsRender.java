/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.collection.service.constants.CollectionConstants;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.relation.service.constants.DefaultRelationTypes;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qxpsm.AddFileRequest;
import com.quark.qxpsm.AppStudioRequest;
import com.quark.qxpsm.CopyDeskRequest;
import com.quark.qxpsm.DeleteRequest;
import com.quark.qxpsm.EPubRenderRequest;
import com.quark.qxpsm.JPEGRenderRequest;
import com.quark.qxpsm.Layout;
import com.quark.qxpsm.NameValueParam;
import com.quark.qxpsm.PDFRenderRequest;
import com.quark.qxpsm.Page;
import com.quark.qxpsm.Project;
import com.quark.qxpsm.QContentData;
import com.quark.qxpsm.QException;
import com.quark.qxpsm.QRequestContext;
import com.quark.qxpsm.QxpsmStreamingService;
import com.quark.qxpsm.RequestParameters;
import com.quark.qxpsm.RequestService;
import com.quark.qxpsm.Spread;
import com.quark.qxpsm.XMLRequest;

/**
 *
 * This activity is used for rendering Quark XPress Projects and Quark Copydesk Articles to various render outputs
 * supported by QXPS. For example: PDF, ePub, Jpeg(output would be in zip format containing all page images).
 *
 * <p>
 * Prerequisites:
 * <li>renderFormat: The rendering format to be considered.It can have values like PDF, Jpeg, ePub, and
 * appstudio.</li>
 * <li>sourecFormat: Source format specifies whether the input content is QXP or QCD.</li>
 * <br>
 * <br>
 *
 * This activity takes in two types of content:
 * <li>Quark XPress Project which is represented by {@link #QXP_CONTENT_NAME}</li>
 * <li>Attachments represented by {@link #ATTACHEMENT_CONTENT_NAME}</li>
 * <br>
 * <br>
 *
 * Name with which this activity emits content is specified by name {@link #OUTPUT_CONTENT_NAME}.
 * </p>
 *
 **/
public class QxpsRender extends AbstractActivity {
	/*
	 * Name with which this activity expects input content
	 */
	private static final String QXP_CONTENT_NAME = "QXP";

	private static final String ATTACHEMENT_CONTENT_NAME = "QXPAttachment";
	
	private final String QXPS_TRANSACTION_UID_PARAM_NAME = "TRANSACTION-UUID";

	/*
	 * Name with which this activity emits content
	 */
	private static final String OUTPUT_CONTENT_NAME = "QxpsRenderOutput";

	private Map<String, ArrayList<String>> processDocpoolFilesMap = new HashMap<String, ArrayList<String>>();

	private Logger logger = Logger.getLogger(QxpsRender.class);

	@Autowired
	RequestService requestService;

	@Autowired
	AssetService assetService;

	@Autowired
	AssetFacade assetFacade;

	@Autowired
	QueryService queryService;

	@Autowired
	private QxpsmStreamingService qxpsmStreamingService;

	@Autowired
	private TempFileManager fileManager;

	private String activityName;

	private int qxpsmSessionTime = 300000;

	private String assetId;
	
	private boolean clearDocpool = true;
	
	public void setClearDocpool(boolean clearDocpool) {
		this.clearDocpool = clearDocpool;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	// default values
	private String renderFormat = "JPG";
	private String scale = "1";
	private String spreadView = null;
	private String layoutId = null;

	private String organization;
	private String publication;
	private String issue;

	private String articleTitle;

	private String articleSource;

	public void setArticleSource(String articleSource) {
		this.articleSource = articleSource;
	}

	private String upload;

	private String outputStyle = null;
	private String sourceFormat = "QXP";

	private String SOURCE_NAME_QCD = "QCD";

	/*
	 * Name of the user to log In to AppStudio
	 */
	private String username;

	/*
	 * Password of the user to log In to AppStudio
	 */
	private String password;
	
	private String qxpsUserName;
	private String qxpsPassword;

	public void setQxpsUserName(String qxpsUserName) {
		this.qxpsUserName = qxpsUserName;
	}

	public void setQxpsPassword(String qxpsPassword) {
		this.qxpsPassword = qxpsPassword;
	}
	

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}

	public void setUpload(String upload) {
		this.upload = upload;
	}

	public void setQxpsmSessionTime(int qxpsmSessionTime) {
		this.qxpsmSessionTime = qxpsmSessionTime;
	}

	public String getLayoutId() {
		return layoutId;
	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public String getSourceFormat() {
		return sourceFormat;
	}

	public void setSourceFormat(String sourceFormat) {
		this.sourceFormat = sourceFormat;
	}

	public void setRenderFormat(String renderFormat) {
		this.renderFormat = renderFormat;
	}

	public void setScale(String scale) {
		this.scale = scale;
	}

	public void setSpreadView(String spreadView) {
		this.spreadView = spreadView;
	}

	public void setOutputStyle(String outputStyle) {
		this.outputStyle = outputStyle;
	}

	private String convertSectionToPages;

	public void setConvertSectionToPages(String convertSectionToPages) {
		this.convertSectionToPages = convertSectionToPages;
	}


	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		ContentInfo[] streamHolders = publishingContext.getInputContentInfos(QXP_CONTENT_NAME);

		// First ContentInfo corresponds to the QXP document. Others are
		// attached assets
		String projectDocPoolName = publishingContext.getProcessId() + "/"
				+ streamHolders[0].getAttributeValue(DefaultAttributes.NAME+"");
		addFileToDocPool(publishingContext,streamHolders);

		streamHolders = publishingContext.getInputContentInfos(ATTACHEMENT_CONTENT_NAME);
		addFileToDocPool(publishingContext,streamHolders);

		// execute qxps request
		String url = null;

		String mimeType = null;
		String fileExtension = null;

		String formatStr = resolveParameter(renderFormat, publishingContext);
		String src = resolveParameter(sourceFormat, publishingContext);
		if (formatStr.equalsIgnoreCase("pdf")) {
			url = getPdf(projectDocPoolName, publishingContext, src);
			mimeType = "application/pdf";
			fileExtension = "pdf";
		} else if (formatStr.equalsIgnoreCase("jpeg")
				|| formatStr.equalsIgnoreCase("jpg")) {
			url = getJpeg(projectDocPoolName, publishingContext, src);
			mimeType = "application/zip";
			fileExtension = "zip";
		} else if (formatStr.equalsIgnoreCase("epub")) {
			url = getEpub(projectDocPoolName, publishingContext);
			mimeType = "application/octet-stream";
			fileExtension = "epub";
		} 
		else if (formatStr.equalsIgnoreCase("appstudio")) {
			url = getAppstudio(projectDocPoolName, publishingContext);
			mimeType = "application/zip";
			fileExtension = "zip";
		}
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, convertInputToURI(url));

		contentInfo.setMimeType(mimeType);
		contentInfo.setFileExtension(fileExtension);

		String modifiedUrl = url.replaceAll("\\\\", "/");
		contentInfo.setResourceName(modifiedUrl.substring(modifiedUrl.lastIndexOf("/") + 1));
	}

	private String getAppstudio(String projectDocPoolName, PublishingContext publishingContext) throws Exception {
		long projAssetId = Long.parseLong(resolveParameter(assetId, publishingContext));
		String xml = getInteractiveAttachmentXml(projAssetId);
		if (xml != null) {
			addXmlToDocPool(xml, getXmlDocpoolName(projectDocPoolName));
		}

		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(projectDocPoolName);
		rc.setResponseAsURL(true);

		AppStudioRequest ar = new AppStudioRequest();

		ar.setConvertSectionsToPageStacks(resolveParameter(convertSectionToPages, publishingContext));

		String resolvedUpload = resolveParameter(this.upload, publishingContext);
		if (resolvedUpload != null && resolvedUpload.equalsIgnoreCase("true")) {
			ar.setUpload("true");
			ar.setOrganization(resolveParameter(organization, publishingContext));
			ar.setPublication(resolveParameter(publication, publishingContext));
			ar.setIssue(resolveParameter(issue, publishingContext));
			ar.setArticle(resolveParameter(articleTitle, publishingContext));
			ar.setArticleSource(resolveParameter(articleSource, publishingContext));
			ar.setUserName(resolveParameter(username, publishingContext));
			ar.setPassword(resolveParameter(password, publishingContext));
		}

		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		requestParameters.setRequest(ar);
		rc.setRequest(requestParameters);	
		
		/* Using qxpsmStreaming service since it returns a local temp file path */
		QContentData qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private String getXmlDocpoolName(String projectDocpoolName) {
		if (projectDocpoolName != null) {
			if (projectDocpoolName.endsWith(".qxp") || projectDocpoolName.endsWith(".qpt")) {
				String name = projectDocpoolName.substring(0, projectDocpoolName.length() - 4);
				return name + ".xml";
			} else {
				return projectDocpoolName += ".xml";
			}
		}
		return null;
	}

	private String getEpub(String projectDocPoolName, PublishingContext publishingContext) throws Exception{

		long projAssetId = Long.parseLong(resolveParameter(assetId, publishingContext));
		String xml = getInteractiveAttachmentXml(projAssetId);
		if (xml != null) {
			addXmlToDocPool(xml, getXmlDocpoolName(projectDocPoolName));
		}

		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(projectDocPoolName);
		rc.setResponseAsURL(true);

		/* Create PDF Request */
		EPubRenderRequest ePubRenderRequest = new EPubRenderRequest();
		ePubRenderRequest.setOutputStyle(resolveParameter(outputStyle, publishingContext));
		ePubRenderRequest.setLayout(resolveParameter(layoutId, publishingContext));

		RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
		requestParameters.setRequest(ePubRenderRequest);
		rc.setRequest(requestParameters);	
		
		/* Using qxpsmStreaming service since it returns a local temp file path */
		QContentData qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private String getJpeg(String projectDocPoolName, PublishingContext publishingContext, String source) throws Exception {
		String session = null;
		try {
			Project project = null;
			if (source != null && source.equalsIgnoreCase(SOURCE_NAME_QCD)) {
				project = getQcdDomObject(projectDocPoolName);
			} else {
				session = qxpsmStreamingService.createSession(qxpsmSessionTime);
				qxpsmStreamingService.openDoc(projectDocPoolName, null, 0, session);
				project = getXpressDom(projectDocPoolName, session);
			}

			Map<String, String> fileNamesMap = getJpegFiles(project, projectDocPoolName, session, publishingContext, source);

			File zipFile = fileManager.getTemporaryFile(".zip", publishingContext.getProcessId());
			createZip(fileNamesMap, zipFile);
			return "file://" + zipFile.getAbsolutePath();

		} finally {
			if (projectDocPoolName != null && session != null) {
				qxpsmStreamingService.closeDoc(projectDocPoolName, session);
				qxpsmStreamingService.closeSession(session);
			}
		}
	}

	private Map<String, String> getJpegFiles(Project project, String docName, String session, PublishingContext publishingContext,
			String sourceFormat) throws QException {
		Map<String, String> fileNamesMap = new HashMap<String, String>();

		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(docName);
		rc.setResponseAsURL(true);

		JPEGRenderRequest jpgRenderRequest = new JPEGRenderRequest();
		jpgRenderRequest.setScale(resolveParameter(scale, publishingContext));

		Layout[] layouts = project.getLayouts();
		for (Layout layout : layouts) {
			if (layout.getLayoutHidden() != null && layout.getLayoutHidden().equalsIgnoreCase("true")) {
				continue;
			}
			jpgRenderRequest.setLayout(layout.getUID());
			Spread[] spreads = layout.getSpreads();
			for (int i = 0; spreads != null && i < spreads.length; i++) {
				//If spread view then make per spread request else make request for all pages of the request
				if (this.spreadView != null && resolveParameter(this.spreadView, publishingContext).equalsIgnoreCase("true")) {
					jpgRenderRequest.setSpread(spreads[i].getUID() + "");
					QContentData qData = null;
					if (session != null) {
						RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
						requestParameters.setRequest(jpgRenderRequest);
						rc.setRequest(requestParameters);	
						
						qData = qxpsmStreamingService.processRequestEx(rc, session);
						fileNamesMap.put(layout.getUID() + "_" + spreads[i].getUID(), qData.getResponseURL());
					} else if (sourceFormat != null && sourceFormat.equalsIgnoreCase(SOURCE_NAME_QCD)) {
						CopyDeskRequest copyDeskRequest = new CopyDeskRequest();
						copyDeskRequest.setRequest(jpgRenderRequest);

						NameValueParam showPagePictureParam = new NameValueParam();
						showPagePictureParam.setParamName("showPagePicture");
						showPagePictureParam.setTextValue("true");
						NameValueParam ignoreOvermatterParam = new NameValueParam();
						ignoreOvermatterParam.setParamName("ignoreOvermatter");
						ignoreOvermatterParam.setTextValue("true");

						RequestParameters requestParameters = new RequestParameters();
						requestParameters.setParams(new NameValueParam[]{showPagePictureParam, ignoreOvermatterParam});
						requestParameters.setRequest(copyDeskRequest);

						rc.setRequest(requestParameters);

						qData = qxpsmStreamingService.processRequest(rc, null);
						fileNamesMap.put(layout.getUID() + "_" + spreads[i].getUID(), qData.getResponseURL());
					}
				} else {
					Page[] pages = spreads[i].getPages();
					for (int j = 0; pages != null && j < pages.length; j++) {
						jpgRenderRequest.setPage(String.valueOf(pages[j].getUID()));
						QContentData qData = null;
						if (session != null) {
							RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
							requestParameters.setRequest(jpgRenderRequest);
							rc.setRequest(requestParameters);	
							
							qData = qxpsmStreamingService.processRequestEx(rc, session);
							fileNamesMap.put(layout.getUID() + "_" + pages[j].getUID(), qData.getResponseURL());
						} else if (sourceFormat != null && sourceFormat.equalsIgnoreCase(SOURCE_NAME_QCD)) {
							CopyDeskRequest copyDeskRequest = new CopyDeskRequest();
							copyDeskRequest.setRequest(jpgRenderRequest);

							NameValueParam showPagePictureParam = new NameValueParam();
							showPagePictureParam.setParamName("showPagePicture");
							showPagePictureParam.setTextValue("true");
							NameValueParam ignoreOvermatterParam = new NameValueParam();
							ignoreOvermatterParam.setParamName("ignoreOvermatter");
							ignoreOvermatterParam.setTextValue("true");

							RequestParameters requestParameters = new RequestParameters();
							requestParameters.setParams(new NameValueParam[]{showPagePictureParam, ignoreOvermatterParam});
							requestParameters.setRequest(copyDeskRequest);

							rc.setRequest(requestParameters);

							qData = qxpsmStreamingService.processRequest(rc, null);
							fileNamesMap.put(layout.getUID() + "_" + pages[j].getUID(), qData.getResponseURL());
						}
					}
				}
			}
		}
		return fileNamesMap;
	}

	private Project getQcdDomObject(String docName) throws QException {
		QRequestContext reqContext = new QRequestContext();
		reqContext.setDocumentName(docName);
		XMLRequest xmlRequest = new XMLRequest();
		CopyDeskRequest qcdRequest = new CopyDeskRequest();
		qcdRequest.setRequest(xmlRequest);
		reqContext.setRequest(qcdRequest);
		QContentData qContentData = requestService.processRequest(reqContext);
		return  requestService.getXPressDOMFromXML(qContentData.getTextData());

	}

	private Project getXpressDom(String savedQxpDocName, String session) throws QException {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(savedQxpDocName);
		XMLRequest xmlRequest = new XMLRequest();
		rc.setRequest(xmlRequest);

		QContentData qc = requestService.processRequestEx(rc, session);
		return requestService.getXPressDOMFromXML(qc.getTextData());

	}

	private String getPdf(String projectDocPoolName, PublishingContext publishingContext, String source) throws Exception {
		QRequestContext rc = new QRequestContext();
		rc.setDocumentName(projectDocPoolName);
		rc.setResponseAsURL(true);

		/* Create PDF Request */
		PDFRenderRequest pdfRenderRequest = new PDFRenderRequest();
		pdfRenderRequest.setLayout(resolveParameter(layoutId, publishingContext));
		String spreadViewResolved = resolveParameter(this.spreadView, publishingContext);
		if (spreadViewResolved != null && !spreadViewResolved.isEmpty()) {
			pdfRenderRequest.setSpreads(spreadViewResolved);
		}
		pdfRenderRequest.setOutputStyle(resolveParameter(outputStyle, publishingContext));

		if (source != null && source.equalsIgnoreCase(SOURCE_NAME_QCD)) {

			CopyDeskRequest copyDeskRequest = new CopyDeskRequest();
			copyDeskRequest.setRequest(pdfRenderRequest);

			NameValueParam showPagePictureParam = new NameValueParam();
			showPagePictureParam.setParamName("showPagePicture");
			showPagePictureParam.setTextValue("true");
			NameValueParam ignoreOvermatterParam = new NameValueParam();
			ignoreOvermatterParam.setParamName("ignoreOvermatter");
			ignoreOvermatterParam.setTextValue("true");

			RequestParameters requestParameters = new RequestParameters();
			requestParameters.setParams(new NameValueParam[]{showPagePictureParam, ignoreOvermatterParam});
			requestParameters.setRequest(copyDeskRequest);

			rc.setRequest(requestParameters);
		}
		else {
			RequestParameters requestParameters = getTxnUIDRequestParameter(publishingContext.getProcessId());
			requestParameters.setRequest(pdfRenderRequest);
			rc.setRequest(requestParameters);			
		}

		QContentData qData = null;
		//		qData=requestService.processRequest(rc);
		/* Using qxpsmStreaming service since it returns a local temp file path */
		qData = qxpsmStreamingService.processRequest(rc,null);
		return "file://" + qData.getResponseURL();
	}

	private void addFileToDocPool(PublishingContext publishingContext,ContentInfo[] streamHolders) throws Exception {
		if (streamHolders != null) {
			// Read input streams and upload to docpool
			for (ContentInfo contentInfo : streamHolders) {
				String docPoolName = contentInfo.getAttributeValue(DefaultAttributes.NAME + "");
				File file = contentInfo.getFile();

				long projAssetId = Long.parseLong(resolveParameter(assetId, publishingContext));
				boolean collectionDependent = false;
				String id = contentInfo.getAttributeValue(DefaultAttributes.ID + "");
				if (id != null) {
					long assetId = Long.parseLong(id);
					AssetRelation[] assetRelations = assetService.getChildAssetRelationsOfType(projAssetId,
						new long[] { DefaultRelationTypes.OVERLAY_ATTACHMENT });
					collectionDependent = isDependentOnCollectionAssets(assetId, assetRelations);
				}
				if (collectionDependent) {
					addWebViewDependencies(contentInfo, publishingContext);
				} else {
					addToDocpool(docPoolName, file, publishingContext);
				}
			}
		}
	}


	private void addToDocpool(String docName, File file, PublishingContext publishingContext) throws QException {
		QRequestContext requestContext = new QRequestContext();
		requestContext.setDocumentName(publishingContext.getProcessId()+ "/" + docName);
		requestContext.setResponseAsURL(false);

		if (qxpsUserName != null && !qxpsUserName.trim().isEmpty()) {
			requestContext.setUserName(qxpsUserName);
		}
		if (qxpsPassword != null && !qxpsPassword.trim().isEmpty()) {
			requestContext.setUserPassword(qxpsPassword);			
		}
		
		AddFileRequest addFileRequest = new AddFileRequest();

		requestContext.setRequest(addFileRequest);
		qxpsmStreamingService.processRequest(requestContext, new File[] { file });

//		Add file to the list so that it is deleted on completion
		ArrayList<String> filesList = processDocpoolFilesMap.get(publishingContext.getProcessId());
		if(filesList==null){
			filesList = new ArrayList<String>();
		}
		filesList.add(docName);
		processDocpoolFilesMap.put(publishingContext.getProcessId(), filesList);

	}

	private void addWebViewDependencies(ContentInfo contentInfo, PublishingContext publishingContext)
			throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException, QException, IOException,
			StreamingException {

		String id = contentInfo.getAttributeValue(DefaultAttributes.ID + "");
		long assetId = Long.parseLong(id);

		AttributeValue[] attValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.COLLECTION,
				DefaultAttributes.COLLECTION_PATH });

		long collectionId = getCollectionID(attValues);
		String mainAssetCollPath = getCollectionPath(attValues);

		QueryResultElement[] queryResultElements = getAssetsInCollection(collectionId);
		for (int i = 0; i < queryResultElements.length; i++) {
			AssetElement assetElement = (AssetElement) queryResultElements[i];
			AttributeValue[] attributeValues = assetElement.getAttributeValues();
			String documentName = getDocumentName(attributeValues, mainAssetCollPath, collectionId);

			List<String> filesList = processDocpoolFilesMap.get(publishingContext.getProcessId());
			if (!filesList.contains(documentName)) {
				File file = fileManager.getTempFileWithGivenName(documentName, publishingContext.getProcessId());
				FileOutputStream fos = null;
				try {
					fos = new FileOutputStream(file);
					assetFacade.getAsset(assetElement.getAssetId(), null, null, null, false, false, null, "HIGH_RES", fos, null, null, false);
				} finally {
					if (fos != null)
						fos.close();
				}
				addToDocpool(documentName, file, publishingContext);
			}
		}

	}

	private String getDocumentName(AttributeValue[] attributeValues, String mainAssetCollPath, long mainAssetCollId) {
		String collPath = getCollectionPath(attributeValues);
		String assetName = getAssetName(attributeValues);
		String documentName = null;
		if (collPath.equalsIgnoreCase(mainAssetCollPath)) {
			documentName = assetName;
		} else {
			collPath = collPath.replace(mainAssetCollPath + CollectionConstants.COLLECTION_PATH_SEPARTOR, "");
			documentName = collPath + "/" + assetName;
		}

		return "/"+mainAssetCollId + "/" + documentName;
	}

	private boolean isDependentOnCollectionAssets(long assetId, AssetRelation[] assetRelations) {
		for (int i = 0; i < assetRelations.length; i++) {
			if(assetRelations[i].getChildAssetId() == assetId){
				AttributeValue[] attributeValues = assetRelations[i].getRelationAttributes();
				for (int j = 0; j < attributeValues.length; j++) {
					if(attributeValues[j].getAttributeId() == DefaultAttributes.DEPENDENT_ON_COLLECTION_RESOURCES){
						if(attributeValues[j].getAttributeValue() != null){
							return ((BooleanValue)attributeValues[j].getAttributeValue()).getValue();
						}
					}
				}
			}
		}
		return false;
	}

	private String getAssetName(AttributeValue[] attributeValues) {
		for (int i = 0; i < attributeValues.length; i++) {
			if(attributeValues[i].getAttributeId() == DefaultAttributes.NAME){
				return ((TextValue)attributeValues[i].getAttributeValue()).getValue();
			}
		}
		return null;
	}

	private long getCollectionID(AttributeValue[] attributeValues) {
		for (int i = 0; i < attributeValues.length; i++) {
			if(attributeValues[i].getAttributeId() == DefaultAttributes.COLLECTION){
				return ((DomainValue)attributeValues[i].getAttributeValue()).getId();
			}
		}
		return -1;
	}

	private String getCollectionPath(AttributeValue[] attributeValues) {
		for (int i = 0; i < attributeValues.length; i++) {
			if(attributeValues[i].getAttributeId() == DefaultAttributes.COLLECTION_PATH){
				return ((TextValue)attributeValues[i].getAttributeValue()).getValue();
			}
		}
		return null;
	}


	private QueryResultElement[] getAssetsInCollection(long collectionId) throws InvalidQueryDefinitionException, InvalidQueryDisplayException,
			QppServiceException {
		ArrayList<QueryCondition> queryConditions = new ArrayList<QueryCondition>();

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.ASSET);
		queryContext.setCollections(new long[] { collectionId });
		queryContext.setRecursive(true);

		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[2];
		displayColumns[0] = new DisplayColumn();
		displayColumns[1] = new DisplayColumn();

		displayColumns[0].setColumnId(DefaultAttributes.NAME);
		displayColumns[0].setAttributeColumn(true);
		displayColumns[0].setWidth(100);

		displayColumns[1].setColumnId(DefaultAttributes.COLLECTION_PATH);
		displayColumns[1].setAttributeColumn(true);
		displayColumns[1].setWidth(100);

		queryDisplay.setDisplayColumns(displayColumns);

		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions.toArray(new QueryCondition[0]),
				queryContext, queryDisplay);

		return queryResultElements;

	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		// TODO We are resolving these parameters twice.
		// For better performance we can store channel parameter values
		// here itself for the execution.Ref: ImaageMagickRender activity.
		// validate if all expected parameter values are available via channel
		checkForValue(renderFormat, context);
		checkForValue(sourceFormat, context);
	}


	@Override
	public void clean(String processId) {
		// Delete process folder first
		deleteFileFromDocPool(processId);
		processDocpoolFilesMap.remove(processId);
		fileManager.cleanup(processId);
	}

	private void deleteFileFromDocPool(String fileName) {
		if(clearDocpool){
			QRequestContext requestContext = new QRequestContext();
			requestContext.setDocumentName(fileName);
			requestContext.setResponseAsURL(false);
			if (qxpsUserName != null && !qxpsUserName.trim().isEmpty()) {
				requestContext.setUserName(qxpsUserName);
			}
			if (qxpsPassword != null && !qxpsPassword.trim().isEmpty()) {
				requestContext.setUserPassword(qxpsPassword);
			}
			DeleteRequest deleteRequest = new DeleteRequest();
			requestContext.setRequest(deleteRequest);
			try {
				qxpsmStreamingService.processRequest(requestContext, null);
			logger.debug("deleted file from docpool. filename = " + fileName);
			} catch (Exception e) {
				logger.error("Unable to delete " + fileName + " from QXPS docpool.");
			}
		}
	}

	@Override
	public String getName() {
	return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	private void createZip(Map<String, String> filenames, File zipFile) {
		ZipOutputStream out = null;
		FileInputStream in = null;
		try {
			out = new ZipOutputStream(new FileOutputStream(zipFile));
			byte[] buf = new byte[1024];
			Iterator<String> keyset = filenames.keySet().iterator();
			while(keyset.hasNext()) {
				String entryName = keyset.next();
				String fileName = filenames.get(entryName);
				in = new FileInputStream(fileName);

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(entryName+".jpg"));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Complete the entry
				out.closeEntry();
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				logger.error("Error closing zip stream");
			}
		}
	}

	private String getInteractiveAttachmentXml(long projAssetId) throws QppServiceException {
		AssetRelation[] assetRelations = assetService.getChildAssetRelations(projAssetId);

		if (assetRelations == null || assetRelations.length == 0) {
			return null;
		}
		Map<Long, Map<Long, List<RelatedAssetInfo>>> layoutBoxMap = new HashMap<Long, Map<Long, List<RelatedAssetInfo>>>();
		for (int i = 0; i < assetRelations.length; i++) {
			long attachmentType = assetRelations[i].getRelationTypeId();
			if (attachmentType == DefaultRelationTypes.OVERLAY_ATTACHMENT) {
				long attachedAssetId = assetRelations[i].getChildAssetId();
				AttributeValue[] relAttributes = assetRelations[i].getRelationAttributes();
				long boxId = getBoxId(relAttributes);
				long boxLayoutId = getLayoutId(relAttributes);
				Map<Long, List<RelatedAssetInfo>> boxAssetMap = layoutBoxMap.get(boxLayoutId);
				if (boxAssetMap == null) {
					boxAssetMap = new HashMap<Long, List<RelatedAssetInfo>>();
					layoutBoxMap.put(boxLayoutId, boxAssetMap);
				}
				List<RelatedAssetInfo> assetList = boxAssetMap.get(boxId);
				if (assetList == null) {
					assetList = new ArrayList<RelatedAssetInfo>();
					boxAssetMap.put(boxId, assetList);
				}

				boolean dependentOnCollection = false;
				for (int j = 0; j < relAttributes.length; j++) {
					if(relAttributes[j].getAttributeId() == DefaultAttributes.DEPENDENT_ON_COLLECTION_RESOURCES){
						dependentOnCollection = ((BooleanValue)relAttributes[j].getAttributeValue()).getValue();
					}
				}
				AttributeValue[] attValues = assetService.getAttributeValues(attachedAssetId, new long[]{DefaultAttributes.COLLECTION, DefaultAttributes.NAME});
				long collection = getCollectionID(attValues);
				String assetName = getAssetName(attValues);
				RelatedAssetInfo relatedAssetInfo = new RelatedAssetInfo(attachedAssetId, collection, assetName, dependentOnCollection);
				assetList.add(relatedAssetInfo);

			}
		}
		if(layoutBoxMap.size() == 0){
			return null;
		}
		return createInteractivityOutputXml(layoutBoxMap);
	}

	private long getLayoutId(AttributeValue[] relAttributes) {
		for (int i = 0; i < relAttributes.length; i++) {
			if(relAttributes[i].getAttributeId() == DefaultAttributes.ATTACHED_LAYOUT_ID){
				NumericValue attrValue = (NumericValue) relAttributes[i].getAttributeValue();
				if (attrValue != null) {
					return attrValue.getValue();
				}
			}
		}
		return 0;
	}

	private long getBoxId(AttributeValue[] relAttributes) {
		for (int i = 0; i < relAttributes.length; i++) {
			if(relAttributes[i].getAttributeId() == DefaultAttributes.BOX_ID){
				NumericValue attrValue = (NumericValue) relAttributes[i].getAttributeValue();
				if (attrValue != null) {
					return attrValue.getValue();
				}
			}
		}
		return 0;
	}

	private String createInteractivityOutputXml(Map<Long, Map<Long, List<RelatedAssetInfo>>> layoutBoxMap) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		StringBuffer stringBuffer = new StringBuffer("<Project>");
		Set<Long> layoutKeySet = layoutBoxMap.keySet();
		for (Long layoutId : layoutKeySet) {
			stringBuffer.append("<Layout UID=\"" + layoutId + "\" >");
			Map<Long, List<RelatedAssetInfo>> boxAssetMap = layoutBoxMap.get(layoutId);
			if (boxAssetMap != null) {
				Set<Long> boxKeySet = boxAssetMap.keySet();
				for (Long boxId : boxKeySet) {
					stringBuffer.append("<Box UID=\"" + boxId + "\" >");
					List<RelatedAssetInfo> assetsList = boxAssetMap.get(boxId);
					if (assetsList != null) {
						for (RelatedAssetInfo attachedAsset : assetsList) {
							String attacheddAssetName = attachedAsset.assetName;// ((TextValue) attachedAssetAttributeValues[0].getAttributeValue()).getValue();
							stringBuffer.append("<Asset Id=\"" + attachedAsset.assetId + "\" name=\"" + attacheddAssetName + "\"");
							if(attachedAsset.dependentOnCollection){
								stringBuffer.append(" collection=\"" + attachedAsset.collection + "\"");
							}
							stringBuffer.append(" />");
						}
					}
					stringBuffer.append("</Box>");
				}
			}
			stringBuffer.append("</Layout>");
		}
		stringBuffer.append("</Project>");
		return stringBuffer.toString();
	}

	public void addXmlToDocPool(String xml, final String fileName) throws QException, Exception {
		byte[] file = xml.getBytes("utf-8");
		QRequestContext requestContext = new QRequestContext();
		requestContext.setDocumentName(fileName);
		requestContext.setResponseAsURL(false);
		
		if (qxpsUserName != null && !qxpsUserName.trim().isEmpty()) {
			requestContext.setUserName(qxpsUserName);
		}
		if (qxpsPassword != null && !qxpsPassword.trim().isEmpty()) {
			requestContext.setUserPassword(qxpsPassword);
		}
		
		AddFileRequest addFileRequest = new AddFileRequest();
		addFileRequest.setFileData(file);
		requestContext.setRequest(addFileRequest);

		requestService.processRequest(requestContext);
		logger.debug("added file to the docpool: fileName = " + fileName);

	}
	
	private RequestParameters getTxnUIDRequestParameter(String processId) {
		NameValueParam nameValueParam = new NameValueParam();
		nameValueParam.setParamName(QXPS_TRANSACTION_UID_PARAM_NAME);
		nameValueParam.setTextValue(processId);
		RequestParameters requestParameters = new RequestParameters();
		requestParameters.setParams(new NameValueParam[]{nameValueParam});
		return requestParameters;
	}

	class RelatedAssetInfo {
		long assetId;
		String assetName;
		long collection;
		boolean dependentOnCollection;

		public RelatedAssetInfo(long assetId, long collection, String name, boolean dependentOnCollection) {
			this.assetId = assetId;
			this.collection = collection;
			this.dependentOnCollection = dependentOnCollection;
			this.assetName = name;
		}
	}
}

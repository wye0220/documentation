/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.IDfTime;
import com.quark.qpp.common.utility.DateUtility;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;

/**
 * 
 * This activity checks-in the content into Documentum.
 * 
 * <p>
 * Prerequisites:
 * <li>userName: Documentum username to be used to check-In and access data in
 * Documentum.</li>
 * <li>password: Password of the Documentum user</li>
 * <li>Server : Hostname for Documentum.</li>
 * <li>Port : Port Number for DocBroker of Documentum.</li>
 * <li>folderPath: folder path in Documentum where the file is to be checked In</li>
 * <li>FileName (optional): Name with which the asset is to be checked in,
 * useful in case of checkin of generated assets with temporary names.</li>
 * <li>Repository Name : Documentum repository to be referred for check-In</li>
 * 
 * <br>
 * Name with which this activity expects input content is defined in the
 * variable {@link #IN_CONTENT_NAME}.The input content should have the file
 * associated that is to be checked-In.
 * </p>
 */
public class CheckInToDocumentum extends AbstractActivity {

	private Map<String, String> dcAttributesMap;

	private IDfSessionManager sessionMgr = null;

	private IDfSession session = null;

	private String activityName;

	private String repositoryName;

	private String folderPath;

	private String serverName;

	private String serverPort;

	private String userName;

	private String password;

	private String dcFileName;

	private Logger logger = Logger.getLogger(getClass());

	public void setDcFileName(String dcFileName) {
		this.dcFileName = dcFileName;
	}

	/**
	 * Name with which this activity expects input content to be checked-In.
	 */
	private String IN_CONTENT_NAME = "SourceDocument";

	public void setDcAttributesMap(Map<String, String> dcAttributesMap) {
		this.dcAttributesMap = dcAttributesMap;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String getName() {
		return this.activityName;
	}

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		checkForValue(userName, publishingContext);
		checkForValue(password, publishingContext);
		checkForValue(serverName, publishingContext);
		checkForValue(serverPort, publishingContext);
		checkForValue(folderPath, publishingContext);
		checkForValue(repositoryName, publishingContext);
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		ContentInfo[] contentInfos = publishingContext
				.getInputContentInfos(IN_CONTENT_NAME);
		if (contentInfos == null || contentInfos.length == 0) {
			return;
		}
		File f = contentInfos[0].getFile();
		setSession(resolveParameter(serverName, publishingContext),
				resolveParameter(serverPort, publishingContext),
				resolveParameter(repositoryName, publishingContext),
				resolveParameter(userName, publishingContext),
				resolveParameter(password, publishingContext));

		for (ContentInfo contentInfo : contentInfos) {
			String fileName = resolveParameter(dcFileName, publishingContext);
			if (fileName.equalsIgnoreCase("") || fileName == null) {
				fileName = f.getName();
			}

			createDocument(f, fileName,
					resolveParameter(folderPath, publishingContext),
					contentInfo);
		}
	}

	@Override
	public void clean(String processId) {
		try {
			if (session != null && session.isConnected()) {

				session.flushCache(true);

				sessionMgr.release(session);
			}
		} catch (DfException e) {
			logger.warn("",e);
		}
	}

	public CheckInToDocumentum() {
		// Nothing to do in constructor
	}

	public void createDocument(File fileContent, String docName,
			String docPath, ContentInfo contentInfo) throws Exception {

		if (getdocFormat(fileContent.getPath()) == null) {
			throw new Exception("INVALID_FILE_TYPE");
		}
		IDfDocument document = (IDfDocument) session.newObject("dm_document");
		document.setContentType(getdocFormat(fileContent.getPath()));
		document.setObjectName(docName);
		document.setFile(fileContent.getAbsolutePath()); // add content to this
															// dm_document
		setAttributesForDocument(contentInfo, document);
		// System.out.println(document.getFormat());
		document.link(docPath);
		document.save();
		// System.out.println("Asset checked in successfully.");
	}

	public void setAttributeValue(IDfDocument document, String attributeName,
			String value) {
		try {
			if (getAttrType(attributeName) != 100
					&& getDocumentumAttrName(attributeName) != null) {

				switch (getAttrType(attributeName)) {
				case 0: {
					// boolean
					boolean attrValue;

					if (value.equalsIgnoreCase("true")) {
						attrValue = true;
					} else if (value.equalsIgnoreCase("false")) {
						attrValue = false;
					} else {
						throw new Exception(
								"INVALID_BOOLEAN_VALUE for Attribute "
										+ attributeName);
					}

					document.setBoolean(getDocumentumAttrName(attributeName),
							attrValue);
					break;
				}

				case 1: {
					// Integer
					document.setInt(getDocumentumAttrName(attributeName),
							Integer.parseInt(value));
					break;
				}

				case 2: {
					// String
					document.setString(getDocumentumAttrName(attributeName),
							value);
					break;
				}

				case 3: {
					// ID
					IDfId id = new DfId(value);
					document.setId(getDocumentumAttrName(attributeName), id);
					break;
				}

				case 4: {
					// Time
					String localDate = convertToLocalDate(value);
					IDfTime time = new DfTime(localDate, "DF_TIME_PATTERN44");
					document.setTime(getDocumentumAttrName(attributeName), time);
					break;
				}

				case 5: {
					// Float
					document.setDouble(getDocumentumAttrName(attributeName),
							Double.parseDouble(value));
					break;
				}

				default:
					break;
				}

			}

		} catch (Exception e) {
			logger.error("Error Occurred while setting value for : "
					+ attributeName + " --> " + e.getLocalizedMessage()
					+ " <-- this does not affect the checkin of the document.");
		}
	}

	private String convertToLocalDate(String strServerDate) {
		SimpleDateFormat sdf = null;
		Date currDate = null;
		try {
			currDate = DateUtility.parseISODate(strServerDate);
			sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		} catch (Exception e) {
			logger.warn("",e);
		}
		return sdf.format(currDate);
	}

	public void setAttributesForDocument(ContentInfo contentInfo,
			IDfDocument document) {
		if (dcAttributesMap != null) {
			Set<Entry<String, String>> attributeNames = dcAttributesMap
					.entrySet();
			for (Entry<String, String> attribute : attributeNames) {
				String value = contentInfo.getAttributeValue(attribute
						.getValue());
				if (value != null) {
					String dcAttributeName = attribute.getKey();
					logger.debug("Attribute Name :: '" + attribute.getValue()
							+ "', Documentum Attribute Name :: '"
							+ dcAttributeName + "' Value ::'" + value + "'");
					// System.out.println("Attribute Name :: '"
					// + attribute.getValue()
					// + "', Documentum Attribute Name :: '"
					// + dcAttributeName + "' Value ::'" + value + "'");
					setAttributeValue(document, dcAttributeName, value);
				}
			}
		}
	}

	private String getDocumentumAttrName(String attrLabelText) throws Exception {
		String attrName = null;
		IDfQuery dfq = new DfQuery();
		try {
			dfq.setDQL("SELECT attr_name FROM dmi_dd_attr_info where lower(label_text)='"
					+ attrLabelText.toLowerCase()
					+ "' and type_name='dm_sysobject'");
			IDfCollection coll = dfq.execute(session, IDfQuery.DF_READ_QUERY);

			int i = 0;
			while (coll.next()) {
				attrName = coll.getString(coll.getAttr(i).getName());
				break;

			}
		} catch (Exception e) {
			logger.warn("",e);
			attrName = null;
		}
		return attrName;
	}

	private int getAttrType(String attrLabelText) throws Exception {
		int attrType = 100;
		IDfQuery dfq = new DfQuery();
		try {
			dfq.setDQL("SELECT domain_type FROM dmi_dd_attr_info where lower(label_text)='"
					+ attrLabelText.toLowerCase()
					+ "' and type_name='dm_sysobject'");
			IDfCollection coll = dfq.execute(session, IDfQuery.DF_READ_QUERY);

			int i = 0;
			while (coll.next()) {
				attrType = coll.getInt(coll.getAttr(i).getName());
				break;

			}
		} catch (Exception e) {
			logger.warn("",e);
			attrType = 100;
		}
		return attrType;
	}

	private String getdocFormat(String filePath) throws Exception {
		String fileFormat = null;
		IDfQuery dfq = new DfQuery();
		String fileExtension = filePath
				.substring(filePath.lastIndexOf('.') + 1);
		try {
			dfq.setDQL("select name from dm_format where upper(dos_extension)='"
					+ fileExtension.toUpperCase()
					+ "' and filename_modifier='' order by name");
			IDfCollection coll = dfq.execute(session, IDfQuery.DF_READ_QUERY);

			int i = 0;
			while (coll.next()) {
				fileFormat = coll.getString(coll.getAttr(i).getName());
				break;

			}
		} catch (Exception e) {
			logger.warn("",e);
			fileFormat = null;
		}
		return fileFormat;
	}

	public void setSession(String inputHostName, String inputPortNum,
			String inputDocBase, String inputUserName, String inputUserPassword)
			throws Exception {
		IDfTypedObject cfg = null;

		IDfClient client = DfClient.getLocalClient();
		sessionMgr = client.newSessionManager();

		// Alter client config to set the primary connection broker
		try {
			cfg = client.getClientConfig();
		} catch (Exception e) {
			logger.warn("",e);
		}

		// Set host name and port dynamically based on URI reference in the XML
		// Document
		cfg.setString("primary_host", inputHostName);
		cfg.setInt("primary_port", Integer.parseInt(inputPortNum));

		// System.out.println(cfg.getString("secondary_host"));
		// Setup login details.
		IDfLoginInfo login = new DfLoginInfo();
		login.setUser(inputUserName);
		login.setPassword(inputUserPassword);
		sessionMgr.setIdentity(inputDocBase, login);
		session = sessionMgr.newSession(inputDocBase);
	}
}

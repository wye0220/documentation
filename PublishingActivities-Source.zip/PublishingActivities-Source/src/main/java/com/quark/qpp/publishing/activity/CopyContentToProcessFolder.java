/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.util.TempFileManager;

/**
 * 
 * This activity copies the content to the specified folder relative to the process working directory. All content with
 * the name specified in {@link #SOURCE_CONTENT} is copied to the desired folder and registered with the name provided
 * in {@link #TARGET_CONTENT}. File names of the files associated with the source content are being used while copying.
 * 
 * <p>
 * Name with which the activity expects input content is provided by the {@link #SOURCE_CONTENT}
 * </p>
 * <p>
 * Name with which the activity emits content is provided by the {@link #TARGET_CONTENT}
 * </p>
 */
public class CopyContentToProcessFolder extends AbstractActivity {

	 /**
	  * Name with which the activity expects input content.
	  */
	private static final String SOURCE_CONTENT = "SourceContent";
	
	/**
	 * Name with which the activity emits content.
	 */
	private static final String TARGET_CONTENT = "TargetContent";

	private String processFolder = null;

	private String activityName;

	@Autowired
	private TempFileManager tempFileManager;

	public void setProcessFolder(String processFolder) {
		this.processFolder = processFolder;
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {

		// Get all the content info objects with name 'SourceFile'
		ContentInfo[] inData = publishingContext.getInputContentInfos(SOURCE_CONTENT);
		if (inData == null || inData.length == 0) {
			return;
		}

		for (ContentInfo inputInfo : inData) {
			OutputStream os = null;

			try {
				File content = inputInfo.getFile();

				InputStream is = new FileInputStream(content);

				// copy file
				String fileNameStr = content.getName();

				File temp = tempFileManager.getTempFileWithGivenName(processFolder + "/" + fileNameStr, publishingContext.getProcessId());

				os = new FileOutputStream(temp);
				pipe(is, os);
				os.close();
				ContentInfo outContentInfo = publishingContext.registerOutputContentInfo(TARGET_CONTENT, new URI("file", temp.getAbsolutePath(), null), temp);
				copyAttributes(inputInfo, outContentInfo);
			} finally {
				if (os != null)
					os.close();
			}
		}
	}

	private void copyAttributes(ContentInfo inputContnetInfo, ContentInfo outContentInfo) {
		Map<String, String> attrsMap = inputContnetInfo.getAttributes();
		if (attrsMap != null) {
			Iterator<String> keys = attrsMap.keySet().iterator();
			while (keys.hasNext()) {
				String attrName = keys.next();
				String attrValue = attrsMap.get(attrName);
				outContentInfo.setAttribute(attrName, attrValue);
			}
		}
	}

	@Override
	public void validate(PublishingContext context) throws Exception {
		//Nothing to validate in this activity
	}

	@Override
	public void clean(String processId) {
		//Nothing to clean in this activity.
	}

	@Override
	public String getName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

}

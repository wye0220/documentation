/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.asset.service.exceptions.RenditionNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;

/**
 * This activity fetches all related assets of the asset which is identified by assetId channel parameter of
 * PublishingContext. In case of an article, if the picture component has a linked picture, it will also be included in output
 * contents.
 *
 * Prerequisites :
 * <li>assetId : id of the asset whose attachments are to be retrieved.</li>
 *
 * <p>
 * This activity emits content with name {@link #OUTPUT_CONTENT_NAME} that will have attachment file
 * associated with it.
 * </p>
 */
public class GetQPPAttachments extends AbstractActivity {

	@Autowired
	AssetService assetService;

	@Autowired
	ContentStructureService contentStructureService;

	// id of the asset whose attachments are to be retrieved
	private String assetId;

	private Map<String, Long> projectAssetIdsMap = new HashMap<String, Long>();

	private String activityName;

	private List<String> attachmentAttributeNames;

 	@Autowired
	private AttributeService attributeService;

 	@Autowired
 	private TempFileManager tempFileManager;

 	@Autowired
 	AssetFacade restAssetFacade;

 	/*
 	 * names with which this activity emits content
 	 */
	private static final String OUTPUT_CONTENT_NAME = "Attachment";
	private static final String OUTPUT_PAGE_PICTURE = "ArticlePagePicture";

	@Override
	public void execute(PublishingContext publishingContext) throws InvalidAssetException, QppServiceException, Exception {
		String processId  = publishingContext.getProcessId();
		long projectAssetId = projectAssetIdsMap.get(processId);
		/* Recurse to register all children attachments as new content stream*/
		addAllChildAssetsToContext(projectAssetId, publishingContext);

		/* If input asset is copydesk then include its page picture */
		if (isCopyDesk(projectAssetId)) {
			addPagePictureToContext(projectAssetId, publishingContext);
		}
	}

	private boolean isAssetPlaceHolder(long assetId, AssetVersion assetVersion) throws QppServiceException {
		AttributeValue[] attValues = assetService.getAttributeValuesForAssetVersion(assetId, assetVersion, new long[]{DefaultAttributes.IS_PLACEHOLDER});
		if (attValues != null && attValues.length > 0) {
			BooleanValue bVal = (BooleanValue) attValues[0].getAttributeValue();
			if (bVal != null) {
				return bVal.getValue();
			}
		}
		return false;
	}

	private boolean isCopyDesk(long assetId) throws QppServiceException {
		AttributeValue contentTypeAttr = assetService.getAttributeValues(assetId, new long[] {DefaultAttributes.CONTENT_TYPE})[0];
		long assetContentTypeId = ((DomainValue)contentTypeAttr.getAttributeValue()).getId();

		return (DefaultContentTypes.QCD_ARTICLE == assetContentTypeId) || contentStructureService.isValidAncestor(DefaultContentTypes.QCD_ARTICLE, assetContentTypeId);
	}

	/**
	 * Fetch PagePicture rendition of a CopyDesk asset and register it as a content stream by the name of "PagePicture".
	 * Downloads PagePicture rendition of asset to a local file which is used as URI for the content stream.
	 */
	private void addPagePictureToContext(long assetId, PublishingContext publishingContext) throws Exception {
		FileOutputStream assetOutputStream = null;
		String renditionType = "" + DefaultRenditionTypes.ARTICLE_PAGE_PICTURE;
		try {

			File tempAssetFile = tempFileManager.getTemporaryFile(".qcp", publishingContext.getProcessId());
			assetOutputStream = new FileOutputStream(tempAssetFile);
			restAssetFacade.getAsset(assetId, null, null, null, false, false, null, renditionType, assetOutputStream, 1, 1, false);

			URI pagePicturUri = new URI("file", tempAssetFile.getCanonicalPath(), null);
			ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_PAGE_PICTURE, pagePicturUri);

			/* Set name attribute for the PagePicture content stream. The name is derived from asset's name
			 * but the file extension is .qcp */
			String assetName = getAssetName(assetId);
			String pagePictureFileName = getPagePictureFileName(assetName);
			contentInfo.setAttribute(DefaultAttributes.NAME +"",pagePictureFileName);

		} catch (StreamingException e) {
			throw new QppServiceException(e);
		} catch (RenditionNotFoundException rex){
			// Page picture may not exist for the article
		} finally {
			if (assetOutputStream != null) {
				try {
					assetOutputStream.close();
				} catch (IOException e) {
				}
			}
		}
	}

	private String getAssetName(long assetId) throws QppServiceException {
		AttributeValue attrName = assetService.getAttributeValues(assetId, new long[] {DefaultAttributes.NAME})[0];
		String assetName = ((TextValue)attrName.getAttributeValue()).getValue();
		return assetName;
	}

	private String getPagePictureFileName(String assetName) {
		int index = assetName.lastIndexOf(".");
		if(index > 0) {
			String assetNameWithoutExtension = assetName.substring(0, index);
			return assetNameWithoutExtension + ".qcp";
		} else {
			return assetName + ".qcp";
		}
	}

	private void addToContext(long assetId, AssetVersion assetVersion, PublishingContext publishingContext) throws Exception {
		StringBuilder sb = new StringBuilder();
		sb.append("//assets/");
		sb.append(assetId);
		if(assetVersion != null) {
			sb.append("?");
			sb.append("majorversion="+assetVersion.getMajorVersion());
			sb.append("&");
			sb.append("minorversion="+assetVersion.getMinorVersion());
		}
		URI assetURI = new URI("qpp", sb.toString(), null);
		ContentInfo contentInfo = publishingContext.registerOutputContentInfo(OUTPUT_CONTENT_NAME, assetURI);
		setQPSAttributes(assetId, contentInfo);

	}

	private void addAllChildAssetsToContext(long assetId, PublishingContext publishingContext) throws Exception {
		// get attachments of asset id
		AssetRelation[] allAttachments = assetService.getChildAssetRelations(assetId);
		if (allAttachments == null) {
			return;
		}
		for (AssetRelation attachment : allAttachments) {
			/*
			 * Examine if attached asset is an article or picture. In case of article, if the component has a linked picture, it must be
			 * included for output. In case attached asset is a Picture, it must be included for output.
			 */
			long attachedAssetId = attachment.getChildAssetId();
			AssetVersion attachedAssetVersion = attachment.getChildAssetVersion();

			if (isAssetPlaceHolder(attachedAssetId, attachedAssetVersion)) {
				continue;
			}
			/* Recurse to add all children attachments */
			addAllChildAssetsToContext(attachedAssetId, publishingContext);
			/* Add attached asset itself */
			addToContext(attachedAssetId, attachedAssetVersion, publishingContext);
		}

	}


	@Override
	public void validate(PublishingContext context) throws Exception {
		Long projectAssetId = getParameterValueAsLong(context,assetId);
		projectAssetIdsMap.put(context.getProcessId(), projectAssetId);
		if(attachmentAttributeNames == null)
			attachmentAttributeNames = new ArrayList<String>(0);
	}


	@Override
	public void clean(String processId) {
		projectAssetIdsMap.remove(processId);
	}

	@Override
	public String getName() {
		return activityName;
	}


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	private long getParameterValueAsLong(PublishingContext publishingContext,
			String parameterKey) throws InvalidActivityParameterException {
		String valueAsString = resolveParameter(parameterKey, publishingContext);

		if (valueAsString == null) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.PARAMETER_NOT_FOUND,
					new String[] { "Unable to ressolve parameter :: '"
							+ parameterKey + "'." });
		}
		long valueAsLong = 0;
		try {
			valueAsLong = Long.parseLong(valueAsString);
		} catch (NumberFormatException e1) {
			throw new InvalidActivityParameterException(
					InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Parameter (" + parameterKey + ") Value ("
							+ valueAsString + ") is not valid." });
		}
		return valueAsLong;
	}

	public void setAttachmentAttributeNames(List<String> attachmentAttributeNames) {
		this.attachmentAttributeNames = attachmentAttributeNames;
	}

	private void setQPSAttributes(long assetId,ContentInfo contentInfo) throws Exception
	{
		if(attachmentAttributeNames == null || attachmentAttributeNames.size() == 0){
			//Do nothing if there is no  attribute specified
			return;
		}
		long[] attributeIds = new long[attachmentAttributeNames.size()];
		int index = 0;
		for (String attributeName : attachmentAttributeNames) {
			Attribute attribute = attributeService.getAttributeByName(attributeName);
			attributeIds[index++] = attribute.getId();
		}
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, attributeIds);

		for (AttributeValue attributeValue : attributeValues) {

			String value = "";
			int type = attributeValue.getType();

			switch (type) {
			case AttributeValueTypes.NUMERIC:
				value = ((NumericValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.TEXT:
				value = ((TextValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.BOOLEAN:
				value = ((BooleanValue) attributeValue.getAttributeValue()).getValue() + "";
				break;
			case AttributeValueTypes.DATE:
				value = ((DateValue) attributeValue.getAttributeValue()).getValue();
				break;
			case AttributeValueTypes.DOMAIN:
				value = ((DomainValue) attributeValue.getAttributeValue()).getName();
				break;
			default:
				break;
			}
			contentInfo.setAttribute(attributeValue.getAttributeId() + "", value);
			}
	}
}

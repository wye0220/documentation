/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.activity;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.collection.service.constants.CollectionConstants;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.TooManyQueriesException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.publishing.framework.ContentInfo;
import com.quark.qpp.publishing.framework.PublishingContext;
import com.quark.qpp.publishing.framework.exception.InvalidActivityParameterException;
import com.quark.qpp.publishing.framework.exception.PublishingException;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes;
import com.quark.qpp.publishing.framework.exception.PublishingExceptionCodes.InvalidActivityParameterExceptionCodes;
import com.quark.qpp.publishing.util.TempFileManager;
import com.quark.qpp.service.facade.AssetFacade;
import com.quark.qpp.service.facade.AssetsByPathFacade;
import com.quark.qpp.service.facade.CollectionFacade;
import com.quark.qpp.service.facade.CollectionsByPathFacade;
import com.quark.qpp.service.facade.QueryFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AssetRelationInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValue;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.ArticleComponentInfoList;
import com.quark.qpp.service.xmlBinding.CollectionInfo;

/**
 * This activity will check In a folder, file or a zip file (after unzipping) into the platform by creating collection corresponding to a
 * folder/sub-folder and checking in files in the collection created corresponding to the containing folder.
 *
 * <p>
 * Name with which this activity expects input content is specified by {@link #SOURCE_CONTENT}. The input content URI should resolve to
 * either file or a folder containing files and sub folders. For each folder/sub-folder a collection is created and the folder files are
 * checked in to the platform in collection that was created corresponding to that file folder.
 * </p>
 *
 */
public class CheckInToPlatform extends AbstractActivity {

	private String activityName;

	/*
	 * name with which this activity expects content
	 */
	private static final String SOURCE_CONTENT = "SourceContent";

	@Autowired
	private CollectionFacade collectionFacade;

	@Autowired
	private CollectionsByPathFacade collectionbyByPathFacade;

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private QueryFacade queryFacade;

	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private AssetsByPathFacade assetsByPathFacade;

	@Autowired
	private TempFileManager tempFileManager;

	private String overwriteExisting = "false";

	public void setOverwriteExisting(String overwriteExisting) {
		this.overwriteExisting = overwriteExisting;
	}

	@Override
	public String getName() {
		return activityName;
	}

	@Override
	public void clean(String processId) {
		tempFileManager.cleanup(processId);
	}

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	/**
	 * Name with which this activity expects input content of main asset's metadata XML.
	 */
	private static final String METADATA_CONTENT_NAME = "MainAssetMetadataXML";

	/**
	 * Name with which this activity expects input content of relations XML in order to create relations of the asset
	 * being checked-In.
	 */
	private static final String RELATIONS_CONTENT_NAME = "RelationsXML";

	private String metadataXml;

	private String relationsXml;

	private String checkinType;

	public void setCheckinType(String checkinType) {
		this.checkinType = checkinType;
	}

	public void setMetadataXml(String metadataXml) {
		this.metadataXml = metadataXml;
	}

	public void setRelationsXml(String relationsXml) {
		this.relationsXml = relationsXml;
	}

	private static final Logger logger = Logger.getLogger(CheckInToPlatform.class);


	private final String CHECKIN_TYPE_FOLDER = "FOLDER";
	private final String CHECKIN_TYPE_FILE = "FILE";
	private final String CHECKIN_TYPE_UNZIP = "UNZIP";

	@Override
	public void validate(PublishingContext publishingContext) throws Exception {
		// Nothing to validate in this activity
	}

	@Override
	public void execute(PublishingContext publishingContext) throws Exception {
		String checkinTypeParam = resolveParameter(checkinType, publishingContext);
		ContentInfo[] inputContentInfos = publishingContext.getInputContentInfos(SOURCE_CONTENT);
		if (inputContentInfos == null || inputContentInfos.length == 0) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "Input content with name '" + SOURCE_CONTENT + "' not found." });
		}

		Source metadataSource = getSourceFromXML(publishingContext, metadataXml, METADATA_CONTENT_NAME);
		AssetInfo assetInfo = null;
		AttributeValueList attributeValueList = null;
		try {
			// TODO: HACK!! @since 9.5.4.1: To maintain backward compatibility with 9.5-9.5.4 builds, we are supporting METADAT_CONTENT to be XML form of either AssetInfo or
			// AttributeValueList. Need to deprecate AttributeValueList as input since it cannot be used for describing Article and Component metadata.
			Object unmarshalled =  jaxb2Marshaller.unmarshal(metadataSource);
			if(unmarshalled instanceof AssetInfo) {
				assetInfo = (AssetInfo) unmarshalled;
				attributeValueList = assetInfo.getAttributeValueList();
			} else {
				attributeValueList = (AttributeValueList) unmarshalled;
				assetInfo = new AssetInfo();
				assetInfo.setAttributeValueList(attributeValueList);
			}
		} catch (Exception e) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
					new String[] { "MetadataXml" });
		}

		String targetCollPath = getAttributeValue("Collection Path", attributeValueList);
		if(targetCollPath == null){
			targetCollPath = getAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValueList);
		}

		if (CHECKIN_TYPE_FOLDER.equalsIgnoreCase(checkinTypeParam)) {

			for (ContentInfo inputContent : inputContentInfos) {
				File sourceFolder = inputContent.getFile();
				if (sourceFolder.isDirectory()) {
					validateAndHandleOverwrite(targetCollPath+CollectionConstants.COLLECTION_PATH_SEPARTOR+sourceFolder.getName(), publishingContext);
					createCollectionAndAssets(targetCollPath, sourceFolder, publishingContext, attributeValueList);
				} else {
					throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER,
							new String[] { "Input content with name '" + SOURCE_CONTENT + "' is not a valid directory." });
				}
			}
		} else if (CHECKIN_TYPE_FILE.equalsIgnoreCase(checkinTypeParam)) {
			Source relationSource = getSourceFromXML(publishingContext, relationsXml, RELATIONS_CONTENT_NAME);
			AssetRelationInfoList assetRelationInfoList = null;
			try {
				if (relationSource != null) {
					assetRelationInfoList = (AssetRelationInfoList) jaxb2Marshaller.unmarshal(relationSource);
				}
			} catch (Exception e) {
				logger.error("Invalid activity parameter: " + RELATIONS_CONTENT_NAME + ", Exception:" + e + ", Reason:"+ e.getMessage());
				logger.debug("",e);
			}

			ContentInfo assetContentInfo = inputContentInfos[0];

			checkinAssetWithRelations(assetContentInfo, assetInfo, assetRelationInfoList);
		}
		else if (CHECKIN_TYPE_UNZIP.equalsIgnoreCase(checkinTypeParam)) {
			createCollectionHierarchy(targetCollPath);
			ContentInfo zipContentInfo = inputContentInfos[0];
			File unzipFolder =  new File(unzipGivenFile(zipContentInfo.getFile(), publishingContext));
			validateAndHandleOverwrite(targetCollPath + CollectionConstants.COLLECTION_PATH_SEPARTOR + unzipFolder.getName(),
					publishingContext);
			createCollectionAndAssets(targetCollPath,unzipFolder, publishingContext, attributeValueList);
		} else{
			throw new PublishingException(PublishingExceptionCodes.InvalidActivityParameterExceptionCodes.INVALID_PARAMETER, new String[] { "CHECKIN_TYPE" });
		}
	}


	private void validateAndHandleOverwrite(String collectionPath, PublishingContext publishingContext) throws IOException, PublishingException, QppServiceException {
		boolean overwriteResolved = Boolean.parseBoolean(resolveParameter(overwriteExisting, publishingContext));
		try {
			CollectionInfo collectionInfo = collectionbyByPathFacade.getCollection(collectionPath, null, false, false, false, false, false, false, false,
					false, false, null, null, null).getCollectionInfo().get(0);
			if (collectionInfo != null) {
				if (overwriteResolved) {
					//delete collection with assets
					collectionbyByPathFacade.deleteCollectionWithAssets(collectionPath);
				} else {
					throw new PublishingException("Cannot overwrite existing collection: " + collectionPath);
				}
			}

		} catch (InvalidCollectionException e) {
			//Suppress the exception and go ahead with creation of the given collection
		}

	}

	private void createCollectionHierarchy(String targetCollPath) throws InvalidCollectionException, InvalidAttributeValueException,
			RepositoryActionException, QppServiceException {
		CollectionInfo collectionInfo = null;
		try {
			collectionInfo = collectionbyByPathFacade.getCollection(targetCollPath, null, false, false, false, false, false, false, false,
					false, false, null, null, null).getCollectionInfo().get(0);
		} catch (InvalidCollectionException e) {
			//Suppress the exception and go ahead with creation of the given collection
		}
		if (collectionInfo == null) {
			String parentCollPath = targetCollPath.substring(0, targetCollPath.lastIndexOf(CollectionConstants.COLLECTION_PATH_SEPARTOR));
			createCollectionHierarchy(parentCollPath);
			String collName = targetCollPath.substring(targetCollPath.lastIndexOf(CollectionConstants.COLLECTION_PATH_SEPARTOR) + 1);
			collectionFacade.createCollection(collName, parentCollPath, false, "" + DefaultContentTypes.GENERAL, null);
		} else {
			return;
		}
	}

	private void checkinAssetWithRelations(ContentInfo assetContentInfo, AssetInfo assetInfo, AssetRelationInfoList assetRelationInfoList) throws Exception {
		FileInputStream fileInputStream = new FileInputStream(assetContentInfo.getFile());

		AttributeValueList attributeValueList = assetInfo.getAttributeValueList();
		AttributeValueList validatedAttributeValueList = validateAndUpdateAttributes(attributeValueList, assetContentInfo);

		boolean isArticle = (assetInfo.getArticleComponentInfoList() != null) && (assetInfo.getArticleComponentInfoList().getArticleComponentInfo().size() > 0);

		long assetId = -1;
		try {
			// query for asset with name and collection as given in attributeValueList.
			// In case an asset with given name and collection doesn't exist, then it will be a case of new checkIn
			// else checkout and then check in the asset.
			assetId = queryForAsset(validatedAttributeValueList);
			if (assetId < 0) {
				// new checkIn scenario
				String assetName = getAttributeValue(DefaultAttributes.NAME, validatedAttributeValueList);
				if(isArticle) {
					// Checkin as Article
					ArticleComponentInfoList articleComponentList = assetInfo.getArticleComponentInfoList();
					assetFacade.checkInNewArticle(fileInputStream, assetName, validatedAttributeValueList, articleComponentList, assetRelationInfoList, false);
				} else {
					assetFacade.checkInNew(fileInputStream, assetName, validatedAttributeValueList, assetRelationInfoList, false);
				}
			} else {
				// asset already exists, thus checkout and then checkIn the asset.
				AttributeValueList checkOutAttributes = createAssetCheckOutAttributes();
				assetFacade.checkOut(assetId, checkOutAttributes, null);
				if(isArticle) {
					// Checkin as Article
					ArticleComponentInfoList articleComponentList = assetInfo.getArticleComponentInfoList();
					assetFacade.checkInArticle(fileInputStream, assetId, validatedAttributeValueList, articleComponentList, assetRelationInfoList, false);
				} else {
					assetFacade.checkIn(fileInputStream, assetId, validatedAttributeValueList, assetRelationInfoList, false);
				}
			}
		} catch (Exception e) {
			// In case there is an exception then abort checkOut the asset
			if (assetId > 0) {
				AssetInfo aInfo = assetFacade.getAsset(assetId, null, null,
						new String[] { String.valueOf(DefaultAttributes.IS_CHECKED_OUT) }, false, false, null, null, null, null, null, false);
				boolean assetCheckedOut = Boolean.valueOf(aInfo.getAttributeValueList().getAttributeValue().get(0).getValue());
				if (assetCheckedOut) {
					assetFacade.abortCheckout(assetId);
				}
			}
			throw e;
		} finally {
			fileInputStream.close();
		}
	}

	// query for asset with given name and collection
	private long queryForAsset(AttributeValueList attributeValueList) throws Exception {
		String assetName = getAttributeValue(DefaultAttributes.NAME, attributeValueList);
		String collection = getAttributeValue(DefaultAttributes.COLLECTION, attributeValueList);
		HashMap<String, String> parametersMap = new HashMap<String, String>();
		parametersMap.put("Name", assetName);
		AssetInfoList assetInfoList = (AssetInfoList) queryFacade.searchAssets(new String[]{collection}, true, null, null, false, parametersMap);
		if (assetInfoList != null && assetInfoList.getAssetInfo() != null && assetInfoList.getAssetInfo().size() > 0) {
			return assetInfoList.getAssetInfo().get(0).getId();
		}
		return -1;
	}

	private AttributeValueList validateAndUpdateAttributes(AttributeValueList attributeValueList, ContentInfo assetContentInfo)
			throws InvalidQueryDefinitionException, InvalidQueryDisplayException, TooManyQueriesException, QppServiceException,
			IllegalAccessException, InvocationTargetException {

		//@TODO Both of these maps can be combined to single map by keeping AttributeValue object as value.
		//Attribute id to values map.
		HashMap<Long, String> attributeValuesMap = new HashMap<Long, String>();
		//Attribute Ids to valueId map. Applicable only for domain values 
		HashMap<Long, Long> attributeValueIdsMap = new HashMap<Long, Long>();

		List<AttributeValue> attributeValues = attributeValueList.getAttributeValue();
		for (int i = 0; i < attributeValues.size(); i++) {
			long attributeId = attributeValues.get(i).getId();
			String attributeName = attributeValues.get(i).getName();
			String attributeValue = attributeValues.get(i).getValue();
			long valueId = attributeValues.get(i).getValueId();
			if (attributeName != null && attributeName.trim().length() > 0) {
				Attribute attribute = attributeService.getAttributeByName(attributeName);
				attributeId = attribute.getId();
			} 
			attributeValuesMap.put(attributeId, attributeValue);
			attributeValueIdsMap.put(attributeId, valueId);
		}

		// check if collection path is supplied, convert it to collection attribute
		if (!attributeValuesMap.containsKey(DefaultAttributes.COLLECTION)) {
			String collectionPath = attributeValuesMap.get(DefaultAttributes.COLLECTION_PATH);
			if (collectionPath != null && !collectionPath.isEmpty()) {
				attributeValuesMap.put(DefaultAttributes.COLLECTION, collectionPath);
			}
		}
		
		//Should be removed in all scenarios because it is a server modifiable attribute
		attributeValuesMap.remove(DefaultAttributes.COLLECTION_PATH);

		String fileXtension = assetContentInfo.getFileExtension();
		if (fileXtension == null) {
			fileXtension = attributeValuesMap.get(DefaultAttributes.FILE_EXTENSION);
		}
		String mimeType = assetContentInfo.getMimeType();

		if (!attributeValuesMap.containsKey(DefaultAttributes.FILE_EXTENSION) && fileXtension != null) {
			attributeValuesMap.put(DefaultAttributes.FILE_EXTENSION, fileXtension);
		}

		if (!attributeValuesMap.containsKey(DefaultAttributes.CONTENT_TYPE)) {
			if (fileXtension != null || mimeType != null) {
				long contentType = contentStructureService.detectContentType(fileXtension, mimeType, null);
				attributeValueIdsMap.put(DefaultAttributes.CONTENT_TYPE, contentType);
				attributeValuesMap.put(DefaultAttributes.CONTENT_TYPE, "");
			}
		}

		if (attributeValuesMap.containsKey(DefaultAttributes.NAME)) {
			String assetName = attributeValuesMap.get(DefaultAttributes.NAME);
			int lastIndex = assetName.lastIndexOf(".");
			if (lastIndex > 0) {
				String subString = assetName.substring(lastIndex + 1, assetName.length());
				if (fileXtension != null && !subString.equalsIgnoreCase(fileXtension)) {
					String newName = attributeValuesMap.get(DefaultAttributes.NAME).substring(0, lastIndex) + "." + fileXtension;
					attributeValuesMap.put(DefaultAttributes.NAME, newName);
					if (!attributeValuesMap.containsKey(DefaultAttributes.ORIGINAL_FILENAME)) {
						attributeValuesMap.put(DefaultAttributes.ORIGINAL_FILENAME, newName);
					}
				}
			}
		}

		AttributeValueList newAttributeValueList = new AttributeValueList();
		Iterator<Long> keysIterator = attributeValuesMap.keySet().iterator();
		while (keysIterator.hasNext()) {
			long key = keysIterator.next();
			AttributeValue attributeValue = new AttributeValue();
			attributeValue.setId(key);
			attributeValue.setValue(attributeValuesMap.get(key));
			attributeValue.setValueId(attributeValueIdsMap.get(key));
			newAttributeValueList.getAttributeValue().add(attributeValue);
		}
		return newAttributeValueList;
	}

	// create attributeValueList for asset checkOut
	private AttributeValueList createAssetCheckOutAttributes() {
			AttributeValue filePathAttribute = new AttributeValue();
			filePathAttribute.setId(DefaultAttributes.CHECKED_OUT_FILE_PATH);
			filePathAttribute.setValue(" ");

			AttributeValue checkedOutApplicationAttribute = new AttributeValue();
			checkedOutApplicationAttribute.setId(DefaultAttributes.CHECKED_OUT_APPLICATION);
			checkedOutApplicationAttribute.setValue("Publishing Activity");

			AttributeValueList attributeValueList = new AttributeValueList();
			attributeValueList.getAttributeValue().add(filePathAttribute);
			attributeValueList.getAttributeValue().add(checkedOutApplicationAttribute);

			return attributeValueList;
		}

	private String getAttributeValue(long attributeId, AttributeValueList attributeValueList) {
		List<AttributeValue> attributeValues = attributeValueList.getAttributeValue();
		for (int i = 0; i < attributeValues.size(); i++) {
			AttributeValue attributeValue = attributeValues.get(i);
			if (attributeValue.getId() == attributeId) {
				if (attributeValue.getValue() != null && attributeValue.getValue().trim().length() > 0) {
					return attributeValue.getValue();
				} else {
					return attributeValue.getValueId() + "";
				}
			}
		}
		return null;
	}

	private String getAttributeValue(String attributeName, AttributeValueList attributeValueList) {
		List<AttributeValue> attributeValues = attributeValueList.getAttributeValue();
		for (int i = 0; i < attributeValues.size(); i++) {
			AttributeValue attributeValue = attributeValues.get(i);
			if (attributeValue.getName().equalsIgnoreCase(attributeName)) {
				return attributeValue.getValue();
			}
		}
		return null;
	}

	private void createCollectionAndAssets(String targetCollectionPath, File folder, PublishingContext publishingContext, AttributeValueList commonAttributeValueList) throws Exception {
		String collectionToBeCreated = folder.getName();
		// create collection under targetCollectionPath
		CollectionInfo collectionInfo = collectionFacade.createCollection(collectionToBeCreated, targetCollectionPath, false, ""
				+ DefaultContentTypes.GENERAL, null);
		ArrayList<AttributeValue> list = (ArrayList<AttributeValue>) collectionInfo.getAttributeValueList().getAttributeValue();
		String collectionPath = null;
		for (AttributeValue attributeValue : list) {
			if (attributeValue.getId() == DefaultAttributes.COLLECTION_PATH) {
				collectionPath = attributeValue.getValue();
				break;
			}
		}

		// fetch children and either create collection for a folder or check in
		// if child is a file
		File[] childFiles = folder.listFiles();
		for (File childFile : childFiles) {
			if (childFile.isDirectory()) {
				createCollectionAndAssets(collectionPath, childFile, publishingContext, commonAttributeValueList);
			} else if (childFile.isFile()) {
				AttributeValueList attributeValueList = appendAssetAttributesForCheckIn(childFile, commonAttributeValueList);
				checkInAsset(childFile, collectionPath, publishingContext, attributeValueList);
			}
		}
	}

	private void checkInAsset(File childFile, String collectionPath, PublishingContext publishingContext, AttributeValueList attributeValueList) throws Exception {
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(childFile);
			if(fileInputStream.available() > 0){
				attributeValueList = removeAttributeFromList("Collection Path", DefaultAttributes.COLLECTION_PATH, attributeValueList);
				assetsByPathFacade.checkInNew(fileInputStream, collectionPath + "/" + childFile.getName(), attributeValueList, null, false);
			} else{
				logger.debug("Skipped 0 KB file with name "+childFile.getName());
			}

		} finally {
			if (fileInputStream != null)
				try {
					fileInputStream.close();
				} catch (IOException e) {
					logger.warn("Error closing file stream. " + e);
				}
		}
	}

	public AttributeValueList removeAttributeFromList(String attributeName, long attributeId,
			AttributeValueList attributeValueList) {
		ArrayList<AttributeValue> list = (ArrayList<AttributeValue>) attributeValueList.getAttributeValue();
		AttributeValue attrValToBeRemoved = null;
		for (AttributeValue attributeValue : list) {
			if(attributeValue.getName().equalsIgnoreCase(attributeName) || attributeId == attributeValue.getId()){
				attrValToBeRemoved =  attributeValue;
				break;
			}
		}
		list.remove(attrValToBeRemoved);
		return attributeValueList;
	}

	private Source getSourceFromXML(PublishingContext publishingContext, String xmlParam, String contentName) throws Exception {
		Source source = null;
		URI metadataUri = null;
		String scheme = null;
		if(xmlParam!=null){
		 metadataUri = convertInputToURI(xmlParam);
		 scheme = metadataUri.getScheme();
		}
		if (scheme!=null && scheme.equalsIgnoreCase("param")) {
			String paramValue = resolveParameter(metadataUri.toString(), publishingContext);
			if (paramValue != null && !paramValue.isEmpty()) {
				source = new StreamSource(new ByteArrayInputStream(paramValue.getBytes("UTF-8")));
			} else {
				ContentInfo[] contentInfos = publishingContext.getInputContentInfos(contentName);
				if (contentInfos != null && contentInfos.length > 0) {
					File metadataXmlFile = contentInfos[0].getFile();
					source = new StreamSource(metadataXmlFile);
				}
			}
		} else {
			ContentInfo[] cinfos = publishingContext.getInputContentInfos(contentName);
			if(cinfos!=null && cinfos.length > 0){
				File xml = cinfos[0].getFile();
				source = new StreamSource(xml);
			}
		}
		return source;
	}

	private AttributeValueList appendAssetAttributesForCheckIn(File file, AttributeValueList attributeValueList) throws Exception{
		try {
			String assetName = file.getName();
			int lastIndex = assetName.lastIndexOf(".");
			String fileXtension = "";
			if (lastIndex > 0) {
				fileXtension = assetName.substring(lastIndex + 1);
			}
			FileInputStream fileInputStream = null;
			String contentType = DefaultContentTypes.ASSET + "";
			try {
				fileInputStream = new FileInputStream(file);
				contentType = assetFacade.detectContentType(fileXtension, null, fileInputStream).getName();
			} catch (Exception e) {
				logger.error("Error detecting content type for file. Default content type ASSET will be used. file:" + file.getAbsolutePath() + ", Exception:" + e + ", Reason:" + e.getMessage());
				logger.debug("", e);
			} finally {
				if (fileInputStream != null) {
					try {
						fileInputStream.close();
					} catch (IOException e) {
						logger.warn("Error closing file stream." + e);
					}
				}
			}

			ArrayList<AttributeValue> list = (ArrayList<AttributeValue>) attributeValueList.getAttributeValue();

			AttributeValueList newAttributeValueList = new AttributeValueList();
			ArrayList<AttributeValue> newList = (ArrayList<AttributeValue>) newAttributeValueList.getAttributeValue();

			for(int i = 0;i<list.size(); i++){
				newList.add(list.get(i));
			}

			createAndAddAttributeValue(DefaultAttributes.FILE_EXTENSION, fileXtension, newList);
			createAndAddAttributeValue(DefaultAttributes.CONTENT_TYPE, contentType, newList);
			createAndAddAttributeValue(DefaultAttributes.ORIGINAL_FILENAME, assetName, newList);
			return newAttributeValueList;
		} catch (Exception e) {
			throw new InvalidActivityParameterException(InvalidActivityParameterExceptionCodes.INVALID_PARAMETER, new String[] { "MetadataXml" });
		}
	}


	private void createAndAddAttributeValue(long attributeId, String value, ArrayList<AttributeValue> list) {
		AttributeValue attributeValue = new AttributeValue();
		attributeValue.setId(attributeId);
		attributeValue.setValue(value);
		list.add(attributeValue);
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	private String unzipGivenFile(File file, PublishingContext publishingContext) throws IOException {
		ZipFile zipFile = null;
		FileOutputStream out = null;
		InputStream in = null;
		try {
			zipFile = new ZipFile(file);
			String destFolder = "unzippedfiles/" + file.getName();
			Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
			while (enumeration.hasMoreElements()) {
				ZipEntry zipEntry = enumeration.nextElement();
				if(zipEntry.isDirectory()){
					continue;
				}
				File targetFile = tempFileManager.getTempFileWithGivenName( destFolder + "/" + zipEntry.getName(),
						publishingContext.getProcessId());
				try {
					in = zipFile.getInputStream(zipEntry);
					out = new FileOutputStream(targetFile);
					pipe(in, out);
				} finally {
					if (out != null)
						out.close();
				}
			}
			return tempFileManager.getProcessIdFolder(publishingContext.getProcessId())+"/"+destFolder;
		} finally {
			try {
				if (zipFile != null)
					zipFile.close();
			} catch (IOException ioException) {
				logger.error("Error while closing streams.", ioException);
			}
		}
	}
}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.publishing.uriresolver;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;

public class DitaFileNamingScheme implements FileNamingScheme{

	@Autowired
	private AssetService assetService;
	
	private String supportedSchemeName;
	
	public void setSupportedSchemeName(String supportedSchemeName) {
		this.supportedSchemeName = supportedSchemeName;
	}

	private Logger logger = Logger.getLogger(DitaFileNamingScheme.class);
	
	@Override
	public String getSupportedNamingScheme() {
		return this.supportedSchemeName;
	}

	@Override
	public String resolveFileName(long assetId, AssetVersion assetVersion) {
		return assetId+"_"+assetVersion.getMajorVersion()+"."+assetVersion.getMinorVersion()+"."+getFileExtension(assetId, assetVersion);
	}

	private String getFileExtension(long assetId, AssetVersion assetVersion) {
		String fileExtension = null;
		AttributeValue[] attributeValues;
		try {
			attributeValues = assetService.getAttributeValuesForAssetVersion(assetId, assetVersion,
					new long[] { DefaultAttributes.FILE_EXTENSION });

			if (attributeValues != null && attributeValues.length > 0) {
				TextValue textValue = (TextValue) attributeValues[0].getAttributeValue();
				if (textValue != null) {
					return fileExtension = textValue.getValue();
				}
			}
		} catch (Exception e) {
			logger.error("Unable to get file extension for asset with ID: " + assetId, e);
		}
		logger.error("Unable to get file extension for asset with ID: " + assetId);
		return fileExtension;
	}
	
}

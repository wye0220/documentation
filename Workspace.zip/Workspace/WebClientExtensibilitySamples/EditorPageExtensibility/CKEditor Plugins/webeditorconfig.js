/*
Copyright (c) 2003-2010, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	//To remove context menu use below commented code
	//config.removePlugins = 'scayt,menubutton,contextmenu';
	config.enterMode = CKEDITOR.ENTER_DIV;
	config.shiftEnterMode = CKEDITOR.ENTER_BR;
	config.fullPage = true;
	defaultLanguage = "en";
	config.removePlugins = 'elementspath,image,forms';
    config.skin = 'v2';
	config.disableObjectResizing = true;
	config.toolbarCanCollapse = false,
	config.resize_enabled = false,
	config.pasteFromWordPromptCleanup = true;
	
	config.protectedSource.push('hidden|hiddentext|tabspec|tab');   // PHP Code
	
	config.extraPlugins = 'outline,refresh,groupchar,rubi,note,zoomin,zoomout,custombgcolor,tracking,dictionary,search';
	
	config.toolbar_WebEditor = [
    	['Source', 'Undo','Redo','-','Find','Replace','-','SelectAll', 'Copy',  'Paste', 'PasteFromWord'],
    	['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
    	['indent.btn', 'outdent.btn', 'SpecialChar','custombgcolor.btn','zoomin.btn','zoomout.btn'], ['refresh.btn'], ['rubi.btn','groupchar.btn',  'note.btn'],
    	[ 'Tracking', 'Highlighting', 'Accept', 'Reject'],['dictionary.btn','search.btn']
    ] ;
	
	config.toolbar_Bold_Italic_Underline =  [
	                         	['Undo','Redo','-','Find','Replace','-','SelectAll', 'Copy', 'Paste', 'PasteFromWord'],
	                        	['Bold','Italic','Underline'],
	                        	['indent.btn', 'outdent.btn', 'SpecialChar','custombgcolor.btn','zoomin.btn','zoomout.btn'],['rubi.btn','groupchar.btn','note.btn'],['dictionary.btn','search.btn']
	                        ] ;
	
	config.toolbar_Strike_Sub_Sup = [
	                             	['Undo','Redo','-','Find','Replace','-','SelectAll', 'Copy', 'Paste', 'PasteFromWord'],
	                            	['Strike','-','Subscript','Superscript'],
	                            	['indent.btn', 'outdent.btn', 'SpecialChar','custombgcolor.btn','zoomin.btn','zoomout.btn'],['rubi.btn','groupchar.btn','note.btn'],['dictionary.btn','search.btn']
	                            ] ;
	
	config.toolbar_none = [
	                   	['Undo','Redo','-','Find','Replace','-','SelectAll', 'Copy', 'Paste', 'PasteFromWord'],
	                	['indent.btn', 'outdent.btn', 'SpecialChar','custombgcolor.btn','zoomin.btn','zoomout.btn'],['rubi.btn','groupchar.btn','note.btn'], ['refresh.btn'],['dictionary.btn','search.btn']
	                ] ;
	
	config.toolbar_Basic = [
       	['Bold','Italic','-','OrderedList','UnorderedList','-','Link','Unlink','-','About','indent.btn', 'outdent.btn','custombgcolor.btn','zoomin.btn','zoomout.btn'],['rubi.btn','groupchar.btn','note.btn'],['dictionary.btn','search.btn']
       	                                                                                      ] ;
	config.keystrokes.push([ CKEDITOR.CTRL + 86 /*V*/, 'pastefromword' ]);
};

CKEDITORDictionaryPlugin = function()
{};
CKEDITORDictionaryPlugin.executeDictionaryCommand = function(oEditor){
	var ckDocument = oEditor.document;
	var nativeDocument = ckDocument.$;	
 	var text = "";
 	if (document.all){
		text= oEditor.getSelection().getNative().createRange().htmlText;
	}else{
 		var range = oEditor.getSelection().getNative().getRangeAt(0);
		text = range.toString();
 	}
	var url = 'http://dictionary.reference.com/browse/'+text;
	window.open(url, "dictionaryWindow", "width=800,height=600,left=100,top=100, resizable=yes, scrollbars=yes,dependent=yes");
}

CKEDITOR.plugins.add('dictionary',
{
	init: function (editor) {
		var pluginName = 'dictionary';
		editor.ui.addButton('dictionary.btn',
			{
				label: "Find Synonyms",
				command: 'dictionary.cmd',
				icon: CKEDITOR.plugins.getPath('dictionary') + 'dict.jpg'
			});
		var cmd = editor.addCommand('dictionary.cmd', { exec: CKEDITORDictionaryPlugin.executeDictionaryCommand });
	}
});

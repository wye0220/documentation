QPP Web Client Editor Page Extensibility Sample
----------------------------------------------------------------

The sample project demonstrates the extensibility feature of CKEditor.
The sample code adds buttons in CKEditor toolbar on the Editor Page. The search button searches the selected text on www.Google.com and the second button searches the selected text on www.Dictionary.com.
Provide the path to QPS Server installation directory in build.xml file.
The server needs to be restarted after deploying the sample.
 
 
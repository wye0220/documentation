CKEDITORSearchPlugin = function()
{};
CKEDITORSearchPlugin.executeSearchCommand = function(oEditor){
	var ckDocument = oEditor.document;
	var nativeDocument = ckDocument.$;	
 	var text = "";
 	if (document.all){
		text= oEditor.getSelection().getNative().createRange().htmlText;
	}else{
 		var range = oEditor.getSelection().getNative().getRangeAt(0);
		text = range.toString();
 	}
	var url = 'http://google.com/search?q='+text;
	window.open(url, "searchWindow", "width=800,height=600,left=100,top=100, resizable=yes, scrollbars=yes,dependent=yes");
}

CKEDITOR.plugins.add('search',
{
	init: function (editor) {
		var pluginName = 'search';
		editor.ui.addButton('search.btn',
			{
				label: 'Search Google',
				command: 'search.cmd',
				icon: CKEDITOR.plugins.getPath('search') + 'search.gif'
			});
		var cmd = editor.addCommand('search.cmd', { exec: CKEDITORSearchPlugin.executeSearchCommand });
	}
});

/*****************************************************************************\
 **
 ** �1990-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/

package com.quark.qpp.web.extension;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.query.service.constants.QueryConstants;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.ContentTypeCondition;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.local.QueryService;

public class AssetInfoController extends AbstractController {
	private QueryService queryService;
	private AssetService assetService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
												 HttpServletResponse response) throws Exception {
		String sessionId = (String) request.getSession().getAttribute("sessionId");
		SessionContext sessionContext = new SessionContext();
		sessionContext.setSessionId(sessionId);
		SecurityContextHolder.setContext(sessionContext);
		StringBuffer xml = new StringBuffer("<AssetInfo>");
		long contentTypeId = Long.parseLong(request.getParameter("contentTypeId"));

		QueryCondition[] queryConditions = new QueryCondition[1];

		ContentTypeCondition contentTypeCondition = new ContentTypeCondition();
		contentTypeCondition.setComparisonOperator(QueryConstants.PopupOperators.IS);
		contentTypeCondition.setLogicalOperator(QueryConstants.LogicalOperators.AND);
		contentTypeCondition.setNegated(false);
		contentTypeCondition.setNestingLevel(1);
		contentTypeCondition.setContentTypeIds(new long[]{contentTypeId});
		contentTypeCondition.setRecursive(true);
		queryConditions[0] = contentTypeCondition;
		QueryDisplay queryDisplay = new QueryDisplay();

		DisplayColumn nameColumn = new DisplayColumn();
		nameColumn.setAttributeColumn(true);
		nameColumn.setColumnId(DefaultAttributes.NAME);

		DisplayColumn fileClassColumn = new DisplayColumn();
		fileClassColumn.setAttributeColumn(true);
		fileClassColumn.setColumnId(DefaultAttributes.CONTENT_TYPE);

		DisplayColumn fileExtColumn = new DisplayColumn();
		fileExtColumn.setAttributeColumn(true);
		fileExtColumn.setColumnId(DefaultAttributes.FILE_EXTENSION);

		queryDisplay.setDisplayColumns(new DisplayColumn[] { nameColumn,
									   fileClassColumn, fileExtColumn });
		queryDisplay.setDisplayMode(1);

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.ASSET);

		long resultId = queryService.openQueryResultForConditions(
																  queryConditions, queryContext, queryDisplay, false);
		QueryResultElement[] queryResultElements = queryService
		.getNextQueryResult(resultId, -1, 500, 0);

		queryService.closeQueryResults(resultId);

		for (int i = 0; i < queryResultElements.length; i++) {
			AssetElement assetElement = (AssetElement) queryResultElements[i];
			long assetId = assetElement.getAssetId();

			AttributeValue[] attributeValues = assetService.getAttributeValues(
																			   assetId, new long[] { DefaultAttributes.NAME,
																			   DefaultAttributes.CONTENT_TYPE,
																			   DefaultAttributes.FILE_EXTENSION });

			long fileClass = ((DomainValue) getAttributeValue(
															  DefaultAttributes.CONTENT_TYPE, attributeValues)
							  .getAttributeValue()).getId();

			String assetName = ((TextValue) getAttributeValue(
															  DefaultAttributes.NAME, attributeValues)
								.getAttributeValue()).getValue();

			String fileExtension = ((TextValue) getAttributeValue(
																  DefaultAttributes.FILE_EXTENSION, attributeValues)
									.getAttributeValue()).getValue();

			xml.append("<Asset id=\"" + assetId + "\" name=\"" + assetName
					   + "\" fileClass=\"" + fileClass + "\" fileExtension=\""
					   + fileExtension + "\" />");
		}
		xml.append("</AssetInfo>");

		PrintWriter writer = null;
		response.setContentType("text/xml");
		response.setCharacterEncoding("UTF-8");
		writer = response.getWriter();
		writer.print(xml.toString());
		response.setHeader("Cache-Control", "no-cache");
		response.setStatus(HttpServletResponse.SC_OK);
		return null;
	}

	public static AttributeValue getAttributeValue(long attributeId,
												   AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return null;
		}
		int index = findIndex(attributeId, attributeValues);
		if (index < 0) {
			return null;
		}
		return attributeValues[index];
	}

	private static int findIndex(long attributeId,
								 AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return -1;
		}
		for (int i = 0; i < attributeValues.length; i++) {
			if (attributeValues[i].getAttributeId() == attributeId) {
				return i;
			}
		}
		return -1;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public void setAssetService(AssetService assetService) {
		this.assetService = assetService;
	}

}

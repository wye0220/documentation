/*****************************************************************************\
 **
 ** �1990-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.security.core.context.SecurityContextHolder;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentType;
import com.quark.qpp.core.content.service.local.ContentStructureService;

public class ContentInfoController extends AbstractController {
	private ContentStructureService contentStructureService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// Get sessionId from the user's session
		String sessionId = (String) request.getSession().getAttribute("sessionId");
		SessionContext sessionContext = new SessionContext();
		sessionContext.setSessionId(sessionId);
		SecurityContextHolder.setContext(sessionContext);
		StringBuffer xml = new StringBuffer("<ContentTypes>");
		ContentType contentType = contentStructureService
				.getContentType(DefaultContentTypes.ASSET);
		ContentType[] subContentTypes = contentType.getSubContentTypes();
		for (int i = 0; i < subContentTypes.length; i++) {
			ContentType subContentType = subContentTypes[i];
			long contentTypeId = subContentType.getId();
			String contentTypeName = subContentType.getName();
			xml.append("<ContentType id=\"" + contentTypeId + "\" name=\""
					+ contentTypeName + "\">");
			if(subContentType.getSubContentTypes() != null && subContentType.getSubContentTypes().length> 0){
				ContentType[] subSubContentTypes = subContentType.getSubContentTypes();
				for (int j = 0; j < subSubContentTypes.length; j++) {
					ContentType subSubContentType = subSubContentTypes[j];
					contentTypeId = subSubContentType.getId();
					contentTypeName = subSubContentType.getName();
					xml.append("<SubContentType id=\"" + contentTypeId + "\" name=\""
							+ contentTypeName + "\" />");
				}

			}
			xml.append("</ContentType>");
		}
		xml.append("</ContentTypes>");

		PrintWriter writer = null;
		response.setContentType("text/xml");
		response.setCharacterEncoding("UTF-8");
		writer = response.getWriter();
		writer.print(xml.toString());
		response.setHeader("Cache-Control", "no-cache");
		response.setStatus(HttpServletResponse.SC_OK);
		return null;
	}

	public void setContentStructureService(
			ContentStructureService contentStructureService) {
		this.contentStructureService = contentStructureService;
	}

}

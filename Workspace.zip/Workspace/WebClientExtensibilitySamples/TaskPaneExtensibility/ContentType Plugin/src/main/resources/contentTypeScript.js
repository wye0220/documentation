var ContentStructureScript = function() {
	var wfstatues = [];
	var selectedStatusId;
	var selectedAsset;
	return {
		loadContentTypeData : function() {
			Ext.Ajax.request( {
				method : 'GET',
				url : WEB_APP_CONTEXT_NAME + '/getContentTypeInfos.qsp',
				callback : ContentStructureScript.contentTypeHandler,
				disableCaching : true
			});
		},
		contentTypeHandler : function(options, success, response) {
			if (success) {
				var root = response.responseXML.documentElement;
				var html = '<div id="workflow-tree"><table width="100%">';
				var contentTypeList = root.getElementsByTagName('ContentType');
				for (j = 0; j < contentTypeList.length; j++) {
					var contentType = contentTypeList[j];
					var contentTypeName = contentType.getAttribute('name');
					var contentTypeId = contentType.getAttribute('id');
					html = html
							+ '<tr><td><div style="cursor:pointer" id="ct-'
							+ contentTypeId
							+ '" onClick="ContentStructureScript.contentTypeClickHander('
							+ contentTypeId + ')">&nbsp;&nbsp;&nbsp;' + contentTypeName
							+ '</div></td></tr>';
					var subContentTypeList = contentType.getElementsByTagName('SubContentType');
					if(subContentTypeList != null && subContentTypeList.length > 0) {
						for (i = 0; i < subContentTypeList.length; i++) {
							var subContentType = subContentTypeList[i];
							var subContentTypeName = subContentType.getAttribute('name');
							var subContentTypeId = subContentType.getAttribute('id');
							html = html
									+ '<tr><td><div style="cursor:pointer" id="ct-'
									+ subContentTypeId
									+ '" onClick="ContentStructureScript.contentTypeClickHander('
									+ subContentTypeId + ')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + subContentTypeName
									+ '</div></td></tr>';
							

						}
					}
					

				}
				html = html + '</table></div>';
				document.getElementById('ct-plugin-nav-div').innerHTML = html;
			}
		},
		
		contentTypeClickHander : function(contentTypeId) {
			Ext.Ajax.request( {
				method : 'GET',
				url : WEB_APP_CONTEXT_NAME + '/getContentAssets.qsp',
				callback : ContentStructureScript.updateCenterPanel,
				params : {
					contentTypeId : contentTypeId
				},
				disableCaching : true
			});
		},
		assetClickHandler : function(assetId, fileClassId) {
			if (selectedAsset != undefined && selectedAsset != null) {
				if (document.getElementById(selectedAsset) != null) {
					document.getElementById(selectedAsset).style.backgroundColor = '';
				}
			}
			var id = 'asset-' + assetId;
			document.getElementById(id).style.backgroundColor = '#99BBE8';
			selectedAsset = id;

			var pluginSelectedAsset = new Object();
			pluginSelectedAsset.assetId = assetId;
			pluginSelectedAsset.fileClassId = fileClassId;

			AssetSelectionContext.setSelectedAsset(pluginSelectedAsset);
			AssetSelectionContext.enableToolbarButton('show-Asset-Preview');
		},
		updateCenterPanel : function(options, success, response) {
			if (success) {
				var root = response.responseXML.documentElement;
				var assetsList = root.getElementsByTagName('Asset');
				var html = '<div id="sample-ct"><div id="all-demos"><h2><div>Assets</div></h2><dl>';
				for ( var i = 0; i < assetsList.length; i++) {
					var assetId = assetsList[i].getAttribute('id');
					var assetName = assetsList[i].getAttribute('name');
					var fileClassId = assetsList[i].getAttribute('fileClass');
					var fileExtension = assetsList[i]
							.getAttribute('fileExtension');

					html = html
							+ '<dd id="asset-'
							+ assetId
							+ '" onClick="ContentStructureScript.assetClickHandler('
							+ assetId
							+ ','
							+ fileClassId
							+ ')">'
							+ ContentStructureScript.getFileIcon(fileClassId,
									fileExtension)
							+ '<p>'
							+ assetName
							+ '<br><img class="internal" src="'
							+ WEB_APP_CONTEXT_NAME
							+ '/images/extension/edit-headers.png" align="absmiddle" onClick="ContentStructureScript.editHeaders()">'
							+ '<img class="internal" src="'
							+ WEB_APP_CONTEXT_NAME
							+ '/images/extension/Preview-asset.png" align="absmiddle" onClick="ContentStructureScript.showPreview()"></p></dd>';
				}

				html = html + '</dl></div></div>';

				document.getElementById('ct-plugin-main-div').innerHTML = html;
			}
		},
		showPreview : function() {
			var data = new Object();
			data.scriptSrc = WEB_APP_CONTEXT_NAME + '/js/asset-preview-dlg.js';
			data.callback = 'PreviewAsset.showDialog';

			UserHomeUI.genericHandler(data);
		},
		editHeaders : function() {
			UserHomeUI.editHeaderHandler();
		},
		getFileIcon : function(fileClassId, fileExtension) {
			if (CommonUtils.isProject(fileClassId)) {
				return "<img src='" + WEB_APP_CONTEXT_NAME
						+ "/images/extension/QuarkXPress.png' align='absmiddle'>";
			} else if (CommonUtils.isArticle(fileClassId)) {
				if (fileExtension != null && fileExtension != undefined
						&& fileExtension != '--') {
					if (fileExtension == 'qcd') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/DOC.png' align='absmiddle'>";
					} else if (fileExtension == 'qcp') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/GIF.png' align='absmiddle'>";
					} else if (fileExtension == 'qct') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/XLS.png' align='absmiddle'>";
					} else if (fileExtension == 'txt') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/Text.png' align='absmiddle'>";
					} else if (fileExtension == 'html') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/HTML.png' align='absmiddle'>";
					} else if (fileExtension == 'doc') {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/DOC.png' align='absmiddle'>";
					} else {
						return "<img src='" + WEB_APP_CONTEXT_NAME
								+ "/images/extension/Text.png' align='absmiddle'>";
					}
				} else {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/XML.png' align='absmiddle'>";
				}
			} else if (fileClassId == defaultContentTypes.PICTURE) {
				if (fileExtension == 'pdf') {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/PDF.png' align='absmiddle'>";
				} else if (fileExtension == 'gif') {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/GIF.png' align='absmiddle'>";
				} else if (fileExtension == 'tiff') {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/TIFF.png' align='absmiddle'>";
				} else if (fileExtension == 'png') {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/PNG.png' align='absmiddle'>";
				} else {
					return "<img src='" + WEB_APP_CONTEXT_NAME
							+ "/images/extension/JPG.png' align='absmiddle'>";
				}
			} else if (fileClassId == defaultContentTypes.XML) {
				return "<img src='" + WEB_APP_CONTEXT_NAME
						+ "/images/extension/XML.png' align='absmiddle'>";
			} else {//default
				return "<img src='" + WEB_APP_CONTEXT_NAME
						+ "/images/extension/HTML.png' align='absmiddle'>";
			}
		},
		openQuarkSite : function() {
			window.open("http://www.quark.com", "blank", "toolbar=no");
		}
	}
}();
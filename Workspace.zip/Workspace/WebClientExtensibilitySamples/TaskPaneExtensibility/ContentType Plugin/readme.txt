QPP Web Client Assignment Page Extensibility Sample
----------------------------------------------------------------

The sample project demonstrates the task pane extensibility feature of Web Client UI.
The sample code adds an item into the task pane. On clicking the task (ContentType Plugin), from the task pane, the list of base content types is shown in the navigation pane in a tree format. On clicking the content type node,
the list of assets is shown in the main layout panel. This sample also demonstrates the reusability of Web Client's toolbar items & dialogs. 
The sample code can be compiled by running the ant build file. It will also copy the required files into WebHub under QPP Server installation directory.
Provide the path to QPP Server installation directory in build.xml file. The server needs to be restarted after deploying the sample.
 
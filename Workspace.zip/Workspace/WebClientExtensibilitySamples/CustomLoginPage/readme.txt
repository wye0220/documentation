QPP Web Client Login Page Extensibility Sample
----------------------------------------------------------------

The sample demonstrates that the Login page of Web Client can be customized to dispay custom user interface.
The login page should submit two mandatory attributes namely "userName" and "Password" to the url "login.qsp".
An optional parameter "language" can be set to specify the locale used in the application. The supported values for language parameter are "en", "fr", "de", "ja" and "ko".
The build file copies the Login.jsp and images to the Web Client's root folder.
Provide the path to QPP Server installation directory in build.xml file. The server needs to be restarted after deploying the sample.
 
 
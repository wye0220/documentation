QPP Data Doc Sample
----------------------------------------------------------------

This is a sample project to show Data Doc feature.
The sample code adds a menu item name 'Data Doc' under 'New' menu.clicking on Datadoc will list all the Publishing/DataDoc channels. To create a new datadoc User need to specify which channel to use, Attribute values etc. clicking on 'Ok' will create a datadoc with specified arguments.
The sample code can be compiled by running the ant build file. It will also copy the required files into workspace under QPP Server installation directory. 
Provide the path to QPP Server installation directory in build.xml file. The server needs to be restarted after deploying the sample.
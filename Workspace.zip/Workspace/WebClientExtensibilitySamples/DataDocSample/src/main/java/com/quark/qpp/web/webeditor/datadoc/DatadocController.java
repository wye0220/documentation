package com.quark.qpp.web.webeditor.datadoc;

import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.betwixt.io.BeanWriter;
import org.apache.commons.betwixt.registry.DefaultXMLBeanInfoRegistry;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.quark.qpp.service.facade.PublishFacade;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.PublishingChannelList;

public class DatadocController extends MultiActionController {

	private Jaxb2Marshaller jaxb2Marshaller;

	private PublishFacade publishFacade;

	public void setJaxb2Marshaller(Jaxb2Marshaller jaxb2Marshaller) {
		this.jaxb2Marshaller = jaxb2Marshaller;
	}

	public void setPublishFacade(PublishFacade publishFacade) {
		this.publishFacade = publishFacade;
	}

	// getAllDatadocChannels - Method to get all DataDoc / Publishing channels.
	// It sends all channels in form of xml as a ajax response.
	public ModelAndView getAllDatadocChannels(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		boolean isDataDocChannels = ServletRequestUtils.getBooleanParameter(
				request, "isDataDoc", false);
		PublishingChannelList publishingChannelList;
		if (isDataDocChannels) {
			publishingChannelList = publishFacade.getDatadocChannels();
		} else {
			publishingChannelList = publishFacade.getAllPublishingChannels();
		}
		String xml = serialize(publishingChannelList.getPublishingChannelInfo());

		sendServerAjaxResponse(response, xml);
		return null;
	}

	// createDatadoc - Method to create a DataDoc.
	// Input to this method is Channel Id, Attribute values in form of xml
	// Parameter map and minor version value i.e true/false.
	public ModelAndView createDatadoc(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map<String, String> paramMap = new HashMap<String, String>();
		Enumeration<String> parameterNames = request.getParameterNames();
		while (parameterNames.hasMoreElements()) {
			String parameterName = parameterNames.nextElement();
			if (parameterName.equalsIgnoreCase("channelId")
					|| parameterName.equalsIgnoreCase("attributeValues")
					|| parameterName.equalsIgnoreCase("revisionValue")) {
				continue;
			}
			if (request.getParameter(parameterName).length() > 0) {
				paramMap.put(parameterName, request.getParameter(parameterName));
			}
		}
		String channelId = request.getParameter("channelId");
		String attributeValuesStr = request.getParameter("attributeValues");
		String revisionValueStr = request.getParameter("revisionValue");
		AttributeValueList attributeValueslist = (AttributeValueList) jaxb2Marshaller
				.unmarshal(new StreamSource(new ByteArrayInputStream(
						attributeValuesStr.getBytes("UTF-8"))));
		AssetInfo asset = publishFacade.createDatadoc(channelId, paramMap,
				attributeValueslist, Boolean.parseBoolean(revisionValueStr));
		sendServerAjaxResponse(response, "<response assetId=\"" + asset.getId()
				+ "\" />");
		return null;
	}

	private void sendServerAjaxResponse(HttpServletResponse response,
			final String serializedObject) throws Exception {
		PrintWriter writer = null;
		try {
			if (serializedObject != null) {
				response.setContentType("text/xml");
				response.setCharacterEncoding("UTF-8");
				writer = response.getWriter();
				writer.print(serializedObject);
				response.setHeader("Cache_Control", "no-cache");
				response.setStatus(HttpServletResponse.SC_OK);
			} else {
				response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	// To serialize the list of PublishingChannelInfo
	private String serialize(Object object) throws Exception {
		StringWriter stringWriter = new StringWriter();
		BeanWriter beanWriter = new BeanWriter(stringWriter);
		try {
			beanWriter.getXMLIntrospector().setRegistry(
					new DefaultXMLBeanInfoRegistry());
			beanWriter.getXMLIntrospector().getConfiguration()
					.setAttributesForPrimitives(true);
			beanWriter.getBindingConfiguration().setMapIDs(false);
			beanWriter.write(object);
			return stringWriter.toString();
		} finally {
			try {
				beanWriter.close();
				stringWriter.close();
			} catch (Exception e) {
			}
		}
	}
}


var DataDocDlg = function() {
	var	dialog;
	var channelStore;
	var parameterStore;
	
	function createDialog() {
		dialog = new  Ext.Window({
			width : 500,
			height : 280,
			autoScroll : true,
			modal : true,
			resizable : false,
			title : 'Create DataDoc',
			closeAction : 'close',
			layout : 'form',
			bodyStyle : {
		            margin: '10px'
		        },
			items : [ new Ext.form.ComboBox({
				id : 'channelCombo',
				store: channelStore,
				displayField:'name',
				valueField : 'id',
				typeAhead: false,
				allowBlank:false,
				mode: 'local',
				triggerAction:'all',
				forceSelection:true,
				selectOnFocus:true,
				fieldLabel : 'Publishing channels',
				width : 300,
				labelStyle: 'width:150px;',
				editable : false,
				forceSelection:true,
				listeners :{
					select : function(combo, record, index) {
						var id = record.data.id;
						var records = parameterStore.query('channelId', id, false);
						var paramPanel = dialog.getComponent('paramPanel');
						paramPanel.removeAll(true);
						var paramPanelHeight = records.getCount() * 30;
						dialog.setHeight(280 + paramPanelHeight);
						paramPanel.setHeight(paramPanelHeight);
						records.each(function(item) {
							var paramName = item.get('name');
							// Replace any char in caps to lower case(exceept first). Also replace _ with space. 
							var labelName =	paramName.charAt(0).toUpperCase() + paramName.substr(1).toLowerCase();
							labelName = labelName.replace(/_/g, ' ');
							paramPanel.add(new Ext.form.TextField({
								itemId : paramName,
								name : paramName,
								fieldLabel : labelName,
								labelStyle: 'width:150px;',
								width : 300,
								style : {
									marginBottom: '5px'
						        },
							}));
						}) ;
						paramPanel.doLayout();
					}
				}
			}), {
				xtype : 'panel',
				itemId : 'paramPanel',
				border : false,
				layout : 'form',
				style : {
					marginTop: '10px',
		            marginRight: '10px',
		            marginBottom: '5px'
		        },
		        bodyStyle : {
		        	backgroundColor: '#E8E8E8'
		        },
			}, {
				xtype     : 'textarea',
		        fieldLabel: 'Attribute values',
		        id: 'attribute-values',
		        labelStyle: 'width:150px;',
		        width : 300,
		        height : 120
			}, {
			 	xtype: 'radiogroup',
	            fieldLabel: 'Revision',
		        id: 'revision-radio',
		        style : {
		        	marginTop: '10px',
					marginLeft: '48px'
		        },
	            items: [
	                {boxLabel: 'Major Version', name: 'rb-auto',  inputValue: 1, checked: true},
	                {boxLabel: 'Minor Version', name: 'rb-auto',  inputValue: 2},
	            ]
	        }],
			buttons : [ {
				text : 'OK',
				handler : function(button) {
					dialog.getEl().mask(loading_Label);
					var paramPanel = dialog.getComponent('paramPanel');
					var channelCombo = dialog.getComponent('channelCombo');
					var attributeValueCmp = dialog.getComponent('attribute-values');
					var revisionRadioCmp = dialog.getComponent('revision-radio');
					var urlParam = "";
					var selectedRadioValue = revisionRadioCmp.getValue().inputValue;
					paramPanel.items.items.forEach(function(element, index) {
						if (index != 0) {
							urlParam += '&';
						}
						urlParam += element.name + '=' + element.getValue();
					});
					urlParam +='&channelId='+channelCombo.getValue();
					urlParam +='&attributeValues='+attributeValueCmp.getValue();
					urlParam +='&revisionValue='+(selectedRadioValue == 2 ? 'true' : 'false');
					Ext.Ajax.request({
						method : 'POST',
						url : WEB_APP_CONTEXT_NAME + '/datadoc/createDatadoc.qsp?do=createDatadoc',
						params : urlParam,
						success : function(response, options) {
							dialog.getEl().unmask();
							Ext.MessageBox.alert('Data Doc Created', 'Data Doc has been successfully created.');
							dialog.close();
						},
						failure : function(response, options) {
							dialog.getEl().unmask();
							if(response && response.responseXML) {
								ErrorResolver.showErrorDlg(response);
							} else {
								Ext.MessageBox.alert('Error', 'Error while creating Data Doc.');
							}
						},
						disableCaching : true,
						scope: this
					});
				}
				}, {
					text : 'Cancel',
					handler : function() {
						dialog.close();
					}
				} ],
				listeners: {
					  afterrender: {
				            fn: function(window){
				            	var combo = window.getComponent('channelCombo');
				            	var store = combo.getStore();
				            	combo.setValue(store.getAt(0).get('id'));
				            	combo.fireEvent('select', combo, store.getAt(0));
				            	
				            }
				        }
				  }
		});
	}
	return {
		showDialog : function(){
			if(!channelStore) {
				channelStore = new Ext.data.ArrayStore({
				    fields: ['id', 'name']
				});
			}
			if(!parameterStore) {
				parameterStore = new Ext.data.ArrayStore({
				    fields: ['channelId', 'name']
				});
			}

			Ext.Ajax.request( {
				method : 'GET',
				url : WEB_APP_CONTEXT_NAME + '/datadoc/getAllPublishingChannels.qsp?isDataDoc=true&do=getAllDatadocChannels',
				callback : function(options, success, response){
					if(success) {
						channelStore.removeAll();
						parameterStore.removeAll();
						var root = response.responseXML.documentElement;
						var channelInfos= Ext.query('PublishingChannelInfo', root);
						for ( var i = 0; i < channelInfos.length; i++) {
							var channelInfo = channelInfos[i];
							var record = new Ext.data.Record({
								id: channelInfo.getAttribute('id'),
                                name: channelInfo.getAttribute('name')
							});
							var parameterInfos = Ext.query('Parameter', channelInfo);
							for ( var j = 0; j < parameterInfos.length; j++) {
								var parameterInfo = parameterInfos[j];
								var parameterRecord = new Ext.data.Record({
									channelId: channelInfo.getAttribute('id'),
	                                name: parameterInfo.getAttribute('name')
								});
								parameterStore.add(parameterRecord);
							}
							channelStore.add(record);
						}
						createDialog();
						dialog.show();
					}
				},
				disableCaching : true,
				scope: this
			});
			
		}
	}
}();
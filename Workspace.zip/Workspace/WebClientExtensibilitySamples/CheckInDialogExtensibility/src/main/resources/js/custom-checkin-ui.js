var CustomCheckInUI = function(){
	var customPanel;

	/**
	 * Create UI based on attribute value if "Assignee List" attribute value
	 * send from server.
	 */
	function populateCustomPanelCallback(options, success, response) {
		if (success) {
			if (response) {
				var root = response.responseXML.documentElement;
				if (root) {
					var attributeInfos = Ext.query("attribute", root);
					if (attributeInfos && attributeInfos.length > 0) {
						var id = attributeInfos[0].getAttribute('id');
						var type = attributeInfos[0].getAttribute('type');
						var value = attributeInfos[0].getAttribute('value');
						formElementId = 'attr:' + id + ';' + 'type:' + type;
						var name = attributeInfos[0].getAttribute('name');
						var label = name + ":";
						var textBoxHTML = '<input type="text" id="reviewedBy-customUI" readonly="readonly" value="'
								+ value
								+ '" style="height:18px; width:390px;"/>';
						var buttonHTML = '<div style="display: table-cell;" id="assigneeListBtn"></div>';
						var tr = createCustomPanelRow(label, textBoxHTML,
								buttonHTML);
						var html = "<table>" + tr + "</table>";
						customPanel.body.update(html);
						/**
						 * Create Assignee List Button. Click handler of this
						 * button displays available and set users in
						 * ItemSelector.
						 */
						var assigneeListBtn = new Ext.Button({
							renderTo : 'assigneeListBtn',
							width : 30,
							height : 25,
							text : '<span style="color: black;">...<span>',
							tooltip : "Edit " + name,
							handler : function() {
								var collectionInfo = CheckinUtils
										.getSelectedCollectionInfo();
								var customReviewedByEl = document
										.getElementById("reviewedBy-customUI");
								var assigneeList = "";
								if (customReviewedByEl) {
									assigneeList = customReviewedByEl.value;
								}
								/**
								 * Get Selected collection users from server.
								 */
								Ext.Ajax.request({
									method : 'GET',
									url : WEB_APP_CONTEXT_NAME
											+ '/checkInExt.qsp?do=getApplicableCollectionUsers',
									params : {
										assigneeList : assigneeList,
										collectionId : collectionInfo.collectionId
									},
									callback : showAssigneeItemSelector,
									disableCaching : true
								});
							}
						});
					}
				}
			}
		}
	}
	
	function createCustomPanelRow(label, textBoxHTML, buttonHTML) {
		var tr = '<tr><td> &nbsp;&nbsp; </td> <td style="width"15%;" class="x-btn-txt" nowrap="nowrap">'
				+ label
				+ '</td> <td>'
				+ textBoxHTML
				+ '</td><td colspan="2"> '
				+ buttonHTML + '</td></tr>';
		return tr;
	}
	
	function showAssigneeItemSelector(options, success, response){
		var root = response.responseXML.documentElement;
		if (root) {
			var usersList = Ext.query("collectionUsers user", root);
			var availableUsers = getUsersInfo(usersList);
			var selectedUsersList = Ext.query("selectedUsers user", root);
			var itemSelectorConfig = {
				winTitle : selectUsersTitle,
				toMultiselectTitle : availableUsers_Label,
				formMultiselectTitle : selectedUsers_Label,
				manageUsersDescription : manageUsersDescription_Label
			};
			var selectedUsers = getUsersInfo(selectedUsersList);
			CustomItemSelector.showDialog(availableUsers, selectedUsers,
					assigneeItemSelectorCallback, -1, null, itemSelectorConfig);
		}
	}
	
	function assigneeItemSelectorCallback(selectedUsers, selectedRecords, params){
		var value = "";
		for ( var i = 0; i < selectedRecords.length; i++) {
			var text = selectedRecords[i].get('text');
			value += text;
			if(i < (selectedRecords.length -1)){
				value += "; ";
			}
		}
		var customReviewedByEl = document.getElementById("reviewedBy-customUI");
		customReviewedByEl.value = value;
		var formElement = Ext.get(formElementId);
		if(formElement){
			formElement.dom.value = value;
			customReviewedByEl.name = customReviewedByEl.id;
		}else{
			customReviewedByEl.name = formElementId;
		}
	}
	
	function getUsersInfo(users){
		var data = [];
		for ( var i = 0; i < users.length; i++) {
			var id = users[i].getAttribute('id');
			var name = users[i].getAttribute('name');
			data[i] = [id, name];
		}
		return data;
	}
	
	return {
		populateCustomPanelUI : function(panel){
			customPanel = panel;
			var panelBody = customPanel.body;
			var panelBodyContainerDom = panelBody.dom;
			panelBodyContainerDom.style.backgroundColor = '#F3F3F3';
			
			var assetId = -1;
			var checkinType = AssetCheckInDialog.getCheckinType();
			if(checkinType != CheckInTypes.NEW_CHECKIN){
				assetId = CheckinUtils.getAssetId();
			}
			/**
			 * Get custom attribute's information from server.
			 */
			Ext.Ajax.request( {
				method : 'GET',
				url : WEB_APP_CONTEXT_NAME + '/checkInExt.qsp?do=getCheckinAttributesInfo',
				params : {
					assetId : assetId
				},
				callback : populateCustomPanelCallback,
				disableCaching : true
			});
		}
	}
}();
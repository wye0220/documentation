/*****************************************************************************\
 **
 ** �1990-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.webeditor.extension.checkin;

import java.io.PrintWriter;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.dto.TextValuePreferences;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.collection.service.dto.CollectionUser;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.security.service.dto.User;

public class CheckInExtensionController extends MultiActionController {

	private AttributeService attributeService;

	private AssetService assetService;
	
	private CollectionService collectionService;
	
	private ContentStructureService contentStructureService;

	final String CUSTOM_ATTRIBUTE_NAME = "Assignee List";

	/**
	 * Method extracts available collection users and assignee list attribute
	 * value and sends the same to UI
	 */
	public ModelAndView getApplicableCollectionUsers(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String assigneeStrValue = ServletRequestUtils.getStringParameter(
				request, "assigneeList");
		String[] assigneeNames = new String[0];
		long collectionId = ServletRequestUtils.getLongParameter(request,
				"collectionId", -1);
		if (assigneeStrValue != null) {
			assigneeNames = assigneeStrValue.split(";");
		} else {
			assigneeStrValue = "";
		}
		CollectionUser[] collectionUsers = collectionService
				.getCollectionUsers(collectionId);
		StringBuilder collectionUsersXML = new StringBuilder(
				"<collectionUsers>");
		StringBuilder selectedUsersXML = new StringBuilder("<selectedUsers>");
		String userName = null;
		boolean selectedUser = false;
		for (int i = 0; i < collectionUsers.length; i++) {
			selectedUser = false;
			User user = collectionUsers[i].getUser();
			userName = getFormatedUserName(user);
			for (int j = 0; j < assigneeNames.length; j++) {
				if (assigneeNames[j].trim().equalsIgnoreCase(userName)) {
					selectedUser = true;
					break;
				}
			}
			if (selectedUser) {
				selectedUsersXML.append("<user id=\"").append(user.getId())
						.append("\" name=\"").append(replaceIllegalXMLChars(userName)).append("\" />");
			} else {
				collectionUsersXML.append("<user id=\"").append(user.getId())
						.append("\" name=\"").append(replaceIllegalXMLChars(userName)).append("\" />");
			}
		}
		collectionUsersXML.append("</collectionUsers>");
		selectedUsersXML.append("</selectedUsers>");
		String responseXml = "<customCheckInUI><attribute  value=\""
				+ replaceIllegalXMLChars(assigneeStrValue) + "\"></attribute> " + collectionUsersXML
				+ selectedUsersXML + "  </customCheckInUI>";
		sendServerAjaxResponse(response, responseXml);
		return null;
	}

	private String replaceIllegalXMLChars(String aTagFragment) {
		if (aTagFragment != null && aTagFragment.length() > 0) {
			final StringBuffer result = new StringBuffer();
			final StringCharacterIterator iterator = new StringCharacterIterator(
					aTagFragment);
			char character = iterator.current();
			while (character != CharacterIterator.DONE) {
				if (character == '<') {
					result.append("&amp;lt;");
				} else if (character == '>') {
					result.append("&gt;");
				} else if (character == '\"') {
					result.append("&quot;");
				} else if (character == '\'') {
					result.append("&#039;");
				} else if (character == '\\') {
					result.append("&#092;");
				} else if (character == '&') {
					result.append("&amp;");
				} else {
					// the char is not a special one
					// add it to the result as is
					result.append(character);
				}
				character = iterator.next();
			}
			return result.toString();
		}
		return aTagFragment;
	}
	private String getFormatedUserName(User user) {
		String firstName = user.getFirstName();
		firstName = (firstName == null || firstName.trim().equals("")) ? null
				: firstName;
		String lastName = user.getLastName();
		lastName = (lastName == null || lastName.trim().equals("")) ? null
				: lastName;
		String userName = user.getName();
		String formatedName = userName;
		if (firstName != null && lastName != null) {
			formatedName = lastName + ", " + firstName;
		} else if (firstName != null) {
			formatedName = firstName;
		} else if (lastName != null) {
			formatedName = lastName;
		}
		return formatedName;
	}
	
	/**
	 * Method sends CUSTOM_ATTRIBUTE_NAME attribute information to UI. If
	 * attribute does not exists, method creates text attribute "Assignee List".
	 */
	public ModelAndView getCheckinAttributesInfo(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		final long assetId = ServletRequestUtils.getLongParameter(request,
				"assetId", -1);
		Attribute attribute = null;
		try{
			attribute = attributeService
					.getAttributeByName(CUSTOM_ATTRIBUTE_NAME);
		}catch (QppServiceException e) {
			attribute = createTextAttribute();
		}
		String assigneeStrValue = getAttributeValue(assetId, attribute.getId());
		String responseXml = "<customCheckInUI><attribute id=\""
				+ attribute.getId() + "\" name=\"" + attribute.getName()
				+ "\" type=\"" + attribute.getValueType() + "\" value=\""
				+ assigneeStrValue + "\"></attribute> "
				+ "  </customCheckInUI>";
		sendServerAjaxResponse(response, responseXml);
		return null;
	}

	private Attribute createTextAttribute() {
		// Create a new attribute at the server level
		Attribute attribute = new Attribute();
		attribute.setName(CUSTOM_ATTRIBUTE_NAME);
		attribute.setValueType(AttributeValueTypes.TEXT);

		TextValue defaultValue = new TextValue("");
		TextValuePreferences textValuePreferences = new TextValuePreferences();
		textValuePreferences.setDefaultValue(defaultValue);

		// set default value preferences
		attribute.setDefaultValuePreference(textValuePreferences);

		try {
			// call service to create the attribute. This would return Attribute
			// object of the newly created attribute.
			attribute = attributeService.createAttribute(attribute);
			contentStructureService.setAttributeContentTypes(attribute.getId(),
					new long[] { DefaultContentTypes.ASSET,
							DefaultContentTypes.PICTURE,
							DefaultContentTypes.QCD_ARTICLE,
							DefaultContentTypes.PROJECT,
							DefaultContentTypes.XML });
		} catch (QppServiceException e) {
			e.printStackTrace();
		}
		return attribute;
	}

	private String getAttributeValue(long assetId, long attributeId)
			throws QppServiceException {
		String assigneeStrValue = "";
		if (assetId > 0) {
			AttributeValue[] attributeValues = assetService.getAttributeValues(
					assetId, new long[] { attributeId });
			if (attributeValues != null && attributeValues.length > 0) {
				AttributeValue attributeValue = attributeValues[0];
				if (attributeValue != null
						&& attributeValue.getAttributeValue() != null) {
					assigneeStrValue = ((TextValue) attributeValue
							.getAttributeValue()).getValue();
				}
			}
		}
		return assigneeStrValue;
	}

	private void sendServerAjaxResponse(HttpServletResponse response,
			final String serializedObject) throws Exception {
		PrintWriter writer = null;
		try {
			if (serializedObject != null) {
				response.setContentType("text/xml");
				response.setCharacterEncoding("UTF-8");
				writer = response.getWriter();
				writer.print(serializedObject);
				response.setHeader("Cache_Control", "no-cache");
				response.setStatus(HttpServletResponse.SC_OK);
			} else {
				response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	public void setAttributeService(AttributeService attributeService) {
		this.attributeService = attributeService;
	}

	public void setAssetService(AssetService assetService) {
		this.assetService = assetService;
	}


	public void setCollectionService(CollectionService collectionService) {
		this.collectionService = collectionService;
	}

	public void setContentStructureService(
			ContentStructureService contentStructureService) {
		this.contentStructureService = contentStructureService;
	}
}
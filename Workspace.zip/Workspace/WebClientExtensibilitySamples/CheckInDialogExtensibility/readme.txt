QPP Workspace Check-in dialog Extensibility Sample
----------------------------------------------------------------

The sample project demonstrates the extensibility feature of CheckIn dialog.
The sample code adds a custom panel in Edit attribute dialog. The custom panel can render custom attributes or any other HTML elements. The sample code creates a new text attribute and maps it to user domain.
The custom panel can be added to CheckIn dialog by setting attribute 'addToCheckIn' as 'true' in ui-extension.xml file.
The sample code can be compiled by running the ant build file. It will also copy the required files into workspace under QPP Server installation directory. 
Provide the path to QPP Server installation directory in build.xml file. The server needs to be restarted after deploying the sample.
/*****************************************************************************\
 **
 ** �1986-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.filetransfergateway.service.StreamingService;

public class RevisionCompareController extends AbstractController {

	private AssetService assetService;
	private StreamingService streamingService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// Get the assetId from the request
		String strAssetId = request.getParameter("assetId");
		long assetId = Long.valueOf(strAssetId).longValue();
		
		// Get sessionId from the user's session
		String sessionId = (String) request.getSession().getAttribute(
				"sessionId");
		SessionContext sessionContext = new SessionContext();
		sessionContext.setSessionId(sessionId);
		SecurityContextHolder.setContext(sessionContext);
		
		AttributeValue[] attributeValues = assetService.getAttributeValues(
				assetId, new long[] {DefaultAttributes.NAME });
		
		String assetName = ((TextValue) getAttributeValue(
				DefaultAttributes.NAME, attributeValues).getAttributeValue())
				.getValue();
		AssetVersion[] assetVersions = assetService.getAssetVersionNumbers(assetId);
		
		// Get the text rendition for the current version of the asset
		ByteArrayOutputStream currentVersionOutputStream = getAssetRendition(
				assetId, DefaultRenditionTypes.TEXT, assetVersions[assetVersions.length - 1]);
		String currentText = currentVersionOutputStream.toString();
		currentVersionOutputStream.close();
		String previousVersionText = "No Previous Revision";
		
		if(assetVersions.length >= 2) {
			// Get the text rendition for the previous version of the asset
			ByteArrayOutputStream previousVersionOutputStream = getAssetRendition(
					assetId, DefaultRenditionTypes.TEXT,  assetVersions[assetVersions.length - 2]);
			previousVersionText = previousVersionOutputStream.toString();
			previousVersionText = previousVersionText
			// Remove the XML tag
					.substring(previousVersionText.indexOf(">") + 1);
			previousVersionOutputStream.close();	
		}
		//version = new AssetV
		Map<String, Object> modelMap = new HashMap<String, Object>();
		logger.debug("text is = " + currentText);
		modelMap.put("currentText", currentText.substring(currentText
				.indexOf(">") + 1));
		modelMap.put("previousVersionText", previousVersionText
				.substring(previousVersionText.indexOf(">") + 1));
		modelMap.put("assetName", assetName);
		return new ModelAndView("extension/CompareRevision", modelMap);
	}

	private ByteArrayOutputStream getAssetRendition(long assetId,
			int renditionType, AssetVersion assetVersion) throws Exception {
		ByteArrayOutputStream assetOutputStream = new ByteArrayOutputStream();
		long assetContextId = assetService.createReadContext(assetId,
				assetVersion, renditionType);
		try {
			streamingService.download(assetOutputStream, assetContextId);
		} finally {
			try {
				assetService.closeContext(assetContextId);
			} catch (Exception e) {
			}
		}
		return assetOutputStream;
	}

	public static AttributeValue getAttributeValue(long attributeId,
			AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return null;
		}
		int index = findIndex(attributeId, attributeValues);
		if (index < 0) {
			return null;
		}
		return attributeValues[index];
	}

	private static int findIndex(long attributeId,
			AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return -1;
		}
		for (int i = 0; i < attributeValues.length; i++) {
			if (attributeValues[i].getAttributeId() == attributeId) {
				return i;
			}
		}
		return -1;
	}

	public void setAssetService(AssetService assetService) {
		this.assetService = assetService;
	}

	public void setStreamingService(StreamingService streamingService) {
		this.streamingService = streamingService;
	}

}

RevisionCompareDialog = function(){
	return{
		showDialog: function(){
			var selectedAsset = CommonUtils.getSelectedAsset();
			if(selectedAsset == null || selectedAsset == 'undefined'){
				 alert("Please select an asset.");
			}else{
				var url = WEB_APP_CONTEXT_NAME + '/compareRevision.qsp?assetId='+selectedAsset.assetId+'&fileClassId='+selectedAsset.fileClassId;
				window.open(url, "compareRevisionWindow", "width=600,height=500,left=400,top=300, resizable=yes, scrollbars=yes,dependent=yes");
			}
		}
	};
}();
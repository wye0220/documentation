/***************************************************************************** 
** Quark Publishing 
** 
** � 2017 Quark Software, Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.web.webeditor.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.Value;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.security.service.dto.SessionContext;

public class AppStudioWebUrlController extends AbstractController {

	private AssetService assetService;
	private AttributeService attributeService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// Get the assetId from the request
		String strAssetId = request.getParameter("assetId");
		long assetId = Long.valueOf(strAssetId).longValue();
		String attributeName = request.getParameter("attribute");
		// Get sessionId from the user's session
		String sessionId = (String) request.getSession().getAttribute("sessionId");
		SessionContext sessionContext = new SessionContext();
		sessionContext.setSessionId(sessionId);
		SecurityContextHolder.setContext(sessionContext);
		Attribute attribute = attributeService.getAttributeByName(attributeName);
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { attribute.getId() });
		String strAttributeValue = "";
		if (attributeValues != null && attributeValues.length > 0) {
			Value value = attributeValues[0].getAttributeValue();
			final int attributeType = attribute.getValueType();
			if (value != null) {
				switch (attributeType) {
				case AttributeValueTypes.NUMERIC:
					long numericValue = ((NumericValue) value).getValue();
					strAttributeValue = String.valueOf(numericValue);
					break;
				case AttributeValueTypes.TEXT:
					strAttributeValue = ((TextValue) value).getValue();
					break;
				}
			}
		}

		String xml = "<Attribute value=\"" + strAttributeValue + "\" />";
		PrintWriter writer = null;
		response.setContentType("text/xml");
		response.setCharacterEncoding("UTF-8");
		writer = response.getWriter();
		writer.print(xml.toString());
		response.setHeader("Cache-Control", "no-cache");
		response.setStatus(HttpServletResponse.SC_OK);
		return null;
	}

	public void setAssetService(AssetService assetService) {
		this.assetService = assetService;
	}

	public void setAttributeService(AttributeService attributeService) {
		this.attributeService = attributeService;
	}
}

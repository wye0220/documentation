var AppStudioWebUrlHandler = function(){
	var ATTRIBUTE_NAME = 'App Studio Web URL';
	function openWindow(options, success, response) {
		if(success) {
			var root = response.responseXML.documentElement;
			var attrValue = root.getAttribute('value');
			var url = attrValue;
			window.open(url, "blank", "toolbar=no");
		}
	}
	return{
		getAttributeValue: function(){
			var selectedAsset = CommonUtils.getSelectedAsset();
			if(selectedAsset == null || selectedAsset == 'undefined'){
				 alert("Please select an asset.");
			}else{
				var contentTypeId = selectedAsset.fileClassId;
				//11020 is content type id for app studio package
				if(contentTypeId != 11020) {
					alert("This option is only available for App Studio Package");
					return;
				}
				var url = "getCustomAttributeValueExt.qsp";
				Ext.Ajax.request( {
					method : 'GET',
					url : url,
					callback : openWindow,
					params : {
						assetId : selectedAsset.assetId,
						attribute:ATTRIBUTE_NAME
					},
					disableCaching : true
				});
			}
		}
	};
}();
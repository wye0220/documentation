QPP Web Client Assignment Page Extensibility Sample
----------------------------------------------------------------

The sample project demonstrates the extensibility feature of Web Client UI.
The sample code adds menu items in Web Client toolbar on the Home Page. The menu items allows selected asset to be sent to SharePoint, FileNet or as attachment via email
The sample code can be compiled by running the ant build file. It will also copy the required files into workspace under QPP Server installation directory. 
Provide the path to QPP Server installation directory in build.xml file. The server needs to be restarted after deploying the sample.
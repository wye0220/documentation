/*****************************************************************************\
 **
 ** �1986-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.local.PublishingService;

public class FileNetDeliveryChannelController extends AbstractController {
	PublishingService publishingService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String strAssetId = request.getParameter("assetId");
		String serverUrl = request.getParameter("serverUrl");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		String objectStore = request.getParameter("objectStore");
		String folderPath = request.getParameter("folderPath");
		long assetId = Long.valueOf(strAssetId);
		PublishingParameter[] publishingParameters = new PublishingParameter[5];
		PublishingParameter serverUrlParam = new PublishingParameter(
				"CONNECTION_URI", serverUrl);
		PublishingParameter userNameParam = new PublishingParameter(
				"USER_NAME", userName);
		PublishingParameter passwordParam = new PublishingParameter("PASSWORD",
				password);
		PublishingParameter objectStoreParam = new PublishingParameter(
				"OBJECT_STORE", objectStore);
		PublishingParameter folderPathParam = new PublishingParameter(
				"FOLDER_PATH", folderPath);
		publishingParameters[0] = serverUrlParam;
		publishingParameters[1] = userNameParam;
		publishingParameters[2] = passwordParam;
		publishingParameters[3] = objectStoreParam;
		publishingParameters[4] = folderPathParam;

		publishingService.deliverAsset(assetId, "checkInToFileNet", publishingParameters);
		return null;
	}

	public void setPublishingService(PublishingService publishingService) {
		this.publishingService = publishingService;
	}

}

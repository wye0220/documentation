/*****************************************************************************\
 **
 ** �1986-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.local.PublishingService;

public class SharePointDeliveryChannelController extends AbstractController {
	PublishingService publishingService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String strAssetId = request.getParameter("assetId");
		String serverUrl = request.getParameter("serverUrl");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		long assetId = Long.valueOf(strAssetId);
		PublishingParameter[] publishingParameters = new PublishingParameter[3];
		PublishingParameter serverUrlParam = new PublishingParameter(
				"DESTINATION_PATH_URI", serverUrl);
		PublishingParameter userNameParam = new PublishingParameter(
				"USER_NAME", userName);
		PublishingParameter passwordParam = new PublishingParameter("PASSWORD",
				password);
		publishingParameters[0] = serverUrlParam;
		publishingParameters[1] = userNameParam;
		publishingParameters[2] = passwordParam;

		publishingService.deliverAsset(assetId, "checkInToSharepoint", publishingParameters);
		return null;
	}

	public void setPublishingService(PublishingService publishingService) {
		this.publishingService = publishingService;
	}
}

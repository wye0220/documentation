/*****************************************************************************\
 **
 ** �1990-2016 Quark Software Inc., All rights reserved.

 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.local.PublishingService;

public class DocumentumDeliveryChannelController extends AbstractController {
	PublishingService publishingService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String strAssetId = request.getParameter("assetId");
		String serverUrl = request.getParameter("serverUrl");
		String port = request.getParameter("port");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String repository = request.getParameter("repository");
		String folderPath = request.getParameter("folderPath");
		long assetId = Long.valueOf(strAssetId);
		PublishingParameter publishingParameters[] = new PublishingParameter[6];
		PublishingParameter serverUrlParam = new PublishingParameter("SERVER_NAME", serverUrl);
		PublishingParameter userNameParam = new PublishingParameter("USER_NAME", userName);
		PublishingParameter passwordParam = new PublishingParameter("PASSWORD", password);
		PublishingParameter objectStoreParam = new PublishingParameter("SERVER_PORT", port);
		PublishingParameter folderPathParam = new PublishingParameter("FOLDER_PATH", folderPath);
		PublishingParameter repositoryPathParam = new PublishingParameter("REPOSITORY_NAME", repository);
		publishingParameters[0] = serverUrlParam;
		publishingParameters[1] = userNameParam;
		publishingParameters[2] = passwordParam;
		publishingParameters[3] = objectStoreParam;
		publishingParameters[4] = folderPathParam;
		publishingParameters[5] = repositoryPathParam;

		publishingService.deliverAsset(assetId, "checkInToDocumentum", publishingParameters);
		return null;
	}

	public void setPublishingService(PublishingService publishingService) {
		this.publishingService = publishingService;
	}
}

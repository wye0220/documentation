/*****************************************************************************\
 **
 ** �1990-2016 Quark Software Inc., All rights reserved.
 **
\****************************************************************************/
package com.quark.qpp.web.extension;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.local.PublishingService;

public class EmailDeliveryChannelController extends AbstractController {
	PublishingService publishingService;
	ContentStructureService contentStructureService;
	AssetService assetService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		long assetId = ServletRequestUtils.getLongParameter(request, "assetId",
				-1);
		String fromField = request.getParameter("fromUser");
		String toField = request.getParameter("toUser");
		String subject = request.getParameter("subject");
		String sendAttachment = request.getParameter("sendAttachment");
		String attachAsset = "false";
		if(sendAttachment != null && sendAttachment.equalsIgnoreCase("on")){
			attachAsset = "true";
		}
		String protocol = request.getProtocol();
		if (protocol.startsWith("HTTPS") || protocol.startsWith("https")) {
			protocol = "https";
		} else {
			protocol = "http";
		}
		String baseUrl = protocol + "://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath();
		String checkoutUrl = "/checkoutAsset.qsp?assetId=" + assetId
				+ "&link=true";
		AttributeValue[] attributeValues = assetService.getAttributeValues(
				assetId, new long[] { DefaultAttributes.CONTENT_TYPE,
						DefaultAttributes.NAME });
		final long contentTypeId = ((DomainValue) getAttributeValue(
				DefaultAttributes.CONTENT_TYPE, attributeValues)
				.getAttributeValue()).getId();
		final String assetName = ((TextValue) getAttributeValue(
				DefaultAttributes.NAME, attributeValues).getAttributeValue())
				.getValue();
		if (contentStructureService.isValidAncestor(
				DefaultContentTypes.QCD_ARTICLE, contentTypeId)) {
			checkoutUrl = "/checkout.qsp?assetId=" + assetId + "&link=true";
		} else if (contentStructureService.isValidAncestor(
				DefaultContentTypes.QUARK_XPRESS_PROJECT, contentTypeId)) {
			checkoutUrl = "/checkoutProject.qsp?assetId=" + assetId
					+ "&link=true";
			;
		}
		checkoutUrl = baseUrl + checkoutUrl;
		String body = fromField
				+ " has assigned asset '"
				+ assetName
				+ "' to you. You can checkout the asset by clicking on the link\n "
				+ checkoutUrl;
		body = body
				+ "\n You can also get readonly copy of this asset by clicking on the link \n";
		body = body + baseUrl + "/getAssetRendition.qsp?assetId=" + assetId
				+ "&renditionType=1";
		if (toField != null) {
			PublishingParameter[] publishingParameters = new PublishingParameter[5];
			PublishingParameter serverUrlParam = new PublishingParameter(
					"SENDER_EMAIL_ID", fromField);
			PublishingParameter userNameParam = new PublishingParameter(
					"RECIPIENT_EMAIL_IDS", toField);
			PublishingParameter passwordParam = new PublishingParameter(
					"SUBJECT", subject);
			PublishingParameter attachParam = new PublishingParameter(
					"SEND_AS_ATTACHMENT", String.valueOf(attachAsset));
			PublishingParameter bodyParam = new PublishingParameter("MESSAGE",
					body);
			publishingParameters[0] = serverUrlParam;
			publishingParameters[1] = userNameParam;
			publishingParameters[2] = passwordParam;
			publishingParameters[3] = attachParam;
			publishingParameters[4] = bodyParam;
			publishingService.deliverAsset(assetId, "sendEmail", publishingParameters);
		}
		return null;

	}

	public static AttributeValue getAttributeValue(long attributeId,
			AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return null;
		}
		int index = findIndex(attributeId, attributeValues);
		if (index < 0) {
			return null;
		}
		return attributeValues[index];
	}

	private static int findIndex(long attributeId,
			AttributeValue[] attributeValues) {
		if (attributeValues == null) {
			return -1;
		}
		for (int i = 0; i < attributeValues.length; i++) {
			if (attributeValues[i].getAttributeId() == attributeId) {
				return i;
			}
		}
		return -1;
	}

	public void setPublishingService(PublishingService publishingService) {
		this.publishingService = publishingService;
	}

	public void setContentStructureService(
			ContentStructureService contentStructureService) {
		this.contentStructureService = contentStructureService;
	}

	public void setAssetService(AssetService assetService) {
		this.assetService = assetService;
	}

}

var DeliveryChannelExt = function() {
	return {
		sendToSharePoint : function(){
			var selectedAsset  = CommonUtils.getSelectedAsset();
			var assetId = selectedAsset.assetId;
			window.open('htm/extension/SharePoint.html?assetId='+assetId,'SharePoint'+assetId, 'width=400, height=450,left=400,top=200,resizable=yes,scrollbars=yes,dependent=yes');
		},
		sendToFileNet : function(){
			var selectedAsset  = CommonUtils.getSelectedAsset();
			var assetId = selectedAsset.assetId;
			window.open('htm/extension/FileNet.html?assetId='+assetId,'FileNet'+assetId,'width=400, height=500,left=400,top=200,resizable=yes,scrollbars=yes,dependent=yes');
		},
		sendToDocumentum : function(){
					var selectedAsset  = CommonUtils.getSelectedAsset();
					var assetId = selectedAsset.assetId;
					window.open('htm/extension/Documentum.html?assetId='+assetId,'Documentum'+assetId,'width=400, height=600,left=500,top=200,resizable=yes,scrollbars=yes,dependent=yes');
		},
		sendToEmail : function(){
			var selectedAsset  = CommonUtils.getSelectedAsset();
			var assetId = selectedAsset.assetId;
			window.open('htm/extension/EmailUser.html?assetId='+assetId,'Email'+assetId,'width=400, height=450,left=400,top=200,resizable=yes,scrollbars=yes,dependent=yes');
		}
	};
}();
/*
 * This sample demonstrates the use of Bodydiv element. In this example, Bodydiv is of type 'virus-info' and it consists of virus types (table), 
 * virus structure(image) and some other details(paragraph and list element).  
 * 
 * */
CKEDITOR.plugins.add('demobodydiv',
{
	init: function (editor) {
		var pluginName = 'demobodydiv';
		Ext.Loader.loadScript(CKEDITOR.plugins.getPath('democustomtag')+'/dialogs/virus-list-dialog.js');
		editor.ui.addButton('demobodydiv',
			{
					label: 'Demo Bodydiv',
					command: 'demobodydiv',
					icon: CKEDITOR.plugins.getPath('demobodydiv') + 'icon.jpg'
			});
		var me = this;
		editor.addCommand('demobodydiv', { 
			exec: function() {
				//create table element
				var tableElement = createTableElement();
				//create image element.
				var imageElement = createImageElement();
				//create para element.
				var paraElement = createParaElement();
				//create list element.
				var listElement = createListElement();
				//Invoke insertBodyDivNodes api to insert elements in bodydiv of type virus info and make this bodydiv non-editabe (last parameter is true)
				QXmlEditorEx.insertBodyDivNodes([tableElement, imageElement, paraElement, listElement], 'virus-info', null, true);
		} });
		
		QXmlEditorEventManager.addListener(QXmlEditorEventManager.Events.SECTION_HIERARCHY_CHANGE, function(event) {
			if(event && event.updatedSection) {
				var updatedSection = event.updatedSection;
				//Check for Synopsis section
				if(updatedSection.getElementName() == 'Synopsis') {
					//Move selection to the body of Synopsis section
					var editor = QXmlEditorEx.getEditorInstance();
					var contentElement = QXmlEditorEx.getContentElement(updatedSection.getContentId());
					var bodyNode = QXmlEditorEx.getBodyNode(contentElement);
					var selection = editor.getSelection();
					var range = selection.getRanges()[0];
					range.moveToElementEditablePosition(bodyNode);
					if( CKEDITOR.env.ie ) {
						QXmlEditorEx.getEditorInstance().focus();
					}
					range.select();
					//Execute command to insert body div.
					editor.execCommand( 'demobodydiv');
				}
			}
		}, this);
		
		function createTableElement() {
			var store = VirusListDialog.getStore();
			var tableElement = QXmlEditorEx.createElement('div');
			tableElement.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'table');
			tableElement.addClass('table');
			var table = QXmlEditorEx.createElement('table');
			tableElement.append(table);
			table.setAttribute('class', 'smart-table');
			var colgroup = QXmlEditorEx.createElement('colgroup');
			colgroup = table.append(colgroup);
			for ( var i = 1; i <= 4; i++) {
				//Create col node for each column
				var colNode = QXmlEditorEx.createElement('col');
				colNode.setAttribute("colnum", i);
				colNode.setAttribute("colname", i);
				colNode.setAttribute("width", '25%');
				colgroup.append(colNode);
			}
			//set this custom attribute used is xsl transformation
			colgroup.setAttribute("cols", 4);
			
			var tbody = table.append( QXmlEditorEx.createElement( 'tbody' ) );
			var thead = new CKEDITOR.dom.element( table.$.createTHead() );
			var header_row = thead.append( QXmlEditorEx.createElement( 'tr' ) );
			header_row.setAttribute('class', 'smart-table-row');
			var head_col = header_row.append( QXmlEditorEx.createElement( 'th' ) );
			var para =  QXmlEditorEx.createElement( 'div' ) ;
			para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			para.addClass('p');
			para.setText('Name');
			head_col.append(para);
			
			var head_col = header_row.append( QXmlEditorEx.createElement( 'th' ) );
			var para =  QXmlEditorEx.createElement( 'div' ) ;
			para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			para.addClass('p');
			para.setText('Host');
			head_col.append(para);
			
			var head_col = header_row.append( QXmlEditorEx.createElement( 'th' ) );
			var para =  QXmlEditorEx.createElement( 'div' ) ;
			para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			para.addClass('p');
			para.setText('Transmission');
			head_col.append(para);
			
			var head_col = header_row.append( QXmlEditorEx.createElement( 'th' ) );
			var para =  QXmlEditorEx.createElement( 'div' ) ;
			para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			para.addClass('p');
			para.setText('Disease');
			head_col.append(para);
			
			/*tbody.append(thead);*/
			for ( var i = 0 ; i < store.getCount() ; i++ )
			{
				var row = tbody.append( QXmlEditorEx.createElement( 'tr' ) );
				row.setAttribute('class', 'smart-table-row');
				var record = store.getAt(i);
				//Virus name
				var name_cell = row.append( QXmlEditorEx.createElement( 'td' ) );
				name_cell.setAttribute('class', 'smart-table-cell');
				var para =  QXmlEditorEx.createElement( 'div' ) ;
				para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
				para.addClass('p');
				para.setText(record.get('name'));
				name_cell.append(para);
				
				//Host
				var host_cell = row.append( QXmlEditorEx.createElement( 'td' ) );
				host_cell.setAttribute('class', 'smart-table-cell');
				var para =  QXmlEditorEx.createElement( 'div' ) ;
				para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
				para.addClass('p');
				para.setText(record.get('host'));
				host_cell.append(para);
				
				//Transmission
				var trans_cell = row.append( QXmlEditorEx.createElement( 'td' ) );
				trans_cell.setAttribute('class', 'smart-table-cell');
				var para =  QXmlEditorEx.createElement( 'div' ) ;
				para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
				para.addClass('p');
				para.setText(record.get('transmission'));
				trans_cell.append(para);
				
				//Disease
				var disease_cell = row.append( QXmlEditorEx.createElement( 'td' ) );
				disease_cell.setAttribute('class', 'smart-table-cell');
				var para =  QXmlEditorEx.createElement( 'div' ) ;
				para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
				para.addClass('p');
				para.setText(record.get('transmission'));
				disease_cell.append(para);
			}
			return tableElement;
		}
		
		function createImageElement() {
			var image =  QXmlEditorEx.createElement( 'div' ) ;
			image.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			image.addClass('p');
			var imgPath = CKEDITOR.plugins.getPath('demobodydiv')+ 'virus.jpg';
			image.setHtml('<img src="'+imgPath+'"/>');
			return image;
		}
		
		function createParaElement() {
			var para =  QXmlEditorEx.createElement( 'div' ) ;
			para.setAttribute(QXmlEditorConstants.attribute.ELEMENT, 'p');
			para.addClass('p');
			para.setText('Some of the most harmful viruses: ');
			return para;
		}
		
		function createListElement() {
			var store = VirusListDialog.getStore();
			var listElement = QXmlEditorEx.createElement('ol');
			for ( var i = 0 ; i < store.getCount() ; i++ )	{
				var record = store.getAt(i);
				var item = QXmlEditorEx.createElement('li');
				item.setText(record.get('name'));
				listElement.append(item);
			}
			return listElement;
		}
	},
	insertBodyDiv : function(record) {
		var name = record.get('name');
		var transmission = record.get('transmission');
		var disease = record.get('disease');
	}
});

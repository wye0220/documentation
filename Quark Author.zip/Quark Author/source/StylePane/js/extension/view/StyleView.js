Ext.define('com.quark.kestrel.extension.view.StyleView', {
	extend : 'Ext.panel.Panel',
	alias : 'widget.styleView',
	layout: {
        type: 'vbox',
        align: 'stretch'
    },
	overflow:'auto',
	autoScroll:true,
	title : 'Style',
	border : false,
	margin : '20 10 10 10',
	items : [{
			border : false,
			items : [ {
				xtype : 'fieldset',
				region: 'north',
				layout : 'auto',
				title : 'Tag',
				border : true,
				collapsible : false,
				collapsed : false,
				items : [{
					xtype : 'combo',
					margin : '15 10 10 0',
					labelWidth : 125,
					fieldLabel: 'Tag Type',
					store: 'InlineTypes',
					queryMode: 'local',
					displayField: 'name',
					valueField: 'name',
					id: 'inline-type-combo'
				},{
					xtype : 'button',
					text: 'Apply',
					margin : '10 10 10 0',
					id: 'apply-inline-btn'
				}]
			}]
	   }
	]
});
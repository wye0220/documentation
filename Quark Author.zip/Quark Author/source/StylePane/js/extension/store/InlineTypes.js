Ext.define('com.quark.kestrel.extension.store.InlineTypes', {
	extend : 'Ext.data.Store',
	fields: ['name'],
	 data : [
	         {"name":"Quote"},
	         {"name":"Keyword"},
	         {"name":"Term"},
	         {"name":"Trademark"},
	         {"name":"Citation"}
	     ]
});

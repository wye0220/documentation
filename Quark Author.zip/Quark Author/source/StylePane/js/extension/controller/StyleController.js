Ext.define('com.quark.kestrel.extension.controller.StyleController', {
	extend : 'Ext.app.Controller',
	stores : ['InlineTypes'],
	views : [ 'StyleView' ],
	
	refs : [ {
		selector : '#inline-type-combo',
		ref : 'inlineTypeCombo'
	}],
	
	init : function() {
		this.control({
			'#apply-inline-btn' : {
				click : this.applyInlineType
			}
		});
	},
	
	applyInlineType : function() {
		QXmlEditorEx.applyTag(this.getInlineTypeCombo().getValue());
	}
});

/*****************************************************************************************************
 * ExtJS based controller class that creates a button and provides options to move the asset to a new status
 *****************************************************************************************************/
Ext.define('com.quark.kestrel.extension.controller.HeaderBtnController', {
	extend : 'Ext.app.Controller',
	refs : [ {
		selector : '#hdr-tbar-btn-move',
		ref : 'moveBtn'
	}],
	statusMenu : null,
	currentCollectionId: null,
	currentWorkflowId : null,
	currentStatusId : null,
	closeAfterSave : null,
	init : function() {
		this.control({
			'#hdr-tbar-btn-move' : {
				render : function(btn){
					//disable button if a new document is created
					if(QXmlEditorEx.isNewDocument()) {
						btn.setDisabled(true);
					} else {
						btn.setDisabled(false);
					}
				},
				click : function(btn) {
					if(this.statusMenu.items == null || this.statusMenu.items.getCount() == 0){
						//get the list of statuse
						this.getStatusList();	
					}
					this.statusMenu.showBy(btn);
				},
				scope : this
			}
		});
		this.statusMenu = new Ext.menu.Menu({
			id:'move-asset-menu'
		});
		this.getAttributeValues();
		//assoaciate a listener to be called when document is saved
		QXmlEditorEventManager.addListener(QXmlEditorEventManager.Events.SAVE, this.saveDocumentCallback, this);
	},
	/**
	 * Get the currentvalues for collection, workflow and status
	 */
	getAttributeValues : function(){
		var assetId = QXmlEditorUtils.getAssetId(QXmlEditorEx.getSourceUri());
		if(assetId < 0){
			return;
		}
		// make a rest request to get attribute valeus as XML
		Ext.Ajax.request({
			method : 'GET',
			url : '/rest/service/assets/'+assetId,
			success : function(response, options) {
				var root = response.responseXML.documentElement;
				if(root != undefined && root != null){
					var attributeValueList = Ext.query("attributeValueList attributeValue", root);
					for(var i =0 ; i< attributeValueList.length; i++){
						var attributeValue = attributeValueList[i];
						var id = attributeValue.getAttribute('id');
						var value = attributeValue.getAttribute('valueId');
						if(id == Constants.attribute.COLLECTION){
							this.currentCollectionId = value;
						}else if(id == Constants.attribute.WORKFLOW){
							this.currentWorkflowId = value;
						} else{
							this.currentStatusId = value;
						}
					}
					
				}
			},
			failure : function(response, options) {
				console.log("Error fetching attribute values");
			},
			params : {
				qppsessionid: userSessionId,
				attributes : Constants.attribute.COLLECTION+','+Constants.attribute.WORKFLOW+','+Constants.attribute.STATUS
			},
			disableCaching : true,
			scope : this
		});
	},
	getStatusList : function(){
		Ext.Ajax.request({
			method : 'GET',
			url : '/rest/service/collections/'+ this.currentCollectionId,
			success : function(response, options) {
				var root = response.responseXML.documentElement;
				if(root != undefined && root != null){
					var nextPossibleStatusInfoList = Ext.query("nextPossibleStatusInfoList nextPossibleStatusInfo ", root);
					//Iterate over list of possible statuses
					for ( var i = 0; i < nextPossibleStatusInfoList.length; i++) {
						var id = nextPossibleStatusInfoList[i].getAttribute('id');
						var name = Ext.query('name', nextPossibleStatusInfoList[i])[0].firstChild.nodeValue;
						//create a menu item corresponding to each status
						this.statusMenu.add( new Ext.menu.Item ( { 
								text : name,
								statusId:id,
								handler :this.moveToStatus,
								scope:this
							}
						));
					}
				}
			},
			failure : function(response, options) {
				console.log(response);
			},
			async : false,
			params : {
				statustransitions:true,
				workflow : this.currentWorkflowId,
				status : this.currentStatusId,
				qppsessionid:userSessionId
			},
			disableCaching : true,
			scope : this
		});
	},
	moveToStatus : function(item){
		var statusId = item.statusId;
		var attributeArray = [];
		// create an object with new status value
		var status = {
				name:'Status',
				value: statusId
		}
		attributeArray.push(status);
		//save the asset and set a flag to close it after changing status
		this.closeAfterSave = true;
		QXmlEditorEx.saveData(attributeArray, false);
		
	},
	/**
	 * Callback method after a document is saved
	 */
	saveDocumentCallback : function(){
		if(this.closeAfterSave === true){
			window.close();
		}else{
			//enable move button when new document is saved
			this.getMoveBtn().enable();
			this.getAttributeValues();
		}
	}
	
});
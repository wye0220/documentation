Ext.define('com.quark.kestrel.extension.view.RestAttributeView', {
	extend : 'Ext.panel.Panel',
	alias : 'widget.restAttributeView',
	overflow:'auto',
	autoScroll:true,
	layout : 'fit',
	title : 'Rest-Attribute Values',
	border : false,
	margin : '20 10 10 10',
	initComponent : function(){
		var tpl = new Ext.XTemplate(
				'<table>',
					'<tr><th>Attribute Name</th><th>Value</th>',
			      '<tpl for=".">',
		  	      	'<tr class="attribute-item">',
		  	      	'<td>{id}</td>',
		          	'<td>{value}</td>',
		          	'</tr>',
		      	'</tpl>',
		        '</table>'
				);
		this.items = Ext.create('Ext.view.View', {
			autoScroll : true,
			itemSelector: 'tr.attribute-item',
			multiSelect: false,
			store : 'AttributeValues',
			tpl: tpl
		});
		this.callParent();
	}
	
});
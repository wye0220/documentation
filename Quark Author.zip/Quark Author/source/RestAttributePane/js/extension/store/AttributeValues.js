Ext.define('com.quark.kestrel.extension.store.AttributeValues', {
	extend : 'Ext.data.Store',
	requires : 'com.quark.kestrel.extension.model.AttributeValue',
	model : 'com.quark.kestrel.extension.model.AttributeValue'
});
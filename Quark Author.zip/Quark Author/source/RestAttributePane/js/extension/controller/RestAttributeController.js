Ext.define('com.quark.kestrel.extension.controller.RestAttributeController', {
	extend : 'Ext.app.Controller',
	views : [ 'RestAttributeView' ],
	stores: ['AttributeValues'],
	init : function() {
		//Register a listerner which is called when data is completely loaded in the editor
		QXmlEditorEventManager.addListener(QXmlEditorEventManager.Events.CONREFS_RESOLVED, this.createAttributePanel, this);
	},
	createAttributePanel : function(){
		var assetId = QXmlEditorUtils.getAssetId(QXmlEditorEx.getSourceUri());
		if(assetId < 0){
			return;
		}
		//make a rest request to get all attribute values of the asset
		Ext.Ajax.request({
			method : 'GET',
			url : '/rest/service/assets/'+assetId,
			success : function(response, options) {
				var root = response.responseXML.documentElement;
				if(root != undefined && root != null){
					var attributeValueArray = [];
					var attributeValueList = Ext.query("attributeValueList attributeValue", root);
					for(var i =0 ; i< attributeValueList.length; i++){
						var attributeValue = attributeValueList[i];
						var id = attributeValue.getAttribute('name');
						var value = '';
						if(attributeValue.firstChild){
							value = attributeValue.firstChild.nodeValue;
						}
						var record = Ext.create('com.quark.kestrel.extension.model.AttributeValue', {
						    id   : id,
						    value : value
						});
						attributeValueArray.push(record);
					}
					this.getAttributeValuesStore().loadData(attributeValueArray);
				}
			},
			failure : function(response, options) {
				console.log("Error");
			},
			params : {
				qppsessionid: userSessionId,
				attributes : 'all'
			},
			disableCaching : true,
			scope : this
		});
	}
	
});

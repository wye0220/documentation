Ext.define('com.quark.kestrel.extension.model.AttributeValue', {
	extend : 'Ext.data.Model',
	idProperty : 'id',
	fields : [ {
		name : 'id',
		type : 'string'
	},{
		name : 'value',
		type : 'string'
	}]
});

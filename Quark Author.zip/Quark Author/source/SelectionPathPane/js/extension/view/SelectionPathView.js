Ext.define('com.quark.kestrel.extension.view.SelectionPathView', {
	extend : 'Ext.panel.Panel',
	title :'Path',
	cls : 'path',
	alias : 'widget.selectionPathView'
});


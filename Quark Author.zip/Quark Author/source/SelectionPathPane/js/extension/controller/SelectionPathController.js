Ext.define('com.quark.kestrel.extension.controller.SelectionPathController', {
	extend : 'Ext.app.Controller',
	views : [ 'SelectionPathView' ],
	refs : [{ 
		selector : 'selectionPathView', 
		ref : 'selectionPathView'
	}],
	init : function() {
		QXmlEditorEventManager.addListener(QXmlEditorEventManager.Events.SELECTION_CHANGE, this.selectionChangeHandler, this);
	},
	selectionChangeHandler : function(event) {
		var element = event.data.selection.getStartElement();
		var html = '<table>';
			html += '<tr><th>HTML Element</th>'+
			'<th>Smart Element</th>'+
			'<th>Type</th>';
		while (element) {
			if(element.type == CKEDITOR.NODE_ELEMENT && element.hasAttribute(QXmlEditorConstants.attribute.ELEMENT)) {
				var type = element.hasAttribute(QXmlEditorConstants.attribute.TYPE) == true ? element.getAttribute(QXmlEditorConstants.attribute.TYPE) : '';
				var data = '<td>'+element.getName()+'</td>';
					data += '<td>'+element.getAttribute(QXmlEditorConstants.attribute.ELEMENT)+'</td>';
					data += '<td>'+ type +'</td>';
				html += '<tr>'+data+'</tr>';
			}
			element = element.getParent();
		}
		
		html += '<table>';
		this.getSelectionPathView().update(html);
	}
});

/**
 * Plugin that validates the length the document title when the toolbar button is clicked. Length of title should not be more than 20 characters.
 */
CKEDITOR.plugins.add('validate', {
    init: function (editor) {
    	
    	 editor.ui.addButton('validate', {
             label: 'Validate Title',
             command: 'validatetitle',
             icon: this.path + 'validate.png'
         });

         /*
         * Add a command to be associated when button is clicked
         * */
         editor.addCommand('validatetitle', {
             modes: { wysiwyg: 1 }, 
             readOnly: 1, // allow command execution even when documetn is opened in readonly mode
             readOnlyExec: true, // allow command execution even when cursor is in readonly mode
             exec: function (editor) {
            	 // get the root section
            	 var rootTopicNode = QXmlEditorEx.getRootSectionElement();
             	 var titleNode = QXmlEditorEx.getTitleNode(rootTopicNode);
             	 //Get text content from title node
             	 var titleText = QXmlEditorEx.getText("", titleNode);
                 var length = titleText.length;
                 if (length > 20) {
                	  Ext.MessageBox.show({
                          title: 'Document Title Check',
                          msg: 'Document title cannot be more than 20 characters',
                          buttons: Ext.MessageBox.OK,
                          fn: function () {
                             	titleNode.addClass("headline-error");
                                QXmlEditorUtils.moveCursorToNode(titleNode, true);
                          }
                      });
                 }else if (titleNode.hasClass("headline-error")) {
                 	 titleNode.removeClass("headline-error");
                 }
             }
         });
    }
});

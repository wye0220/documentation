/**
 * This sample demonstrate how to apply block type. This sample adds combo in the toolbar 
 * with all para, list and table styles and apply type to the current cusror location.  
 * */

CKEDITOR.plugins.add('blockstyles', {
	requires : [ 'richcombo' ],
	init : function(editor) {
		var config = editor.config;
		var styleManager = QXmlEditorEx.getStyleManager();
		var combo;
		
		function loadCombo(styleDefs) {
			if(combo == null) {
				return;
			}
			for(var index=0; index < styleDefs.length; index++) {
				var styleDef = styleDefs[index];
				combo.add(styleDef.type, styleDef.displayText, styleDef.displayText);
			}
		}
		
		 // select applied table type as combo box value
		function selectComboValue (value, objBlockCombo) {
			var styleDefs = styleManager.getBlockTypes();
			for (var j=0; j<styleDefs.length; j++) {
				var styleDef = styleDefs[j];
				if (styleDef.type == value) {
					objBlockCombo.setValue(styleDef.type, styleDef.displayText);
					break;
				}
			}
		}
		
		editor.ui.addRichCombo('blockCombo', {
			label : 'Formats',
			title : "Formats",
			className : 'cke_format',
			multiSelect : false,
			panel : {
				css : [ CKEDITOR.skin.getPath('editor') ]
						.concat(config.contentsCss)
			},
			init : function() {
				combo = this;
				//Load the items in the combo from schema-configuration file
				//Pass the combo reference for further use by editor
				combo.startGroup('Para Types');
				var styleDefs = styleManager.getParaTypes();
				//Remove title para-type
				for(var i=0; i<styleDefs.length; i++) {
					if(styleDefs[i].type == 'title') {
						styleDefs.splice(i, 1);
						break;
					}
				}
				loadCombo(styleDefs);
				combo.startGroup('List Types');
				styleDefs = styleManager.getListTypes();
				loadCombo(styleDefs);
				combo.startGroup('Table Types');
				styleDefs = styleManager.getTableTypes();
				loadCombo(styleDefs);
			},
			onRender : function() {
				editor.on('selectionChange', function(event) {
					var selection = event.data.selection;
					if(!selection) {
						return;
					}
					var range = selection.getRanges(true)[0];
					if(!range) {
						return;
					}
					var startNode = range.startContainer;
					var parents = startNode.getParents(true);
					if(parents) {
						for ( var index = 0; index < parents.length; index++) {
							var parent = parents[index];
							if(parent.type == CKEDITOR.NODE_ELEMENT &&  parent.hasAttribute(QXmlEditorConstants.attribute.TYPE) && parent.getAttribute(QXmlEditorConstants.attribute.TYPE) != '') {
								var type = parent.getAttribute(QXmlEditorConstants.attribute.TYPE);
								selectComboValue(type, this);
								return;
							}
						}
					}
					this.setValue('');
				}, this);
			},
			showAllowedStyles : function(selection, block){},
			onOpen : function(){},
			onClick : function(value) {
				styleManager.applyBlockType(value);
				selectComboValue(type, this);
			}
		});
	}
});
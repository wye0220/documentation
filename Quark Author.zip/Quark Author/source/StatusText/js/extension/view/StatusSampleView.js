Ext.define('com.quark.kestrel.extension.view.StatusSampleView', {
	extend : 'Ext.panel.Panel',
	title :'Status',
	layout : 'hbox',
	alias : 'widget.statusSampleView',
    items: [{
        margin: '50 10 10 10',
        xtype: 'textfield',
        id: 'status-text'
        }, {
        margin: '50 10 10 10',
        xtype: 'button',
        text: 'Update',
        id: 'update-status'
        }]
   
});


Ext.define('com.quark.kestrel.extension.controller.StatusSampleController', {
	extend : 'Ext.app.Controller',
	views : [ 'StatusSampleView' ],
	refs : [{ 
		selector : '#status-text', 
		ref : 'statusText'
	}],
	init : function() {
		this.control({
            '#update-status': {
            	click: this.updateStatus
            }
        });
	},

	updateStatus : function() {
		var statusText = this.getStatusText().getValue();
		QXmlEditorEx.setStatusbarText(statusText);
	}
});

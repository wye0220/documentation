var VirusListDialog = function(){
	var dialog, callback, scope;
	var virusStore = Ext.create('Ext.data.Store', {
	    fields:['name', 'host', 'transmission', 'disease'],
	    data:[
	        { 'name' : 'Influenza B virus', 'host': 'Human',  'transmission' : 'Respiratory', 'disease': 'Flu'},
	        { 'name' : 'Langat virus' , 'host': 'Ticks',  'transmission' : 'Zoonosis', 'disease': 'Hemorrhagic fever'},
	        { 'name': 'Mokola virus', 'host': 'Dog',  'transmission' : 'Animal bite', 'disease': 'Encephalitis'},
	        { 'name' : 'Dengue virus', 'host': 'Mosquitoes',  'transmission' : 'Arthropod bite', 'disease': 'Hemorrhagic fever'},
	        { 'name': 'Hepatitis E virus', 'host': 'Chimpanzees',  'transmission' : 'Blood', 'disease': 'Hepatitis' }
	    ],
	    proxy: {
	        type: 'memory'
	    }
	});
	return{
		showDialog : function(name, calbck, scpe){
			callback = calbck;
			scope = scpe;
			virusStore.clearFilter();
			if(name) {
				virusStore.filterBy(function(record) {
					if(record.get('name').toLowerCase().indexOf(name.toLowerCase()) > -1) {
						return true;
					}
					return false;
				}, this);
			}
            dialog = new Ext.Window({
                title: 'Virus List',
                width:600,
                height : 300,
                modal:true,
                layout:'anchor',
                closeAction:'destroy',
                constrain:true,
               	items:[{
               		xtype : 'grid',
               		id : 'virus-list-grid',
               		store : virusStore,
               		columns: [ { 
		       					text: 'Virus',  
		       					dataIndex: 'name',
		       					flex: 1
		       				},{ 
               					text: 'Host',  
               					dataIndex: 'host',
               					flex: 1
               				}, { 
               					text: 'Transmission',  
               					dataIndex: 'transmission',
               					flex: 1
               				}, { 
               					text: 'Disease', 
               					dataIndex: 'disease',
               					flex: 1
               				}]
               	}],
                fbar: [{
	      	    	   xtype:'checkbox',
	     	    	   margin: '0 10 10 5',
	     	    	   boxLabel: 'Clear Filter',
	     	    	   handler : function(cmp, checked) {
	     	    		  virusStore.clearFilter(); 
	     	    	   }
	   	    	 },'->',{
                	xtype:'button',
                    text: 'OK',
                    id:'ok_button',
                    handler: function(cmp){
                    	var grid = Ext.getCmp('virus-list-grid');
                    	var records = grid.getSelectionModel().getSelection();
                    	if(records.length > 0) {
                    		var selectedRecord = records[0];
                    		if(scope) {
                    			callback.call(scope, selectedRecord);
                    		} else {
                    			callback.call(selectedRecord);
                    		}
                    		dialog.close();
                    	}
                    }	                    
                },{
                	xtype:'button',
                	text: 'Cancel',
                    handler: function(){
                        dialog.close();
                    }
                }]
            });
            dialog.show();
		},
		
		getStore : function() {
			virusStore.clearFilter();
			return virusStore;
		}
	};
}();

/*
 * This sample demonstrates the use of custom tag element. In this example, custom tag 'virus' is applied on the selected text and also custom attributes 
 * (disease, transmission, host) applied along with tag.
 * 
 * 
 * */
CKEDITOR.plugins.add('democustomtag',
{
	init: function (editor) {
		var pluginName = 'democustomtag';
		Ext.Loader.loadScript(CKEDITOR.plugins.getPath('democustomtag')+'/dialogs/virus-list-dialog.js');
		editor.ui.addButton('democustomtag',
			{
					label: 'Demo Custom Tag',
					command: 'democustomtag',
					icon: CKEDITOR.plugins.getPath('democustomtag') + 'tag.png'
			});
		var me = this;
		editor.addCommand('democustomtag', { 
			exec: function(editor) {
				var selection = editor.getSelection();
				var selectedText;
				if(selection.getSelectedText() != '') {
					selectedText = selection.getSelectedText();
				}
				VirusListDialog.showDialog(selectedText, me.insertCustomTag, me);
		}});
		
	},
	
	insertCustomTag : function(record) {
		var name = record.get('name');
		var element = CKEDITOR.dom.element.createFromHtml('<span>' + record.get('name') +'</span>');
		var editor = QXmlEditorEx.getEditorInstance();
		editor.insertElement(element);
		var selection = editor.getSelection();
		selection.selectElement(element);
		var metaObj = {type:'meta'};
		metaObj.attributes = [{type:'attribute', name: 'disease', value: [record.get('disease')]}, 
		                      {type:'attribute',name: 'transmission', value: [record.get('transmission')]},
		                      {type:'attribute',name: 'host', value: [record.get('host')]}]; 
		QXmlEditorEx.applyTag('virus', metaObj, true);
	}
});

/**
 * Validation Errors pane view which shows the details for each failed rules 
 */
Ext.define('com.quark.kestrel.extension.view.ValidationErrorView', {
	extend : 'Ext.panel.Panel',
	id : 'validation-error-panel',
	alias : 'widget.validationErrorView',
	layout : 'fit',
	overflow : 'auto',
	autoScroll : true,
	bodyCls : 'comment-view-panel',
	xTitle : 'Validation Errors',
	border : false,
	errorMessages : {
						TITLE_LIMIT_EXCEEDED : 'Document title is too long',
						ONLY_TWO_PARAGRAPH : 'Maximum two paragraphs are allowed in section body.'
					},
	
	initComponent : function() {
		var tpl = new Ext.XTemplate(
				'<tpl for=".">',
					'<div class="commentDetails comment-pane-item-selected comment-pane-item-over" id="target-{elementId}" style="border-left:2px solid">',
						'<div class="review-header commentHeader">',
							'{[getMessage(values.ruleId)]}',
						'</div>',
						'<div class="commentContent">',
							'<div id="content-{elementId}" class="commentContent-comment">',
								'<div>Line : {line} Column : {column}</div>',
							'</div>',
						'</div>',
					'</div>',
				'</tpl>'
			);

		/**
		 *  Get friendly error message based on validation rule ID
		 */
		getMessage = function(ruleId) {
			return Ext.getCmp('validation-error-panel').errorMessages[ruleId];
		}

		this.items = Ext.create('Ext.view.View', {
			itemId : 'validation-error-pane-view',
			autoScroll : true,
			itemSelector : 'div.commentDetails',
			overItemCls : 'comment-pane-item-over',
			selectedItemCls : 'comment-pane-item-selected',
			multiSelect : false,
			trackOver : true,
			store : 'ValidationErrors',
			tpl : tpl
		});
		this.setTitle(this.xTitle);
		this.callParent();
	},
});
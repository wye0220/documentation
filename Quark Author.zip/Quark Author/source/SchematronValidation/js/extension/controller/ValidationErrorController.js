/***************************************************************************************************************************************************************
 * ValidationErrorController for Validation Errors panes
 * 	- shows the failed business rules and on click highlight the element on UI
 *  
 **************************************************************************************************************************************************************/
Ext.define('com.quark.kestrel.extension.controller.ValidationErrorController', {
	extend : 'Ext.app.Controller',
	views : [ 'ValidationErrorView' ],
	stores : [ 'ValidationErrors' ],
	init : function() {
		this.control({
			'#validation-error-pane-view' : {
				itemclick : this.onCommentPaneItemClick
			}
		});
	},
	showValidationErrors : function(failedRules) { // method is called from validatexml plugin
		var validaionErrorStore = this.getValidationErrorsStore();
		var id = 0; // to make store items unique
		var validadationErrors = [];
		for (var fr in failedRules) {
			var failedAsserts = failedRules[fr];
			for(var i=0;i< failedAsserts.length;i++){
				validadationErrors.push({
					id : id++,
					elementId : failedAsserts[i].elementId,
					ruleId : failedAsserts[i].ruleId,
					location : failedAsserts[i].location,
					line : failedAsserts[i].line,
					column : failedAsserts[i].column
				});
			}
		}
		validaionErrorStore.loadData(validadationErrors, false); // load data to store
	},
	/* This method is handler for validation error pane item selection which scroll down the editor window to show where rule is failed */
	onCommentPaneItemClick : function(pane, record, item, index, e, eOpts) {
		var id = record.getElementId();
		var editor = QXmlEditorEx.getEditorInstance();
		var searchKey = 'id'; // based on this html will be searched to get element 
		var element = QXmlEditorEx.scanSearchContentId(QXmlEditorEx.getRootSectionElement(), id, searchKey);
		if (element) { // if element is on html based on search key select it on view
			var selection = editor.getSelection();
			selection.selectElement(element);
			element.scrollIntoView(); //method scrolls the current element into the visible area of the browser window.
		}
	},
});
/**
 * Model for the ValidationErrors data store
 */
Ext.define('com.quark.kestrel.extension.model.ValidationError', {
	extend : 'Ext.data.Model',
	idProperty : 'id',
	fields : [ {
		name : 'elementId',
		type : 'string'
	}, {
		name : 'ruleId',
		type : 'string'
	}, {
		name : 'line',
		type : 'string'
	}, {
		name : 'column',
		type : 'int'
	}, {
		name : 'location',
		type : 'string'
	}, {
		name : 'id',
		type : 'int'
	}  ],
	
	getElementId : function() { // to get element id in ValidationErrorController
		return this.get('elementId');
	}
});
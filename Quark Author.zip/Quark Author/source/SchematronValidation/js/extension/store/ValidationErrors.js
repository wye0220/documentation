/**
 * Data store for the Validation error pane 
 */
Ext.define('com.quark.kestrel.extension.store.ValidationErrors', {
	extend : 'Ext.data.Store',
	requires : 'com.quark.kestrel.extension.model.ValidationError',
	model : 'com.quark.kestrel.extension.model.ValidationError'
});
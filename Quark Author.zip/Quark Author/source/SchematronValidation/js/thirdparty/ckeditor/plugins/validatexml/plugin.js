/**
 * XML Validation plugin to validate Smart Document XML
 */
CKEDITOR.plugins.add('validatexml', {
	icons : 'validatexml',
	init : function(editor) {
		var pluginName = 'validatexml';
		editor.ui.addButton('validatexml', {
			label : 'Validate XML',
			command : "validateXml"
		});

		/* On VALIDATE_XML command, verify the business rules and show failed */
		var cmd = editor.addCommand("validateXml", {
			modes : {
				wysiwyg : 1,
				source : 1
			}, // Enable this View XML command even in case of read-only mode of editor.
			readOnly : 1,
			requiresConnection : true,
			exec : function(editor) {
				//Convert current document to SmartContent XML
				var smartDoc = QXmlEditorEx.getCurrentSmartDoc();

				// convertToXml returns promise object, so on sucesss call validate api with smart content
				QXmlEditorEx.convertToXml(smartDoc).then(function(xmlDoc) {
					
					// Invoke AJAX request for Schematron based validation of XML
					Ext.Ajax.request({
						method : 'POST',
						url : location.protocol + '//' + location.host + '/rest/service' + '/validate',
						params : {
							contentType : QXmlEditor.getContentType(),
							xmlDoc : xmlDoc
						},

						disableCaching : true,
						async : false,
						success : function(response, options) {
							var responseData = JSON.parse(response.responseText);
							QXmlEditorUtils.getController('com.quark.kestrel.extension.controller.ValidationErrorController')
								.showValidationErrors(responseData.failedAsserts);

						},
						failure : function(response, options) {
							console.log(response);
							alert("Unable to validate XML");
						},
						scope : this
					});
				}, function(reason) {
					console.log('Conversion to SmartContent XML failed. :',reason.responseText)
				});
			},
			readOnlyExec : true
		}); // addCommand

	} // init
});
package com.quark.qpp.xmleditor.validation;

import java.util.ArrayList;
import java.util.Map;

/**
 * 
 * Object with failedAsserts and successReports that will be returned as Output
 *
 */
public class SmartContentValidationReport {
	private Map<String, ArrayList<ValidationRule>> failedAsserts;
	private Map<String, ArrayList<ValidationRule>> successReports;

	public SmartContentValidationReport(Map<String, ArrayList<ValidationRule>> failedAsserts,
			Map<String, ArrayList<ValidationRule>> successReports) {
		this.failedAsserts = failedAsserts;
		this.successReports = successReports;
	}

	public Map<String, ArrayList<ValidationRule>> getFailedAsserts() {
		return failedAsserts;
	}

	public Map<String, ArrayList<ValidationRule>> getSuccessReports() {
		return successReports;
	}
}
package com.quark.qpp.xmleditor.schematron;

/**
 * Response class consist of failed and sucess rules used in unmarshalling 
 * 
 */
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.quark.qpp.xmleditor.validation.ValidationRule;

@XmlRootElement(name = "schematron-output",namespace="http://purl.oclc.org/dsdl/svrl")
public class ValidationResponse {

	public ValidationResponse() {
	}

	private ArrayList<ValidationRule> failedAssertList;
	private ArrayList<ValidationRule> successReportList;

	@XmlElement(name = "failed-assert", namespace="http://purl.oclc.org/dsdl/svrl")
	public ArrayList<ValidationRule> getFailedAssertList() {
		return failedAssertList;
	}

	public void setFailedAssertList(ArrayList<ValidationRule> failedAssertList) {
		this.failedAssertList = failedAssertList;
	}
	
	@XmlElement(name="success-report", namespace="http://purl.oclc.org/dsdl/svrl")
	public ArrayList<ValidationRule> getSuccessReportList() {
		return successReportList;
	}

	public void setSuccessReportList(ArrayList<ValidationRule> successReportList) {
		this.successReportList = successReportList;
	}
}
package com.quark.qpp.xmleditor.validation.controller;

/**
 * Facade that will return the validation report consist of failed and success rules
 */
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.quark.qpp.xmleditor.validation.SmartContentRulesValidator;
import com.quark.qpp.xmleditor.validation.SmartContentValidationReport;

@RestController
public class SmartContentValidatorFacade {

	Map<String, String> contentTypeRulesMap;

	@Resource(name = "contentTypeRulesMap")
	public void setContentTypeMap(Map<String, String> contentTypeRulesMap) {
		this.contentTypeRulesMap = contentTypeRulesMap;
	}

	SmartContentRulesValidator rulesValidator;

	@Autowired
	public void setRulesValidator(SmartContentRulesValidator rulesValidator) {
		this.rulesValidator = rulesValidator;
	}

	public SmartContentValidatorFacade() {
	}

	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public SmartContentValidationReport validate(@RequestParam(value = "contentType") String contentType,
			@RequestParam(value = "xmlDoc") String xmlDoc) throws Exception {

		SmartContentValidationReport svr = null;
		String schemaDocPath = contentTypeRulesMap.get(contentType);
		svr = rulesValidator.validate(schemaDocPath, xmlDoc);
		return svr;
	}
}
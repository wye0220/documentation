package com.quark.qpp.xmleditor.schematron;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.probatron.Session;
import org.probatron.ValidationReport;

import com.quark.qpp.xmleditor.validation.SmartContentRulesValidator;
import com.quark.qpp.xmleditor.validation.SmartContentValidationReport;
import com.quark.qpp.xmleditor.validation.ValidationRule;

/**
 * 
 * SmartContentRulesValidator implementation that will validate input xml
 * and return SmartContentValidationReport object
 */
public class SchematronValidator implements SmartContentRulesValidator {
	/**
	 * validate input xml against rules in input schematron(.sch) file
	 * 
	 * @param schemaDocPath
	 *            {String}
	 * @param xmlDoc
	 *            {String}
	 */
	@Override
	public SmartContentValidationReport validate(String schemaDocPath, String xmlDoc) throws Exception {

		// write input xml into a temp file
		new File("tmp").mkdir();
		PrintWriter out = new PrintWriter("tmp/xmlDoc.xml");
		out.print(xmlDoc);
		out.close();

		// validate the xml against schematron rules using Schematron validation
		// engine
		Session session = new Session();
		session.setSchemaDoc("file:" + schemaDocPath);
		String candidate = "file:" + new File("tmp/xmlDoc.xml").getAbsolutePath();
		ValidationReport vr = session.doValidation(candidate);

		// Stream validation report into a temp file
		vr.streamOut(new FileOutputStream("tmp/report.xml"));

		// unmarshalling validation report into ValidationResponse Object.
		ValidationResponse validationResponse = ValidationReportReader.xmlToObject("tmp/report.xml");

		// as we need to add id of each element from xml where rule failed so
		Map<String, String> locationIdMap = ValidationReportReader.getIds(validationResponse, "tmp/xmlDoc.xml");

		try {
			delete(new File("tmp")); // delete the tmp directory
		} catch (IOException e) {
			e.printStackTrace();
		}

		// rule map that will be filled with failed assert from unmarshalled xml
		Map<String, ArrayList<ValidationRule>> failedAssertMap = null;
		Map<String, ArrayList<ValidationRule>> successReportMap = null;

		if (validationResponse.getFailedAssertList() != null) {
			failedAssertMap = new HashMap<String, ArrayList<ValidationRule>>(
					validationResponse.getFailedAssertList().size());
			for (int i = 0; i < validationResponse.getFailedAssertList().size(); i++) {
				ValidationRule failedAssert = validationResponse.getFailedAssertList().get(i);

				// get failed validation rule from the map
				ArrayList<ValidationRule> validationRule = failedAssertMap.get(failedAssert.getRuleId());

				// if failed rule does not have the same ruleId in map then add
				// new entry for failed map
				if (validationRule == null) {
					ArrayList<ValidationRule> validationRuleList = new ArrayList<ValidationRule>();
					validationRuleList.add(
							new ValidationRule(locationIdMap.get(failedAssert.getLocation()), failedAssert.getRuleId(),
									failedAssert.getLocation(), failedAssert.getLine(), failedAssert.getColumn()));
					failedAssertMap.put(failedAssert.getRuleId(), validationRuleList);
				} else { // add failed validation rule to array under same
							// ruleId key in map
					validationRule.add(
							new ValidationRule(locationIdMap.get(failedAssert.getLocation()), failedAssert.getRuleId(),
									failedAssert.getLocation(), failedAssert.getLine(), failedAssert.getColumn()));
				}
			}
		}

		if (validationResponse.getSuccessReportList() != null) {
			successReportMap = new HashMap<String, ArrayList<ValidationRule>>(
					validationResponse.getSuccessReportList().size());

			for (int i = 0; i < validationResponse.getFailedAssertList().size(); i++) {
				ValidationRule successReport = validationResponse.getSuccessReportList().get(i);

				// get sucessfull validation rule from the map
				ArrayList<ValidationRule> passedRule = successReportMap.get(successReport.getRuleId());

				// if failed rule does not have the same ruleId in map then add
				// new entry for failed map
				if (passedRule == null) {
					ArrayList<ValidationRule> validationRuleList = new ArrayList<ValidationRule>();
					validationRuleList.add(new ValidationRule(locationIdMap.get(successReport.getLocation()),
							successReport.getRuleId(), successReport.getLocation(), successReport.getLine(),
							successReport.getColumn()));
					successReportMap.put(successReport.getRuleId(), validationRuleList);
				} else { // add failed validation rule to array under same
							// ruleId key in map
					passedRule.add(new ValidationRule(locationIdMap.get(successReport.getLocation()),
							successReport.getRuleId(), successReport.getLocation(), successReport.getLine(),
							successReport.getColumn()));
				}
			}
		}
		return new SmartContentValidationReport(failedAssertMap, successReportMap);
	}

	private void delete(File file) throws IOException {
		if (file.isDirectory()) {
			// directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
			} else {
				// list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);
					// recursive delete
					delete(fileDelete);
				}
				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
				}
			}
		} else {
			// if file, then delete it
			file.delete();
		}
	}
}
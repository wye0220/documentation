package com.quark.qpp.xmleditor.schematron;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.quark.qpp.xmleditor.validation.ValidationRule;

public class ValidationReportReader {

	public static ValidationResponse xmlToObject(String file) throws JAXBException {
		// jaxb to convert xml result file to java objects
		JAXBContext jaxbContext = JAXBContext.newInstance(ValidationResponse.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		// unmarshall xml in java objects
		return (ValidationResponse) jaxbUnmarshaller.unmarshal(new File(file));
	}

	/**
	 * Get error locations
	 * 
	 * @param validationResponse
	 *            [ValidationResponse]
	 * @param xmlPath [String]
	 * @return map of node ids or node parent corresponding to the location
	 * @throws Exception
	 */
	public static Map<String, String> getIds(ValidationResponse validationResponse, String xmlPath) throws Exception {

		ArrayList<String> locations = getUniqueLocations(validationResponse);
		Map<String, String> locationIdMap = new HashMap<String, String>();

		File inputFile = new File(xmlPath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;

		dbFactory.setNamespaceAware(true);
		dBuilder = dbFactory.newDocumentBuilder();

		Document doc = dBuilder.parse(inputFile);
		doc.getDocumentElement().normalize();

		XPath xPath = XPathFactory.newInstance().newXPath();

		HashMap<String, String> prefixMap = new HashMap<String, String>();
		prefixMap.put("q", "http://quark.com/smartcontent/4.0");

		GenericNamespaceContext namespaces = new GenericNamespaceContext(prefixMap);
		xPath.setNamespaceContext(namespaces);

		for (String expression : locations) { // for each location(xpath), get
												// id of node in XML
			NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
			Node node = nodeList.item(0);
			String id = getId(node);
			locationIdMap.put(expression, id);
		}
		return locationIdMap;
	}

	// get id attribute of the node or its parent using recursion
	private static String getId(Node node) {
		Node attribute = node.getAttributes().getNamedItem("id");
		if (attribute == null) {
			return getId(node.getParentNode());
		} else {
			return attribute.getNodeValue();
		}
	}

	// method to get unique location/xpath from passed response
	private static ArrayList<String> getUniqueLocations(ValidationResponse validationResponse) {
		ArrayList<String> locations = new ArrayList<String>();

		if (validationResponse.getFailedAssertList() != null) {
			for (int i = 0; i < validationResponse.getFailedAssertList().size(); i++) {
				ValidationRule failedAssert = validationResponse.getFailedAssertList().get(i);
				if (!locations.contains(failedAssert.getLocation())) {
					locations.add(failedAssert.getLocation());
				}
			}
		}

		if (validationResponse.getSuccessReportList() != null) {
			for (int i = 0; i < validationResponse.getSuccessReportList().size(); i++) {
				ValidationRule successReport = validationResponse.getSuccessReportList().get(i);
				if (!locations.contains(successReport.getLocation())) {
					locations.add(successReport.getLocation());
				}
			}
		}
		return locations;
	}
}

class GenericNamespaceContext implements NamespaceContext {
	private final Map<String, String> PREF_MAP = new HashMap<String, String>();

	public GenericNamespaceContext(final Map<String, String> prefixMap) {
		PREF_MAP.putAll(prefixMap);
	}

	@Override
	public String getNamespaceURI(String prefix) {
		return PREF_MAP.get(prefix);
	}

	@Override
	public String getPrefix(String namespaceURI) {
		return null;
	}

	@Override
	public Iterator getPrefixes(String namespaceURI) {
		return null;
	}
}
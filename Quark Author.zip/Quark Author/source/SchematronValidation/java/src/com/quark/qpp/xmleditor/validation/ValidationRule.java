package com.quark.qpp.xmleditor.validation;

/**
 * ValidationRule class that holds properties of a failed/passed rule
 */
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ValidationRule {
	private String location, ruleId, elementId;
	private int line, column;

	ValidationRule() {
	}

	public ValidationRule(String elementId, String ruleId, String location, int line, int column) {
		this.elementId = elementId;
		this.ruleId = ruleId;
		this.location = location;
		this.line = line;
		this.column = column;
	}

	@XmlAttribute
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@XmlElement(name = "text", namespace = "http://purl.oclc.org/dsdl/svrl")
	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	@XmlAttribute
	public int getLine() {
		return line;
	}

	public void setLine(int line) {
		this.line = line;
	}

	@XmlAttribute(name = "col")
	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	 public String getElementId() {
	 return elementId;
	 }
	
	 public void setElementId(String elementId) {
	 this.elementId = elementId;
	 }
}

package com.quark.qpp.xmleditor.validation;

public interface SmartContentRulesValidator {
	public SmartContentValidationReport validate(String xmlRules, String xmlDoc) throws Exception;

}
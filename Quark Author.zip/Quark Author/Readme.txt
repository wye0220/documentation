
Deployment Instructions for Extensibility Samples (in Standalone Build)

========================
== Available Plugins  ==
========================

xmlvalidation
blockstyles
demobodydiv
democustomtag
validate
sendfor
restattribute
style
selectionpath
status

=============================
== Steps to deploy samples ==
=============================

Step 1	: Set QPP-Server-Base property as the installed QPP Server directory value in build.xml file.

Step 2	: Open Admin Client and create new content types 'Outbreak Notice' and 'Assessment' under 'Asset -> XML -> Smart Content'.

Step 3	: To deploy all plugins build this project using ant command.

Step 4	: To deploy individual plugin use "ant deploy-sample-<plugin-name>". Replace <plugin-name> from available plugins.

Now you can access XDK samples by creating document of type 'Outbreak Notice' and observe toolbar and panes.

=============================
== Steps to remove samples ==
=============================

Step 1	: To clean individual plugin use "ant clean-sample-<plugin-name>". Replace <plugin-name> from available plugins.
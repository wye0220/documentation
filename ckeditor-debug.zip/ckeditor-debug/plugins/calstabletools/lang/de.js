CKEDITOR.plugins.setLang( 'calstabletools', 'de', {
	context:{
		tableTypes : 'Tabellentypen',
		insert: 'Einfügen',
		insertColsLeft: 'Spalten nach links einfügen',
		insertColsRight: 'Spalten nach rechts einfügen',
		insertRowsAbove: 'Zeilen oberhalb einfügen',
		insertRowsBelow: 'Zeilen unterhalb einfügen',
		insertHeaderAbove: 'Insert Header Above',
		insertHeaderBelow: 'Insert Header Below',
		insertCaption: 'Bildunterschrift',
		insertDescription: 'Beschreibung',
		deleteText : 'Löschen',
		deleteTable : 'Tabelle Löschen',
		appendPara : 'Absatz einfügen nach',
		headerRow : 'Zeile im Kopfbereich'
	}
});
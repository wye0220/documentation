CKEDITOR.plugins.setLang( 'calstabletools', 'fr', {
	context:{
		tableTypes : 'Types de tableaux',
		insert: 'Insérer',
		insertColsLeft: 'Insérer des colonnes à gauche',
		insertColsRight: 'Insérer des colonnes à droite',
		insertRowsAbove: 'Insérer des rangées au-dessus',
		insertRowsBelow: 'Insérer des rangées en dessous',
		insertHeaderAbove: 'Insert Header Above',
		insertHeaderBelow: 'Insert Header Below',
		insertCaption: 'Légende',
		insertDescription: 'Description',
		deleteText : 'Supprimer',
		deleteTable : 'Supprimer le tableau',
		appendPara : 'Insérer un paragraphe après',
		headerRow : "Rangée d'en-tête"
	}
});	
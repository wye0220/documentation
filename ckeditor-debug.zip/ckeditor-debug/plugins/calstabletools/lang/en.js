CKEDITOR.plugins.setLang( 'calstabletools', 'en', {
	context:{
		tableTypes : 'Table Types',
		insert: 'Insert',
		insertColsLeft: 'Insert Column to the Left',
		insertColsRight: 'Insert Column to the Right',
		insertRowsAbove: 'Insert Row Above',
		insertRowsBelow: 'Insert Row Below',
		insertHeaderAbove: 'Insert Header Above',
		insertHeaderBelow: 'Insert Header Below',
		insertCaption: 'Caption',
		insertDescription: 'Description',
		deleteText : 'Delete',
		deleteTable : 'Delete Table',
		appendPara : 'Insert Paragraph After',
		headerRow : 'Header Row'
	}
});
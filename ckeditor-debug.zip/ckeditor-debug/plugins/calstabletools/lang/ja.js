CKEDITOR.plugins.setLang( 'calstabletools', 'ja', {
	context:{
		tableTypes : '表の種類',
		insert: '\u633F\u5165',
		insertColsLeft: '\u5DE6\u306B\u5217\u3092\u633F\u5165(L)',
		insertColsRight: '\u53F3\u306B\u5217\u3092\u633F\u5165(R)',
		insertRowsAbove: '\u4E0A\u306B\u884C\u3092\u633F\u5165(A)',
		insertRowsBelow: '\u4E0B\u306B\u884C\u3092\u633F\u5165(B)',
		insertCaption: '\u30AD\u30E3\u30D7\u30B7\u30E7\u30F3',
		insertHeaderAbove: 'Insert Header Above',
		insertHeaderBelow: 'Insert Header Below',
		insertDescription: '\u8A2D\u5B9A\u5185\u5BB9',
		deleteText : '\u524A\u9664',
		deleteTable : '\u30C6\u30FC\u30D6\u30EB\u3092\u524A\u9664',
		appendPara : 'この後に段落を挿入する',
		headerRow : 'ヘッダー行'
	}
});
CKEDITOR.plugins.setLang( 'calstabletools', 'ko', {
	context:{
		tableTypes : '표 유형',
		insert: '\uC0BD\uC785',
		insertColsLeft: '왼쪽에 열 삽입',
		insertColsRight: '오른쪽에 열 삽입',
		insertRowsAbove: '위에 행 삽입',
		insertRowsBelow: '아래에 행 삽입',
		insertHeaderAbove: 'Insert Header Above',
		insertHeaderBelow: 'Insert Header Below',
		insertCaption: '캡션',
		insertDescription: '\uC124\uBA85',
		deleteText : '\uC0AD\uC81C',
		deleteTable : '\uD45C \uC0AD\uC81C',
		appendPara : '뒤에 단락 삽입',
		headerRow : '머리말 행'
	}
});
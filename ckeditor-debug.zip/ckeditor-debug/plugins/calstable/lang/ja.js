CKEDITOR.plugins.setLang( 'calstable', 'ja', {
	tooltip: '\u8868\u306E\u633F\u5165',
	dialog:{
		title: '\u8868\u306E\u633F\u5165',
		rows: '\u884C\u6570',
		columns: '列',
		header: '\u30D8\u30C3\u30C0\u30FC\u884C',
		caption: '\u30AD\u30E3\u30D7\u30B7\u30E7\u30F3',
		desc: '\u8A2D\u5B9A\u5185\u5BB9',
		size: '\u8868\u306E\u30B5\u30A4\u30BA',
		options: '\u30C6\u30FC\u30D6\u30EB\u30AA\u30D7\u30B7\u30E7\u30F3'
	}
});
CKEDITOR.plugins.setLang( 'calstable', 'ko', {
	tooltip: '표 삽입',
	dialog:{
		title: '표 삽입',
		rows: '행 개수',
		columns: '열 개수',
		header: '머리말 행',
		caption: '캡션',
		desc: '\uC124\uBA85',
		size: '표 크기',
		options: '\uD45C \uC120\uD0DD\uC0AC\uD56D'
	}
});
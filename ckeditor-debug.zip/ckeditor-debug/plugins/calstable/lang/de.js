CKEDITOR.plugins.setLang( 'calstable', 'de', {
	tooltip: 'Tabelle einfügen',
	dialog:{
		title: 'Tabelle einfügen',
		rows: 'Zeilenanzahl',
		columns: 'Anzahl an Spalten',
		header: 'Zeile im Kopfbereich',
		caption: 'Bildunterschrift',
		desc: 'Beschreibung',
		size: 'Tabellengröße',
		options: 'Tabellenoptionen'
	}
});
CKEDITOR.plugins.setLang( 'calstable', 'fr', {
	tooltip: 'Insérer un tableau',
	dialog:{
		title: 'Insérer un tableau',
		rows: 'Nombre de rangées',
		columns: 'Nombre de colonnes',
		header: "Rangée d'en-tête",
		caption: 'Légende',
		desc: 'Description',
		size: 'Taille du tableau',
		options: 'Options de tableaux'
	}
});
CKEDITOR.plugins.setLang( 'calstable', 'en', {
	tooltip: 'Insert Table',
	dialog:{
		title: 'Insert Table',
		rows: 'Number of rows',
		columns: 'Number of columns',
		header: 'Header Row',
		caption: 'Caption',
		desc: 'Description',
		size: 'Table Size',
		options: 'Table Options'
	}
});
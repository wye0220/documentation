CKEDITOR.plugins.setLang( 'video', 'en', {
	tooltip: 'Insert Video',
	context:{
		videoTitle: 'Video Title',
		videoDesc: 'Video Description',
		videoDel: 'Delete',
		preview : 'Preview',
		replaceImage : 'Replace Poster Image',
		appendPara : 'Insert Paragraph After',
		pinVideo :'Pin Component Reference',
		unpinVideo :'Unpin Component Reference',
        editReference : 'Edit'
	},
	dialog:{
		title: 'Insert Video',
		titleField: 'Title',
		descField: 'Description',
		browseBtn: 'Browse...',
		qppVideoLbl: 'From Platform',
		selectImage: 'Select a poster image',
		httpVideoLbl: 'From Web',
		inlineOptLbl: 'Insert Inline with text',
		error: 'Video is not supported',
		errorTitle: 'Error'
	}
});
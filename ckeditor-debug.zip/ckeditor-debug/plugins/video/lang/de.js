CKEDITOR.plugins.setLang( 'video', 'de', {
	tooltip: 'Video einfügen',
	context:{
		videoTitle: 'Video-Titel',
		videoDesc: 'Video-Beschreibung',
		videoDel: 'Löschen',
		preview : 'Voransicht',
		replaceImage : 'Poster-Bild ersetzen',
		appendPara : 'Absatz einfügen nach',
		pinVideo :'Komponentenverweis anheften',
		unpinVideo :'Komponentenverweis abtrennen',
        editReference : 'Bearbeiten'
	},
	dialog:{
		title: 'Video einfügen',
		browseBtn: 'Blättern...',
		qppVideoLbl: 'Von Platform',
		selectImage: 'Ein Poster-Bild wählen',
		httpVideoLbl: 'Aus dem Internet',
		inlineOptLbl: 'Insert Inline with text',
		error: 'Video is not supported',
		errorTitle: 'Fehler'
	}
});
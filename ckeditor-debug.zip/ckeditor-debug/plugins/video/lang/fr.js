CKEDITOR.plugins.setLang( 'video', 'fr', {
	tooltip: 'Insertion d\'une vidéo',
	context:{
		videoTitle: 'Titre de la vidéo',
		videoDesc: 'Description de la vidéo',
		videoDel: 'Supprimer',
		preview : 'Prévisualisation',
		replaceImage : 'Remplacer l\'image de poster',
		appendPara : 'Insérer un paragraphe après',
		pinVideo :'Epingler la référence de composant',
		unpinVideo :'Détacher la référence de composant',
        editReference : 'Edition'
	},
	dialog:{
		title: 'Insertion d\'une vidéo',
		browseBtn: 'Parcourir...',
		qppVideoLbl: 'De Platform',
		selectImage: 'Sélectionner une image de poster',
		httpVideoLbl: 'Du Web',
		inlineOptLbl: 'Insert Inline with text',
		error: 'Video is not supported',
		errorTitle: 'Erreur'
	}
});
CKEDITOR.plugins.setLang( 'video', 'ja', {
	tooltip: 'ビデオの挿入',
	context:{
		videoTitle: 'ビデオのタイトル',
		videoDesc: 'ビデオの説明',
		videoDel: '削除',
		preview : 'プレビュー',
		replaceImage : 'ポスター画像の置き換え',
		appendPara : 'この後に段落を挿入する',
		pinVideo :'コンポーネントの参照を固定',
		unpinVideo :'コンポーネントの参照の固定を解除',
        editReference : '編集'
	},
	dialog:{
		title: 'ビデオの挿入',
		titleField: 'タイトル',
		descField: '設定内容',
		browseBtn: '\u53C2\u7167...',
		qppVideoLbl: 'プラットフォームから',
		selectImage: 'ポスター画像の選択',
		httpVideoLbl: 'Webから',
		inlineOptLbl: 'Insert Inline with text',
		error: 'Video is not supported',
		errorTitle: 'エラー'
	}
});
CKEDITOR.plugins.setLang( 'video', 'ko', {
	tooltip: '비디오 삽입',
	context:{
		videoTitle: '비디오 제목',
		videoDesc: '비디오 설명',
		videoDel: '삭제',
		preview : '미리보기',
		replaceImage : '포스터 이미지 대치',
		appendPara : '뒤에 단락 삽입',
		pinVideo :'컴포넌트 참조 고정',
		unpinVideo :'컴포넌트 참조 고정 해제',
        editReference : '편집'
	},
	dialog:{
		title: '비디오 삽입',
		browseBtn: '찾아보기...',
		qppVideoLbl: '플랫폼 시작',
		selectImage: '포스터 이미지 선택',
		httpVideoLbl: '웹 시작',
		inlineOptLbl: 'Insert Inline with text',
		error: 'Video is not supported',
		errorTitle: '오류'
	}
});
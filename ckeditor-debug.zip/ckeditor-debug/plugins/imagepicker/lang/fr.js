CKEDITOR.plugins.setLang( 'imagepicker', 'fr', {
	tooltip: 'Insérer une image',
	convertToFigure : 'Convertir en figure',
	fromPlatform:'De Platform',
	fromFilesystem:'Depuis un système de fichiers local',
    editReference : 'Edition'
});
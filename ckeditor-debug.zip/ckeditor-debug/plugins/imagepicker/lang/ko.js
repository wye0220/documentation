CKEDITOR.plugins.setLang( 'imagepicker', 'ko', {
	tooltip: '이미지 삽입',
	convertToFigure : '숫자로 변환',
	fromPlatform:'플랫폼 시작',
	fromFilesystem:'로컬 파일 시스템으로부터',
    editReference : '편집'
});
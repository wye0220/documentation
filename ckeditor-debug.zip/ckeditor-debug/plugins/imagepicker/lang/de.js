CKEDITOR.plugins.setLang( 'imagepicker', 'de', {
	tooltip: 'Bild einfügen',
	convertToFigure : 'In Abbildung umwandeln',
	fromPlatform:'Von Platform',
	fromFilesystem:'Vom lokalen Dateisystem',
    editReference : 'Bearbeiten'
});
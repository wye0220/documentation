CKEDITOR.plugins.setLang( 'imagepicker', 'en', {
	tooltip: 'Insert Image',
	convertToFigure : 'Convert to Figure',
	fromPlatform:'From Platform',
	fromFilesystem:'From Local File System',
    editReference : 'Edit'
});
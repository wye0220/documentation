CKEDITOR.plugins.setLang( 'imagepicker', 'ja', {
	tooltip: '\u753B\u50CF\u306E\u633F\u5165',
	convertToFigure : '図に変換',
	fromPlatform:'プラットフォームから',
	fromFilesystem:'ローカルファイルシステムから',
    editReference : '編集'
});
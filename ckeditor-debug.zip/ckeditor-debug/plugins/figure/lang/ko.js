CKEDITOR.plugins.setLang( 'figure', 'ko', {
	tooltip: '그림 삽입',
	context:{
		figureTitle: '그림 제목',
		figureDesc: '그림 설명',
		figureDel: '\uC0AD\uC81C',
		appendPara : '뒤에 단락 삽입',
        editReference : '편집'
	},
	dialog:{
		title: '그림 삽입',
		figureTitle: '\uC81C\uBAA9',
		figureDesc: '\uC124\uBA85',
		figureUrl: 'URL',
		figureSelectBtn: '\uC774\uBBF8\uC9C0 \uC120\uD0DD',
		name: '어셋 이름',
		browse: '\uCC3E\uC544\uBCF4\uAE30',
		error: '이미지를 선택하십시오.',
		errorTitle: '\uC624\uB958',
		fromPlatform:'플랫폼 시작',
		fromFilesystem:'로컬 파일 시스템으로부터',
		invalidFile:'\uC774 \uD30C\uC77C \uC720\uD615\uC740 \uC9C0\uC6D0\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uC720\uD6A8\uD55C \uADF8\uB9BC \uD30C\uC77C\uC744 \uC120\uD0DD\uD558\uC5EC \uC8FC\uC2ED\uC2DC\uC624.'
	}
});
CKEDITOR.plugins.setLang( 'figure', 'ja', {
	tooltip: '\u56F3\u3092\u633F\u5165',
	context:{
		figureTitle: '\u56F3\u30BF\u30A4\u30C8\u30EB',
		figureDesc: '\u56F3\u306E\u8AAC\u660E',
		figureDel: '\u524A\u9664',
		appendPara : 'この後に段落を挿入する',
        editReference : '編集'
	},
	dialog:{
		title: '\u56F3\u3092\u633F\u5165',
		figureTitle: '\u56F3\u30BF\u30A4\u30C8\u30EB',
		figureDesc: '\u8A2D\u5B9A\u5185\u5BB9',
		figureUrl: 'URL',
		figureSelectBtn: '\u30A4\u30E1\u30FC\u30B8\u306E\u9078\u629E',
		name: 'アセット名',
		browse: '\u53C2\u7167',
		error: '画像を1つ選択してください。',
		errorTitle: '\u30A8\u30E9\u30FC',
		fromPlatform:'プラットフォームから',
		fromFilesystem:'ローカルファイルシステムから',
		invalidFile:'\u3053\u306E\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u306F\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002\u6709\u52B9\u306A\u753B\u50CF\u30D5\u30A1\u30A4\u30EB\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002'
	}
});
CKEDITOR.plugins.setLang( 'figure', 'de', {
	tooltip: 'Abbildung einfügen',
	context:{
		figureTitle: 'Abb.-Titel',
		figureDesc: 'Abbildungsbeschreibung',
		figureDel: 'Löschen',
		appendPara : 'Absatz einfügen nach',
        editReference : 'Bearbeiten'
	},
	dialog:{
		title: 'Abbildung einfügen',
		figureTitle: 'Titel',
		figureDesc: 'Beschreibung',
		figureUrl: 'URL',
		figureSelectBtn: 'Bild auswählen',
		name: 'Asset-Name',
		browse: 'Blättern',
		error: 'Bitte wählen Sie ein Bild aus',
		errorTitle: 'Fehler',
		fromPlatform:'Von Platform',
		fromFilesystem:'Vom lokalen Dateisystem',
		invalidFile:'Dieser Dateityp wird nicht unterst\u00FCtzt. Bitte w\u00E4hlen Sie eine g\u00FCltige Bilddatei aus.'
	}
});
CKEDITOR.plugins.setLang( 'figure', 'fr', {
	tooltip: 'Insérer une figure',
	context:{
		figureTitle: 'Titre de la figure',
		figureDesc: 'Description de figure',
		figureDel: 'Supprimer',
		appendPara : 'Insérer un paragraphe après',
        editReference : 'Edition'
	},
	dialog:{
		title: 'Insérer une figure',
		figureTitle: 'Titre',
		figureDesc: 'Description',
		figureUrl: 'URL',
		figureSelectBtn: 'Sélectionner image',
		name: 'Nom d\'élément',
		browse: 'Parcourir',
		error: 'Sélectionnez une image.',
		errorTitle: 'Erreur',
		fromPlatform:'De Platform',
		fromFilesystem:'Depuis un système de fichiers local',
		invalidFile:"Ce type de fichier n'est pas pris en charge. S\u00E9lectionnez un fichier image valide."
	}
});
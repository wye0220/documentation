CKEDITOR.plugins.setLang( 'figure', 'en', {
	tooltip: 'Insert Figure',
	context:{
		figureTitle: 'Figure Title',
		figureDesc: 'Figure Description',
		figureDel: 'Delete',
		appendPara : 'Insert Paragraph After',
		editReference : 'Edit'
	},
	dialog:{
		title: 'Insert Figure',
		figureTitle: 'Title',
		figureDesc: 'Description',
		figureUrl: 'URL',
		figureSelectBtn: 'Select Image',
		name: 'Asset Name',
		browse: 'Browse',
		error: 'Please select an image',
		errorTitle: 'Error',
		fromPlatform:'From Platform',
		fromFilesystem:'From Local File System',
		invalidFile:'This file type is not supported. Please select valid picture file.'
	}
});
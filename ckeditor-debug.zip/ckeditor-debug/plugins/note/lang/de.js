CKEDITOR.plugins.setLang( 'note', 'de', {
	insertEndNote : 'Endnoten einsetzen',
	insertFootNote : 'Fußnoten einsetzen'
});
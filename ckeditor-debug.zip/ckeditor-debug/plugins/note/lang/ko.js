CKEDITOR.plugins.setLang( 'note', 'ko', {
	insertEndNote : '미주 삽입',
	insertFootNote : '각주 삽입'
});
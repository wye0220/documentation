CKEDITOR.plugins.setLang( 'note', 'ja', {
	insertEndNote : '文末脚注の挿入',
	insertFootNote : '脚注の挿入'
});
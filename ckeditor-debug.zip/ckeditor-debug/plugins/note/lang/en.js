CKEDITOR.plugins.setLang( 'note', 'en', {
	insertEndNote : 'Insert Endnote',
	insertFootNote : 'Insert Footnote'
});
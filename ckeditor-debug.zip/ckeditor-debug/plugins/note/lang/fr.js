CKEDITOR.plugins.setLang( 'note', 'fr', {
	insertEndNote : 'Insérer une note de fin',
	insertFootNote : 'Insérer une note de bas de page'
});
CKEDITOR.plugins.setLang('docx', 'ja', {
    insertPPT: 'PowerPointの挿入',
    insertPPTSlide: 'PowerPointスライドの挿入',
    insertVisioPage: 'Visioの図の挿入',
    insertVisio: 'Visioの挿入',
    pptPreviewIndexLabel:'スライド',
    visioPreviewIndexLabel:'ページ',
    previewIndexLabelSeparator : '／'
});
CKEDITOR.plugins.setLang('docx', 'ko', {
    insertPPT: 'PowerPoint 삽입',
    insertPPTSlide: 'PowerPoint 슬라이드 삽입',
    insertVisioPage: 'VISIO 드로잉 삽입',
    insertVisio: 'Visio 삽입',
    pptPreviewIndexLabel:'슬라이드',
    visioPreviewIndexLabel:'페이지',
    previewIndexLabelSeparator : '/'
});
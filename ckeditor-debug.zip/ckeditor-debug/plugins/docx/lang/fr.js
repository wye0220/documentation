CKEDITOR.plugins.setLang('docx', 'fr', {
    insertPPT: 'Insérer PowerPoint',
    insertPPTSlide: 'INSÉRER UNE DIAPOSITIVE POWERPOINT',
    insertVisioPage: 'INSÉRER UN DESSIN VISIO',
    insertVisio: 'Insérer Visio',
    pptPreviewIndexLabel:'DIAPOSITIVE',
    visioPreviewIndexLabel:'PAGE',
    previewIndexLabelSeparator : 'sur'
});
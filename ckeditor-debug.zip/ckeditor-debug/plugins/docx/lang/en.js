CKEDITOR.plugins.setLang('docx', 'en', {
    insertPPT: 'Insert Powerpoint',
    insertPPTSlide: 'insert powerpoint slide',
    insertVisioPage: 'insert visio drawing',
    insertVisio: 'Insert Visio',
    pptPreviewIndexLabel:'slide',
    visioPreviewIndexLabel:'page',
    previewIndexLabelSeparator : 'of'
});
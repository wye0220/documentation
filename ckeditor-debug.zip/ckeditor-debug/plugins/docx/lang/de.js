CKEDITOR.plugins.setLang('docx', 'de', {
    insertPPT: 'PowerPoint einfügen',
    insertPPTSlide: 'POWERPOINT-FOLIE EINFÜGEN',
    insertVisioPage: 'VISIO-ZEICHNUNG EINFÜGEN',
    insertVisio: 'Visio einfügen',
    pptPreviewIndexLabel:'FOLIE',
    visioPreviewIndexLabel:'SEITE',
    previewIndexLabelSeparator : 'von'
});
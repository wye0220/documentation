CKEDITOR.plugins.setLang( 'parastyles', 'fr', {
	tooltip: 'Format',
	paraTypes: 'Types para',
	regions : 'Régions',
	none_Label : 'Aucun'
});
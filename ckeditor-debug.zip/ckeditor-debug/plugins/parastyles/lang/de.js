CKEDITOR.plugins.setLang( 'parastyles', 'de', {
	tooltip: 'Formate',
	paraTypes: 'Absatztypen',
	regions : 'Bereiche',
	none_Label : 'Kein'
});
CKEDITOR.plugins.setLang( 'parastyles', 'en', {
	tooltip: 'Formats',
	paraTypes: 'Para Types',
	regions : 'Regions',
	none_Label : 'None'
});
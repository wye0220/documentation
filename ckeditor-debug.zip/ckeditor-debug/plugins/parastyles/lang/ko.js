CKEDITOR.plugins.setLang( 'parastyles', 'ko', {
	tooltip: '\uD3EC\uB9F7',
	paraTypes: '단락 유형',
	regions : '지역',
	none_Label : '없음'
});
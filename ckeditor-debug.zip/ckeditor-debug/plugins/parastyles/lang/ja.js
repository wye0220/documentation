CKEDITOR.plugins.setLang( 'parastyles', 'ja', {
	tooltip: '\u6BB5\u843D\u8A2D\u5B9A',
	paraTypes: '段落の種類',
	regions : '地域',
	none_Label : 'なし'
});
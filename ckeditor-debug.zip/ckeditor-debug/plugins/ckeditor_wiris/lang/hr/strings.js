var strings = new Array();
strings['cancel'] = 'Poništi';
strings['accept'] = 'U redu';
strings['manual'] = 'Priručnik';
strings['latex'] = 'LaTeX';
var strings = new Array();
strings['cancel'] = 'Avbryt';
strings['accept'] = 'OK';
strings['manual'] = 'Håndbok';
strings['latex'] = 'LaTeX';
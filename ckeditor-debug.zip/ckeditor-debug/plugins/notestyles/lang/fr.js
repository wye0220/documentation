﻿CKEDITOR.plugins.setLang( 'notestyles', 'fr', {
	label: 'Styles',
	panelTitle: 'Styles de mise en page',
	panelTitle2: 'Styles en ligne',
	inlineTypes: 'Types de balises'
});
﻿CKEDITOR.plugins.setLang( 'notestyles', 'ko', {
	label: '스타일',
	panelTitle: 'Formatting Styles', // MISSING
	panelTitle1: 'Inline Styles', // MISSING
	inlineTypes: '태그 유형'
});
﻿CKEDITOR.plugins.setLang( 'notestyles', 'en', {
	label: 'Styles',
	panelTitle: 'Formatting Styles',
	panelTitle1: 'Inline Styles',
	inlineTypes: 'Tag Types'
});
﻿CKEDITOR.plugins.setLang( 'notestyles', 'ja', {
	label: 'スタイル',
	panelTitle: 'スタイル',
	panelTitle1: 'インラインスタイル',
	inlineTypes: 'タグの種類'
});
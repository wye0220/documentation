﻿CKEDITOR.plugins.setLang( 'notestyles', 'de', {
	label: 'Stil',
	panelTitle: 'Formatierungenstil',
	panelTitle2: 'Inline Stilart',
	inlineTypes: 'Tag-Typen'
});
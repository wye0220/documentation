CKEDITOR.plugins.setLang( 'blockcomponent', 'ko', {
	editBlockComponent: '컴포넌트 편집',
	saveBlockComponent :'컴포넌트 저장',
	saveCloseBlockComponent :'컴포넌트 저장 후 닫기',
	discardChangesBlockComponent :'변경사항 무시'
});
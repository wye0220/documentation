CKEDITOR.plugins.setLang( 'blockcomponent', 'de', {
	editBlockComponent: 'Komponente bearbeiten',
	saveBlockComponent :'Komponente sichern',
	saveCloseBlockComponent :'Komponente sichern und schließen',
	discardChangesBlockComponent :'Änderungen verwerfen'
});
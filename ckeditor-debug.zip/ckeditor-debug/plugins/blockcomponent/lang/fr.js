CKEDITOR.plugins.setLang( 'blockcomponent', 'fr', {
	editBlockComponent: 'Modifier le composant',
	saveBlockComponent :'Enregistrer le composant',
	saveCloseBlockComponent :'Enregistrer et fermer le composant',
	discardChangesBlockComponent :'Abandonner les modifications'
});
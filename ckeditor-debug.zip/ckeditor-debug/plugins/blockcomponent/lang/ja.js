CKEDITOR.plugins.setLang( 'blockcomponent', 'ja', {
	editBlockComponent: 'コンポーネントの編集 ',
	saveBlockComponent :'コンポーネントの保存',
	saveCloseBlockComponent :'コンポーネントを保存して閉じる',
	discardChangesBlockComponent :'変更を破棄'
});
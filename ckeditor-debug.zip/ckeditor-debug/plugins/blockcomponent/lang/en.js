CKEDITOR.plugins.setLang( 'blockcomponent', 'en', {
	editBlockComponent: 'Edit Component',
	saveBlockComponent :'Save Component',
	saveCloseBlockComponent :'Save & Close Component',
	discardChangesBlockComponent :'Discard Changes'
});
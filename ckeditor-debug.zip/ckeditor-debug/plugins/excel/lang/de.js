CKEDITOR.plugins.setLang( 'excel', 'de', {
	insertTable: 'Tabelle einfügen',
	insertChart : 'Chart einfügen',
	insertExcelComponents: 'Microsoft Excel Komponenten einfügen',
	table : 'Bereich eingeben oder wählen',
	chart : 'Diagramm',
	browse : 'Blättern',
	assetName : 'Asset-Name',
	worksheet : 'Arbeitsblatt',
	preview : 'Voransicht',
	checkInAsNew : 'Auto upload to Server(de)',
	errorLabel :'Wählen Sie einen Wert',
	insertImage : 'Als Bild einfügen'
});
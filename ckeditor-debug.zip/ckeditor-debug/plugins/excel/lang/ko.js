CKEDITOR.plugins.setLang( 'excel', 'ko', {
	insertTable: '표 삽입',
	insertChart : '챠트를 삽입합니다',
	insertExcelComponents: 'Microsoft Excel 컴포넌트 삽입',
	table : '범위 입력 또는 선택',
	chart : '차트',
	browse : '\uCC3E\uC544\uBCF4\uAE30',
	assetName : '어셋 이름',
	worksheet : '워크시트',
	preview : '\uBBF8\uB9AC\uBCF4\uAE30',
	checkInAsNew : 'Auto upload to Server(ko)',
	errorLabel :'값 선택',
	insertImage : '이미지로 삽입'
});
CKEDITOR.plugins.setLang( 'excel', 'ja', {
	insertTable: '表の挿入',
	insertChart : 'チャートを挿入',
	insertExcelComponents: 'Microsoft Excelコンポーネントを挿入する',
	table : 'タイプまたは選択範囲',
	chart : 'チャート',
	browse : '\u53C2\u7167',
	assetName : 'アセット名',
	worksheet : 'ワークシート',
	preview : '\u30D7\u30EC\u30D3\u30E5\u30FC',
	checkInAsNew : 'サーバーへ自動的にアップロードする',
	errorLabel :'値の選択',
	insertImage : '画像として挿入'
});
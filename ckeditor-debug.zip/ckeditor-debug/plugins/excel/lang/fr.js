CKEDITOR.plugins.setLang( 'excel', 'fr', {
	insertTable: 'Insérer un tableau',
	insertChart : 'Insérer un diagramme',
	insertExcelComponents: 'Insérer des composants Microsoft Excel',
	table : 'Entrer ou sélectionner une série',
	chart : 'Graphique',
	browse : 'Parcourir',
	assetName : 'Nom d\'élément',
	worksheet : 'Feuille de calcul',
	preview : 'Prévisualisation',
	checkInAsNew : 'Chargement automatique sur le serveur ',
	errorLabel :'Sélectionner une valeur',
	insertImage : 'Insérer comme image'
});
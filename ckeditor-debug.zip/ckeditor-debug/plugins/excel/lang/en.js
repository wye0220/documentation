CKEDITOR.plugins.setLang( 'excel', 'en', {
	insertTable: 'Insert Table',
	insertChart : 'Insert Chart',
	insertExcelComponents: 'Insert Excel Components',
	table : 'Type or Select Range',
	chart : 'Chart',
	browse : 'Browse',
	assetName : 'Asset Name',
	worksheet : 'Worksheet',
	preview : 'Preview',
	checkInAsNew : 'Auto upload to Server',
	errorLabel :'Select a value',
	insertImage : 'Insert as Image'
});
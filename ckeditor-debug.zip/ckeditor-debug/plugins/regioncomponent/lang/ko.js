﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'regioncomponent', 'ko', {
	createRegionCmp :'지역 컴포넌트 생성',
	replaceFromServer :'서버에서 지역 대치',
	insertRegionFromServer :'서버에서 지역 삽입',
	defaultRegionText : '정규'
});
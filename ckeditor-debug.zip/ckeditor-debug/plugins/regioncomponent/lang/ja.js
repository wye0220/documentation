﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'regioncomponent', 'ja', {
	createRegionCmp :'リージョン・コンポーネントの作成',
	replaceFromServer :'サーバーからリージョンを置換',
	insertRegionFromServer :'サーバーからリージョンを挿入',
	defaultRegionText : '地域'
});
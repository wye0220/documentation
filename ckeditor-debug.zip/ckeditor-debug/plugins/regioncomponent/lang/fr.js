﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'regioncomponent', 'fr', {
	createRegionCmp :'Créer un composant Région',
	replaceFromServer :'Remplacer la région depuis le serveur',
	insertRegionFromServer :'Insérer une région depuis le serveur',
	defaultRegionText : 'Région'
});
CKEDITOR.plugins.setLang('wordcount', 'de', {
    wordCount: 'Wörter',
    charCount: 'Zeichen (mit Leerzeichen)',
    charCountWithoutSpace: 'Zeichen (ohne Leerzeichen)',
    title: 'Statistik'
});

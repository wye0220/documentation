CKEDITOR.plugins.setLang('wordcount', 'ko', {
    wordCount: '\uB2E8\uC5B4',
    charCount: '문자(공백 포함)',
    charCountWithoutSpace: '문자(공백 제외)',
    title: '\uD1B5\uACC4'
});

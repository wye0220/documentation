CKEDITOR.plugins.setLang('wordcount', 'ja', {
    wordCount: '\u5358\u8A9E\u6570',
    charCount: '文字数（スペースを含む）',
    charCountWithoutSpace: '文字数（スペースを含まない）',
    title: '\u7D71\u8A08'
});

CKEDITOR.plugins.setLang('wordcount', 'fr', {
    wordCount: 'Mots',
    charCount: 'Caractères (avec espaces)',
    charCountWithoutSpace: 'Caractères (sans espace)',
    title: 'Statistiques'
});

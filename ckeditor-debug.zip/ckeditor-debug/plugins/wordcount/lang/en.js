CKEDITOR.plugins.setLang('wordcount', 'en', {
    wordCount: 'Words',
    charCount: 'Characters (with spaces)',
    charCountWithoutSpace: 'Characters (no spaces)',
    title: 'Statistics'
});

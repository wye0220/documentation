CKEDITOR.plugins.setLang('localimage', 'fr', {
	errors : {
		invalidFile : "Ce type de fichier n'est pas pris en charge. S\u00E9lectionnez un fichier image valide."
	}
});
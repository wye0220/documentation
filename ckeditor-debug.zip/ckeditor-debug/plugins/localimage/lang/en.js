CKEDITOR.plugins.setLang( 'localimage', 'en', {
	errors:{		
		invalidFile:'This file type is not supported. Please select valid picture file.'
	}
});
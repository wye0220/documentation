CKEDITOR.plugins.setLang('localimage', 'de', {
	errors : {
		invalidFile : 'Dieser Dateityp wird nicht unterst\u00FCtzt. Bitte w\u00E4hlen Sie eine g\u00FCltige Bilddatei aus.'
	}
});
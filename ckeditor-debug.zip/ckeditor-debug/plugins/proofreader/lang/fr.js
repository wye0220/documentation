CKEDITOR.plugins.setLang( 'proofreader', 'fr', {
	checkSpellingLabel : 'Orthographe et grammaire',
	toggleSpellChecker :'Toggle Proofing Check',
	enableSpellCheck :'Activer la vérification orthographique et grammaticale',
	disableSpellCheck :'Désactiver la vérification orthographique et grammaticale',
	spellingError : 'Faute d’orthographe',
	grammarError : 'Erreur grammaticale',
	ignoreAll : 'Ignorer toujours',
	ignore : 'Ignorer',
	ignoreRule : 'Ignorer la règle',
	addWord : 'Ajouter un mot au dictionnaire',
	selectLanguage : 'Définir la langue de vérification'
});
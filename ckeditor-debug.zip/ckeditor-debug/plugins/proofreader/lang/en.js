﻿CKEDITOR.plugins.setLang( 'proofreader', 'en', {
	checkSpellingLabel : 'Spelling and Grammar',
	toggleSpellChecker :'Toggle Proofing Check',
	enableSpellCheck :'Enable Spelling and Grammar Check',
	disableSpellCheck :'Disable Spelling and Grammar Check',
	spellingError : 'Spelling Error',
	grammarError : 'Grammatical Error',
	ignoreAll : 'Ignore All',
	ignore : 'Ignore',
	ignoreRule : 'Ignore Rule',
	addWord : 'Add Word To Dictionary',
	selectLanguage : 'Set Proofing Language'
});
CKEDITOR.plugins.setLang( 'proofreader', 'ja', {
	checkSpellingLabel : 'スペルと文法',
	toggleSpellChecker :'Toggle Proofing Check',
	enableSpellCheck :'スペルおよび文法チェックを有効にする',
	disableSpellCheck :'スペルおよび文法チェックを無効にする',
	spellingError : 'スペルエラー',
	grammarError : '文法エラー	',
	ignoreAll : 'すべて無視',
	ignore : '無視',
	ignoreRule : 'このルールを無視する',
	addWord : '単語を辞書に追加',
	selectLanguage : 'プルーフ言語の設定'
});
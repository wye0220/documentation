CKEDITOR.plugins.setLang( 'proofreader', 'ko', {
	checkSpellingLabel : '철자 및 문법',
	toggleSpellChecker :'Toggle Proofing Check',
	enableSpellCheck :'철자 및 맞춤법 검사 활성화',
	disableSpellCheck :'철자 및 맞춤범 검사 비활성화',
	spellingError : '철자 오류',
	grammarError : '맞춤법 오류',
	ignoreAll : '모두 무시하기',
	ignore : '무시',
	ignoreRule : '규칙 무시',
	addWord : '사전에 단어 추가',
	selectLanguage : '교정 언어 지정'
});
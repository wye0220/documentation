CKEDITOR.plugins.setLang( 'proofreader', 'de', {
	checkSpellingLabel : 'Rechtschreibung und Grammatik',
	toggleSpellChecker :'Toggle Proofing Check',
	enableSpellCheck :'Rechtschreib- und Grammatikprüfung aktivieren',
	disableSpellCheck :'Rechtschreib- und Grammatikprüfung deaktivieren',
	spellingError : 'Rechtschreibfehler',
	grammarError : 'Grammatikfehler',
	ignoreAll : 'Alle ignorieren',
	ignore : 'Ignorieren',
	ignoreRule : 'Regel ignorieren',
	addWord : 'Zum Wörterbuch hinzufügen',
	selectLanguage : 'Sprache für Prüfung einstellen'
});
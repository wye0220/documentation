﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ko', {
	find: '찾기',
	findOptions: 'Find Options',
	findWhat: '찾을 문자열:',
	matchCase: '대소문자 구분',
	matchCyclic: 'Match cyclic',
	matchWord: '온전한 단어',
	notFoundMsg: '문자열을 찾을 수 없습니다.',
	replace: '바꾸기',
	replaceAll: '모두 바꾸기',
	replaceSuccessMsg: '%1 occurrence(s) replaced.',
	replaceWith: '바꿀 문자열:',
	title: '찾기 & 바꾸기',
	findNext : '다음 찾기',
	warning : '경고',
	readOnlyMsg: 'Read-only or deleted content can\'t be replaced'
});

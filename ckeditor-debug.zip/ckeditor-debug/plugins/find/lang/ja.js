﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ja', {
	find: '検索',
	findOptions: 'Find Options',
	findWhat: '検索する文字列:',
	matchCase: '大文字と小文字を区別する',
	matchCyclic: '一周する',
	matchWord: '単語単位で探す',
	notFoundMsg: '指定された文字列は見つかりませんでした。',
	replace: '置き換え',
	replaceAll: 'すべて置換え',
	replaceSuccessMsg: '%1 個置換しました。',
	replaceWith: '置換えする文字列:',
	title: '検索して置換',
	findNext : '検索',
	warning : '警告',
	readOnlyMsg: 'Read-only or deleted content can\'t be replaced'
});

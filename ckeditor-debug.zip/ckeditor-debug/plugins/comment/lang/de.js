CKEDITOR.plugins.setLang( 'comment', 'de', {
	tooltipAdd: 'Kommentar hinzufügen',
	tooltipRemove: 'Kommentar entfernen',
	tooltipShowAll : 'Alle Kommentare zeigen',
	tooltipHideAll : 'Alle Kommentare verbergen',
	tooltipShowNext : 'Nächsten Kommentar zeigen',
	tooltipShowPrevious : 'Vorherigen Kommentar zeigen'
});
CKEDITOR.plugins.setLang( 'comment', 'en', {
	tooltipAdd: 'Add Comment',
	tooltipRemove: 'Remove Comment',
	tooltipShowAll : 'Show All Comments',
	tooltipHideAll : 'Hide All Comments',
	tooltipShowNext : 'Show Next Comment',
	tooltipShowPrevious : 'Show Previous Comment'
});
CKEDITOR.plugins.setLang( 'comment', 'ja', {
	tooltipAdd: 'コメントの追加',
	tooltipRemove: 'コメントの削除',
	tooltipShowAll : 'すべてのコメントを表示します',
	tooltipHideAll : 'すべてのコメントを隠します',
	tooltipShowNext : '次のコメントを表示します',
	tooltipShowPrevious : '前のコメントを表示します'
});
CKEDITOR.plugins.setLang( 'comment', 'ko', {
	tooltipAdd: '주석 추가',
	tooltipRemove: '주석 제거',
	tooltipShowAll : '모든 주석 보기',
	tooltipHideAll : '모든 주석 숨기기',
	tooltipShowNext : '다음 주석 보기',
	tooltipShowPrevious : '이전 주석 보기'
});
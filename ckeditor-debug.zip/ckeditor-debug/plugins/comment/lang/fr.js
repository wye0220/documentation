CKEDITOR.plugins.setLang( 'comment', 'fr', {
	tooltipAdd: 'Ajouter un commentaire',
	tooltipRemove: 'Supprimer un commentaire',
	tooltipShowAll : 'Afficher tous les commentaires',
	tooltipHideAll : 'Masquer tous les commentaires',
	tooltipShowNext : 'Afficher le commentaire suivant',
	tooltipShowPrevious : 'Afficher le commentaire précédent'
});
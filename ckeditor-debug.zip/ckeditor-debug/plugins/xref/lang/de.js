CKEDITOR.plugins.setLang('xref', 'de', {
	insertCrossReference: 'Querverweis einfügen',
	updateCrossReference : 'Querverweis synchronisieren',
	updateAllCrossReference : 'Alle Querverweise synchronisieren',
	confirmUpdateCrossReferenceMsg : 'Der Text eines oder mehrerer Querverweise(s) wurden von dem oder den Anwender(n) geändert, sodass der Text nicht mehr mit dem Zielelement synchronisiert wird. Möchten Sie diese(n) Querverweis(e) auch synchronisieren?',
	editXref:"Querverweis bearbeiten",
	editLink:"Link bearbeiten",
	dialog:{
		title: 'Querverweis einfügen',
		editTitle:"Querverweis bearbeiten",
		referenceType : 'Verweistyp',
		referenceToLink : 'Wählen Sie den zu verlinkenden Verweis:',
		OK : 'OK',
		Cancel :'Abbrechen',
		error : 'Fehler',
		noTargetElement : 'Es ist kein Zielelement ausgewählt.',
		noTable: 'Dieser Abschnitt enthält keine Tabellen.',
		noFigure : 'Dieser Abschnitt enthält keine Abbildungen.',
		section: 'Abschnitt',
		table: 'Tabelle',
		figure: 'Abbildung',
		noRegion : 'Dieser Abschnitt enthält keine Bereiche des ausgewählten Typs'
	}
});
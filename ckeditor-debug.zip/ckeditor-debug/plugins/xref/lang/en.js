CKEDITOR.plugins.setLang( 'xref', 'en', {
	insertCrossReference: 'Insert Cross Reference',
	updateCrossReference : 'Synchronize Cross Reference',
	updateAllCrossReference : 'Synchronize All Cross References',
	confirmUpdateCrossReferenceMsg : 'The text of one or more cross references has been changed by the user(s), so that the text is no longer synchronized with the target element. Do you want to synchronize those cross reference(s) also?',
	editXref:"Edit Cross Reference",
	editLink:"Edit Link",
	dialog:{
		title: 'Insert Cross Reference',
		editTitle:"Edit Cross Reference",
		referenceType : 'Reference Type',
		referenceToLink : 'Select the reference to link:',
		OK : 'OK',
		Cancel :'Cancel',
		error : 'Error',
		noTargetElement : 'No target element is selected.',
		noTable : 'This section does not contain any tables.',
		noFigure : 'This section does not contain any figures.',
		section: 'Section',
		table: 'Table',
		figure: 'Figure',
		noRegion : 'This section does not contain any regions of selected type'
	}
});
CKEDITOR.plugins.setLang( 'xref', 'ja', {
	insertCrossReference: 'クロス参照の挿入',
	updateCrossReference : '相互参照を同期',
	updateAllCrossReference : 'すべての相互参照を同期',
	confirmUpdateCrossReferenceMsg : 'ユーザーにより相互参照のテキストが変更されたため、テキストはターゲット要素と同期されません。変更された相互参照も同期しますか？',
	editXref:"クロス参照の編集",
	editLink:"リンクを編集",
	dialog:{
		title: 'クロス参照の挿入',
		editTitle:"クロス参照の編集",
		referenceType : '参照タイプ',
		referenceToLink : 'リンクする参照を選択:',
		OK : 'OK',
		Cancel :'キャンセル',
		error : 'エラー',
		noTargetElement : '対象の要素が選択されていません。',
		noTable: 'このコレクションにはテーブルが含まれていません',
		noFigure: 'このコレクションには図が含まれていません。',
		section: 'セクション',
		table: 'テーブル',
		figure: '図',
		noRegion : 'このセクションには、選択したタイプの地域が含まれていません'
	}
});
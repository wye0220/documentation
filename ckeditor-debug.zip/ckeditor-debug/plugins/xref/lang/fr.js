CKEDITOR.plugins.setLang( 'xref', 'fr', {
	insertCrossReference: 'Insérer un renvoi',
	updateCrossReference : 'Synchroniser le renvoi',
	updateAllCrossReference : 'Synchroniser tous les renvois',
	confirmUpdateCrossReferenceMsg : 'Le texte d\'un renvoi au moins a été modifié par les utilisateurs, il n\'est donc plus synchronisé avec l\'élément cible. Voulez-vous également synchroniser ces renvois?',
	editXref:"Modifier le renvoi",
	editLink:"Modifier le lien",
	dialog:{
		title: 'Insérer un renvoi',
		editTitle:"Modifier le renvoi",
		referenceType : 'Type de référence',
		referenceToLink : 'Sélectionner la référence à lier:',
		OK : 'OK',
		Cancel :'Annuler',
		error : 'Erreur',
		noTargetElement : 'Aucun élément cible sélectionné.',
		noTable: 'Cette section ne contient aucune table.',
		noFigure: 'Cette section ne contient aucune figure.',
		section: 'Section',
		table: 'Tableau',
		figure: 'Figure',
		noRegion : 'Cette section ne contient aucune région du type sélectionné.'
	}
});
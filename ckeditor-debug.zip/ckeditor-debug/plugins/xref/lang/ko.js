CKEDITOR.plugins.setLang( 'xref', 'ko', {
	insertCrossReference: '교차 참조 삽입',
	updateCrossReference : '교차 참조 동기화',
	updateAllCrossReference : '모든 교차 참조 동기화',
	confirmUpdateCrossReferenceMsg : '사용자가 하나 이상의 교차 참조 텍스트를 변경했기 때문에 텍스트가 더 이상 대상 요소와 동기화되지 않습니다. 해당 교차 참조도 동기화하시겠습니까?',
	editXref:"교차 참조 편집",
	editLink:"링크 편집",
	dialog:{
		title: '교차 참조 삽입',
		editTitle:"링크 편집",
		referenceType : '참조 유형',
		referenceToLink : '링크에 대한 참조 선택:',
		OK : '양호',
		Cancel :'취소',
		error : '오류',
		noTargetElement : '선택된 대상 요소가 없습니다.',
		noTable: '이 섹션은 표를 포함하지 않습니다.',
		noFigure: '이 섹션은 그림을 포함하지 않습니다.',
		section: '절 번호 지정',
		table: '표',
		figure: '숫자',
		noRegion : '이 섹션에는 선택한 유형의 지역이 없습니다.'
	}
});
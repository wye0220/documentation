﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'region', 'ko', {
	regionsLabel : "지역 유형",
	insertRegion :"지역 삽입 ",
	defaultRegion :'정규'
});

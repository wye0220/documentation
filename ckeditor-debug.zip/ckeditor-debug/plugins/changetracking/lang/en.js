CKEDITOR.plugins.setLang( 'changetracking', 'en', {
	tracking: 'Track Changes',
	highlighting:'Highlight Changes',
    accept:'Accept',
    reject:'Reject',
    acceptChange:'Accept Change',
    rejectChange:'Reject Change',
    acceptAndMove:'Accept and Move to Next',
    rejectAndMove:'Reject and Move to Next',
    acceptAllChanges:'Accept all Changes in Document',
    rejectAllChanges:'Reject all Changes in Document',
    nextChange : 'Show Next Change',
    previousChange : 'Show Previous Change'
});
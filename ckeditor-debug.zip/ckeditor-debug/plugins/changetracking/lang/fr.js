CKEDITOR.plugins.setLang( 'changetracking', 'fr', {
	tracking: 'Suivi des modifications',
	highlighting:'Mettre en évidence les modifications',
    accept:'Accepter',
    reject:'Refuser',
    acceptChange:'Accepter modification',
    rejectChange:'Refuser modification',
    acceptAndMove:'Accepter et passer au suivant',
    rejectAndMove:'Refuser et passer au suivantt',
    acceptAllChanges:'Accepter toutes les modifications dans le document',
    rejectAllChanges:'Refuser toutes les modifications dans le document',
    nextChange : 'Suivante',
    previousChange : 'Précédente'
});
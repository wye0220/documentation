CKEDITOR.plugins.setLang( 'changetracking', 'de', {
	tracking: 'Änderungen nachverfolgen',
	highlighting:'Änderungen hervorheben',
    accept:'Akzeptieren',
    reject:'Ablehnen',
    acceptChange:'Änderung akzeptieren',
    rejectChange:'Änderung ablehnen',
    acceptAndMove:'Annehmen und weiter zur nächsten',
    rejectAndMove:'Zurückweisen und weiter zur nächsten',
    acceptAllChanges:'Alle Änderungen im Dokument annehmen',
    rejectAllChanges:'Alle Änderungen im Dokument zurückweisen',
    nextChange : 'Nächste',
    previousChange : 'Vorherige'
});
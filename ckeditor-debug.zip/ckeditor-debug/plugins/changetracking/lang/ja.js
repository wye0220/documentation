CKEDITOR.plugins.setLang( 'changetracking', 'ja', {
	tracking: '変更履歴の記録',
	highlighting:'変更をハイライトする',
    accept:'\u540C\u610F\u3059\u308B',
    reject:'\u62D2\u5426',
    acceptChange:'\u5909\u66F4\u5185\u5BB9\u306B\u540C\u610F\u3059\u308B',
    rejectChange:'\u5909\u66F4\u5185\u5BB9\u3092\u62D2\u5426\u3059\u308B',
    acceptAndMove:'承諾して次へ進む',
    rejectAndMove:'拒否して次へ進む',
    acceptAllChanges:'\u6587\u66F8\u5185\u306E\u3059\u3079\u3066\u306E\u5909\u66F4\u306E\u627F\u8AFE',
    rejectAllChanges:'\u6587\u66F8\u5185\u306E\u3059\u3079\u3066\u306E\u5909\u66F4\u306E\u62D2\u5426',
    nextChange : '次へ',
    previousChange : '前ページへ'
});
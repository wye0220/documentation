CKEDITOR.plugins.setLang( 'changetracking', 'ko', {
	tracking: '\uCD94\uC801',
	highlighting:'변경 하이라이트',
    accept:'\uB3D9\uC758',
    reject:'\uAC70\uBD80',
    acceptChange:'\uBCC0\uACBD \uC2B9\uC778',
    rejectChange:'\uBCC0\uACBD \uAC70\uBD80',
    acceptAndMove:'승인하고 다음으로 이동',
    rejectAndMove:'거부하고 다음으로 이동',
    acceptAllChanges:'도큐멘트 전체 변경 승인',
    rejectAllChanges:'도큐멘트 전체 변경 거부',
    nextChange : '다음',
    previousChange : '이전'
});
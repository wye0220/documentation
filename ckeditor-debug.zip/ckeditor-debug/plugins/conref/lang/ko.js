CKEDITOR.plugins.setLang( 'conref', 'ko', {
	errorMessage: '컴포넌트 참조를 로드하는데 실패했습니다. : {0}',
	moreDetailsMessage : 'Click <u>here</u> to view more details.(ko)',
	refresh : '\uC0C8\uB85C \uACE0\uCE68',
	convertreference : '참조를 로컬 컨텐츠로 변환',
	pinreference : '컴포넌트 참조 고정',
	unpinreference : '컴포넌트 참조 고정 해제',
	removereference : '컴포넌트 참조 제거',
	deletereference :'삭제',
	loading : '로딩중...',
	deleteRegion : '지역 삭제'
});
CKEDITOR.plugins.setLang( 'conref', 'fr', {
	errorMessage: 'Echec du chargement de la référence de composant: {0}',
	moreDetailsMessage : 'Click <u>here</u> to view more details.(fr)',
	refresh : 'Rafraîchir',
	convertreference : 'Convertir la référence en contenu local',
	pinreference : 'Epingler la référence de composant',
	unpinreference : 'Détacher la référence de composant',
	removereference : 'Supprimer la référence de composant',
	deletereference :'Supprimer',
	loading : 'Chargement...',
	deleteRegion : 'Supprimer la région'
});
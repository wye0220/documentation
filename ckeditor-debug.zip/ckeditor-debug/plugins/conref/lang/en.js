CKEDITOR.plugins.setLang( 'conref', 'en', {
	errorMessage: 'Failed to load Component Reference: {0}',
	moreDetailsMessage : 'Click <u>here</u> to view more details.',
	refresh : 'Refresh',
	convertreference : 'Convert reference to local content',
	pinreference : 'Pin Component Reference',
	unpinreference : 'Unpin Component Reference',
	removereference : 'Remove Component Reference',
	deletereference :'Delete',
	loading : 'Loading...',
	deleteRegion : 'Delete Region'
});
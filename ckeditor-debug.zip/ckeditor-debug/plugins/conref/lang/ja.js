CKEDITOR.plugins.setLang( 'conref', 'ja', {
	errorMessage: 'コンポーネント参照の読み込みに失敗しました: {0}',
	moreDetailsMessage : 'Click <u>here</u> to view more details.(ja)',
	refresh : '\u30EA\u30D5\u30EC\u30C3\u30B7\u30E5',
	convertreference : '参照をローカルコンテンツに変換する',
	pinreference : '\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u306E\u53C2\u7167\u3092\u56FA\u5B9A',
	unpinreference : '\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u306E\u53C2\u7167\u306E\u56FA\u5B9A\u3092\u89E3\u9664',
	removereference : '\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u306E\u53C2\u7167\u3092\u524A\u9664',
	deletereference :'削除',
	loading : '読み込み中...',
	deleteRegion : 'リージョンの削除'
});
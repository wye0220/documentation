CKEDITOR.plugins.setLang('conref', 'de', {
	errorMessage : 'Fehler beim Laden der Komponentenreferenz: {0}',
	moreDetailsMessage : 'Click <u>here</u> to view more details.(de)',
	refresh : 'Aktualisieren',
	convertreference : 'Referenz zu lokalem Inhalt konvertieren',
	pinreference : 'Komponentenverweis anheften',
	unpinreference : 'Komponentenverweis abtrennen',
	removereference : 'Komponentenverweis entfernen',
	deletereference :'Löschen',
	loading : 'Laden...',
	deleteRegion : 'Bereich löschen'
});
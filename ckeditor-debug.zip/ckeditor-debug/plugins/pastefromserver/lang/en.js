CKEDITOR.plugins.setLang( 'pastefromserver', 'en', {
	pasteFromServer : 'Paste from Server',
	preview:'Preview'
});
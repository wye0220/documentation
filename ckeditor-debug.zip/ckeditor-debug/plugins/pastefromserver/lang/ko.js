CKEDITOR.plugins.setLang( 'pastefromserver', 'ko', {
	pasteFromServer : '서버에서 붙여넣기',
	preview:'미리보기'
});
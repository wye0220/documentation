CKEDITOR.plugins.setLang( 'pastefromserver', 'de', {
	pasteFromServer : 'Von Server einsetzen',
	preview:'Voransicht'
});
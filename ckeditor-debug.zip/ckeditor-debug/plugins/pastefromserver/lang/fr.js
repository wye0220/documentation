CKEDITOR.plugins.setLang( 'pastefromserver', 'fr', {
	pasteFromServer : 'Coller à partir du serveur',
	preview:'Prévisualisation'
});
CKEDITOR.plugins.setLang( 'pastefromserver', 'ja', {
	pasteFromServer : 'サーバーからペースト',
	preview:'プレビュー'
});
CKEDITOR.plugins.setLang( 'tablecomponent', 'de', {
	replaceTableComponent : 'Tabelle vom Server ersetzen',
	createTableCmp : 'Tabellenkomponente erstellen',
	insertTableFromServer: 'Tabelle vom Server einfügen',
	defaultTableText : 'Normal'
});
CKEDITOR.plugins.setLang( 'tablecomponent', 'ja', {

	replaceTableComponent : 'サーバーから表を置換',
	createTableCmp : '表コンポーネントを作成',
	insertTableFromServer: 'サーバーからテーブルを挿入する',
	defaultTableText : '標準'
});
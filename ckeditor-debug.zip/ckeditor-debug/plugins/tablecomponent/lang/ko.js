CKEDITOR.plugins.setLang( 'tablecomponent', 'ko', {

	replaceTableComponent : '서버에서 표 대치 ',
	createTableCmp : '표 컴포넌트 생성 ',
	insertTableFromServer: '서버에서 표 삽입',
	defaultTableText : '일반'
});
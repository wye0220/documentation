CKEDITOR.plugins.setLang( 'tablecomponent', 'fr', {

	replaceTableComponent : 'Remplacer le tableau depuis le serveur',
	createTableCmp : 'Créer un composant Tableau',
	insertTableFromServer: 'Insérer un tableau depuis le serveur',
	defaultTableText : 'Normal'
});
CKEDITOR.plugins.setLang( 'tablecomponent', 'en', {
	replaceTableComponent : 'Replace Table from Server',
	createTableCmp : 'Create Table Component',
	insertTableFromServer: 'Insert Table from Server',
	defaultTableText : 'Normal'
});
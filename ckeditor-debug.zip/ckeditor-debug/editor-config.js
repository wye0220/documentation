/*
Copyright (c) 2003-2010, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{	
	/** BEGIN - DO NOT EDIT THIS SECTION **/
	config.enterMode = CKEDITOR.ENTER_DIV;
	config.shiftEnterMode = CKEDITOR.ENTER_DIV;
	config.fullPage = false;
	config.defaultLanguage = "en";
	config.dialog_buttonsOrder = 'ltr';
	//do not filter content
	config.allowedContent = true;
	config.pasteFilter = null;
	config.removePlugins = 'elementspath,forms,magicline,image,div,showborders,tabletools,tab';
	config.disableObjectResizing = false;
	config.toolbarCanCollapse = false;
	config.resize_enabled = false;
	config.coreStyles_bold = { element : 'b', overrides : 'strong' };
	config.coreStyles_italic = { element : 'i', overrides : 'em' };
	config.coreStyles_strike = { element: 'strike', overrides: 's' };
	config.undoStackSize = 50;
	
	config.customConfig = QXmlEditorEx.getEditorConfigFilePath();
	config.contentsCss = [CKEDITOR.basePath+'contents.css', QXmlEditorUtils.getEditorBasePath()+'/config/'+QXmlEditorEx.getContentType()+'/editor-content.css'];
	/** END - DO NOT EDIT THIS SECTION **/
	config.keystrokes = [
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.B, 'bold' ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.I, 'italic' ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.U, 'underline' ],
	                     [ CKEDITOR.CTRL + 13, QXmlEditorConstants.commands.INSERT_PARA_AFTER_REGION ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.F, QXmlEditorConstants.commands.FIND ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.H, QXmlEditorConstants.commands.REPLACE ],   
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.L, QXmlEditorConstants.commands.INSERT_LINK],   
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.T, QXmlEditorConstants.commands.INSERT_TABLE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.U, QXmlEditorConstants.commands.BULLETED_LIST ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.O, QXmlEditorConstants.commands.NUMBERED_LIST ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.C, QXmlEditorConstants.commands.ADD_COMMENT],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.I ,QXmlEditorConstants.commands.INSERT_IMAGE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.K ,QXmlEditorConstants.commands.LOCAL_IMAGE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.G, QXmlEditorConstants.commands.INSERT_FIGURE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.E, QXmlEditorConstants.commands.ENABLE_TRACKING ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.A, QXmlEditorConstants.commands.ACCEPT_CHANGE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.R, QXmlEditorConstants.commands.REJECT_CHANGE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.V, QXmlEditorConstants.commands.INSERT_VIDEO ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.N, QXmlEditorConstants.commands.APPLY_NORMAL_INLINE_STYLE ],
	                     [ CKEDITOR.ALT + CKEDITOR.SHIFT + QXmlEditorConstants.keys.Q, QXmlEditorConstants.commands.INSERT_EQUATION ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.TWO, QXmlEditorConstants.commands.OPEN_INLINE_STYLE_COMBO ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.ONE, QXmlEditorConstants.commands.OPEN_PARA_STYLE_COMBO ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.S, QXmlEditorConstants.commands.SAVE_REVISION ],
	                     [ CKEDITOR.CTRL + CKEDITOR.SHIFT + QXmlEditorConstants.keys.S, QXmlEditorConstants.commands.SAVE_AND_CLOSE ],
	                     [ CKEDITOR.CTRL + CKEDITOR.ALT + QXmlEditorConstants.keys.Q, QXmlEditorConstants.commands.ABORT_DOCUMENT ],
	                     [ CKEDITOR.CTRL + QXmlEditorConstants.keys.Q, QXmlEditorConstants.commands.CLOSE_DOCUMENT ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.RIGHT_ARROW, QXmlEditorConstants.commands.SELECT_NEXT_RIGHT_TAB_PANE ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.LEFT_ARROW, QXmlEditorConstants.commands.SELECT_PREVIOUS_RIGHT_TAB_PANE ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.RIGHT_ANGULAR, QXmlEditorConstants.commands.SELECT_NEXT_LEFT_TAB_PANE ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.LEFT_ANGULAR, QXmlEditorConstants.commands.SELECT_PREVIOUS_LEFT_TAB_PANE ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.RIGHT_BRACKET, QXmlEditorConstants.commands.SELECT_NEXT_EDITOR_TAB],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.LEFT_BRACKET, QXmlEditorConstants.commands.SELECT_PREVIOUS_EDITOR_TAB ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.H, QXmlEditorConstants.commands.SELECT_EDITOR_HOME_TAB ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.I,QXmlEditorConstants.commands.SELECT_EDITOR_INSERT_TAB ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.R, QXmlEditorConstants.commands.SELECT_EDITOR_REVIEW_TAB ],
	                     [ CKEDITOR.ALT + QXmlEditorConstants.keys.E, QXmlEditorConstants.commands.SELECT_EDITOR_REFERENCES_TAB ],
	                     [ CKEDITOR.CTRL + CKEDITOR.SHIFT + QXmlEditorConstants.keys.V, QXmlEditorConstants.commands.PASTE_FROM_SERVER ]
	                 ];
	config.tracking_useDynamicColors = true; //Use automatic colors to tracked content similar to Word
	config.tracking_autoStartup = false; //enable tracking on startup
	config.tracking_defaultInsertionColor = "#0000FF"; //default insertion color of logged in user when tracking_useDynamicColors is true
	config.tracking_defaultDeletionColor = "#FF0000"; //default deletion color of logged in user when tracking_useDynamicColors is true
	// Default list of dynamic colors. Modify as per requirement
	config.tracking_dynamicColors = [ '#996600', '#83CEFF', '#00A600', '#CC0099', '#E68A00', '#AD85FF', '#62A382', '#B26B47', '#00CCA3', '#7ACC29', '#008F6B', '#706680',
		   				'#660066', '#B28F8F', '#FF99CC', '#990000', '#751975', '#006B6B', '#85C2A3', '#99B2FF' ];

	/* SpellCheck plugin related configuration*/
	//config.proofreader_defaultLanguage = 'en-US';
	config.proofreader_autoStartup = true;
	config.proofreader_serviceContextPath = '/proofreader';
	config.proofreader_maxSuggestionCount = 7;
	/* Tokenization related configuration*/
	config.tokenizer_chunkSize = 10; // The number of paragraphs that are processed and grouped in the event data
	config.tokenizer_waitTime = 3000; // Time in milliseconds after last changes in canvas before processing a block
	
	config.extraPlugins = 'proofreader,ckeditor_wiris,customtab,customformat,calstabletools,find,wordcount,scayt,imagepicker,localimage,imageresizer,viewxml,parastyles,figure,calstable,tableresize,excel,domchange,conref,comment,changetracking,inlinestyles,video,note,xref,docx,region,tablecomponent,regioncomponent,blockcomponent,pastefromserver,specialchar';
	
	//Toolbar is shown as flat by using only separator feature. We are not using group feature and below grouping is done to realign toolbar correctly when ckeditor gets resized.
	config.toolbar_XmlEditor = [['ParaCombo'], [ 'InlineStyles'], [ 'Bold', 'Italic', 'Underline'], [ 'Strike', 'Subscript', 'Superscript', '-',
	                             'BulletedList'], [ 'NumberedList', 'Outdent', 'Indent', '-', 'figure'], [ 'imagepicker','video', 'calstable','datatable'], [ 'Excel','insert-ppt','insert-visio',
	                             'SpecialChar','-','Link', 'xref','updatexref'], ['viewxml', '-', 'refresh', '-', 'Undo', 'Redo'], [  'addComment',
	                             'deleteComment', '-', 'Tracking', 'Highlighting', 'Accept', 'Reject','NextChange','PreviousChange', '-', 'Find'],[ 'Replace','Scayt'],['FootNote', 'EndNote'],['ckeditor_wiris_formulaEditor'], ['Spellcheck']];
	config.showDefaultCopyMenuOptions = false;
	//List of commands that support non continuous selection on table cells
	config.multiSelect_Commands = ['bold','italic','underline', 'strike', 'superscript', 'subscript'];
	
	/**
	 * 	Specifies list of note types that are supported and displayed in editor. The type value specifies the type of note. 
	 * 	
	 */
	config.note_supportedTypes = [{
		                    	  type :'footnote',
		                    	  displayName :'Footnote'
		                      }, {
		                    	  type :'endnote',
		                    	  displayName :'Endnote'
		                      }];
	
	//Expression value for displaying text context for cross reference	
	config.referred_criteria = [{ 	
									target_type: 'section',
									expressions: [{
													selector :'title'
												}],
									default_text: 'Section Reference'
								}, {
									target_type: 'table',
									expressions: [{
													selector :'title'
												}, {
													selector :'desc'
												},{
													selector :'p[@type = table-title]'
												},{
													selector :'p[@type = table-desc]'
												}],
									default_text: 'Table Reference'
								}, {

									target_type: 'figure',
									expressions: [{
													selector :'p'
												}],
									default_text: 'Figure Reference'
								}, {

									target_type : 'defaultRegionType',
									expressions : [ {
										selector : 'p[1]',
										maxCharacters : 32
									} ],
									default_text : 'Reference'
								}, {

									target_type : 'box',
									expressions : [ {
										selector : 'p[1]',
										maxCharacters : 32
									} ],
									default_text : 'Box Reference'
								}, {

									target_type : 'callout',
									expressions : [ {
										selector : 'p[1]',
										maxCharacters : 32
									} ],
									default_text : 'Callout Reference'
								}];
	/*
	 * // Create button(s) to apply a custom (preformat) style config.customformats = [ { buttonName: 'btn.preformat',
	 * styleName: 'preformat', buttonLabel: 'Preserve Extra Spaces', formatName: 'preformat', icon:
	 * CKEDITOR.plugins.getPath('customformat') + 'preformat-icon.png' } ];
	 */
};
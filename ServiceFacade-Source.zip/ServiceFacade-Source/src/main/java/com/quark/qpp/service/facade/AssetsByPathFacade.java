/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetAlreadyCheckedOutException;
import com.quark.qpp.core.asset.service.exceptions.AssetCheckedOutByAnotherUserException;
import com.quark.qpp.core.asset.service.exceptions.AssetLockedException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotCheckedOutException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotLockedException;
import com.quark.qpp.core.asset.service.exceptions.CannotDeleteAttachedComponentException;
import com.quark.qpp.core.asset.service.exceptions.ContextRollbackException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetRelationException;
import com.quark.qpp.core.asset.service.exceptions.InvalidComponentException;
import com.quark.qpp.core.asset.service.exceptions.InvalidLayoutException;
import com.quark.qpp.core.asset.service.exceptions.InvalidRenditionException;
import com.quark.qpp.core.asset.service.exceptions.MinorVersionNotSupportedException;
import com.quark.qpp.core.asset.service.exceptions.RenditionNotFoundException;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.query.service.constants.QueryConstants;
import com.quark.qpp.core.query.service.dto.CollectionElement;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.StringAttributeCondition;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.relation.service.constants.DefaultRelationTypes;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryException;
import com.quark.qpp.core.storage.service.exceptions.InvalidResourceException;
import com.quark.qpp.core.storage.service.exceptions.InvalidStorageContextException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.storage.service.exceptions.StorageRuleNotFoundException;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;
import com.quark.qpp.rest.framework.annotations.WebResourcePathParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.ArticleComponentInfoList;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AssetRelationInfo;
import com.quark.qpp.service.xmlBinding.AssetRelationInfoList;
import com.quark.qpp.service.xmlBinding.AssetRenditionInfoList;
import com.quark.qpp.service.xmlBinding.AssetVersionList;
import com.quark.qpp.service.xmlBinding.AttributeValue;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.NameIdList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.textindexing.adapter.exceptions.TextIndexingException;

/**
 * Handles all operations regarding metadata of the the assets belonging to content type
 * {@link DefaultContentTypes#ASSET} or any of it descendants.
 * <p>
 * Asset's metadata in terms of AttributeValues can be inserted, deleted, or updated. AttributeValues of a particular
 * asset can be modified. It also provides for APIs for (new)check-in/check-out, create/update relations of an asset,
 * get asset renditions/relations.
 * </p>
 * 
 */

@Controller(value = "assetsByPathFacade")
@RequestMapping("/assetsbypath/**")
public class AssetsByPathFacade {

	private static final String PATH_IDENTIFIER = "assetsbypath";
	
	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private QueryService queryService;
	
	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	/**
	 * Returns the metadata of all the versions of the given asset.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose versions are required. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers
	 *            to the unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @return AssetInfoList where each AssetInfo object contains assetId, assetVersion and AttributeValuesList for each
	 *         version of the asset.
	 * @throws AssetNotFoundException
	 *             If no asset with the given id exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=allversions")
	@WebReturnType(value = "xmlView")
	public AssetInfoList getAssetAllVersions(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath) throws AssetNotFoundException, QppServiceException {
		long assetId =  facadeUtility.getAssetId(assetPath);
		return assetFacade.getAssetAllVersions(assetId);
	}

	/**
	 * Returns all version numbers of the asset.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose version numbers are required. The assetPath is a string containing collection path
	 *            followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to that
	 *            unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @return AssetVersionList specifying all available major and minor version combinations of the required asset.
	 * @throws AssetNotFoundException
	 *             If no asset with the given id exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=listversions")
	@WebReturnType(value = "xmlView")
	public AssetVersionList getAssetVersionNumbers(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath) throws AssetNotFoundException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAssetVersionNumbers(assetId);
	}

	

	/**
	 * Returns <code>AssetRenditionInfoList</code> object where each <code>AssetRenditionInfo</code> object represent information of each
	 * page of the given rendition. Number of elements in the list will be same as the number of pages that exists for the given rendition.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose metadata is sought.The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset
	 *            in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the asset whose rendition info is required.
	 * @param minorVersion
	 *            minor version of the asset whose rendition info is required.
	 * @param renditionType
	 *            Rendition type id or name whose rendition info is required.
	 * @return <code>AssetRenditionInfoList</code> objects where each <code>AssetRenditionInfo</code> object represents information of each
	 *         page of the given rendition. Includes rendition details of pages (of all layouts for PROJECT assets) which have been
	 *         generated for asset with input ID and version. The number of pages for which information is available may be limited by the
	 *         FilterService that processed Indexing of the asset. If there exists no available rendition of requested type, for the given
	 *         asset then array returned will be blank.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id or version exists.
	 * @throws InvalidRenditionException
	 *             If there exist no such rendition type.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=renditioninfo")
	@WebReturnType(value = "xmlView")
	public AssetRenditionInfoList getAssetRenditionsInfo(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "rendition", required = false) String renditionType) throws AssetNotFoundException,
			InvalidRenditionException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAssetRenditionsInfo(assetId, majorVersion, minorVersion, renditionType);
	}

	/**
	 * Returns the rendition types available for the given asset version. In case the major and minor version are null, then the latest
	 * version of asset will be considered.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose available rendition types are required. The assetPath is a string containing collection
	 *            path followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to
	 *            that unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the asset whose available rendition types are required.
	 * @param minorVersion
	 *            minor version of the asset whose available rendition types are required.
	 * @return NameIdList of rendition types that exist for the given asset. Returns empty list if there is no rendition for the given
	 *         asset.
	 * @throws AssetNotFoundException
	 *             If no asset with the given id and version exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=listrenditiontypes")
	@WebReturnType(value = "xmlView")
	public NameIdList getAvailableRenditions(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion) throws AssetNotFoundException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAvailableRenditions(assetId, majorVersion, minorVersion);
	}

	
	/**
	 * Returns the metadata of the given asset version as AssetInfo OR writes asset's content/rendition to the given HTTP
	 * Response outputstream depending on the supplied parameters. <br/>
	 * In order to fetch specific attributes, specify attribute names in
	 * attributes array.IncludeChildren boolean flag,if true implies return those asset relations with given asset as parent.IncludeParents
	 * boolean flag,if true implies return those asset relations with given asset as child. If the major and minor versions are not
	 * specified then it will return metadata of the latest asset version.In case you want to fetch asset rendition, specify the rendition
	 * type name and an outputStream onto which the rendition has to be written.Draft boolean flag if true, writes the draft copy of the content  
	 * to the given outputstream. In case the draft doesn't exists, last saved content of the asset will be written to the outputstream. 
	 * To fetch draft attribute values, specify boolean flag draft as true & specify attribute ids/names that
	 * are to be fetched in attributes array.
	 * For an asset draft, following attribute values can only be sought : 
	 * <ol> <li>{@link DefaultAttributes#FILE_PATH}</li>
	 * <li>{@link DefaultAttributes#FILE_SIZE}</li>
	 * <li>{@link DefaultAttributes#LAST_MODIFIED}</li>
	 * </ol> 
	 * This method is intended for invocation over HTTP only.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose metadata is sought. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset
	 *            in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            Major Version of the asset.
	 * @param minorVersion
	 *            Minor version of the asset.
	 * @param attributes
	 *            Array of attribute names or id's to be fetched for given asset
	 * @param includeChildren
	 *            A boolean flag,if true implies return those asset relations with given asset as parent.
	 * @param includeParents
	 *            A boolean flag,if true implies return those asset relations with given asset as child.
	 * @param relationTypes
	 *            Array of relation types to be retrieved. The array can contain relation type id or name.
	 * @param renditionType
	 *            Name or id of the rendition type to be fetched.
	 * @param layoutNumber
	 *            Specific layout to be retrieved in context to a rendition.
	 * @param pageNumber
	 *            Specific page to be retrieved in context to a rendition.
	 * @param draft
	 *            if true, draft copy of the content will be written to the http response. In case the draft doesn't exist, last saved
	 *            content of the asset will be written to the http response. To fetch draft attribute values, specify boolean flag
	 * 			  draft as true & specify attribute ids/names that are to be fetched in attributes array.
	 * @param httpResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in respose. Set to "attachment" if downloading of
	 *            asset/rendition is required.
	 * @return AssetInfo object of the given asset.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.Additonal info will refer to the exact cause of this exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 * 
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType(value = "xmlView")
	public AssetInfo getAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, 
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, 
			@WebArrayParam("attributes") String[] attributes,
			@RequestParam(value = "includechildren", defaultValue = "false") boolean includeChildren,
			@RequestParam(value = "includeparents", defaultValue = "false") boolean includeParents, 
			@WebArrayParam("relationtypes") String[] relationTypes, 
			@RequestParam(value = "rendition", required = false) String renditionType, 
			@RequestParam(value = "layout", required = false) Integer layoutNumber, 
			@RequestParam(value = "page", required = false) Integer pageNumber,@RequestParam(value = "draft", required = false) boolean draft,
			HttpServletResponse httpResponse,
			String contentDisposition)
			throws AssetNotFoundException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAsset(assetId, majorVersion, minorVersion, attributes, includeChildren, includeParents, relationTypes, renditionType, layoutNumber, pageNumber, draft, httpResponse, contentDisposition);
	}

	/**
	 * Returns the metadata of the given asset version as AssetInfo OR writes asset's content/rendition to the given HTTP
	 * Response outputstream depending on the supplied parameters. <br/>
	 * In order to fetch specific attributes, specify attribute names in
	 * attributes array.IncludeChildren boolean flag,if true implies return those asset relations with given asset as parent.IncludeParents
	 * boolean flag,if true implies return those asset relations with given asset as child. If the major and minor versions are not
	 * specified then it will return metadata of the latest asset version.In case you want to fetch asset rendition, specify the rendition
	 * type name and an outputStream onto which the rendition has to be written. Draft boolean flag if true, writes the draft copy of the content  
	 * to the given outputstream. In case the draft doesnot exists, last saved content of the asset will be written to the outputstream.
	 * To fetch draft attribute values, specify boolean flag draft as true & specify attribute ids/names that
	 * are to be fetched in attributes array.
	 * For an asset draft, following attribute values can only be sought : 
	 * <ol> <li>{@link DefaultAttributes#FILE_PATH}</li>
	 * <li>{@link DefaultAttributes#FILE_SIZE}</li>
	 * <li>{@link DefaultAttributes#LAST_MODIFIED}</li>
	 * </ol> 
	 * This method is not available as REST API.
	 * 
	 * @param assetId
	 *            Collection path of the asset whose metadata is sought. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset
	 *            in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            Major Version of the asset.
	 * @param minorVersion
	 *            Minor version of the asset.
	 * @param attributes
	 *            Array of attribute names or id's to be fetched for given asset
	 * @param includeChildren
	 *            A boolean flag,if true implies return those asset relations with given asset as parent.
	 * @param includeParents
	 *            A boolean flag,if true implies return those asset relations with given asset as child.
	 * @param relationTypes
	 *            Array of relation types to be retrieved. The array can contain name or id of relation types.
	 * @param renditionType
	 *            Name or id of the rendition type to be fetched.
	 * @param outputStream
	 *            An {@link OutputStream} onto which rendition is to be written
	 * @param layoutNumber
	 *            Specific layout to be retrieved in context to a rendition.
	 * @param pageNumber
	 *            Specific page to be retrieved in context to a rendition.
	 * @param draft
	 *            if true, draft copy of the content will be written to the given outputstream. In case the draft doesnot exist, last saved
	 *            content of the asset will be written to the outputstream. To fetch draft attribute values, specify boolean flag
	 * 			  draft as true & specify attribute ids/names that are to be fetched in attributes array.
	 * @return AssetInfo object of the given asset.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.Additonal info will refer to the exact cause of this exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case the I/O streaming fails.
	 */
	public AssetInfo getAsset(String assetPath, Long majorVersion, Long minorVersion, @WebArrayParam("attributes") String[] attributes,
			boolean includeChildren, boolean includeParents, String[] relationTypes, String renditionType, OutputStream outputStream,
			Integer layoutNumber, Integer pageNumber, boolean draft) throws AssetNotFoundException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAsset(assetId, majorVersion, minorVersion, attributes, includeChildren, includeParents, relationTypes, renditionType, outputStream, layoutNumber, pageNumber, draft);
	}
	
	/**
	 * Returns the metadata of the given asset version as AssetInfo OR writes asset's content/rendtion to the given HTTP
	 * Response outputstream depending on the supplied parameters. <br/>
	 * In order to fetch specific attributes, specify attribute names in
	 * attributes array.IncludeChildren boolean flag,if true implies return those asset relations with given asset as parent.IncludeParents
	 * boolean flag,if true implies return those asset relations with given asset as child. If the major and minor versions are not
	 * specified then it will return metadata of the latest asset version.In case you want to fetch asset rendition, specify the rendition
	 * type name and an outputStream onto which the rendition has to be written. 
	 * This method is not available as REST API.
	 * 
	 * @param assetId
	 *            Collection path of the asset whose metadata is sought. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset
	 *            in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            Major Version of the asset.
	 * @param minorVersion
	 *            Minor version of the asset.
	 * @param attributes
	 *            Array of attribute names or id's to be fetched for given asset
	 * @param includeChildren
	 *            A boolean flag,if true implies return those asset relations with given asset as parent.
	 * @param includeParents
	 *            A boolean flag,if true implies return those asset relations with given asset as child.
	 * @param relationTypes
	 *            Array of relation types to be retrieved. The array can contain name or id of relation types.
	 * @param renditionType
	 *            Name or id of the rendition type to be fetched.
	 * @param outputStream
	 *            An {@link OutputStream} onto which rendition is to be written
	 * @param layoutNumber
	 *            Specific layout to be retrieved in context to a rendition.
	 * @param pageNumber
	 *            Specific page to be retrieved in context to a rendition.
	 * @return AssetInfo object of the given asset.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.Additonal info will refer to the exact cause of this exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case the I/O streaming fails.
	 */
	public AssetInfo getAsset(String assetPath, Long majorVersion, Long minorVersion, @WebArrayParam("attributes") String[] attributes,
			boolean includeChildren, boolean includeParents, String[] relationTypes, String renditionType, OutputStream outputStream,
			Integer layoutNumber, Integer pageNumber) throws AssetNotFoundException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.getAsset(assetId, majorVersion, minorVersion, attributes, includeChildren, includeParents, relationTypes,
				renditionType, outputStream, layoutNumber, pageNumber, false/* fetch draft */);
	}

	/**
	 * Releases the asset from checked-out state.
	 * 
	 * @param assetPath
	 *            Collection path of the asset to be aborted from checkout state. The assetPath is a string containing collection path
	 *            followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to that
	 *            unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @return AssetInfo object of the corresponding asset.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws AssetNotCheckedOutException
	 *             If the asset is not in checked-out state.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=abortcheckout")
	@WebReturnType(value = "xmlView")
	public AssetInfo abortCheckout(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath) throws AssetNotFoundException, AssetLockedException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.abortCheckout(assetId);
	}
	
	/**
	 * CheckIn new asset and returns the AssetInfo of the new checked in asset.
	 * 
	 * While creating asset you can set any attribute as a part of metadata. However, there are certain set of attributes whose value is
	 * mandatory for the creation of new asset. Asset cannot be created without specifying values for such attributes. All such attributes
	 * can be fetched at runtime by following:
	 * <ol>
	 * <li>Calling API {@link com.quark.qpp.core.attribute.service.local.AttributeService#getApplicableAttributes(long)} and supplying the
	 * content type Id as parameter would return array of Attribute objects.</li>
	 * <li>Attribute objects array returned in step 1 can be further filtered to have attributes whose
	 * {@link Attribute#getModificationLevel()} is either {@link AttributeModificationLevels#CLIENT_MODIFIABLE} or
	 * {@link AttributeModificationLevels#USER_MODIFIABLE} and whose value mandatory flag,
	 * {@link ContentTypeAttributeMapping#isValueMandatory()} is true.</li>
	 * 
	 * Also, creates the asset relations if specified, else only the asset will be checked in.
	 * 
	 * @param assetPath
	 *            collection path of the asset that is being checked in. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset is to be checked in and assetName refers to that unique asset name
	 *            with which the asset will be checked into that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param inputStream
	 *            Input stream containing the file stream that is to be uploaded in case of a new asset checkin.
	 * @param attributeValueList
	 *            List of attribute values to be set for the new asset.
	 * @param assetRelationInfoList
	 *            AssetRelationInfoList containing asset relations to be created . Since the fields: parentAssetId, parentAssetVersion,
	 *            relationState in AssetRelation object would be populated by the Server, there is no need for clients to set these fields.
	 *            Latest version of the child asset would be considered if not supplied.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in asset as a new minor version or as a new major version.
	 * @return AssetInfo object containing metadata of the new checked in asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of the attribute values (either asset or relation attributes) in terms of validity,
	 *             mandatory, wrong value, etc. The specific reason for the exception can be found by calling
	 *             <code>getExceptionCode()</code> of the exception. <code>getAdditionalInfo()</code> tells you the id of the attribute
	 *             responsible for the exception.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being checked-in) for the given content type.
	 * @throws RelationTypeNotFoundException
	 *             If one of the relation type supplied in assetRelations is not valid.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails
	 * @throws IOException
	 *             This exception is produced by failed or interrupted I/O operations.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkinnew")
	@WebReturnType(value = "xmlView")
	public AssetInfo checkInNew(@WebInputStream InputStream inputStream, @WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebSerializedParam("relations") AssetRelationInfoList assetRelationInfoList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws MinorVersionNotSupportedException,
			InvalidAttributeValueException, StorageRuleNotFoundException, InvalidComponentException, InvalidRepositoryException, QppServiceException,
			IOException, StreamingException {
		int index = assetPath.lastIndexOf("/");
		String assetName = assetPath.substring(index + 1);
		String collectionPath = assetPath.substring(0, index);
		long collectionId = getCollectonId(collectionPath);
		attributeValueList = addAttributeValue(attributeValueList, DefaultAttributes.COLLECTION, collectionId);
		return assetFacade.checkInNew(inputStream, assetName, attributeValueList, assetRelationInfoList, createMinorVersion);
	}

	private long getCollectonId(String collectionPath) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[1];
		displayColumns[0] = new DisplayColumn();
		displayColumns[0].setColumnId(DefaultAttributes.NAME);
		displayColumns[0].setWidth(50);
		displayColumns[0].setAttributeColumn(true);
		queryDisplay.setDisplayColumns(displayColumns);

		StringAttributeCondition stringAttrCond = new StringAttributeCondition();
		stringAttrCond.setAttributeId(DefaultAttributes.COLLECTION_PATH);
		stringAttrCond.setValue(collectionPath);
		stringAttrCond.setNestingLevel(1);
		stringAttrCond.setComparisonOperator(QueryConstants.StringOperators.IS);
		stringAttrCond.setLogicalOperator(QueryConstants.LogicalOperators.AND);
		QueryCondition[] queryConditions = new QueryCondition[] { stringAttrCond };

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.COLLECTION);// search for collections

		QueryResultElement[] collectionElements = queryService.getQueryResultForConditions(queryConditions, queryContext, queryDisplay);
		if(collectionElements == null || collectionElements.length == 0){
			throw new InvalidCollectionException();
		}
		return ((CollectionElement) collectionElements[0]).getCollectionId();
	}

	private AttributeValueList addAttributeValue(AttributeValueList attributeValueList, long collectionAttrId, long collectionId) {

		AttributeValue attributeValue = new AttributeValue();
		attributeValue.setId(collectionAttrId);
		attributeValue.setValueId(collectionId);
		attributeValueList.getAttributeValue().add(attributeValue);
		return attributeValueList;
	}

	/**
	 * CheckIn's the checked-out asset and returns the asset info. It also validates the asset's metadata (AttributeValues).
	 * <ul>
	 * While checking in asset you can set any attribute as a part of metadata. However, there are certain set of attributes whose value is
	 * mandatory for the check-in of asset. Asset cannot be checked in without specifying values for such attributes. All such attributes
	 * can be fetched at runtime by following:
	 * <ol>
	 * <li>Calling API {@link com.quark.qpp.core.attribute.service.local.AttributeService#getApplicableAttributes(long)} and supplying the
	 * content type Id as parameter would return array of Attribute objects.</li>
	 * <li>Attribute objects array returned in step 1 can be further filtered to have attributes whose
	 * {@link Attribute#getModificationLevel()} is either {@link AttributeModificationLevels#CLIENT_MODIFIABLE} or
	 * {@link AttributeModificationLevels#USER_MODIFIABLE} and whose value mandatory flag,
	 * {@link ContentTypeAttributeMapping#isValueMandatory()} is true.</li> <br>
	 * 
	 * @param inputStream
	 *            Input stream of the file that is to be checked in.
	 * @param assetPath
	 *            Collection path of the asset to be checked in.The assetPath is a string containing collection path followed by asset name.
	 *            The collection path refers to the collection where the asset exists and assetName refers to that unique asset in that
	 *            collection that is to be checked in. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            List of AttributeValues that need to be updated for this asset.
	 * @param assetRelationInfoList
	 *            List of AssetRelationInfo objects to be created or updated with this asset. The AssetRelationInfo would be considered for
	 *            insertion if AssetRelationInfo.getId() is 0. Otherwise the relation would be considered for updation. Since the fields:
	 *            parentAssetId, parentAssetVersion, relationState in AssetRelation object would be populated by the Server, there is no
	 *            need for clients to set these fields. Latest version of the child asset would be considered if supplied as null.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in asset as a new minor version or as a new major version.
	 * @return Id of the context generated.
	 * @throws AssetNotFoundException
	 *             If the asset with the given id is not found.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode() </code> of the exception. <code>
	 *             getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * 
	 * @throws AssetNotCheckedOutException
	 *             If the given asset is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the given asset is not checked out by the user who tries to check it in.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being checked-in) for the given content type.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkin")
	@WebReturnType(value = "xmlView")
	public AssetInfo checkIn(@WebInputStream InputStream inputStream, @WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebSerializedParam("relations") AssetRelationInfoList assetRelationInfoList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws MinorVersionNotSupportedException,
			InvalidAttributeValueException, StorageRuleNotFoundException, InvalidComponentException, InvalidRepositoryException, QppServiceException,
			IOException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.checkIn(inputStream, assetId, attributeValueList, assetRelationInfoList, createMinorVersion);
	}
	
	/**
	 * CheckIn new article asset.
	 * 
	 * While creating article you can set any attribute as a part of metadata. However, there are certain set of attributes whose value is
	 * mandatory for the creation of new asset. Asset cannot be created without specifying values for such attributes. All such attributes
	 * can be fetched at runtime by following:
	 * <ol>
	 * <li>Calling API {@link com.quark.qpp.core.attribute.service.local.AttributeService#getApplicableAttributes(long)} and supplying the
	 * content type Id as parameter would return array of Attribute objects.</li>
	 * <li>Attribute objects array returned in step 1 can be further filtered to have attributes whose
	 * {@link Attribute#getModificationLevel()} is either {@link AttributeModificationLevels#CLIENT_MODIFIABLE} or
	 * {@link AttributeModificationLevels#USER_MODIFIABLE} and whose value mandatory flag,
	 * {@link ContentTypeAttributeMapping#isValueMandatory()} is true.</li>
	 * 
	 * Also, creates the asset relations if specified, else only the asset will be checked in.
	 * 
	 * @param inputStream
	 *            input straem of the file that is to be checked into the platform server
	 * @param assetPath
	 *            collection path of the asset that is to be checked in. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the article asset will be checked in and assetName refers
	 *            to the name with which the asset will be checked in specified collection. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            list of attribute values to be set for the new asset
	 * @param articleComponentList
	 *            article components which are represented by this article asset.
	 * @param assetRelationInfoList
	 *            AssetRelationInfoList containing asset relations to be created. Since the fields: parentAssetId, parentAssetVersion,
	 *            relationState in AssetRelation object would be populated by the Server, there is no need for clients to set these fields.
	 *            Latest version of the child asset would be considered if not supplied.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in asset as a new minor version or as a new major version.
	 * @return AssetInfo object containing metadata & article components of the new checked in article.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()
	 *             </code> of the exception. <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which
	 *             the exception was thrown.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being checked-in) for the given content type.
	 * @throws RelationTypeNotFoundException
	 *             In case there doesn't exist relation type with given id or name
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails. The exact reason of the exception can be determined by calling
	 *             getErrorCode() of the exception.
	 * @throws IOException
	 *             in case of failed or interrupted I/O operations.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkinnewarticle")
	@WebReturnType(value = "xmlView")
	public AssetInfo checkInNewArticle(@WebInputStream InputStream inputStream, @WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebSerializedParam("components") ArticleComponentInfoList articleComponentList,
			@WebSerializedParam("relations") AssetRelationInfoList assetRelationInfoList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion)
			throws InvalidAttributeValueException, StorageRuleNotFoundException, InvalidRepositoryException,
			MinorVersionNotSupportedException, RelationTypeNotFoundException, StreamingException, IOException, QppServiceException {
		int index = assetPath.lastIndexOf("/");
		String assetName = assetPath.substring(index + 1);
		String collectionPath = assetPath.substring(0, index);
		long collectionId = getCollectonId(collectionPath);
		attributeValueList = addAttributeValue(attributeValueList, DefaultAttributes.COLLECTION, collectionId);
		return assetFacade.checkInNewArticle(inputStream, assetName, attributeValueList, articleComponentList, assetRelationInfoList,
				createMinorVersion);
	}

	/**
	 * CheckIn's the checked-out article asset and returns the asset info. It also validates the asset's metadata (AttributeValues).
	 * <ul>
	 * While checking in asset you can set any attribute as a part of metadata. However, there are certain set of attributes whose value is
	 * mandatory for the check-in of asset. Asset cannot be checked in without specifying values for such attributes. All such attributes
	 * can be fetched at runtime by following:
	 * <ol>
	 * <li>Calling API {@link com.quark.qpp.core.attribute.service.local.AttributeService#getApplicableAttributes(long)} and supplying the
	 * content type Id as parameter would return array of Attribute objects.</li>
	 * <li>Attribute objects array returned in step 1 can be further filtered to have attributes whose
	 * {@link Attribute#getModificationLevel()} is either {@link AttributeModificationLevels#CLIENT_MODIFIABLE} or
	 * {@link AttributeModificationLevels#USER_MODIFIABLE} and whose value mandatory flag,
	 * {@link ContentTypeAttributeMapping#isValueMandatory()} is true.</li> <br>
	 * 
	 * @param inputStream
	 *            Input stream of the file that is to be checked in.
	 * @param assetPath
	 *            collection path of the asset that is to be checked in. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the article asset exists and assetName refers
	 *            to the name of the checked out article asset that has to be checked in. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            List of AttributeValues that need to be updated for this asset.
	 * @param articleComponentList
	 *            article components which are represented by this article asset.
	 * @param assetRelationInfoList
	 *            List of AssetRelationInfo objects to be created or updated with this asset. The AssetRelationInfo would be considered for
	 *            insertion if AssetRelationInfo.getId() is 0. Otherwise the relation would be considered for updation. Since the fields:
	 *            parentAssetId, parentAssetVersion, relationState in AssetRelation object would be populated by the Server, there is no
	 *            need for clients to set these fields. Latest version of the child asset would be considered if supplied as null.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in asset as a new minor version or as a new major version.
	 * @return AssetInfo object containing metadata & article components of the new checked in article.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails. The exact reason of the exception can be determined by calling
	 *             getErrorCode() of the exception.
	 * @throws IOException
	 *             In case of failed or interrupted I/O operations.
	 * @throws AttributeNotFoundException
	 * @throws AssetNotFoundException
	 *             If the asset with the given id is not found.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode() </code> of the exception. <code>
	 *             getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws AssetNotCheckedOutException
	 *             If the given asset is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the given asset is not checked out by the user who tries to check it in.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being checked-in) for the given content type.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkinarticle")
	@WebReturnType(value = "xmlView")
	public AssetInfo checkInArticle(@WebInputStream InputStream inputStream, @WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebSerializedParam("components") ArticleComponentInfoList articleComponentList,
			@WebSerializedParam("relations") AssetRelationInfoList assetRelationInfoList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws AttributeNotFoundException, QppServiceException, IOException, StreamingException	{
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.checkInArticle(inputStream, assetId, attributeValueList, articleComponentList, assetRelationInfoList, createMinorVersion);
	}


	/**
	 * Marks the asset with the given assetId as CheckedOut by setting various checkout-related attribute values.And also streams the asset
	 * highres in given output stream.
	 * 
	 * @param assetPath
	 *            Collection path of the asset to be checked out. The assetPath is a string containing collection path followed by asset
	 *            name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset in
	 *            that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            AttributeValueList of checkout-related attribute values. This list should contain values only for two attributes:
	 *            <code>CHECKED_OUT_FILE_PATH</code> and <code>CHECKED_OUT_APPLICATION</code>. These attributes are required to update the
	 *            metadata of the asset at the server end while marking the asset as checked out. Since the server cannot validate these
	 *            attributes, it is the client's responsibility to supply the correct values for them.
	 * @param outputStream
	 *            An output stream onto which the asset's highres will be written.
	 * @return AssetInfo object of the checked out asset.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined from <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of this exception contains the id of the attribute for which the exception was thrown.
	 * @throws AssetAlreadyCheckedOutException
	 *             If the asset is already checked out by some user.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkout")
	public void checkOut(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @WebOutputStream OutputStream outputStream)
			throws AssetNotFoundException, AssetLockedException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.checkOut(assetId, attributeValueList, outputStream);
	}

	/**
	 * Duplicates the given asset and returns the AssetInfo object of newly created asset. Using this API, one can duplicate either only the
	 * metadata of the asset or both the metadata and the physical file of the asset. <br>
	 * Assets may be duplicated either in same collection by providing new name for the asset OR in different collection by providing target
	 * collection in AttributeValue array parameter. Similarly, one may choose to set other attributes like Workflow, Status, Issue etc..
	 * for the duplicated asset.Also one can duplicate the asset relations along with asset by specifying the relation types that are to be
	 * duplicated and whether the child assets are to be duplicated or not <br>
	 * 
	 * @param assetPath
	 *            Collection path of the asset that is to be duplicated. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to the unique asset
	 *            with this name in specified collection. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            While duplicating the asset, all metadata of the source asset would be set for the duplicated asset. However there is
	 *            possibility of overriding part of the metadata for the duplicated asset. For example, one may want to use different Name,
	 *            Collection, Workflow, Status etc.. for the duplicated asset. This may be achieved by supplying array of all those
	 *            attribute values through this parameter. If value for collection attribute is provided, then asset would be duplicated in
	 *            given collection. If value for collection attribute is not provided, then asset would be duplicated parallel to the source
	 *            asset.
	 * @param relationTypesToBeDuplicated
	 *            Array of relation type ids or relation type names that are to be duplicated.
	 * @param duplicateChildAssets
	 *            boolean flag specifying whether the child assets are to be duplicated or not.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to duplicate asset as a new minor version or as a new major version.
	 * @return AssetInfo object of the newly created asset.
	 * @throws AssetNotFoundException
	 *             If no asset with the specified Id exists.
	 * @throws InvalidAssetException
	 *             If the asset's content type is not a descendant of {@link DefaultContentTypes#ASSET} OR content type is is either
	 *             {@link DefaultContentTypes#PROJECT} or {@link DefaultContentTypes#ARTICLE}. Or if the asset is placeholder but the
	 *             duplicateAsPlaceholder flag is false.
	 * @throws InvalidAttributeException
	 *             If the given attribute is invalid or does not exist, then this exception is thrown. Additional info will refer to the
	 *             attribute id that caused this exception.
	 * @throws InvalidResourceException
	 *             if there is some problem in duplicating corresponding physical file of asset.
	 * @throws InvalidRepositoryException
	 *             If the repository in which duplicated asset is to be stored is currently either unavailable or not writable.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to duplicate asset as minor version when it is not allowed in the revision control settings of the
	 *             collection(in which the asset is being checked-in) for the given content type.
	 * @throws RelationTypeNotFoundException
	 *             If the relation type being specified for duplication does not exist, then this exception is thrown.Additional info will
	 *             refer to the id of the relation type causing the exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=duplicate")
	@WebReturnType(value = "xmlView")
	public AssetInfo duplicateAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebArrayParam("relationtypes") String[] relationTypesToBeDuplicated,
			@RequestParam(value = "duplicatechildassets", defaultValue = "false") boolean duplicateChildAssets,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws AssetNotFoundException,
			InvalidAssetException, InvalidAttributeException, InvalidResourceException, InvalidRepositoryException, StorageRuleNotFoundException,
			InvalidAttributeValueException, RepositoryActionException, MinorVersionNotSupportedException, RelationTypeNotFoundException,
			QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.duplicateAsset(assetId, attributeValueList, relationTypesToBeDuplicated, duplicateChildAssets, createMinorVersion);
	}

	/**
	 * Checks in asset rendition.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose rendition is to be checked in. The assetPath is a string containing collection path
	 *            followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to that
	 *            unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param inputStream
	 *            Input stream of the rendition that is to be checked in.
	 * @param majorVersion
	 *            Major Version of the asset.
	 * @param minorVersion
	 *            Minor version of the asset.
	 * @param renditionType
	 *            Rendition type of the asset. HIGH-RES cannot be streamed using this method.
	 * @param fileExtension
	 *            File Extension of the rendition to be checked in.
	 * @param numberOfPages
	 *            Number of pages contained in the rendition being created.
	 * @throws AssetNotFoundException
	 *             If the asset with the given id and version is not found.
	 * @throws InvalidRenditionException
	 *             If the rendition type is other than <code>DefaultRenditionTypes.PREVIEW</code> and
	 *             <code>DefaultRenditionTypes.THUMBNAIL</code>
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not
	 *             writable.
	 * @throws InvalidAssetException
	 *             If the given asset is a placeholder asset.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session. Locking of Asset is required only when rendition type is
	 *             HIGH_RES and rendition type HIGH_RES is allowed only for assets of content type Article for creating
	 *             Geometry Context.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=checkinrendition")
	public void checkInRendition(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebInputStream InputStream inputStream,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "rendition", defaultValue = "preview") String renditionType,
			@RequestParam(value = "fileext", defaultValue = "jpg") String fileExtension,
			@RequestParam(value = "pages", defaultValue = "1") int numberOfPages) throws AssetNotFoundException, InvalidRenditionException,
			InvalidRepositoryException, InvalidAssetException, AssetNotLockedException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.checkInRendition(assetId, inputStream, majorVersion, minorVersion, renditionType, fileExtension, numberOfPages);
	}

	/**
	 * Use case for using an import asset API:
	 * <ul>
	 * <li>User has existing assets (say pictures) in their own ECM solution (say at some location)</li>
	 * <li>User has created a new reposiory adaptor to point to the above location</li>
	 * <li>User needs to use the same assets (physical files) in the QPS workflow</li>
	 * </ul>
	 * <br>
	 * This API imports the metadata of a given asset into the server. If an asset is already available in the external repository to which
	 * one of the repository adaptors points, it can be imported into the server using this API. Asset physical file will be used as is from
	 * the specified location. Only the metadata will be checked into the server. <br>
	 * <br>
	 * Since the asset is already available in the external repository to which one of the repository adaptors points, no storage rules will
	 * be evaluated and the following additional attributes are expected at the time of import: <code>FILE_PATH</code>,
	 * <code>REPOSITORY</code>, <code>FILE_SIZE</code>. <br>
	 * <br>
	 * <code>FILE_PATH</code> as usual is relative with respective to the base path for the repository specified by <code>REPOSITORY</code>
	 * attribute. <br>
	 * 
	 * 
	 * @param assetPath
	 *            Collection path of the asset being imported. The assetPath is a string containing collection path followed by asset name.
	 *            The collection path refers to the collection where the asset is to be imported and assetName refers to that unique name
	 *            with which the asset will be imported. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            List of the attribute values to be set for asset.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to import asset as a new minor version or as a new major version.
	 * @param indexingRequired
	 *            Flag indicating if the indexing is to be done by the server for this asset. Indexing of an asset includes generating asset
	 *            renditions and rendition attributes.
	 * @param repositoryAdaptorToken
	 *            Token provided to repository adaptor during repository adaptor registration through callback
	 *            <code>repositoryRegisteredSuccessfully(String) </code> in <code>RepositoryAdapter</code>.
	 * @return AssetInfo object of the corresponding asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined from <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws InvalidResourceException
	 *             If the file location inferred from REPOSITORY and FILE_PATH combination is not valid.
	 * @throws InvalidRepositoryException
	 *             If repository token provided is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being checked-in) for the given content type.
	 * @throws InvalidLayoutException
	 *             if the layout with attachments is intended for deletion.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @see DefaultAttributes
	 * @see DefaultContentTypes
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=importnew")
	@WebReturnType(value = "xmlView")
	public AssetInfo importNewAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion,
			@RequestParam(value = "index", defaultValue = "true") boolean indexingRequired, @RequestParam(value = "repotoken") String repositoryToken)
			throws InvalidAttributeValueException, InvalidResourceException, InvalidRepositoryException, RepositoryActionException,
			MinorVersionNotSupportedException, InvalidLayoutException, QppServiceException {
		int index = assetPath.lastIndexOf("/");
		String assetName = assetPath.substring(index + 1);
		String collectionPath = assetPath.substring(0, index);
		long collectionId = getCollectonId(collectionPath);
		attributeValueList = addAttributeValue(attributeValueList, DefaultAttributes.COLLECTION, collectionId);
		return assetFacade.importNewAsset(assetName, attributeValueList, createMinorVersion, indexingRequired, repositoryToken);
	}

	/**
	 * Imports metadata of new version the asset into the QPS Server. This helps create new version of the asset without
	 * actually uploading the physical file onto the server.
	 * 
	 * Since the asset is already available in the external repository to which one of the repository adaptors points,
	 * no storage rules are evaluated and the following additional attributes are expected at the time of import:
	 * <code>FILE_PATH</code>, <code>REPOSITORY</code>, <code>FILE_SIZE</code>.
	 * <p>
	 * This API is useful if the physical file of the asset is maintained by some other ECM solution that implements QPS
	 * RepositoryAdapter.
	 * </p>
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose new version needs to be imported. The assetPath is a string containing collection path
	 *            followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to that
	 *            unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param attributeValueList
	 *            List of the attribute values to be set for this asset.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to import asset as a new minor version or as a new major version.
	 * @param indexingRequired
	 *            Boolean flag indicating whether indexing of this assets need to be done by the QPS Server or not.
	 *            Indexing of an asset includes generations of asset renditions and rendition attributes.
	 * @param repositoryAdaptorToken
	 *            Token provided to repository adaptor during repository adaptor registration through callback
	 *            <code>repositoryRegisteredSuccessfully(String) </code> in <code>RepositoryAdapter</code>.
	 * @return AssetInfo object of the corresponding asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value,
	 *             etc. The specific reason for the exception can be determined from <code>getExceptionCode()</code> of
	 *             the exception. <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for
	 *             which the exception was thrown.
	 * @throws InvalidResourceException
	 *             If the file location inferred from REPOSITORY and FILE_PATH combination is not valid.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by any session.
	 * @throws AssetNotFoundException
	 *             If no asset with the given id exists.
	 * @throws AssetNotCheckedOutException
	 *             If the asset is not in checked-out state.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the given asset is not checked out by the user who tries to check it in.
	 * @throws InvalidRepositoryException
	 *             If repository token provided is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of
	 *             the collection(in which the asset is being checked-in) for the given content type.
	 * @throws InvalidLayoutException
	 *             if the layout with attachments is intended for deletion.
	 * @throws InvalidComponentException
	 *             if the component with the given id does not exist in given version of the article.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=import")
	@WebReturnType(value = "xmlView")
	public AssetInfo importAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion,
			@RequestParam(value = "index", defaultValue = "true") boolean indexingRequired,
			@RequestParam(value = "repotoken") String repositoryAdapterToken) throws InvalidAttributeValueException, InvalidResourceException,
			InvalidRepositoryException, RepositoryActionException, MinorVersionNotSupportedException, InvalidLayoutException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.importAsset(assetId, attributeValueList, createMinorVersion, indexingRequired, repositoryAdapterToken);
	}

	/**
	 * Imports asset renditions. For importing the asset renditions, you need to specify the repository, file paths,
	 * rendition attributes and other rendition related information. This makes the required renditions QPS aware.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose renditions are to be imported.
	 * @param majorVersion
	 *            major version of the asset whose renditions are to be imported.
	 * @param minorVersion
	 *            minor version of the asset whose renditions are to be imported.
	 * @param repositoryId
	 *            Id of the repository where physical files for the renditions exist.
	 * @param renditionAttributeValueList
	 *            Values for following rendition attributes are expected:
	 *            <p>
	 *            COLOR_SPACE, RESOLUTION, COLOR_DEPTH, PIXEL_HEIGHT, PIXEL_WIDTH, NUMBER_OF_PAGES
	 *            </p>
	 * @param assetRenditionInfoList
	 *            List of AssetRenditionInfo objects, where each object signifies one physical file. You need not
	 *            specify assetId, version, repositoryId in the AssetRendition objects as this information is common for
	 *            all and thus should be supplied in separate parameters mentioned above.
	 * @param repositoryAdaptorToken
	 *            Token provided to repository adaptor during repository adaptor registration through callback
	 *            <code>repositoryRegisteredSuccessfully(String) </code> in <code>RepositoryAdapter</code>
	 * @throws AssetNotFoundException
	 *             If no asset with the given id and version exists.
	 * @throws InvalidResourceException
	 *             If the resource with the given information is not found.
	 * @throws InvalidRenditionException
	 *             If the rendition type supplied in any of the AssetRendition objects is invalid.
	 * @throws InvalidAttributeValueException
	 *             If there is a discrepancy in any of the given renditionAttributes in terms of validity, mandatory,
	 *             wrong value, etc. The specific reason for the exception can be determined from
	 *             <code>getExceptionCode()</code> of the exception. <code>getAdditionalInfo()</code> of the exception
	 *             contains the id of the attribute for which the exception was thrown.
	 * @throws InvalidRepositoryException
	 *             If repository token provided is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=importrenditions")
	public void importAssetRenditions(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, @RequestParam("repoid") long repositoryId,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@WebSerializedParam("assetrenditions") AssetRenditionInfoList assetRenditionInfoList,
			@RequestParam(value = "repotoken") String repositoryToken) throws InvalidAttributeValueException, InvalidResourceException,
			InvalidRepositoryException, RepositoryActionException, MinorVersionNotSupportedException, InvalidLayoutException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.importAssetRenditions(assetId, majorVersion, minorVersion, repositoryId, attributeValueList, assetRenditionInfoList,
				repositoryToken);
	}

	/**
	 * Creates a new relation between two QPS assets. The parentAssetId refers to the parent asset and childAssetId
	 * refers to the child asset in a relation.The attributeValueList refers to the attribute values to be set for this
	 * relation. Only those attributes are allowed to be set which are mapped to the specified relation type.The boolean
	 * flag lockedToChildVersion server as a hint for clients that for this relation, the child asset version is update
	 * able or not. A false value signifies child asset version is update able but true signifies that parent asset is
	 * permanently related to the given version of child asset.If child asset major and minor version are supplied as
	 * null, then the latest version of child asset is considered.
	 * 
	 * @param parentAssetPath
	 *            Collection path of the asset that is parent in this relation. The assetPath is a string containing collection path
	 *            followed by asset name. The collection path refers to the collection where the asset exists and assetName refers to that
	 *            unique asset in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param childAssetId
	 *            Id of the child asset of the relation.
	 * @param childAssetMajorVersion
	 *            Major Version of the child asset of the relation.
	 * @param childAssetMinorVersion
	 *            Minor Version of the child asset of the relation.
	 * @param relationType
	 *            relation type id signifies the type of relation to be created between two assets.
	 * @param attributeValuesList
	 *            Attribute values to be set while creating this relation.
	 * @param lockedToChildVersion
	 *            A boolean flag if true signifies that child asset version can never be updated in this relation and
	 *            parent is permanently related to the current child version.
	 * @return id of the new asset relation created.
	 * @throws InvalidAssetRelationException
	 *             In case the parent asset id is same as child asset id (which is not permissible),then this exception
	 *             in thrown. Exception code will give the exact cause of this exception.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to given asset id's exists. Addition info will refer to the asset id that
	 *             does not exist.
	 * @throws RelationTypeNotFoundException
	 *             If the relation type does not exist.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values specified is invalid then this exception is thrown. Additional info
	 *             will refer to the attribute id that has caused this exception.
	 * @throws AssetNotCheckedOutException
	 *             If the relation type definition requires that while creating a relation of this type, the parent
	 *             asset has to be mandatory checked out but that asset is not checked out, then this exception is
	 *             thrown.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the asset exists at the server but is not checked out by the user who is trying to perform the
	 *             operation.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @see {@link DefaultRelationTypes}
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=createrelation")
	@WebReturnType(value = "xmlView")
	public AssetRelationInfo createAssetRelation(@WebResourcePathParam(PATH_IDENTIFIER) String parentAssetPath, @RequestParam("childassetid") long childAssetId,
			@RequestParam(value = "childmajorversion", required = false) Long childAssetMajorVersion,
			@RequestParam(value = "childminorversion", required = false) Long childAssetMinorVersion,
			@RequestParam("relationtype") String relationType, @WebSerializedParam("attributevalues") AttributeValueList attributeValuesList,
			@RequestParam(value = "lockedtochildversion", defaultValue = "false") boolean lockedToChildVersion) throws InvalidAssetRelationException,
			AssetNotFoundException, RelationTypeNotFoundException, InvalidAttributeValueException, AssetNotCheckedOutException,
			AssetCheckedOutByAnotherUserException, QppServiceException {
		long assetId = facadeUtility.getAssetId(parentAssetPath);
		return assetFacade.createAssetRelation(assetId, childAssetId, childAssetMajorVersion, childAssetMinorVersion, relationType,
				attributeValuesList, lockedToChildVersion);
	}

	/**
	 * Creates new asset relation for each {@link AssetRelationInfo} element given in AssetRelationInfoList. The
	 * relation will take into consideration the current version of parent asset and child asset. The
	 * childAssetMajorVersion and childAssetMinorVersion field of {@link AssetRelationInfo}is overridden by server.
	 * 
	 * @param assetRelationInfoList
	 *            Asset relations to be created.
	 * @return {@link AssetRelationInfoList} containing asset relations created.
	 * @throws InvalidAssetRelationException
	 *             In case the parent asset id is same as child asset id (which is not permissible),then this exception
	 *             in thrown. Exception code will give the exact cause of this exception.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to given asset id's exists. Addition info will refer to the asset id that
	 *             does not exist.
	 * @throws RelationTypeNotFoundException
	 *             If the relation type does not exist.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values specified is invalid then this exception is thrown. Additional info
	 *             will refer to the attribute id that has caused this exception.
	 * @throws AssetNotCheckedOutException
	 *             If the relation type definition requires that while creating a relation of this type, the parent
	 *             asset has to be mandatory checked out but that asset is not checked out, then this exception is
	 *             thrown.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the asset exists at the server but is not checked out by the user who is trying to perform the
	 *             operation.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=createrelations")
	@WebReturnType(value = "xmlView")
	public AssetRelationInfoList createAssetRelations(@WebSerializedParam("relations") AssetRelationInfoList assetRelationInfoList)
			throws InvalidAssetRelationException, AssetNotFoundException, RelationTypeNotFoundException, InvalidAttributeValueException,
			AssetNotCheckedOutException, AssetCheckedOutByAnotherUserException, QppServiceException {
		return assetFacade.createAssetRelations(assetRelationInfoList);
	}

	/**
	 * Deletes the asset with the given id.In case the major or minor version is not null, then that specified version is deleted. The
	 * boolean flag deleteMinorVersions is considered only if the given assetVersion is major version of the asset. The boolean flag
	 * deleteMinorVersions if true indicates that all the minor versions for the given
	 * 
	 * @param assetPath
	 *            Collection path of the asset that is to be deleted. The assetPath is a string containing collection path followed by asset
	 *            name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset in
	 *            that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            Major version of the asset that is to be deleted.
	 * @param minorVersion
	 *            Minor version of the asset that is to be deleted.
	 * @param deleteMinorVersions
	 *            A boolean flag indicating if all minor versions of the given assetVersion are to be deleted or not. If true - all minor
	 *            versions(associated with the given major version) of the asset would also be deleted else only specified version will be
	 *            deleted. This parameter would be considered only when the given assetVersion is major.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id or version exists.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session before deletion.
	 * @throws InvalidResourceException
	 *             Exception thrown by underlying RepositoryAdapter during deletion of physical file of the given asset.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=delete")
	public void deleteAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "deleteminorver", defaultValue = "false") boolean deleteMinorVersions) throws AssetNotFoundException,
			AssetNotLockedException, InvalidResourceException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.deleteAsset(assetId, majorVersion, minorVersion, deleteMinorVersions);
	}

	/**
	 * Deletes all relations associated with given parent and child assets.In case the child asset id is not supplied
	 * then all the relations of given parent asset will be deleted.
	 * 
	 * @param parentAssetPath
	 *            Collection path of the asset whose relation with the given child asset id to be deleted.
	 * @param childAssetId
	 *            child asset Id whose relation with the given parent asset id to be deleted.
	 * @throws AssetNotFoundException
	 *             If the asset(either parent or child asset) with the given id does not exist
	 * @throws AssetNotCheckedOutException
	 *             If the parent asset is not checked out by the user who is trying to perform the operation.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the parent asset is not checked out by the user who is trying to perform the operation.
	 * @throws InvalidAttributeValueException
	 *             if the attribute value is invalid. Additional info will refer to the invalid attribute id that caused
	 *             this exception.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=deleterelations")
	public void deleteAssetRelationsForParent(@WebResourcePathParam(PATH_IDENTIFIER) String parentAssetPath,
			@RequestParam(value = "childassetid", required = false) Long childAssetId) throws AssetNotFoundException, AssetNotCheckedOutException,
			AssetCheckedOutByAnotherUserException, InvalidAttributeValueException, RepositoryActionException, QppServiceException {
		long assetId = facadeUtility.getAssetId(parentAssetPath);
		assetFacade.deleteAssetRelationsForParent(assetId, childAssetId);
	}

	

	/**
	 * Updates child assets versions to latest versions in all those relations with the given asset id as parent asset
	 * id and any of the given relation type. In case the relation types are not specified, then the child asset version
	 * will be updated in all the relations with the given parent asset id.
	 * 
	 * 
	 * @param parentAssetPath
	 *            Collection path of the parent asset.
	 * @param relationTypes
	 *            Array of relation types for which child asset versions are to be updated. Each array element can be relation type id or name.
	 * @throws AssetNotFoundException
	 *             If the asset with the given id does not exist.
	 * @throws RelationTypeNotFoundException
	 *             If any of the relation type with the given id or name does not exist,then this exception is thrown.
	 *             Additional info will refer to the relation type causing this exception.
	 * @throws AssetNotCheckedOutException
	 *             If the parent asset for this asset relation exists at the server but is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the parent asset for this asset relation exists at the server but is not checked out by the user
	 *             who is trying to perform the operation.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=updateallchildversion")
	public void updateAllChildAssetsVersion(@WebResourcePathParam(PATH_IDENTIFIER) String parentAssetPath, @WebArrayParam("relationtypes") String[] relationTypes)
			throws AssetNotFoundException, AssetNotCheckedOutException, AssetCheckedOutByAnotherUserException, QppServiceException {
		long assetId = facadeUtility.getAssetId(parentAssetPath);
		assetFacade.updateAllChildAssetsVersion(assetId, relationTypes);
	}

	/**
	 * Updates the child asset version to the given version in all those asset relations with the given parent and child
	 * asset id's. In case the child asset major and minor versions are supplied null, then the relation will be updated
	 * to the latest child asset version.
	 * 
	 * @param parentAssetPath
	 *            id of the parent asset
	 * @param childAssetId
	 *            id of the child asset
	 * @param childAssetMajorVersion
	 *            Child asset major version to which relation is to be updated.
	 * @param childAssetMinorVersion
	 *            Child asset minor version to which relation is to be updated.
	 * @throws AssetNotFoundException
	 *             If the asset with the given asset path does not exist.
	 * @throws AssetNotCheckedOutException
	 *             If the parent asset for this asset relation exists at the server but is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the parent asset for this asset relation exists at the server but is not checked out by the user
	 *             who is trying to perform the operation.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=updatechildversion")
	public void updateChildVersionForAsset(@WebResourcePathParam(PATH_IDENTIFIER) String parentAssetPath, @RequestParam(value = "childassetid") long childAssetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion) throws AssetNotFoundException,AssetNotCheckedOutException, AssetCheckedOutByAnotherUserException,  QppServiceException {
		long assetId = facadeUtility.getAssetId(parentAssetPath);
		assetFacade.updateChildVersionForAsset(assetId, childAssetId, majorVersion, minorVersion);
	}

	/**
	 * Updates the metadata of the Asset. The request parameters majorVersion and minorVersion are accounted only while updating the 
	 * attribute values that are owned by repository adaptor. For example: FilePath, FileSize etc..
	 * Thus, this API updates the asset metadata only of the latest version but, one can update repository attributes of specific asset version.
	 * 
	 * @param assetPath
	 *            	Collection path of the asset whose metadata is to be updated
	 * @param attributeValueList
	 *            	AttributeValueList containing list of {@link com.quark.qpp.service.xmlBinding.AttributeValue} to be
	 *            	updated.
	 * @param majorVersion
	 * 				major version of the asset whose repository attributes are to be updated.
	 * @param minorVersion
	 * 				minor version of the asset whose repository attributes are to be updated.
	 * @param repositoryAdaptorToken 
	 * 				Token provided to repository adaptor during repository adaptor
	 *            	registration through callback <code>repositoryRegisteredSuccessfully(String) </code> in <code>RepositoryAdapter</code>.
	 * @throws AssetNotFoundException
	 *             If no asset with the given asset path exists.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value,
	 *             etc. The specific reason for the exception can be determined from <code>getExceptionCode()</code> of
	 *             the exception. <code>getAdditionalInfo()</code> of this exception contains the id of the attribute
	 *             for which the exception was thrown.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=update")
	@WebReturnType("xmlView")
	public AssetInfo updateAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "repotoken", required = false) String repositoryAdaptorToken) throws AssetNotFoundException,
			AssetNotLockedException, InvalidAttributeValueException, RepositoryActionException,
			QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.updateAsset(assetId, attributeValueList, majorVersion, minorVersion, repositoryAdaptorToken);
	}
	
	/**
	 * Allows to save the asset highres file without creating new version of the asset. This can be used when user wants to save the
	 * local/modified copy of the content to the server without creating new version of the asset so that he can work with his last saved
	 * content from anywhere remotely. This saved copy of the content is called as draft. This saved draft copy of the content will be
	 * visible only to the user who checked out the asset. <br/>
	 * Each time a draft is created, it will override the previous draft of that asset. However, the draft gets deleted on invoking
	 * {@link #abortCheckout(long)} or on creating a new version of the asset.<br>
	 * 
	 * @param assetPath
	 *            	Collection path of the asset whose draft is to be saved
	 * @param inputStream
	 *            input stream of the file that is to be saved as asset draft
	 * @throws AssetNotFoundException
	 *             If the asset with the given id dosenot exist or the asset is a placeholder.
	 * @throws AssetNotCheckedOutException
	 *             If the asset with the given id is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the asset is not checked out by the user whose is about to create asset draft.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws AssetLockedException
	 *             If the asset is already locked by the user or by someone else. Calling <code>getAdditionalInfo()</code> of the exception
	 *             gives you id of the user who has locked this asset.
	 * @throws InvalidRepositoryException
	 *             If the repository in which asset draft is to be stored is currently unavailable or not writable.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails. The exact reason of the exception can be determined by calling
	 *             getErrorCode() of the exception.
	 * @throws InvalidStorageContextException
	 *             If there is no context found corresponding to the given contextId, or the contextId supplied is not that of one which is
	 *             generated through <code>AssetService</code>.
	 * @throws ContextRollbackException
	 *             If closeContext is called without doing streaming. For example, if you create checkIn context through
	 *             <code>createCheckinContext</code> and don't upload the stream, and directly try to call closeContext. In this case, since
	 *             streaming is not done, asset metadata should also not be updated.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=savedraft")
	public void saveDraft(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebInputStream InputStream inputStream) throws AssetNotFoundException,
			AssetNotCheckedOutException, AssetCheckedOutByAnotherUserException, AssetNotLockedException, AssetLockedException,
			InvalidRepositoryException, StreamingException, InvalidStorageContextException, ContextRollbackException,
			RepositoryActionException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.saveDraft(assetId, inputStream);
	}

	
	/**
	 * Promotes the last saved asset draft to a new asset version. It uses the saved draft copy of the content and creates a new asset
	 * version. After promoting the content to the new version, asset draft will be deleted.
	 * 
	 * @param assetPath
	 *            	Collection path of the asset whose draft is to be promoted as a new asset version
	 * @param attributeValueList
	 *            List of attribute values to be set for this new asset version.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to promote draft as a new minor version or as a new major version.
	 * @return AssetInfo object of the new asset version that has been created through promote draft.
	 * @throws AssetNotFoundException
	 *             If the asset does not exist.
	 * @throws AssetLockedException
	 *             If the asset is already locked by the user or by someone else. Calling <code>getAdditionalInfo()</code> of the exception
	 *             gives you id of the user who has locked this asset.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by any session.
	 * @throws AssetNotCheckedOutException
	 *             If the asset with given id is not checked out.
	 * @throws AssetCheckedOutByAnotherUserException
	 *             If the logged-on user is not the same who has checked out the asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of the attribute values in terms of validity, mandatory, wrong value, etc. The
	 *             specific reason for the exception can be found by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> tells you the id of the attribute responsible for the exception.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable.
	 * @throws AssetNotLockedException
	 *             If the asset is not locked by this session.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of the collection(in
	 *             which the asset is being promoted) for the given content type.
	 * @throws CannotDeleteAttachedComponentException
	 *             If the given asset is Article and one of article's components, that is attached to some document, is being deleted during
	 *             promote draft.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=promotedraft")
	@WebReturnType("xmlView")
	public AssetInfo promoteDraft(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws AssetNotFoundException,
			AssetLockedException, AssetNotLockedException, AssetNotCheckedOutException, AssetCheckedOutByAnotherUserException,
			AttributeNotFoundException, InvalidAttributeValueException, StorageRuleNotFoundException, InvalidRepositoryException,
			AssetNotLockedException, MinorVersionNotSupportedException, CannotDeleteAttachedComponentException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return assetFacade.promoteDraft(assetId, attributeValueList, createMinorVersion);
	}
	
	/**
	 * Generates text indexes for attributes & content of the asset. Text
	 * indexes will be generated for only those attributes that are text search
	 * enabled. Whereas, the text indexes of the content will be generated from
	 * the asset's TEXT rendition. Therefore, if the text rendition of the asset
	 * is not available, text indexing will fail.
	 * 
	 * @param assetPath
	 *            Collection path of the asset whose text indexes are to be
	 *            generated.
	 * @throws AssetNotFoundException
	 *             If no asset corresponding to the given id exists.
	 * @throws RenditionNotFoundException
	 *             If text rendition for the given asset does not exist.
	 * @throws TextIndexingException
	 *             If the text indexer is unable to index asset attributes or
	 *             asset content.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=generatetextindexes")
	public void generateTextIndexes(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath) throws AssetNotFoundException, RenditionNotFoundException, TextIndexingException,
			QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.generateTextIndexes(assetId);
	}
	
	/**
	 * This API reIndexes the given asset. It generates renditions of an asset such as previews, thumbnails, text renditions etc.
	 * 
	 * @param assetId
	 *            Collection path of the asset whose renditions are to be generated.
	 * @throws AssetNotFoundException
	 *             If the asset does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=reindex")
	public void reIndex(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath) throws AssetNotFoundException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		assetFacade.reIndex(assetId);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

}

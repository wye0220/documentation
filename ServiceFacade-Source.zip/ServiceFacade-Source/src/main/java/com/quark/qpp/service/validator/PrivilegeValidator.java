/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.validator;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.quark.qpp.common.context.SessionContextHolder;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidCollectionExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.exceptions.ContentServiceExceptionCodes.InvalidContentTypeExceptionCodes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.dto.ApplicablePrivileges;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.privilege.service.local.PrivilegeService;
import com.quark.qpp.core.privilege.service.local.UserClassService;
import com.quark.qpp.core.security.service.dto.GroupInfo;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.service.exception.UserPrivilegeException;
import com.quark.qpp.service.exception.UserPrivilegeExceptionCodes;
import com.quark.qpp.service.xmlBinding.Method;
import com.quark.qpp.service.xmlBinding.MethodPrivileges;

public class PrivilegeValidator {
	
	private static String MANDATORY_PRIVILEGES_CONFIG_FILE = "MandatoryPrivileges.xml";
	
	@Autowired 
	private UserClassService userClassService;
	
	@Autowired
	private TrusteeService trusteeService;
	
	@Autowired
	private CollectionService collectionService;
	
	@Autowired
	private AssetService assetService;
	
	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;
	
	@Autowired
	private PrivilegeService privilegeService;

	private MethodPrivileges methodPrivileges ;
	
	public void init() throws IOException{
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(MANDATORY_PRIVILEGES_CONFIG_FILE);
		try {
			Source streamSource = new StreamSource(inputStream);
			methodPrivileges = (MethodPrivileges) jaxb2Marshaller.unmarshal(streamSource);
		} finally {
			inputStream.close();
		}
	}
	
	/**
	 * This method validates content type privileges before performing any
	 * operation on an asset.
	 * 
	 * @param assetId
	 *            id of the asset whose content type privileges are to be
	 *            validated
	 * @param attributeValues
	 *            list of attribute values that should contains collection,
	 *            content type and status values that are required for getting
	 *            privileges over-ridden over status/collection.
	 * @param operationToBePerformed
	 *            operation to be performed on asset.
	 * @throws AssetNotFoundException
	 *             In case the asset doesnot exist
	 * @throws InvalidAttributeException
	 *             In case of invalid attribute id
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public void validateContentTypePrivileges(long assetId, AttributeValue[] attributeValues, String operationToBePerformed) throws AssetNotFoundException, InvalidAttributeException, QppServiceException{
	
		long[] mandatoryPrivileges = getManadatoryPrivilegs(operationToBePerformed, methodPrivileges);
		
		if(mandatoryPrivileges == null || mandatoryPrivileges.length == 0){
			//Nothing to be done if there is no mandatory privileges.
			return;
		}
		
		//collectionId is required to fetch collection over-ridden userclass for current user
		long collectionId = getCollectionId(assetId, attributeValues);
		
		//contentTypeId is required to fetch privileges for a particular content type
		long contentTypeId = getContentTypeId(assetId, attributeValues);
		
		//statusId is required to fetch status enabled privilges
		long statusId = getStatusId(assetId, attributeValues);
		
		long[] enabledPrivileges = collectionService.getApplicableStatusPrivilegesForPrivIds(collectionId, statusId, contentTypeId, mandatoryPrivileges);
		comparePrivileges(mandatoryPrivileges, enabledPrivileges);
	}
	
	/**
	 * This method validates application privileges in case the operation is in context of collections like
	 * create/delete/update/move/.. collection or collection template. 
	 * 
	 * @param operationToBePerformed
	 *            operation to be performed
	 * @param collectionId id of the collection in context to which the operation is being performed.
	 * @throws InvalidCollectionException 
	 * 			In case of invalid collection id
	 * @throws QppServiceException
	 * 			Unhandled server exception
	 */
	public void validateApplicationPrivilegesForCollection(String operationToBePerformed, long collectionId) throws InvalidCollectionException, QppServiceException{
		long[] mandatoryPrivileges = getManadatoryPrivilegs(operationToBePerformed, methodPrivileges);
		ApplicablePrivileges applicablePrivileges = collectionService.getApplicablePrivileges(collectionId);
		comparePrivileges(mandatoryPrivileges, applicablePrivileges.getApplicationPrivileges());
	}
	
	/**
	 * This method validates application privileges in scenarios where no over-riding privileges are to be considered. 
	 * 
	 * @param operationToBePerformed
	 *            operation to be performed
	 * @throws PrivilegeNotFoundException 
	 * @throws UserClassNotFoundException 
	 * @throws QppServiceException
	 * 			Unhandled server exception
	 */
	public void validateApplicationPrivileges(String operationToBePerformed) throws UserClassNotFoundException, PrivilegeNotFoundException, UserPrivilegeException, QppServiceException {
		long[] mandatoryPrivileges = getManadatoryPrivilegs(operationToBePerformed, methodPrivileges);
		long[] userPrivileges = trusteeService.getApplicableApplicationPrivileges(mandatoryPrivileges);
		comparePrivileges(mandatoryPrivileges, userPrivileges);
	}
	
	private void comparePrivileges(long[] mandatoryPrivileges, long[] userPrivileges) throws PrivilegeNotFoundException,
			QppServiceException {
		Arrays.sort(userPrivileges);
		for (int i = 0; mandatoryPrivileges != null && i < mandatoryPrivileges.length; i++) {
			long mandatoryPrivilege = mandatoryPrivileges[i];
			if (Arrays.binarySearch(userPrivileges, mandatoryPrivilege) < 0) {
				String privilegeDefinitionName = privilegeService.getPrivilegeDefs(new long[] { mandatoryPrivilege })[0].getName();
				throw new UserPrivilegeException(UserPrivilegeExceptionCodes.USER_DOES_NOT_HAVE_THE_PRIVILEGE, new String[] {
						String.valueOf(mandatoryPrivilege), privilegeDefinitionName });
			}
		}
	}
	
	private long[] getLongArray(List<Long> privilegeIds) {
		int size = privilegeIds == null ? 0 : privilegeIds.size();
		long[] array = new long[size];
		for (int i = 0; i < size; i++) {
			array[i] = (Long) privilegeIds.get(i);
		}
		return array;
	}

	private long[] getManadatoryPrivilegs(String methodName, MethodPrivileges allMandatoryPrivileges) {
		 List<Method> list = allMandatoryPrivileges.getMethod();
		for (int i = 0; i < list.size(); i++) {
			Method methodPrivileges = list.get(i);
			if(methodPrivileges.getName().equalsIgnoreCase(methodName)){
				List<Long> privilegeIds = methodPrivileges.getPrivilegeId();
				return getLongArray(privilegeIds);
			}
		}
		 return null;
	}
	
	private long getCollectionId(long assetId, AttributeValue[] attributeValues) throws AssetNotFoundException, InvalidAttributeException,
			QppServiceException {
		for (int i = 0; attributeValues != null && i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			if (attributeValue.getAttributeId() == DefaultAttributes.COLLECTION && attributeValue.getAttributeValue() != null) {
				return ((DomainValue) attributeValue.getAttributeValue()).getId();
			}
		}
		if (assetId > 0) {
			AttributeValue collectionAttr = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.COLLECTION })[0];
			return ((DomainValue) collectionAttr.getAttributeValue()).getId();
		} else {
			throw new InvalidCollectionException(InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
		}
	}

	private long getStatusId(long assetId, AttributeValue[] attributeValues) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		for (int i = 0;attributeValues!= null && i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			if(attributeValue.getAttributeId() == DefaultAttributes.STATUS){
				return ((DomainValue)attributeValue.getAttributeValue()).getId();
			}
		}
		if (assetId > 0) {
			AttributeValue statusAttr = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.STATUS })[0];
			return ((DomainValue) statusAttr.getAttributeValue()).getId();
		}
		throw new StatusNotFoundException();
	}

	private long getContentTypeId(long assetId, AttributeValue[] attributeValues) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		for (int i = 0; attributeValues != null && i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			if (attributeValue.getAttributeId() == DefaultAttributes.CONTENT_TYPE) {
				DomainValue value = (DomainValue) attributeValue.getAttributeValue();
				return value.getId();
			}
		}
		if (assetId > 0) {
			AttributeValue contentTypeAttr = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.CONTENT_TYPE })[0];
			return ((DomainValue) contentTypeAttr.getAttributeValue()).getId();
		}
		throw new InvalidContentTypeException(InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
	}

	public boolean isAssetAssignedToOtherUser(long assetId) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {

		SessionContext sc = SessionContextHolder.getSessionContext();

		long loggedOnUserId = sc.getUserId();

		
		if(loggedOnUserId <= 0){
			//If user not logged On
			return false;
		}
		
		AttributeValue[] routeToAttributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.ROUTED_TO });

		long routedToTrustee = -1;
		if (routeToAttributeValues != null && routeToAttributeValues.length > 0) {
			routedToTrustee = ((DomainValue) routeToAttributeValues[0].getAttributeValue()).getId();
		}

		boolean isAssetAssignedToOtherUser = false;
		if (routedToTrustee <= 0) {
			/*
			 * In case an asset is routed to no one, it should be considered as assigned to others. 
			 */
			isAssetAssignedToOtherUser = true;
		} else {
			/*
			 * Asset is considered to be assigned to logged in user if routed to loggedInUser or any of its group.
			 */
			boolean isUser = trusteeService.getTrustee(routedToTrustee).isUser();
			if (isUser) {
				if(loggedOnUserId != routedToTrustee) {
					isAssetAssignedToOtherUser = true;
				}
			} else {
				isAssetAssignedToOtherUser = true;
				GroupInfo[] trusteeGroups = trusteeService.getUserGroups(loggedOnUserId);
				for (int i = 0; trusteeGroups != null && i < trusteeGroups.length; i++) {
					if (trusteeGroups[i].getId() == routedToTrustee) {
						isAssetAssignedToOtherUser = false;
						break;
					}
				}
			}
		}
		return isAssetAssignedToOtherUser;
	}
	
}

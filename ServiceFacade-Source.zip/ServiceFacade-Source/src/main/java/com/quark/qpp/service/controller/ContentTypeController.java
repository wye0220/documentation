/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentType;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.content.service.dto.ContentTypeOptions;
import com.quark.qpp.core.content.service.exceptions.ContentServiceExceptionCodes.InvalidContentTypeExceptionCodes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.ContentTypeAttributeMappingInfo;
import com.quark.qpp.service.xmlBinding.ContentTypeAttributeMappingInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeInfo;
import com.quark.qpp.service.xmlBinding.ContentTypeInfoList;

public class ContentTypeController {

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private AttributeService attributeService;

	private final Logger logger = Logger.getLogger(this.getClass());

	public ContentTypeInfoList createContentTypes(ContentTypeInfoList contentTypeInfoList)
			throws InvalidContentTypeException, QppServiceException {
		if (contentTypeInfoList != null && contentTypeInfoList.getContentTypeInfo() != null) {
			Iterator<ContentTypeInfo> it = contentTypeInfoList.getContentTypeInfo().iterator();
			ContentTypeInfoList createdContentTypes = new ContentTypeInfoList();
			/** Create contentType one by one if list of content type is given. */
			while (it.hasNext()) {
				ContentTypeInfo contentInfo = it.next();
					long newContentTypeId = createContentType(contentInfo, 0);
				if(newContentTypeId > 0){
					ContentTypeInfo newContentTypeInfo = getContentType(String.valueOf(newContentTypeId)).getContentTypeInfo().get(0);
					createdContentTypes.getContentTypeInfo().add(newContentTypeInfo);
				}
			}
			return createdContentTypes;
		}else {
			throw new InvalidContentTypeException(InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
		}
		
	}

	private long createContentType(ContentTypeInfo contentTypeInfo, long parentContentTypeId) throws InvalidContentTypeException,
			QppServiceException {
		long contentTypeId = -1;
		String contentTypeHierarchy = contentTypeInfo.getContentTypeHierarchy();
		if((contentTypeInfo.getName() != null && contentTypeInfo.getName().equalsIgnoreCase("System")) || (contentTypeInfo.getContentTypeHierarchy()!=null && contentTypeInfo.getContentTypeHierarchy().equalsIgnoreCase("System;")) 
				|| (contentTypeInfo.getId()!=null && contentTypeInfo.getId()==DefaultContentTypes.SYSTEM)){
			contentTypeId = DefaultContentTypes.SYSTEM;
		}else{
			if(parentContentTypeId <= 0){
				if(contentTypeHierarchy != null &&  !contentTypeHierarchy.isEmpty()){
					parentContentTypeId = getParentContentTypeId(contentTypeHierarchy);
				}else if(contentTypeInfo.getParentContentTypeId()>0){
					parentContentTypeId = contentTypeInfo.getParentContentTypeId();
				}else{
					logger.error("Error while creating content type with name " + contentTypeInfo.getName()
							+ " due to the missing content type heirarchy & parent content type id.");
					return -1;
				}
			}
			contentTypeId = facadeUtility.getContentTypeWithName(contentTypeInfo.getName(), parentContentTypeId);
		}
		
		/** Create content-type only if its not available */
		if (contentTypeId < 0) {
			try {
				/**
				 * Content type options to be used for applying various settings(like attributes, workflows, forms etc.) from the parent
				 * content type.
				 */
				ContentTypeOptions contentTypeOptions = new ContentTypeOptions();
				contentTypeOptions.setApplyParentRevisionSettings(true);
				contentTypeOptions.setApplyParentPrivileges(true);
				contentTypeOptions.setApplyParentWorkflows(true);
				contentTypeOptions.setApplyParentForms(true);
				contentTypeOptions.setApplyParentAttributesMapping(true);
				/** Boolean flag indicating whether given content type being created is extensible for creating child content types. */
				boolean isExtensible = false;
				if(contentTypeInfo.isExtensible() != null)
					isExtensible = contentTypeInfo.isExtensible();
				contentTypeId = contentStructureService.createContentType(parentContentTypeId, contentTypeInfo.getName(),
						contentTypeOptions, isExtensible);
				try {
					setContentTypeAttributes(contentTypeId, contentTypeInfo);
				} catch (QppServiceException e) {
					logger.error("Error while mapping attributes to content type with name: " + contentTypeInfo.getName()
							+ " under heirarchy: " + contentTypeHierarchy, e);
				}
			} catch (QppServiceException e) {
				logger.error("Error while creating content type with name: " + contentTypeInfo.getName() + " under heirarchy: "
						+ contentTypeHierarchy, e);
				/** Cannot continue as it will effect hierarchy structure */
				return -1;
			}
		}else{
			logger.info("Content type with name: "+contentTypeInfo.getName()+" already exists under parent content type with id "+parentContentTypeId);
		}
		if (contentTypeInfo.getContentTypeInfoList()!= null && contentTypeInfo.getContentTypeInfoList().getContentTypeInfo()!= null) {
			/** Check for child content Types */
			ContentTypeInfoList childContentTypeInfoList = contentTypeInfo.getContentTypeInfoList();
			Iterator<ContentTypeInfo> iterator = childContentTypeInfoList.getContentTypeInfo().iterator();
			while (iterator.hasNext()) {
				ContentTypeInfo contentTypeInfoToBeCreated = iterator.next();
				createContentType(contentTypeInfoToBeCreated, contentTypeId);
			}
		}
		return contentTypeId;
	}

	private long getParentContentTypeId(String contentTypeHierarchy) throws QppServiceException {
		// ---> System;Asset;Document;App Studio Package;sample;
		String[] contentTypes = contentTypeHierarchy.split(";");
		StringBuilder parentHierarchy = new StringBuilder();
		for (int i = 0; i < contentTypes.length - 1; i++) {
			parentHierarchy.append(contentTypes[i]).append(";");
		}
		return facadeUtility.getContentTypeIdForHierarchy(parentHierarchy.toString());
	}

	private void setContentTypeAttributes(long contentTypeId, ContentTypeInfo contentTypeInfo) throws AttributeNotFoundException,
			InvalidContentTypeException, QppServiceException {
		/** Check if ContentType attribute mapping information is available */
		if (contentTypeInfo.getContentTypeAttributeMappingInfoList() != null) {
			/** Update Attribute Ids from system */
			if(contentTypeInfo.getContentTypeAttributeMappingInfoList().getContentTypeAttributeMappingInfo()!=null){
				updateAttributeIds(contentTypeInfo.getContentTypeAttributeMappingInfoList(), contentTypeId);
			}
			ContentTypeAttributeMapping[] contentTypeAttributeMapping = objectTransformer.transform(contentTypeInfo
					.getContentTypeAttributeMappingInfoList());
			contentStructureService.setContentTypeAttributes(contentTypeId, contentTypeAttributeMapping);
		}
	}

	private void updateAttributeIds(ContentTypeAttributeMappingInfoList contentTypeAttributeMappingInfoList,
			long contentTypeId) throws AttributeNotFoundException, QppServiceException {
		Iterator<ContentTypeAttributeMappingInfo> iterator = contentTypeAttributeMappingInfoList.getContentTypeAttributeMappingInfo()
				.iterator();
		while (iterator.hasNext()) {
			ContentTypeAttributeMappingInfo contentTypeAttributeMappingInfo = iterator.next();
			if(contentTypeAttributeMappingInfo.getValue()!=null && !contentTypeAttributeMappingInfo.getValue().isEmpty()){
				contentTypeAttributeMappingInfo.setAttributeId(attributeService.getAttributeByName(
						contentTypeAttributeMappingInfo.getValue()).getId());
			}
		}
	}
	
	public void deleteContentType(String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException {
		long contentTypeId = -1;
		try {
			contentTypeId = Long.parseLong(contentTypeIdOrName);
		} catch (NumberFormatException e) {
			contentTypeId = facadeUtility.getUniqueContentTypeWithName(contentTypeIdOrName);
		}
		contentStructureService.deleteContentType(contentTypeId);
	}

	public ContentTypeInfoList updateContentTypes(ContentTypeInfoList contentTypeInfoList)
			throws AttributeNotFoundException, InvalidContentTypeException, QppServiceException {
		ContentTypeInfoList updatedContentTypes = new ContentTypeInfoList();
		if (contentTypeInfoList != null && contentTypeInfoList.getContentTypeInfo() != null) {
			List<ContentTypeInfo> list = contentTypeInfoList.getContentTypeInfo();
			Iterator<ContentTypeInfo> it = list.iterator();
			/** Update contentType one by one if list of content types is provided. */
			while (it.hasNext()) {
				ContentTypeInfo info = it.next();
					long updatedContentTypeId = updateContentType(info);
				if(updatedContentTypeId > 0){
					ContentTypeInfo updatedContentTypeInfo = getContentType(String.valueOf(updatedContentTypeId)).getContentTypeInfo().get(0);
					updatedContentTypes.getContentTypeInfo().add(updatedContentTypeInfo);
				}
			}
		}else {
			throw new InvalidContentTypeException(InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
		}
		return updatedContentTypes;
	}

	private long updateContentType(ContentTypeInfo contentTypeInfo) throws AttributeNotFoundException, InvalidContentTypeException,
			QppServiceException {
		long contentTypeId = 0;
		try {
			if (contentTypeInfo.getId() == null) {
				/** Content type hierarchy will contain old content name */
				String contentTypeHierarchy = contentTypeInfo.getContentTypeHierarchy();
				if (contentTypeHierarchy != null) {
					contentTypeId = facadeUtility.getContentTypeIdForHierarchy(contentTypeHierarchy);
				}
			} else {
				contentTypeId = contentTypeInfo.getId();
			}
			if(contentTypeInfo.getName()!=null && !contentTypeInfo.getName().isEmpty()){
				contentStructureService.renameContentType(contentTypeId, contentTypeInfo.getName());
			}
			setContentTypeAttributes(contentTypeId, contentTypeInfo);
		} catch (QppServiceException e) {
			logger.error("Error while updating content type with id: " + contentTypeInfo.getId() + " and content type hierarchy "
					+ contentTypeInfo.getContentTypeHierarchy(), e);
			/** Cannot continue as it will effect hierarchy structure.  */
			// return;
		}

		/** Check for child content Types */
		if(contentTypeInfo.getContentTypeInfoList()!=null && contentTypeInfo.getContentTypeInfoList().getContentTypeInfo()!=null){
			Iterator<ContentTypeInfo> iterator = contentTypeInfo.getContentTypeInfoList().getContentTypeInfo().iterator();
			while (iterator.hasNext()) {
				ContentTypeInfo contentTypeInfoToBeUpdated = iterator.next();
				updateContentType(contentTypeInfoToBeUpdated);
			}
		}
		return contentTypeId;
	}

	public ContentTypeInfoList getAllContentTypes() throws QppServiceException {
		/** Every ContentType object has information about its child content types. */
		ContentType contentType = contentStructureService.getRootContentType();
		ContentTypeInfoList contentTypeInfoList = objectTransformer.transform(new ContentType[] { contentType });
		return contentTypeInfoList;
	}

	public ContentTypeInfoList getContentType(String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException {
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrName);
		ContentType contentType = contentStructureService.getContentType(contentTypeId);
		ContentTypeInfo contentTypeInfo = objectTransformer.transform(contentType);
		ContentTypeInfoList contentTypeInfoList = new ContentTypeInfoList();
		contentTypeInfoList.getContentTypeInfo().add(contentTypeInfo);
		return contentTypeInfoList;
	}

	public void setAttributes(String[] contentTypesIdOrPathOrName, String[] attributesIdOrName) throws InvalidContentTypeException, AttributeNotFoundException, QppServiceException {
		long[] contentTypeIds = facadeUtility.getContentTypeIds(contentTypesIdOrPathOrName);
		if(contentTypeIds == null || contentTypeIds.length ==0){
			throw new InvalidContentTypeException(new String[]{"No content type specified to set contenttype-attribute mapping."});
		}
		long[] attributeIds = facadeUtility.getAttributeIds(attributesIdOrName);
		ContentTypeAttributeMapping[] contentTypeAttributeMappings = new ContentTypeAttributeMapping[attributeIds.length];
		for (int i = 0; i < attributeIds.length; i++) {
			ContentTypeAttributeMapping contentTypeAttributeMapping = new ContentTypeAttributeMapping();
			contentTypeAttributeMapping.setAttributeId(attributeIds[i]);
			contentTypeAttributeMapping.setValueMandatory(false);
			contentTypeAttributeMappings[i] = contentTypeAttributeMapping;
		}
		for (int i = 0; i < contentTypeIds.length; i++) {
			contentStructureService.setContentTypeAttributes(contentTypeIds[i], contentTypeAttributeMappings);
		}
	}

}

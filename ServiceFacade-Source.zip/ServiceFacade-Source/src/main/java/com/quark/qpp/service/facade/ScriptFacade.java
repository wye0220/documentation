/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.scheduler.service.dto.Schedule;
import com.quark.qpp.scheduler.service.exceptions.InvalidScheduleException;
import com.quark.qpp.scheduler.service.exceptions.ScheduleInUseException;
import com.quark.qpp.scheduler.service.exceptions.SchedulerException;
import com.quark.qpp.scheduler.service.local.SchedulerService;
import com.quark.qpp.script.service.constants.TriggerTypes;
import com.quark.qpp.script.service.dto.Script;
import com.quark.qpp.script.service.dto.ScriptExecutionDetails;
import com.quark.qpp.script.service.exceptions.EmbeddedScriptException;
import com.quark.qpp.script.service.exceptions.InvalidScriptException;
import com.quark.qpp.script.service.exceptions.InvalidScriptExecutionDetailsException;
import com.quark.qpp.script.service.exceptions.LanguageNotSupportedException;
import com.quark.qpp.script.service.exceptions.ScriptNotFoundException;
import com.quark.qpp.script.service.local.ScriptService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.ScheduleInfo;
import com.quark.qpp.service.xmlBinding.ScriptExecutionInfo;
import com.quark.qpp.service.xmlBinding.ScriptInfo;
import com.quark.qpp.service.xmlBinding.ScriptInfoList;

/**
 * Facade for using scripting capabilities of QPP Server.<BR>
 * A script, in any of the supported languages, can be be executed. 
 * The script content can also be retrieved in the form java.lang.String.
 * 
 */
@Controller("scriptFacade")
@RequestMapping("/scripts")
public class ScriptFacade {

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private ScriptService scriptService;
	
	@Autowired
	private SchedulerService schedulerService;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * Returns the contents of the given script in the form of java.lang.String.
	 * 
	 * @param scriptReference
	 *            Name or Id of the script to be fetched. Name would be given preference. Script would be searched
	 *            first with the given name and if not found it will be searched by Id.
	 * @return Script contents in the form of java.lang.String.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{scriptReference}")
	@WebReturnType("textView")
	public String getScriptContent(@PathVariable String scriptReference) throws QppServiceException {
		long scriptId = getScriptId(scriptReference);
		Script script = scriptService.getScript(scriptId);
		return script.getContent();
	}

	/**
	 * Executes a given script method with the given parameter list.<BR>
	 * The complete script is evaluated before the specified method is invoked. So we recommend that this method be used
	 * for scripts which define objects and functions but do not invoke them from the root level of the script itself.
	 * In case the methodName is null, then the complete script will be executed.
	 * 
	 * @param scriptReference
	 *            Name or Id of the script to be executed. Name would be given preference. Script would be searched first with the given name and if not found it will be searched by Id. 
	 * @param methodName
	 *            Name of the script method to be executed.  In case the methodName is null, then the complete script will be executed.
	 * @param scriptParams
	 *            Array of script parameters
	 * @return The result of execution in form of java.lang.String. Empty string if no explicit return value.
	 * @throws ScriptNotFoundException
	 *             If the script given by the given name or id does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(value = "/{scriptReference}", params = "op=execute")
	@WebReturnType("textView")
	public String executeScript(@PathVariable String scriptReference, @RequestParam(value = "methodname", required = false) String methodName,
			@WebArrayParam(value = "parameters") String[] scriptParams) throws ScriptNotFoundException, QppServiceException {
		long scriptId = getScriptId(scriptReference);
		if (methodName != null && !methodName.isEmpty()) {
			//Execute a script method
			return scriptService.executeScriptWithParameters(scriptId, methodName, scriptParams);
		} else {
			//Execute the whole script
			return scriptService.executeScript(scriptId);
		}
	}
	
	/**
	 * Get all scripts stored at the platform server.
	 * 
	 * @return List of scripts.
	 * @throws ScriptNotFoundException
	 *             If the content file of any of the scripts is not found at the file system.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType("xmlView")
	public ScriptInfoList getAllScripts() throws ScriptNotFoundException, QppServiceException {
		Script[] allScripts = scriptService.getAllScripts();
		return objectTransformer.transform(allScripts);
	}
	
	
	/**
	 * Creates a new script with the given content & name at the platform server. <br>
	 * In the script execution info it is mandatory to mention the trigger type & corresponding eventInfo or scheduleInfo depending upon the trigger type.
	 * <br>
	 * TriggerType can have values like MANUAL/EVENT_DRIVEN/SCHEDULED. The default value is MANUAL.
	 * For a {@link TriggerTypes#MANUAL} trigger type, no additional info is required. <br>
	 * 
	 * If the trigger type is EVENT_DRIVEN, specify a valid EVENT TYPE like
	 * ASSET/ARTICLE/ASSET/DOMAIN/ATTRIBUTE/ASSET_RELATION/RELATION_TYPE/....etc and a change type depending upon the EVENT TYPE 
	 * for example : ALL, ASSET ADDED, ASSET CHANGED, ASSET DELETED,...,DOMAIN ADDED, DOMAIN DELETED,..etc...
	 * <br>
	 * If the trigger type is SCHEDULED, specify the schedule id of an already existing saved schedule or specify cron expressions &
	 * scheduleGroup name to create a new schedule & associate that schedule with this new script. <br> <br>
	 * 
	 * <pre>
	 * Sample ScriptExecutionInfo for manual trigger:
	 * &lt;scriptExecutionInfo triggerType="MANUAL"/&gt;<br>
	 * 
	 * Sample ScriptExecutionInfo for Event based trigger:
	 * &lt;scriptExecutionInfo triggerType="EVENT_DRIVEN"&gt;
	 * 	&lt;eventInfo eventType="FORM" eventChangeType="FORM ADDED"/&gt;
	 * &lt;/scriptExecutionInfo&gt;
	 * 	
	 * Sample ScriptExecutionInfo for schedule based trigger:
	 * &lt;scriptExecutionInfo triggerType="SCHEDULED"&gt;
	 * 	&lt;scheduleInfo scheduleGroup="My schedule group" scheduleId="2"&gt;
	 * 		&lt;cronExpressionList&gt;
	 * 			&lt;cronExpression&gt;0 30 22 27 10 ? 2014&lt;/cronExpression&gt;
	 * 		&lt;/cronExpressionList&gt;
	 * 	&lt;/scheduleInfo&gt;
	 * &lt;/scriptExecutionInfo&gt;
	 * </pre>
	 * 
	 * @param inputStream
	 *            input stream of the script content to be saved at the platform server.
	 * @param name
	 *            name with which the script is to be saved.
	 * @param scriptingLanguage
	 *            scripting language that may be javascript/groovy. The default value is javascript.
	 * @param scriptExecutionInfo
	 *            execution details of the script.<br>
	 * @return Id of the newly created script
	 * @throws InvalidScriptException
	 *             If the script is invalid. Reasons for invalid scripts are in InvalidScriptExceptionCodes.
	 * @throws LanguageNotSupportedException
	 *             If the scripting language is not supported.
	 * @throws InvalidScriptExecutionDetailsException
	 *             If the execution details specified are invalid.
	 * @throws EmbeddedScriptException
	 *             Thrown in case of I/O exception.
	 * @throws InvalidScheduleException
	 *             If the schedule to be created has incorrect data. More information on incorrect data can be obtained from the
	 *             getExceptionCode() method.
	 * @throws SchedulerException
	 *             Other scheduler exception based on the scheduling engine used.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{scriptName}", params = "op=create")
	@WebReturnType("xmlView")
	public ScriptInfo createScript(@WebInputStream InputStream inputStream, @PathVariable(value = "scriptName") String scriptName,
			@RequestParam(value = "language", defaultValue = "javascript") String scriptingLanguage,
			@WebSerializedParam(value = "scriptexecutioninfo") ScriptExecutionInfo scriptExecutionInfo) throws InvalidScriptException,
			LanguageNotSupportedException, InvalidScriptExecutionDetailsException, EmbeddedScriptException, InvalidScheduleException,
			SchedulerException, QppServiceException {
		Script script = new Script();
		// Set script name & scripting language
		script.setName(scriptName);
		script.setLanguage(scriptingLanguage);
		try {
			// set script content
			script.setContent(convertStreamToString(inputStream));
		} catch (UnsupportedEncodingException e) {
			throw new QppServiceException(e);
		}
		/*
		 * Fetch & set the script execution details
		 */
		ScriptExecutionDetails scriptExecutionDetails = new ScriptExecutionDetails();
		if (scriptExecutionInfo != null && scriptExecutionInfo.getTriggerType() != null) {
			String triggerType = scriptExecutionInfo.getTriggerType();
			if (triggerType.equalsIgnoreCase("SCHEDULED")) {
				ScheduleInfo scheduleInfo = scriptExecutionInfo.getScheduleInfo();
				if (scheduleInfo != null) {
					Long scheduleId = (long) 0;
					if (scheduleInfo.getScheduleGroup() != null) {
						Schedule schedule = objectTransformer.transform(scheduleInfo);
						long newScheduleId = schedulerService.createSchedule(schedule);
						scheduleId = newScheduleId;
					} else if (scheduleInfo.getId() != null) {
						scheduleId = scheduleInfo.getId();
					}
					scriptExecutionDetails.setScheduleId(scheduleId);
				}
				scriptExecutionDetails.setTriggerType(TriggerTypes.SCHEDULED);
			} else if (triggerType.equalsIgnoreCase("EVENT_DRIVEN") && scriptExecutionInfo.getEventInfo() != null) {
				scriptExecutionDetails.setTriggerType(TriggerTypes.EVENT_DRIVEN);
				scriptExecutionDetails.setEventId(scriptExecutionInfo.getEventInfo().getEventType());
				scriptExecutionDetails.setEventChangeType(scriptExecutionInfo.getEventInfo().getEventChangeType());
			} else if (triggerType.equalsIgnoreCase("MANUAL")) {
				scriptExecutionDetails.setTriggerType(TriggerTypes.MANUAL);
			}
		} else {
			scriptExecutionDetails.setTriggerType(TriggerTypes.MANUAL);
		}
		script.setScriptExecutionDetails(scriptExecutionDetails);
		long scriptId = scriptService.createScript(script);
		Script scriptCreated = scriptService.getScript(scriptId);
		return objectTransformer.transform(scriptCreated);
	}

	/**
	 * Deletes a script.
	 * 
	 * @param scriptReference
	 *            Name or Id of the script to be executed. The input will be assumed to be a name first & if script with given name doesn't
	 *            exist, then input will be assumed to be an id.
	 * @throws ScriptNotFoundException
	 *             In case there doesn't exist script with the given name or id.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{scriptReference}", params = "op=delete")
	public void deleteScript(@PathVariable("scriptReference") String scriptReference) throws ScriptNotFoundException, QppServiceException {
		long scriptId = getScriptId(scriptReference);
		Script scriptToBeDeleted = scriptService.getScript(scriptId);
		scriptService.deleteScript(scriptId);
		ScriptExecutionDetails scriptExecutionDetails = scriptToBeDeleted.getScriptExecutionDetails();
		if (scriptExecutionDetails.getTriggerType() == TriggerTypes.SCHEDULED) {
			try {
				schedulerService.deleteSchedule(scriptExecutionDetails.getScheduleId());
			} catch (ScheduleInUseException e) {
				logger.debug("Error while deleting schedule because schedule is being referred by another script in the platform.", e);
			}
		}
	}

	private String convertStreamToString(InputStream is)
			throws UnsupportedEncodingException {
		/*
		 * To conver the InputStream to String we use the
		 * BufferedReader.readLine() method. We iterate until the BufferedReader
		 * return null which means there's no more data to read. Each line will
		 * appended to a StringBuilder and returned as String.
		 */
		BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"));
		StringBuilder sb = new StringBuilder();
		String line = null;
		 String newLine = System.getProperty("line.separator");
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
				sb.append(newLine);
			}
		} catch (IOException e) {
		} finally {
			try {
				reader.close();
				is.close();				
			} catch (IOException e) {
			}
		}
		return sb.toString();
	}
	
	
	private long getScriptId(String scriptReference) throws QppServiceException {
		long scriptId = -1;
		try {
			//search for script by given name
			Script script = scriptService.getScriptByName(scriptReference);
			scriptId = script.getId();
		} catch (ScriptNotFoundException e) {
			// ignore
		}
		if (scriptId == -1) {
			try {
				scriptId = Long.parseLong(scriptReference);
			} catch (NumberFormatException e) {
				throw new ScriptNotFoundException();
			}
		}
		return scriptId;
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            Class of the exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

}

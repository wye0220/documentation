/*****************************************************************************
** Quark Publishing
**
** �1986-2014 Quark Software Inc. All rights reserved.
**
*****************************************************************************/
package com.quark.qpp.service.objectTransformer;

import java.lang.reflect.InvocationTargetException;

import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.ArticleComponent;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetRendition;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeDomain;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.clipboard.dto.ClipboardChannelMapping;
import com.quark.qpp.core.clipboard.dto.ClipboardDataInfo;
import com.quark.qpp.core.clipboard.dto.ClipboardFormat;
import com.quark.qpp.core.collection.service.dto.Collection;
import com.quark.qpp.core.collection.service.dto.CollectionGroup;
import com.quark.qpp.core.collection.service.dto.CollectionInfo;
import com.quark.qpp.core.collection.service.dto.CollectionUser;
import com.quark.qpp.core.collection.service.dto.JobJacket;
import com.quark.qpp.core.collection.service.dto.RevisionControl;
import com.quark.qpp.core.collection.service.dto.Routing;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.configuration.service.dto.CustomXmlMimeType;
import com.quark.qpp.core.content.service.dto.ContentType;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.content.service.dto.ContentTypeInfo;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.form.service.dto.Form;
import com.quark.qpp.core.preference.service.dto.FavoriteItem;
import com.quark.qpp.core.preference.service.dto.Preference;
import com.quark.qpp.core.preference.service.dto.PreferenceValue;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceNotFoundException;
import com.quark.qpp.core.privilege.service.dto.ApplicablePrivileges;
import com.quark.qpp.core.privilege.service.dto.ContentTypePrivileges;
import com.quark.qpp.core.privilege.service.dto.PrivilegeDefinition;
import com.quark.qpp.core.privilege.service.dto.PrivilegeGroupDefinition;
import com.quark.qpp.core.privilege.service.dto.UserClass;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeGroupNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.publishing.service.dto.PublishingChannel;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.SortInfo;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.relation.service.dto.RelationType;
import com.quark.qpp.core.relation.service.dto.RelationTypeAttributeMapping;
import com.quark.qpp.core.security.service.dto.Group;
import com.quark.qpp.core.security.service.dto.ImportedGroupInfo;
import com.quark.qpp.core.security.service.dto.Session;
import com.quark.qpp.core.security.service.dto.Trustee;
import com.quark.qpp.core.security.service.dto.User;
import com.quark.qpp.core.security.service.exceptions.GroupNotFoundException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.storage.service.dto.StorageRepository;
import com.quark.qpp.core.userprovisioning.service.dto.LdapAttributeValue;
import com.quark.qpp.core.userprovisioning.service.dto.LdapProfile;
import com.quark.qpp.core.userprovisioning.service.dto.LdapQueryDefinition;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.workflow.service.dto.AttributeConstraint;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.StatusRoutingUserClasses;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.UserRedliningColor;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.office.service.dto.Chart;
import com.quark.qpp.office.service.dto.NamedRange;
import com.quark.qpp.office.service.dto.PowerPointSlide;
import com.quark.qpp.office.service.dto.Table;
import com.quark.qpp.office.service.dto.VisioPage;
import com.quark.qpp.office.service.dto.Worksheet;
import com.quark.qpp.scheduler.service.dto.Schedule;
import com.quark.qpp.scheduler.service.exceptions.ScheduleNotFoundException;
import com.quark.qpp.script.service.dto.Script;
import com.quark.qpp.service.xmlBinding.ApplicablePrivilegesInfo;
import com.quark.qpp.service.xmlBinding.ArticleComponentInfoList;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AssetRelationInfo;
import com.quark.qpp.service.xmlBinding.AssetRelationInfoList;
import com.quark.qpp.service.xmlBinding.AssetRenditionInfoList;
import com.quark.qpp.service.xmlBinding.AssetVersionList;
import com.quark.qpp.service.xmlBinding.AttributeConstraintsInfoList;
import com.quark.qpp.service.xmlBinding.AttributeDomainInfo;
import com.quark.qpp.service.xmlBinding.AttributeDomainInfoList;
import com.quark.qpp.service.xmlBinding.AttributeInfo;
import com.quark.qpp.service.xmlBinding.AttributeInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.ChartInfoList;
import com.quark.qpp.service.xmlBinding.ClipboardChannelMappingInfo;
import com.quark.qpp.service.xmlBinding.ClipboardChannelMappingInfoList;
import com.quark.qpp.service.xmlBinding.ClipboardDataInfoList;
import com.quark.qpp.service.xmlBinding.ClipboardFormatInfo;
import com.quark.qpp.service.xmlBinding.ClipboardFormatInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeAttributeMappingInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypePrivList;
import com.quark.qpp.service.xmlBinding.DomainValueList;
import com.quark.qpp.service.xmlBinding.FavoriteItemlist;
import com.quark.qpp.service.xmlBinding.FormInfo;
import com.quark.qpp.service.xmlBinding.GroupInfo;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.ImportedGroupInfoList;
import com.quark.qpp.service.xmlBinding.JobJacketInfo;
import com.quark.qpp.service.xmlBinding.JobJacketInfoList;
import com.quark.qpp.service.xmlBinding.LdapAttributeInfo;
import com.quark.qpp.service.xmlBinding.LdapAttributeInfoList;
import com.quark.qpp.service.xmlBinding.LdapProfileInfo;
import com.quark.qpp.service.xmlBinding.LdapProfileInfoList;
import com.quark.qpp.service.xmlBinding.LdapSearchInfo;
import com.quark.qpp.service.xmlBinding.LdapSearchInfoList;
import com.quark.qpp.service.xmlBinding.MimeTypeInfoList;
import com.quark.qpp.service.xmlBinding.NameId;
import com.quark.qpp.service.xmlBinding.NameIdList;
import com.quark.qpp.service.xmlBinding.NameValueList;
import com.quark.qpp.service.xmlBinding.NamedRangeInfoList;
import com.quark.qpp.service.xmlBinding.PowerPointSlideInfoList;
import com.quark.qpp.service.xmlBinding.PreferenceInfoList;
import com.quark.qpp.service.xmlBinding.PreferenceValueList;
import com.quark.qpp.service.xmlBinding.Privilege;
import com.quark.qpp.service.xmlBinding.PrivilegeDefinitionList;
import com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinitionList;
import com.quark.qpp.service.xmlBinding.PublishingChannelList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.QueryResultInfo;
import com.quark.qpp.service.xmlBinding.RedlineInfo;
import com.quark.qpp.service.xmlBinding.RedlineInfoList;
import com.quark.qpp.service.xmlBinding.RelationAttributeList;
import com.quark.qpp.service.xmlBinding.RelationTypeInfo;
import com.quark.qpp.service.xmlBinding.RelationTypeInfoList;
import com.quark.qpp.service.xmlBinding.RevisionControlInfoList;
import com.quark.qpp.service.xmlBinding.RoleInfo;
import com.quark.qpp.service.xmlBinding.RoleInfoList;
import com.quark.qpp.service.xmlBinding.RoutingInfo;
import com.quark.qpp.service.xmlBinding.RoutingInfoList;
import com.quark.qpp.service.xmlBinding.ScheduleInfo;
import com.quark.qpp.service.xmlBinding.ScriptInfo;
import com.quark.qpp.service.xmlBinding.ScriptInfoList;
import com.quark.qpp.service.xmlBinding.SearchInfo;
import com.quark.qpp.service.xmlBinding.SearchInfoList;
import com.quark.qpp.service.xmlBinding.SessionInfo;
import com.quark.qpp.service.xmlBinding.SessionInfoList;
import com.quark.qpp.service.xmlBinding.SortInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusRoutingRolesInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfo;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfo;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfoList;
import com.quark.qpp.service.xmlBinding.TableInfoList;
import com.quark.qpp.service.xmlBinding.TrusteeInfo;
import com.quark.qpp.service.xmlBinding.TrusteeInfoList;
import com.quark.qpp.service.xmlBinding.UserInfo;
import com.quark.qpp.service.xmlBinding.UserInfoList;
import com.quark.qpp.service.xmlBinding.VisioPageInfoList;
import com.quark.qpp.service.xmlBinding.WorkflowInfo;
import com.quark.qpp.service.xmlBinding.WorkflowInfoList;
import com.quark.qpp.service.xmlBinding.WorksheetInfo;
import com.quark.qpp.service.xmlBinding.WorksheetInfoList;


/**
 * Provides the functionality to transform the QPS compliant objects into
 *  marshaller complaint objects.
 *
 */
public interface ObjectTransformer {

	/**
	 * Returns marshaller compliant object for {@link Session}.
	 * @param session
	 * @return
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public SessionInfo transform(Session session);

	/**
	 * Returns marshaller compliant object for {@link Session} array.
	 * @param sessions
	 * @return
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public SessionInfoList transform(Session[] sessions);

	/**
	 * Returns marshaller compliant object for {@link Asset_Jaxb}.
	 * @param asset
	 * @return
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 */
	public AssetInfo transform(Asset asset) throws AttributeNotFoundException, QppServiceException;


	/**
	 * Returns marshaller compliant object for {@link Asset} array.
	 * @param assets
	 * @return
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 */
	public AssetInfoList transform(Asset[] assets) throws AttributeNotFoundException, QppServiceException;


	/**
	 * Returns marshaller compliant object for {@link AttributeValue} array.
	 * @param attributeValues
	 * @return
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 */
	public AttributeValueList transform(AttributeValue[] attributeValues) throws AttributeNotFoundException, QppServiceException;

	/**
	 * Transforms AttributeValueList to an array of {@link AttributeValue}; <br>
	 * The value of an attribute is derived from the {@link com.quark.qpp.service.xmlBinding.AttributeValue#getValue()} field.<br>
	 * For domain type attributes, the value is evaluated in the following manner:
	 * 1. First getValue() is evaluated. For attributes belonging to hierarchical domain, the value is considered as name & first matching domain value with the same name is considered. If name is not mentioned then complete path of the value for example: Departments;Enterprise;R&D is expected.     
	 * 2. If value is null or empty then value ID is considered
	 * For example: Formats for setting domain values are : <br>
	 * <attributeValue id="501" name="Departments" type="popup" valueId="3" multiValued="true"></attributeValue> or <br>
	 * <attributeValue id="501" name="Departments" type="popup" multiValued="true">Enterprise</attributeValue> or <br>
	 * <attributeValue id="501" name="Departments" type="popup" multiValued="true">Enterprise;Client;QA</attributeValue>
	 * 
	 * @param attributeValueList
	 * @return
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 */
	public AttributeValue[] transform(AttributeValueList attributeValueList) throws AttributeNotFoundException, QppServiceException;

	AssetRelationInfo transform(AssetRelation assetRelation) throws AttributeNotFoundException, QppServiceException;

	public AssetRelationInfoList transform(AssetRelation[] assetRelations) throws AttributeNotFoundException, QppServiceException;

	public AssetVersionList transform(AssetVersion[] assetVersions);

	public NameIdList transform(NameId[] nameIds);

	public AssetRenditionInfoList transform(AssetRendition[] assetRenditions) throws QppServiceException ;

	public AssetRelation[] transform(AssetRelationInfoList assetRelationInfoList) throws AttributeNotFoundException, QppServiceException;

	public AssetRendition[] transform(AssetRenditionInfoList assetRenditionInfoList) throws QppServiceException;

	public QppServiceExceptionInfo transform(QppServiceException qppServiceException);

	// Collection facade

	public com.quark.qpp.service.xmlBinding.CollectionInfo transform(Collection collection) throws AttributeNotFoundException, QppServiceException;

	public com.quark.qpp.service.xmlBinding.CollectionInfoList transform(Collection[] collections) throws AttributeNotFoundException,
			QppServiceException;

	public WorkflowInfo transform(Workflow workflow, boolean getDetailedInfo) throws QppServiceException;

	public WorkflowInfoList transform(Workflow[] workflows, boolean getDetailedInfo) throws QppServiceException;

	public com.quark.qpp.service.xmlBinding.CollectionInfo transform(CollectionInfo collectionInfo) throws InvalidContentTypeException,
			QppServiceException;

	public JobJacketInfo transform(JobJacket jobJacket, boolean getDetailedInfo, long collectionId) throws UserNotFoundException, QppServiceException;

	public JobJacketInfoList transform(JobJacket[] jobJackets, boolean getDetailedInfo, long collectionId) throws UserNotFoundException, QppServiceException;

	public GroupInfoList transform(CollectionGroup[] collectionGroups, boolean getDetailedInfo) throws GroupNotFoundException, QppServiceException;

	public UserInfoList transform(CollectionUser[] collectionUsers);

	public CollectionUser[] transform(UserInfoList collectionUserInfoList) throws UserClassNotFoundException, QppServiceException;

	public RevisionControlInfoList transform(RevisionControl[] revisionControls) throws InvalidContentTypeException, QppServiceException;

	public RoutingInfoList transform(Routing[] routings) throws TrusteeNotFoundException, QppServiceException;

	public RoleInfo transform(UserClass userClass) throws PrivilegeNotFoundException, InvalidContentTypeException, QppServiceException;

	public RevisionControl[] transform(RevisionControlInfoList revisionControlInfoList) throws InvalidContentTypeException, QppServiceException;

	public Routing[] transform(RoutingInfoList routingInfoList);

	public GroupInfo transform(Group group, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException ;
	
	public GroupInfo transform(com.quark.qpp.core.security.service.dto.GroupInfo groupInfo, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException ;

	public GroupInfoList transform(Group[] groups, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException;

	public GroupInfoList transform(com.quark.qpp.core.security.service.dto.GroupInfo[] groups, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException;
	
	// Query facade

	public QueryResultInfo transform(QueryResultElement[] queryResultElements, long contentTypeId) throws AttributeNotFoundException,
			 QppServiceException;

	public UserInfo transform(User user) throws UserClassNotFoundException, InvalidLdapProfileException, QppServiceException;

	public UserInfoList transform(User[] users) throws UserClassNotFoundException, QppServiceException;

	public SearchInfoList transform(QueryDefinition[] queryDefinitions, boolean getConditions, boolean getDisplay, boolean getContext, boolean getSharedSearchTrustees)
			throws QppServiceException;

	public SearchInfo transform(QueryDefinition queryDefinition, boolean getConditions, boolean getDisplay, boolean getContext, boolean getSharedSearchTrustees)
			throws QppServiceException ;
	
	public QueryDefinition transform(SearchInfo searchInfo) throws QppServiceException;
	
	public SortInfo[] transform(SortInfoList sortInfoList) throws AttributeNotFoundException, QppServiceException;
	
	// Admin facade

	public RelationTypeInfoList transform(RelationType[] relationTypes) throws AttributeNotFoundException, QppServiceException;

	public AttributeInfoList transform(Attribute[] attributes) throws DomainNotFoundException, QppServiceException;

	public AttributeInfo transform(Attribute attribute) throws DomainNotFoundException, QppServiceException;

	public TrusteeInfo transform(Trustee trustee);
	
	public PublishingChannelList transform(PublishingChannel[] publishingChannels);

	public RoleInfoList transform(UserClass[] userClasses) throws InvalidContentTypeException, QppServiceException;

	public User transform(UserInfo userInfo) throws UserClassNotFoundException, InvalidLdapProfileException, QppServiceException;

	public Group transform(GroupInfo groupInfo) throws UserNotFoundException, QppServiceException;

	public UserClass transform(RoleInfo roleInfo) throws QppServiceException;

	public Attribute transform(AttributeInfo attributeInfo) throws QppServiceException;

	public ContentTypeInfoList transform(ContentType[] contentType) throws QppServiceException;

	public ContentTypeAttributeMapping[] transform(ContentTypeAttributeMappingInfoList contentTypeAttributeMappingInfoList) throws AttributeNotFoundException, QppServiceException;

	public com.quark.qpp.service.xmlBinding.ContentTypeInfo transform(ContentType contentType) throws InvalidContentTypeException, QppServiceException;
	
	public com.quark.qpp.service.xmlBinding.ContentTypeInfo transform(ContentTypeInfo contentTypeInfo) throws InvalidContentTypeException, QppServiceException;

	public ContentTypePrivileges[] transform(ContentTypePrivList contentTypePrivList) throws QppServiceException;
	
	public StatusInfoList transform(Status[] status, long workflowId) throws QppServiceException;

	/**
	 * Returns array of Status objects. WorklowName is required in case status id is not mentioned in StatusInfo object, but we can
	 * populate the status id using workflow name & status name.
	 * 
	 * @param statusInfoList
	 * @param workflowName
	 * @return
	 * @throws QppServiceException 
	 * @throws UserClassNotFoundException 
	 */
	public Status[] transform(StatusInfoList statusInfoList, String workflowName) throws UserClassNotFoundException, QppServiceException;
	
	public StatusTransitionInfo transform(StatusTransition statusTransition, long workflowId) throws QppServiceException;
	
	public StatusTransitionInfoList transform(StatusTransition[] statusTransitions, long workflowId) throws QppServiceException;

	public StatusTransition[] transform(StatusTransitionInfoList statusTransitionInfoList, long workflowId) throws QppServiceException;
	
	public StatusTransition transform(StatusTransitionInfo statusTransitionInfo, long workflowId) throws  QppServiceException;
	
	public JobJacket[] transform(JobJacketInfoList jobJacketInfoList);

	public StorageRepositoryInfo transform(StorageRepository storageRepository) throws QppServiceException;

	public StorageRepository transform(StorageRepositoryInfo info) throws QppServiceException;

	public StorageRepositoryInfoList transform(StorageRepository[] storageRepositories) throws QppServiceException;

	public WorkflowInfo[] transform(WorkflowInfoList workflowInfoList);

	public CollectionGroup[] transform(GroupInfoList groupInfoList) throws UserClassNotFoundException, QppServiceException;

	public FormInfo transform(Form form, long workflowId) throws InvalidContentTypeException, QppServiceException;

	public RelationTypeAttributeMapping[] transform(RelationAttributeList relationAttributeList) throws AttributeNotFoundException, QppServiceException;

	public ContentTypeInfoList getContentTypeInfoList(long workFlowId)
			throws WorkflowNotFoundException, QppServiceException;

	public RelationTypeInfo transform(RelationType relationType) throws AttributeNotFoundException, QppServiceException;

	public Routing transform(RoutingInfo routingInfo);

	public AttributeDomainInfoList transform(AttributeDomain[] attributeDomains) throws DomainNotFoundException, QppServiceException;

	public AttributeDomainInfo transform(AttributeDomain attributeDomain) throws DomainNotFoundException, QppServiceException;

	public AttributeDomain transform(AttributeDomainInfo attributeDomainInfo);

	public DomainValue[] transform(DomainValueList domainValueList);

	public com.quark.qpp.service.xmlBinding.DomainValue transform(DomainValue domainValue, boolean isHierarchicalDomain) throws DomainNotFoundException, QppServiceException;

	public com.quark.qpp.service.xmlBinding.DomainValueList transform(DomainValue[] domainValues, boolean isHierarchicalDomain) throws DomainNotFoundException, QppServiceException;

	public LdapProfileInfo transform(LdapProfile ldapProfile);

	public LdapProfileInfoList transform(LdapProfile[] ldapProfiles);

	public LdapProfile transform(LdapProfileInfo ldapProfileInfo);

	public LdapAttributeInfoList transform(LdapAttributeValue[] ldapAttributeValues);

	public LdapAttributeValue transform(LdapAttributeInfo ldapAttributeInfo);

	public LdapAttributeValue[] transform(LdapAttributeInfoList ldapAttributeInfoList2);

	public ArticleComponent[] transform(ArticleComponentInfoList articleComponentList) throws AttributeNotFoundException, QppServiceException;
	
	/**
	 * Transforms array of Preference objects to PreferenceInfo objects & returns a list encapsulating these objects.
	 * 
	 * @throws PreferenceNotFoundException
	 * @throws QppServiceException
	 */
	public PreferenceInfoList transform(Preference[] preferences) throws PreferenceNotFoundException, QppServiceException;

	/**
	 * Transforms PreferenceInfoList to array of Preference objects.
	 * 
	 * @throws InvalidPreferenceException
	 * @throws PreferenceNotFoundException
	 * @throws QppServiceException
	 */
	public Preference[] transform(PreferenceInfoList preferenceInfoList) throws PreferenceNotFoundException, InvalidPreferenceException,
			QppServiceException;

	/**
	 * Transforms array of PreferenceValue objects to PreferenceValueList encapsulating the transformed objects.
	 * 
	 * @throws PreferenceNotFoundException
	 * @throws QppServiceException
	 */
	public PreferenceValueList transform(PreferenceValue[] preferenceValues) throws PreferenceNotFoundException, QppServiceException;

	/**
	 * Transforms PreferenceValueList to array of PreferenceValue objects.
	 * 
	 * @throws InvalidPreferenceException
	 * @throws PreferenceNotFoundException
	 * @throws QppServiceException
	 */
	public PreferenceValue[] transform(PreferenceValueList preferenceValuelist) throws PreferenceNotFoundException,
			InvalidPreferenceException, QppServiceException;

	/**
	 * Transforms array of FavoriteType objecst to a list encapsulating the transformed objects.
	 * 
	 * @param favoriteItems
	 * @return
	 * @throws QppServiceException 
	 * @throws InvalidCollectionException 
	 */
	public FavoriteItemlist transform(FavoriteItem[] favoriteItems) throws InvalidCollectionException, QppServiceException;

	/**
	 * Transforms FavoriteItemList to array of FavoriteItem objects.
	 * 
	 * @param favoriteItemlist
	 * @return
	 * @throws QppServiceException 
	 */
	public FavoriteItem[] transform(FavoriteItemlist favoriteItemlist) throws QppServiceException;


	/**
	 * 
	 * @param privilegeDefinitions
	 * @return
	 * @throws QppServiceException 
	 * @throws PrivilegeGroupNotFoundException 
	 */
	public PrivilegeDefinitionList transform(PrivilegeDefinition[] privilegeDefinitions) throws PrivilegeGroupNotFoundException, QppServiceException;
	
	/**
	 * 
	 * @param privilegeDefinition
	 * @return
	 * @throws QppServiceException 
	 * @throws PrivilegeGroupNotFoundException 
	 */
	public com.quark.qpp.service.xmlBinding.PrivilegeDefinition transform(PrivilegeDefinition privilegeDefinition) throws PrivilegeGroupNotFoundException, QppServiceException;

	/**
	 * 
	 * @param privilegeGroupDefinitions
	 * @return
	 * @throws QppServiceException 
	 * @throws PrivilegeGroupNotFoundException 
	 */
	public PrivilegeGroupDefinitionList transform(PrivilegeGroupDefinition[] privilegeGroupDefinitions) throws PrivilegeGroupNotFoundException, QppServiceException;
	
	/**
	 * 
	 * @param privilegeGroupDefinition
	 * @return
	 * @throws QppServiceException 
	 * @throws PrivilegeGroupNotFoundException 
	 */
	public com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition transform(PrivilegeGroupDefinition privilegeGroupDefinition) throws PrivilegeGroupNotFoundException, QppServiceException;

	/**
	 * 
	 * @param privilegeDefinition
	 * @return
	 * @throws QppServiceException 
	 * @throws PrivilegeGroupNotFoundException 
	 */
	public PrivilegeDefinition transform(com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition) throws PrivilegeGroupNotFoundException, QppServiceException;


	public WorksheetInfoList transform(Worksheet[] worksheets);

	public ChartInfoList transform(Chart[] charts);

	public TableInfoList transform(Table[] tables);

	public NamedRangeInfoList transform(NamedRange[] range);

	public WorksheetInfo transform(Worksheet selectedWS);

	public UserRedliningColor transform(RedlineInfo redlineInfo) throws UserNotFoundException, QppServiceException;

	public RedlineInfo transform(UserRedliningColor userRedliningColor) throws UserNotFoundException, QppServiceException;

	public RedlineInfoList transform(UserRedliningColor[] userRedliningColors) throws UserNotFoundException, QppServiceException;
	
	public Schedule transform(ScheduleInfo scheduleInfo);

	public ScriptInfo transform(Script script) throws ScheduleNotFoundException, QppServiceException;

	public ScriptInfoList transform(Script[] allScripts) throws ScheduleNotFoundException, QppServiceException;
	
	public TrusteeInfoList fetchAndTransformSharedQueryTrustees(long queryId) throws QueryNotFoundException, QppServiceException;

	public StatusRoutingUserClasses[] transform(StatusRoutingRolesInfoList statusRoutingRolesInfoList, long workflowId) throws UserClassNotFoundException, QppServiceException;

	public ApplicablePrivilegesInfo transform(ApplicablePrivileges applicablePrivs) throws PrivilegeNotFoundException, QppServiceException;

	public ContentTypePrivList transform(ContentTypePrivileges[] contentTypePrivileges) throws InvalidContentTypeException,
			QppServiceException;
	
	public Privilege[] transform(long[] privilegeIds) throws PrivilegeNotFoundException, QppServiceException;

	public com.quark.qpp.service.xmlBinding.ImportedGroupInfo transform(ImportedGroupInfo importedGroupInfo) throws TrusteeNotFoundException, GroupNotFoundException, QppServiceException;

	public ImportedGroupInfoList transform(ImportedGroupInfo[] groupInfos) throws TrusteeNotFoundException, GroupNotFoundException, QppServiceException;
	
	public AttributeConstraintsInfoList transform(AttributeConstraint[] attributeConstraints) throws AttributeNotFoundException,
			UserClassNotFoundException, QppServiceException;

	public LdapSearchInfoList transform(LdapQueryDefinition[] ldapQueryDefinitions) throws InvalidLdapProfileException, QppServiceException;
	
	public LdapSearchInfo transform(LdapQueryDefinition ldapQueryDefinitionCreated) throws InvalidLdapProfileException, QppServiceException;
	
	public LdapQueryDefinition transform(LdapSearchInfo ldapSearchInfo) throws InvalidLdapProfileException, QppServiceException;

	
	public VisioPageInfoList transform(VisioPage[] visioPages);
		
	public PowerPointSlideInfoList transform(PowerPointSlide[] pptSildes);
	
	public MimeTypeInfoList transform(CustomXmlMimeType[] customXmlMimeTypes);

	public NameValueList transform(NameValue[] nameValues);
	
	public ClipboardDataInfoList transform(ClipboardDataInfo[] clipboardDataArr);
	
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfo transform(ClipboardDataInfo clipboardData);

	public ClipboardFormatInfoList transform(ClipboardFormat[] cbDataformats);

	public ClipboardFormatInfo transform(ClipboardFormat clipboardDataFormat);

	public ClipboardChannelMappingInfo transform(ClipboardChannelMapping clipboardChannelMapping);

	public ClipboardChannelMappingInfoList transform(ClipboardChannelMapping[] clipboardChannelMappings);
	
}



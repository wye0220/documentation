/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.collection.service.dto.Collection;
import com.quark.qpp.core.collection.service.dto.CollectionGroup;
import com.quark.qpp.core.collection.service.dto.CollectionInfo;
import com.quark.qpp.core.collection.service.dto.CollectionUser;
import com.quark.qpp.core.collection.service.dto.JobJacket;
import com.quark.qpp.core.collection.service.dto.RevisionControl;
import com.quark.qpp.core.collection.service.dto.Routing;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidCollectionExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidJobJacketExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.exceptions.InvalidJobJacketException;
import com.quark.qpp.core.collection.service.exceptions.InvalidRevisionControlException;
import com.quark.qpp.core.collection.service.exceptions.InvalidRoutingException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidUserClassException;
import com.quark.qpp.core.query.service.constants.DefaultDisplayModes;
import com.quark.qpp.core.query.service.constants.ExploreModeTypes;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.security.service.exceptions.InvalidGroupException;
import com.quark.qpp.core.security.service.exceptions.InvalidUserException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowInUseException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.local.WorkflowService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.AttributeUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.CollectionInfoList;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.JobJacketInfo;
import com.quark.qpp.service.xmlBinding.JobJacketInfoList;
import com.quark.qpp.service.xmlBinding.ParentColInfoList;
import com.quark.qpp.service.xmlBinding.RevisionControlInfoList;
import com.quark.qpp.service.xmlBinding.RoutingInfo;
import com.quark.qpp.service.xmlBinding.RoutingInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.UserInfoList;
import com.quark.qpp.service.xmlBinding.WorkflowInfo;
import com.quark.qpp.service.xmlBinding.WorkflowInfoList;

public class CollectionController {

	@Autowired
	private CollectionService collectionService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private AttributeUtility attributeUtility;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private TrusteeService trusteeService;

	@Autowired
	private QueryService queryService;

	@Autowired
	private PrivilegeValidator privilegeValidator;

	private static final String COLLECTION_FIELD_SEPARATOR = "/";

	private final Logger logger = Logger.getLogger(this.getClass());

	public CollectionInfoList getAccessibleTopLevelCollections(String[] attributes, boolean getAssets, boolean getChildCollections, boolean getWorkflows,
			boolean getUsers, boolean getGroups, boolean getRoutings, boolean getRevisionControls, boolean getJobJackets,
			String[] contentTypes, String workflow, String[] assetAttributes) throws InvalidContentTypeException, InvalidCollectionException, QppServiceException {
		CollectionInfoList xmlCollectionInfoList = new CollectionInfoList();
		CollectionInfo[] topLevelcollections = collectionService.getAccessibleTopLevelCollections();
		for (CollectionInfo collectionInfo : topLevelcollections) {
			com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = getSpecificCollectionInfo(collectionInfo.getId(), attributes,
					getAssets, getChildCollections, /* getParentCollections */false, getWorkflows, getUsers, getGroups, getRoutings,
					getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
			xmlCollectionInfoList.getCollectionInfo().add(colInfo);
		}
		return xmlCollectionInfoList;
	}

	public CollectionInfoList createCollections(CollectionInfoList collectionInfoList) throws InvalidCollectionException,
			InvalidAttributeValueException, InvalidRoutingException, WorkflowNotFoundException, StatusNotFoundException,
			TrusteeNotFoundException, InvalidJobJacketException, InvalidRevisionControlException, InvalidGroupException,
			RepositoryActionException, InvalidUserClassException, InvalidUserException, WorkflowInUseException, QppServiceException {

		CollectionInfoList newCollectionInfoList = new CollectionInfoList();

		if (collectionInfoList != null && collectionInfoList.getCollectionInfo() != null) {
			List<com.quark.qpp.service.xmlBinding.CollectionInfo> colInfoList = collectionInfoList.getCollectionInfo();
			Iterator<com.quark.qpp.service.xmlBinding.CollectionInfo> iterator = colInfoList.iterator();
			/**
			 * Create collections one by one under home collection when list of collections is given.
			 */
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = iterator.next();
				long newCollectionId = createCollection(colInfo, 0);
				if (newCollectionId > 0) {
					com.quark.qpp.service.xmlBinding.CollectionInfo createdCol = getSpecificCollectionInfo(newCollectionId, /* attributes */
							null, /* getAssets */
							false, /* getChildCollections */true, false/* getParentCollections */, /* getWorkflows */true,
							/* getUsers */true, /* getGroups */true, /* getRoutings */true, /* getRevisionControls */true, /* getJobJackets */
							true, /* contentTypes */null, /* workflow */null, null);
					newCollectionInfoList.getCollectionInfo().add(createdCol);
				}
			}
		} else {
			throw new InvalidCollectionException(InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
		}
		return newCollectionInfoList;
	}

	public com.quark.qpp.service.xmlBinding.CollectionInfo getSpecificCollectionInfo(long collectionId, String[] attributes,
			boolean getAssets, boolean getChildCollections, boolean getParentCollections, boolean getWorkflows, boolean getUsers,
			boolean getGroups, boolean getRoutings, boolean getRevisionControls, boolean getJobJackets, String[] contentTypes,
			String workflow, String[] assetAttributes) throws InvalidCollectionException, QppServiceException, AttributeNotFoundException,
			InvalidContentTypeException, WorkflowNotFoundException, TrusteeNotFoundException, InvalidQueryDefinitionException,
			InvalidQueryDisplayException {

		com.quark.qpp.service.xmlBinding.CollectionInfo transformedCollectionInfo = objectTransformer.transform(collectionService
				.getCollectionInfo(collectionId));

		if (attributes == null && !getAssets && !getChildCollections && !getParentCollections && !getWorkflows && !getUsers && !getGroups
				&& !getRoutings && !getRevisionControls && !getJobJackets) {
			return transformedCollectionInfo;
		}

		if (attributes != null && attributes.length == 1 && attributes[0].equalsIgnoreCase("all")) {
			AttributeValue[] attributeValues = collectionService.getCollectionAllAttributeValues(collectionId);
			AttributeValueList attributeValueList = objectTransformer.transform(attributeValues);
			transformedCollectionInfo.setAttributeValueList(attributeValueList);
		} else if (attributes != null && attributes.length > 0) {
			long[] attributeIds = facadeUtility.getAttributeIds(attributes);
			AttributeValue[] attributeValues = collectionService.getCollectionAttributeValues(collectionId, attributeIds);
			AttributeValueList attributeValueList = objectTransformer.transform(attributeValues);
			transformedCollectionInfo.setAttributeValueList(attributeValueList);
		}

		WorkflowInfoList workflowInfoList = null;
		if (getWorkflows) {
			workflowInfoList = getApplicableWorkflows(collectionId, contentTypes, false/*getDetailedInfo*/);
			transformedCollectionInfo.setWorkflowInfoList(workflowInfoList);
		}

		if (getUsers) {
			transformedCollectionInfo.setUserInfoList(getCollectionUsers(collectionId));
		}

		if (getGroups) {
			transformedCollectionInfo.setGroupInfoList(getCollectionGroups(collectionId, true/*getDetailedInfo*/));
		}

		if (getRoutings) {
			RoutingInfoList routingInfoList = new RoutingInfoList();
			// If workflow input parameter is not provided then get the status routing info for all applicable workflows in the collection
			// Else get the status routing info of the given workflow
			if (workflow == null) {
				List<Routing> routingList = new ArrayList<Routing>();
				Routing[] routings = new Routing[] {};
				ArrayList<Long> workflowsToBeConsideredForRoutings = new ArrayList<Long>();
				if (workflowInfoList != null && workflowInfoList.getWorkflowInfo().size() > 0) {
					for (int i = 0; i < workflowInfoList.getWorkflowInfo().size(); i++) {
						long workflowId = workflowInfoList.getWorkflowInfo().get(i).getId();
						workflowsToBeConsideredForRoutings.add(workflowId);
					}
				} else {
					Workflow[] applicableWorkflows = collectionService.getCollectionWorkflows(collectionId);
					for (int i = 0; i < applicableWorkflows.length; i++) {
						workflowsToBeConsideredForRoutings.add(applicableWorkflows[i].getId());
					}
				}
				for (int i = 0; i < workflowsToBeConsideredForRoutings.size(); i++) {
					routings = collectionService.getStatusRoutings(collectionId, workflowsToBeConsideredForRoutings.get(i));
					for (int j = 0; j < routings.length; j++) {
						routingList.add(routings[j]);
					}
				}
				routings = routingList.toArray(new Routing[routingList.size()]);
				routingInfoList = objectTransformer.transform(routings);
			} else {
				routingInfoList = getStatusRoutings(collectionId, workflow);
			}
			transformedCollectionInfo.setRoutingInfoList(routingInfoList);
		}
		if (getRevisionControls) {
			transformedCollectionInfo.setRevisionControlInfoList(getRevisionControls(collectionId, contentTypes));
		}
		if (getJobJackets) {
			transformedCollectionInfo.setJobJacketInfoList(getCollectionJobJackets(collectionId, true/*getDetailedInfo*/));
		}
		if (getAssets) {
			AssetInfoList assetInfoList = (AssetInfoList) objectTransformer.transform(getAssetsInCollection(collectionId, false, assetAttributes), DefaultContentTypes.ASSET);
			transformedCollectionInfo.setAssetInfoList(assetInfoList);
		}
		if (getChildCollections) {
			privilegeValidator.validateApplicationPrivileges("collectionBrowsing");
			CollectionInfo[] collectionInfos = collectionService.getAccessibleImmediateChildCollections(collectionId);
			CollectionInfoList childColList = new CollectionInfoList();
			for (int i = 0; i < collectionInfos.length; i++) {
				com.quark.qpp.service.xmlBinding.CollectionInfo transformedChildCol = objectTransformer.transform(collectionInfos[i]);
				childColList.getCollectionInfo().add(transformedChildCol);
			}
			transformedCollectionInfo.setCollectionInfoList(childColList);
		}
		if (getParentCollections) {
			CollectionInfo[] collectionInfos = collectionService.getAccessibleCollectionPath(collectionId);
			ParentColInfoList parentColList = new ParentColInfoList();
			for (int i = 0; i < collectionInfos.length; i++) {
				if (collectionInfos[i].getId() != collectionId) {
					com.quark.qpp.service.xmlBinding.CollectionInfo transformedParentCol = objectTransformer.transform(collectionInfos[i]);
					parentColList.getCollectionInfo().add(transformedParentCol);
				}
			}
			transformedCollectionInfo.setParentColInfoList(parentColList);
		}
		return transformedCollectionInfo;
	}

	private long createCollection(com.quark.qpp.service.xmlBinding.CollectionInfo collectionInfo, long parentCollectionId)
			throws InvalidCollectionException, InvalidAttributeValueException, InvalidRoutingException, InvalidCollectionException,
			WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException, InvalidJobJacketException,
			InvalidRevisionControlException, InvalidGroupException, RepositoryActionException, InvalidUserClassException,
			InvalidUserException, WorkflowInUseException, QppServiceException {

		try {
			AttributeValueList attributeValueList = collectionInfo.getAttributeValueList();
			// String collectionPath = attributeUtility.getNativeAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValueList);
			String collectionPath = collectionInfo.getCollectionPath();
			long collectionId = -1;
			if (collectionPath != null) {
				collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
			} else {
				CollectionInfo[] collectionInfos = collectionService.getAccessibleImmediateChildCollections(parentCollectionId);
				String collectionName = attributeUtility.getNativeAttributeValue(DefaultAttributes.NAME, attributeValueList);
				for (CollectionInfo colInfo : collectionInfos) {
					if (collectionName.equalsIgnoreCase(colInfo.getName())) {
						collectionId = colInfo.getId();
						break;
					}
				}
			}
			/**
			 * Create, only if collection does not exists
			 */
			if (collectionId <= 0) {
				if (parentCollectionId <= 0) {
					parentCollectionId = getParentCollectionId(collectionPath);
				}
				/** create */
				AttributeValue[] attributeValues = objectTransformer.transform(attributeValueList);
				// Get only user/client modifiable attribute values for creating new collection
				attributeValues = attributeUtility.getUserClientModifiableAttributeValues(attributeValues);
				/** Create a new Collection */
				Collection collection = collectionService.createCollection(parentCollectionId, attributeValues);
				collectionId = collection.getId();
				/**
				 * Update other metadata i.e. workflow,users,groups,jobjackets,revisioncontrol,routing
				 */
				collectionInfo.setId(collectionId);
				updateCollectionMetadata(collectionInfo);
			}
			parentCollectionId = collectionId;
		} catch (QppServiceException e) {
			logger.error("Error while creating collection at collection path " + collectionInfo.getCollectionPath(), e);
			/** Cannot continue as it will effect hierarchy structure. */
			return -1;
		}

		/** Check if this collection has Child collections */
		if ((collectionInfo.getCollectionInfoList() != null) && (collectionInfo.getCollectionInfoList().getCollectionInfo() != null)) {
			Iterator<com.quark.qpp.service.xmlBinding.CollectionInfo> iterator = collectionInfo.getCollectionInfoList().getCollectionInfo()
					.iterator();
			while (iterator.hasNext()) {
				/** Create child collection one by one. */
				com.quark.qpp.service.xmlBinding.CollectionInfo childXmlCollectionInfo = iterator.next();
				createCollection(childXmlCollectionInfo, parentCollectionId);
			}
		}
		return parentCollectionId;
	}

	private long getParentCollectionId(String collectionPath) throws QppServiceException {
		long parentCollectionId = -1;
		if (collectionPath != null) {
			String parentCollectionHierarchy = getParentCollectionHierarchy(collectionPath);
			if (parentCollectionHierarchy != null) {
				parentCollectionId = facadeUtility.getCollectionIdForCollectionPath(parentCollectionHierarchy);
			}
		}
		return parentCollectionId;
	}

	public CollectionInfoList updateCollections(CollectionInfoList collectionInfoList) throws AttributeNotFoundException,
			InvalidCollectionException, InvalidAttributeValueException, RepositoryActionException, InvalidRoutingException,
			WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException, InvalidJobJacketException,
			InvalidRevisionControlException, InvalidGroupException, InvalidUserClassException, InvalidUserException,
			WorkflowInUseException, QppServiceException {

		CollectionInfoList updatedCollectionInfoList = new CollectionInfoList();

		if (collectionInfoList != null && collectionInfoList.getCollectionInfo() != null) {
			List<com.quark.qpp.service.xmlBinding.CollectionInfo> listOfXmlCollectionInfo = collectionInfoList.getCollectionInfo();
			Iterator<com.quark.qpp.service.xmlBinding.CollectionInfo> iterator = listOfXmlCollectionInfo.iterator();
			/** Update collection one by one if list of collections is given. */
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = iterator.next();
				long updatedCollectionId = updateCollection(colInfo);
				if (updatedCollectionId > 0) {
					CollectionInfo dtoCollectionInfo = collectionService.getCollectionInfo(updatedCollectionId);
					com.quark.qpp.service.xmlBinding.CollectionInfo updatedCol = getSpecificCollectionInfo(dtoCollectionInfo.getId(), /* attributes */
							null, /* getAssets */false, /* getChildCollections */true, false/* getParentCollections */, /* getWorkflows */true,
							/* getUsers */true, /* getGroups */true, /* getRoutings */true, /* getRevisionControls */true, /* getJobJackets */
							true, /* contentTypes */null, /* workflow */null, null /*asset display attributes*/);
					updatedCollectionInfoList.getCollectionInfo().add(updatedCol);
				}
			}
		} else {
			throw new InvalidCollectionException(InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
		}
		return updatedCollectionInfoList;
	}

	private long updateCollection(com.quark.qpp.service.xmlBinding.CollectionInfo collectionInfo) throws AttributeNotFoundException,
			InvalidCollectionException, InvalidAttributeValueException, RepositoryActionException, InvalidRoutingException,
			WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException, InvalidJobJacketException,
			InvalidRevisionControlException, InvalidGroupException, RepositoryActionException, InvalidUserClassException,
			InvalidUserException, WorkflowInUseException, QppServiceException {
		long collectionId = -1;
		try {
			AttributeValueList attributeValueList = collectionInfo.getAttributeValueList();
			if (collectionInfo.getId() == null) {
				String collectionPath = collectionInfo.getCollectionPath();
				if (collectionPath == null || collectionPath.isEmpty()) {
					throw new InvalidCollectionException(InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
				}
				// String collectionPath = attributeUtility.getNativeAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValueList);
				collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
				collectionInfo.setId(collectionId);
			} else {
				collectionId = collectionInfo.getId();
			}
			AttributeValue[] attributeValues = objectTransformer.transform(attributeValueList);
			// Only valid attribute values for updating collection
			attributeValues = attributeUtility.getUserClientModifiableAttributeValues(attributeValues);
			if (attributeValues != null && attributeValues.length > 0) {
				collectionService.setAttributeValues(collectionId, attributeValues);
			}

			/**
			 * update workflows,groups,users,jobjackets,default jobjacket,revision control,routing
			 */
			updateCollectionMetadata(collectionInfo);
		} catch (QppServiceException e) {
			logger.error("Error while updating collection with id " + collectionId, e);
		}

		/** Check if this collection has Child collections */
		if ((collectionInfo.getCollectionInfoList() != null) && (collectionInfo.getCollectionInfoList().getCollectionInfo() != null)) {
			Iterator<com.quark.qpp.service.xmlBinding.CollectionInfo> iterator = collectionInfo.getCollectionInfoList().getCollectionInfo()
					.iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.CollectionInfo childCollectionInfo = iterator.next();
				/** update child collection */
				updateCollection(childCollectionInfo);
			}
		}
		return collectionId;
	}

	private void updateCollectionMetadata(com.quark.qpp.service.xmlBinding.CollectionInfo collectionInfo)
			throws InvalidCollectionException, WorkflowNotFoundException, WorkflowInUseException, StatusNotFoundException,
			TrusteeNotFoundException, InvalidJobJacketException, InvalidRevisionControlException, InvalidGroupException,
			RepositoryActionException, InvalidUserClassException, InvalidUserException, InvalidRoutingException,
			InvalidContentTypeException, QppServiceException {

		long collectionId = collectionInfo.getId();

		/** Set workflows for collection */
		setCollectionWorkflows(collectionId, collectionInfo.getWorkflowInfoList());
		
		//Set collection trustees
		setCollectionTrustees(collectionId, collectionInfo.getGroupInfoList(), collectionInfo.getUserInfoList(), false, false);
		
		/** Set revision controls for collection */
		setCollectionRevisionControls(collectionId, collectionInfo.getRevisionControlInfoList());
		/** Set jobjackets for collection */
		setJobJackets(collectionId, collectionInfo.getJobJacketInfoList());
		/** Set default jobjackets / default tickets for collection */
		setDefaultJobJackets(collectionId, collectionInfo);
		/** Set routings for collection */
		setCollectionRouting(collectionId, collectionInfo.getRoutingInfoList(), false, false);
	}

	public void setCollectionTrustees(long collectionId, GroupInfoList groupInfoList, UserInfoList userInfoList, boolean applyToChildren, boolean appendToChildren)
			throws InvalidCollectionException, InvalidGroupException, RepositoryActionException, QppServiceException {
		CollectionGroup[] collectionGroups = null;
		if (groupInfoList != null) {
			collectionGroups = objectTransformer.transform(groupInfoList);
		} else {
			collectionGroups = collectionService.getCollectionGroups(collectionId);
		}
		CollectionUser[] collectionUsers = null;
		if (userInfoList != null) {
			collectionUsers = objectTransformer.transform(userInfoList);
		} else {
			collectionUsers = collectionService.getCollectionUsers(collectionId);
		}
		collectionService.setCollectionTrustees(collectionId, collectionGroups, collectionUsers, applyToChildren, appendToChildren, applyToChildren, appendToChildren);
	}

	/** It will set default jobjacket for collection */
	private void setDefaultJobJackets(long collectionId, com.quark.qpp.service.xmlBinding.CollectionInfo collectionInfo)
			throws InvalidCollectionException, InvalidJobJacketException, QppServiceException {

		long defaultJobJacketId = -1;
		String defaultJJName = collectionInfo.getDefaultJobJacketName();
		if (defaultJJName != null) {
			defaultJobJacketId = facadeUtility.getJJIdByName(defaultJJName);
		} else if (collectionInfo.getDefaultJobJacketId() != null) {
			defaultJobJacketId = collectionInfo.getDefaultJobJacketId();
		}
		if (defaultJobJacketId > 0) {
			collectionService.setCollectionDefaultJobJacket(collectionId, defaultJobJacketId, collectionInfo.getDefaultJobJacketTicket(),
					false);
		}
	}

	/** Update Collection all jobjackets */
	private void setJobJackets(long collectionId, JobJacketInfoList jobJacketInfoList) throws InvalidCollectionException,
			InvalidJobJacketException, QppServiceException {

		/** Return if jobjacket is not defined. */
		if (jobJacketInfoList != null) {
			/** Update Ids from system using there name */
			long[] jobjacketIds = getJobJacketIds(jobJacketInfoList);
			collectionService.setCollectionJobjackets(collectionId, jobjacketIds, true, true);
		}
	}

	private long[] getJobJacketIds(JobJacketInfoList jobJacketInfoList) throws InvalidJobJacketException, QppServiceException {

		/** It will get Ids of jobjackets from DB using there names */
		JobJacket[] allSystemJJs = collectionService.getAllJobJackets();
		ArrayList<Long> jobJacketIds = new ArrayList<Long>();

		Iterator<JobJacketInfo> iterator = jobJacketInfoList.getJobJacketInfo().iterator();
		while (iterator.hasNext()) {
			JobJacketInfo jobJacketInfo = iterator.next();
			String jobJacketName = jobJacketInfo.getName();
			if (jobJacketName != null) {
				for (JobJacket systemJJ : allSystemJJs) {
					if (jobJacketName.equalsIgnoreCase(systemJJ.getName())) {
						jobJacketIds.add(systemJJ.getId());
						break;
					}
				}
			} else if (jobJacketInfo.getId() != null) {
				jobJacketIds.add(jobJacketInfo.getId());
			}
		}
		return facadeUtility.getLongArray(jobJacketIds);
	}

	public void setCollectionRouting(long collectionId, RoutingInfoList routingInfoList, boolean applyToChildren, boolean appendToChildren) throws InvalidRoutingException,
			InvalidCollectionException, WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException, QppServiceException {

		/** Return if no routing information is available. */
		if (routingInfoList != null && routingInfoList.getRoutingInfo() != null) {
			/** Update workflow and status Ids from system using name, if given */
			udpateRoutingIds(routingInfoList);
			Map<Long, ArrayList<Routing>> statusRoutingsMap = getStatusRoutingsMap(routingInfoList);

			for (Entry<Long, ArrayList<Routing>> entry : statusRoutingsMap.entrySet()) {
				collectionService.setStatusRoutings(collectionId, entry.getKey(), entry.getValue().toArray(new Routing[0]), applyToChildren, appendToChildren);
			}
		}
	}

	private Map<Long, ArrayList<Routing>> getStatusRoutingsMap(RoutingInfoList routingInfoList) {
		Map<Long, ArrayList<Routing>> statusRoutingsMap = new HashMap<Long, ArrayList<Routing>>();
		Iterator<RoutingInfo> iterator = routingInfoList.getRoutingInfo().iterator();
		while (iterator.hasNext()) {
			RoutingInfo routingInfo = iterator.next();
			long workFlowId = routingInfo.getWorkflowId();
			if (statusRoutingsMap.get(workFlowId) != null) {
				ArrayList<Routing> routingArrayList = statusRoutingsMap.get(workFlowId);
				routingArrayList.add(objectTransformer.transform(routingInfo));
			} else {
				ArrayList<Routing> routingArrayList = new ArrayList<Routing>();
				routingArrayList.add(objectTransformer.transform(routingInfo));
				statusRoutingsMap.put(workFlowId, routingArrayList);
			}
		}
		return statusRoutingsMap;
	}

	private void udpateRoutingIds(RoutingInfoList routingInfoList) throws WorkflowNotFoundException, QppServiceException {

		Iterator<RoutingInfo> iterator = routingInfoList.getRoutingInfo().iterator();
		while (iterator.hasNext()) {
			RoutingInfo routingInfo = iterator.next();

			/** update workflow and status ids */
			String workflowName = routingInfo.getWorkflow();
			long workFlowId = 0;
			if (workflowName != null) {
				workFlowId = workflowService.getWorkflowByName(workflowName).getId();
				routingInfo.setWorkflowId(workFlowId);
			} else {
				workFlowId = routingInfo.getWorkflowId();
			}
			if (routingInfo.getStatus() != null) {
				long statusId = facadeUtility.getStatusId(workFlowId, routingInfo.getStatus());
				routingInfo.setStatusId(statusId);
			}
			/** Update trustee ids */
			String trusteeName = routingInfo.getTrustee();
			if (trusteeName != null) {
				long trusteeId = trusteeService.getTrusteeId(trusteeName);
				routingInfo.setTrusteeId(trusteeId);
			}
		}
	}

	private void setCollectionWorkflows(long collectionId, WorkflowInfoList workflowInfoList) throws InvalidCollectionException,
			WorkflowInUseException, WorkflowNotFoundException, QppServiceException {

		/** Return if no workflow given. */
		if (workflowInfoList != null && workflowInfoList.getWorkflowInfo() != null) {
			long[] workflowIds = getWorkFlowIds(workflowInfoList);
			/**
			 * Set applyToChildren & appendToChildren as false as information of workflows for child collection is provided by user aswell.
			 */
			collectionService.setCollectionWorkflows(collectionId, workflowIds, false, false);
		}
	}

	private long[] getWorkFlowIds(WorkflowInfoList workflowInfoList) throws WorkflowNotFoundException, QppServiceException {
		ArrayList<Long> workflowIds = new ArrayList<Long>();
		Iterator<WorkflowInfo> iterator = workflowInfoList.getWorkflowInfo().iterator();
		while (iterator.hasNext()) {
			WorkflowInfo workflowInfo = iterator.next();
			if (workflowInfo.getName() != null) {
				workflowIds.add(workflowService.getWorkflowByName(workflowInfo.getName()).getId());
			} else if (workflowInfo.getId() != null) {
				workflowIds.add(workflowInfo.getId());
			}
		}
		return facadeUtility.getLongArray(workflowIds);
	}

	private void setCollectionRevisionControls(long collectionId, RevisionControlInfoList revisionControlInfoList)
			throws InvalidRevisionControlException, InvalidCollectionException, InvalidContentTypeException, QppServiceException {

		/** Return if no revision control provided. */
		if (revisionControlInfoList != null) {
			RevisionControl[] revisionControls = objectTransformer.transform(revisionControlInfoList);
			/**
			 * applyToChildren is false as information of child collection revision will be provided by user.
			 */
			RevisionControl[] mergedRevisionControls = mergeRevisionControls(revisionControls, collectionId);
			collectionService.setRevisionControls(collectionId, mergedRevisionControls, false);
		}
	}

	public CollectionInfo[] getAccessibleCollectionPath(long collectionId) throws InvalidCollectionException, QppServiceException {
		return collectionService.getAccessibleCollectionPath(collectionId);
	}

	private String getParentCollectionHierarchy(String collectionPath) throws QppServiceException {
		if (collectionPath != null) {
			// collectionPath: Home/sample_collection_3/Sample_2
			String[] collections = collectionPath.split(COLLECTION_FIELD_SEPARATOR);
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < collections.length - 1; i++) {
				builder.append(collections[i]).append(COLLECTION_FIELD_SEPARATOR);
			}
			// path: Home/sample_collection_3/
			String path = builder.toString();
			// path returned : Home/sample_collection_3
			return path.substring(0, path.lastIndexOf(COLLECTION_FIELD_SEPARATOR));
		} else {
			return null;
		}
	}

	public JobJacketInfoList getAllJobJackets() throws InvalidJobJacketException, QppServiceException {
		JobJacket[] jobJacket = collectionService.getAllJobJackets();
		JobJacketInfoList jobJacketInfoList = new JobJacketInfoList();
		for (int i = 0; i < jobJacket.length; i++) {
			long[] collectionIds = collectionService.getJobJacketCollections(jobJacket[i].getId());
			if (collectionIds.length > 0) {
				JobJacketInfo jobJacketInfo = objectTransformer.transform(jobJacket[i], true/* getDetailedInfo */, collectionIds[0]);
				jobJacketInfoList.getJobJacketInfo().add(jobJacketInfo);
			}
		}
		return jobJacketInfoList;
	}

	public JobJacketInfoList getJobJacket(long jobJacketId) throws InvalidJobJacketException, QppServiceException {
		JobJacket jobJacket = collectionService.getJobjacket(jobJacketId);
		JobJacketInfo jobJacketInfo = objectTransformer.transform(jobJacket, true/*getDetailedInfo*/, -1);
		JobJacketInfoList jobJacketInfoList = new JobJacketInfoList();
		jobJacketInfoList.getJobJacketInfo().add(jobJacketInfo);
		return jobJacketInfoList;
	}

	public byte[] getBytes(InputStream inputStream) throws QppServiceException {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		int index;
		try {
			index = inputStream.read();
			while (index != -1) {
				byteArrayOutputStream.write(index);
				index = inputStream.read();
			}
		} catch (IOException e) {
			throw new QppServiceException(e);
		}

		return byteArrayOutputStream.toByteArray();
	}

	public JobJacketInfoList createJobJackets(InputStream inputStream, JobJacketInfoList jobJacketInfoList)
			throws InvalidJobJacketException, QppServiceException {
		JobJacketInfoList newJobJacketInfoList = new JobJacketInfoList();
		if (jobJacketInfoList != null) {
			List<JobJacketInfo> list = jobJacketInfoList.getJobJacketInfo();
			for (int i = 0; list != null && i < list.size(); i++) {
				try {
					JobJacketInfo newJobJacketInfo = createJobJacket(list.get(i).getContent());
					newJobJacketInfoList.getJobJacketInfo().add(newJobJacketInfo);
				} catch (QppServiceException e) {
					logger.error("Error while creating job jacket.", e);
					if(jobJacketInfoList.getJobJacketInfo().size() == 1){
						throw e;
					}
				}
			}
		} else
			try {
				if (inputStream.available() > 0) {
					byte[] jobjacketContent = getBytes(inputStream);
					JobJacket jobJacket = collectionService.createJobjacket(jobjacketContent);
					JobJacketInfo jobJacketCreated = objectTransformer.transform(jobJacket, true/*getDetailedInfo*/, -1);
					newJobJacketInfoList.getJobJacketInfo().add(jobJacketCreated);
				} else {
					throw new InvalidJobJacketException(InvalidJobJacketExceptionCodes.JOBJACKET_NOT_FOUND);
				}
			} catch (IOException e) {
				throw new QppServiceException(e);
			}
		return newJobJacketInfoList;
	}

	private JobJacketInfo createJobJacket(String jobJacketContent) throws InvalidJobJacketException, QppServiceException {
		byte[] jobjacketContent;
		try {
			jobjacketContent = jobJacketContent.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new QppServiceException(e);
		}
		JobJacket jobJacket = collectionService.createJobjacket(jobjacketContent);
		JobJacketInfo newJobJacketInfo = objectTransformer.transform(jobJacket, true/*getDetailedInfo*/, -1);
		newJobJacketInfo.setContent(jobJacketContent);
		return newJobJacketInfo;
	}

	public JobJacketInfoList updateJobJackets(JobJacketInfoList jobJacketInfoList) throws InvalidJobJacketException, QppServiceException {
		if (jobJacketInfoList != null) {
			List<JobJacketInfo> list = jobJacketInfoList.getJobJacketInfo();
			JobJacketInfoList updatedJobJacketInfoList = new JobJacketInfoList();
			for (int i = 0; list != null && i < list.size(); i++) {
				try {
					JobJacketInfo updatedJobJacketInfo = updateJobJacket(list.get(i));
					updatedJobJacketInfoList.getJobJacketInfo().add(updatedJobJacketInfo);
				} catch (QppServiceException e) {
					logger.error("Error while updating the job jacket with id "+list.get(i).getId()+" and name "+list.get(i).getName(), e);
				}
			}
			return updatedJobJacketInfoList;
		} else {
			throw new InvalidJobJacketException(InvalidJobJacketExceptionCodes.JOBJACKET_NOT_FOUND);
		}
	}

	private JobJacketInfo updateJobJacket(JobJacketInfo jobJacketInfo) throws InvalidJobJacketException, QppServiceException {
		long jobJacketId = -1;
		if (jobJacketInfo.getId() != null && jobJacketInfo.getId() > 0) {
			jobJacketId = jobJacketInfo.getId();
		} else if (jobJacketInfo.getName() != null) {
			jobJacketId = facadeUtility.getJJIdByName(jobJacketInfo.getName());
		}
		try {
			collectionService.updateJobJacket(jobJacketId, jobJacketInfo.getContent().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			throw new QppServiceException(e);
		}
		JobJacket jobjacket = collectionService.getJobjacket(jobJacketId);
		JobJacketInfo updatedJobJacketInfo = objectTransformer.transform(jobjacket, true/*getDetailedInfo*/,-1);
		return updatedJobJacketInfo;
	}

	private WorkflowInfoList getApplicableWorkflows(long collectionId, String[] contentTypes, boolean getDetailedInfo) throws InvalidCollectionException,
			InvalidContentTypeException, QppServiceException {
		Workflow[] workflows = null;
		if (contentTypes == null || contentTypes.length == 0) {
			workflows = collectionService.getCollectionWorkflows(collectionId);
		} else {
			long[] contentTypeIds = facadeUtility.getContentTypeIds(contentTypes);
			workflows = collectionService.getApplicableWorkflows(collectionId, contentTypeIds);
		}
		return objectTransformer.transform(workflows, getDetailedInfo);
	}

	private GroupInfoList getCollectionGroups(long collectionId, boolean getDetailedInfo) throws InvalidCollectionException, QppServiceException {
		CollectionGroup[] collectionGroups = collectionService.getCollectionGroups(collectionId);
		return objectTransformer.transform(collectionGroups, getDetailedInfo);
	}

	private JobJacketInfoList getCollectionJobJackets(long collectionId, boolean getDetailedInfo) throws InvalidCollectionException, QppServiceException {
		JobJacket[] jobJackets = collectionService.getCollectionJobJackets(collectionId);
		return objectTransformer.transform(jobJackets, getDetailedInfo, collectionId);
	}

	private UserInfoList getCollectionUsers(long collectionId) throws InvalidCollectionException, QppServiceException {
		CollectionUser[] collectionUsers = collectionService.getCollectionUsers(collectionId);
		return objectTransformer.transform(collectionUsers);
	}

	private RevisionControlInfoList getRevisionControls(long collectionId, String[] contentTypes) throws InvalidCollectionException,
			QppServiceException {
		long[] contentTypeIds = facadeUtility.getContentTypeIds(contentTypes);
		RevisionControl[] revisionControls = null;
		if (contentTypeIds != null && contentTypeIds.length > 0) {
			ArrayList<RevisionControl> arrayList = new ArrayList<RevisionControl>();
			for (int i = 0; i < contentTypeIds.length; i++) {
				RevisionControl revisionControl = collectionService.getRevisionControlForContentType(collectionId, contentTypeIds[i]);
				if(revisionControl != null){
					arrayList.add(revisionControl);
				}
			}
			revisionControls = arrayList.toArray(new RevisionControl[]{});
		} else {
			revisionControls = collectionService.getRevisionControls(collectionId);
		}
		return objectTransformer.transform(revisionControls);
	}

	private RoutingInfoList getStatusRoutings(long collectionId, String workflow) throws InvalidCollectionException, QppServiceException {
		long workflowId = facadeUtility.getWorkflowIds(new String[] { workflow })[0];
		Routing[] routings = collectionService.getStatusRoutings(collectionId, workflowId);
		return objectTransformer.transform(routings);
	}

	public AssetElement[] getAssetsInCollection(long collectionId, boolean recursive, String[] assetAttributes) throws InvalidQueryDefinitionException,
			InvalidQueryDisplayException, QppServiceException {
		ArrayList<QueryCondition> queryConditions = new ArrayList<QueryCondition>();

		QueryContext queryContext = new QueryContext();
		queryContext.setRecursive(recursive);
		queryContext.setContentType(DefaultContentTypes.ASSET);
		queryContext.setCollections(new long[] { collectionId });

		//Use the given asset display attributes while retrieving collection assets.If not mentioned use collection's asset view.
		QueryDisplay queryDisplay = null;
		if (assetAttributes == null || assetAttributes.length == 0) {
			queryDisplay = queryService.getCollectionDisplay(collectionId).getAssetView();
			
			//override modes because over REST we support only PLAIN modes.
			queryDisplay.setExploreMode(ExploreModeTypes.PLAIN);
			queryDisplay.setDisplayMode(DefaultDisplayModes.PLAIN);
			
			//The facade layer does not support 'Group by' queries.
			queryDisplay.setGroupingAttributes(null);
		} else {
			queryDisplay = createQueryDisplay(assetAttributes);
		}
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions.toArray(new QueryCondition[0]),
				queryContext, queryDisplay);
		ArrayList<AssetElement> assetElements = new ArrayList<AssetElement>();
		for (int i = 0;queryResultElements != null && i < queryResultElements.length; i++) {
			assetElements.add((AssetElement) queryResultElements[i]);
		}
		return assetElements.toArray(new AssetElement[0]);
	}
	
	private QueryDisplay createQueryDisplay(String[] displayColumns)
			throws QppServiceException {
		QueryDisplay queryDisplay = new QueryDisplay();

		long[] displayColumnIds = new long[0];
		if(displayColumns != null && displayColumns.length>0){
			displayColumnIds = facadeUtility.getAttributeIds(displayColumns);
		}
		DisplayColumn[] columns = new DisplayColumn[displayColumnIds.length];
		for (int i = 0; i < displayColumnIds.length; i++) {
			boolean isAttribute = true;
			//Client specific attribute columns like thumbnail are in negative
			if(displayColumnIds[i] < 0) {
				isAttribute = false;
			}
			columns[i] = new DisplayColumn(displayColumnIds[i], 100, isAttribute);
		}
		queryDisplay.setDisplayColumns(columns);
		return queryDisplay;
	}

	public com.quark.qpp.service.xmlBinding.CollectionInfo getCollectionHierarchy(long collectionId, String[] attributes,
			boolean getAssets, boolean getWorkflows, boolean getUsers, boolean getGroups, boolean getRoutings, boolean getRevisionControls,
			boolean getJobJackets, String[] contentTypes, String workflow, String[] assetAttributes) throws InvalidCollectionException, AttributeNotFoundException, InvalidContentTypeException, WorkflowNotFoundException, TrusteeNotFoundException, InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		com.quark.qpp.service.xmlBinding.CollectionInfo transformedCollectionInfo = objectTransformer.transform(collectionService
				.getCollectionInfo(collectionId));
		CollectionInfo[] collectionInfos = collectionService.getAccessibleImmediateChildCollections(collectionId);
		CollectionInfoList childColList = new CollectionInfoList();
		for (int i = 0; i < collectionInfos.length; i++) {
			com.quark.qpp.service.xmlBinding.CollectionInfo childColInfo = getCollectionHierarchy(collectionInfos[i].getId(), attributes, getAssets, getWorkflows, getUsers, getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
			childColList.getCollectionInfo().add(childColInfo);
		}
		transformedCollectionInfo.setCollectionInfoList(childColList);
		
		if (attributes == null && !getAssets && !getWorkflows && !getUsers && !getGroups
				&& !getRoutings && !getRevisionControls && !getJobJackets) {
			return transformedCollectionInfo;
		}
		if (attributes != null && attributes.length == 1 && attributes[0].equalsIgnoreCase("all")) {
			AttributeValue[] attributeValues = collectionService.getCollectionAllAttributeValues(collectionId);
			AttributeValueList attributeValueList = objectTransformer.transform(attributeValues);
			transformedCollectionInfo.setAttributeValueList(attributeValueList);
		} else if (attributes != null && attributes.length > 0) {
			long[] attributeIds = facadeUtility.getAttributeIds(attributes);
			AttributeValue[] attributeValues = collectionService.getCollectionAttributeValues(collectionId, attributeIds);
			AttributeValueList attributeValueList = objectTransformer.transform(attributeValues);
			transformedCollectionInfo.setAttributeValueList(attributeValueList);
		}

		WorkflowInfoList workflowInfoList = null;
		if (getWorkflows) {
			workflowInfoList = getApplicableWorkflows(collectionId, contentTypes, false);
			transformedCollectionInfo.setWorkflowInfoList(workflowInfoList);
		}

		if (getUsers) {
			transformedCollectionInfo.setUserInfoList(getCollectionUsers(collectionId));
		}

		if (getGroups) {
			transformedCollectionInfo.setGroupInfoList(getCollectionGroups(collectionId, false));
		}

		if (getRoutings) {
			RoutingInfoList routingInfoList = new RoutingInfoList();
			// If workflow input parameter is not provided then get the status routing info for all applicable workflows in the collection
			// Else get the status routing info of the given workflow
			if (workflow == null) {
				List<Routing> routingList = new ArrayList<Routing>();
				Routing[] routings = new Routing[] {};
				if (workflowInfoList != null && workflowInfoList.getWorkflowInfo().size() > 0) {
					for (int i = 0; i < workflowInfoList.getWorkflowInfo().size(); i++) {
						long workflowId = workflowInfoList.getWorkflowInfo().get(i).getId();
						routings = collectionService.getStatusRoutings(collectionId, workflowId);
						for (int j = 0; j < routings.length; j++) {
							routingList.add(routings[j]);
						}
					}
					routings = routingList.toArray(new Routing[routingList.size()]);
					routingInfoList = objectTransformer.transform(routings);
				} else {
					/*
					 * Do not throw exception in case workflow to fetch status routings is missing. Simply return empty routingInfoList.
					 */
					//throw new WorkflowNotFoundException();
				}
			} else {
				routingInfoList = getStatusRoutings(collectionId, workflow);
			}
			transformedCollectionInfo.setRoutingInfoList(routingInfoList);
		}
		if (getRevisionControls) {
			transformedCollectionInfo.setRevisionControlInfoList(getRevisionControls(collectionId, contentTypes));
		}
		if (getJobJackets) {
			transformedCollectionInfo.setJobJacketInfoList(getCollectionJobJackets(collectionId, false));
		}
		if (getAssets) {
			AssetInfoList assetInfoList = (AssetInfoList) objectTransformer.transform(getAssetsInCollection(collectionId, false, assetAttributes), DefaultContentTypes.ASSET);
			transformedCollectionInfo.setAssetInfoList(assetInfoList);
		}
		return transformedCollectionInfo;
	}

	public CollectionInfoList getAccessibleCollectionHierarchies(String[] attributes, boolean getAssets, boolean getWorkflows,
			boolean getUsers, boolean getGroups, boolean getRoutings, boolean getRevisionControls, boolean getJobJackets,
			String[] contentTypes, String workflow, String[] assetAttributes) throws QppServiceException {
		CollectionInfoList collectionInfoList = new CollectionInfoList();
		CollectionInfo[] topLevelCollections = collectionService.getAccessibleTopLevelCollections();
		for (int i = 0; i < topLevelCollections.length; i++) {
			com.quark.qpp.service.xmlBinding.CollectionInfo transformedColInfo = getCollectionHierarchy(topLevelCollections[i].getId(),
					attributes, getAssets, getWorkflows, getUsers, getGroups, getRoutings, getRevisionControls, getJobJackets,
					contentTypes, workflow, assetAttributes);
			collectionInfoList.getCollectionInfo().add(transformedColInfo);
		}
		return collectionInfoList;
	}
	
	public StatusTransitionInfoList getApplicableStatusTransition(long collectionId, String workflowIdOrName,
			String statusIdOrName) throws InvalidCollectionException, StatusNotFoundException,
			InvalidStatusException, QppServiceException {
		long workflowId = 0;
		long statusId = 0;
		if (workflowIdOrName != null && workflowIdOrName.trim().length() > 0) {
			workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
		}
		if (statusIdOrName != null && statusIdOrName.trim().length() > 0) {
			long[] workflowAndStatus = facadeUtility.getWorkflowAndStatusId(statusIdOrName);
			workflowId = workflowAndStatus[0];
			statusId = workflowAndStatus[1];
		}
		StatusTransition[] statusTransitions = null;
		if (statusId == 0) {
			Status[] statuses = workflowService.getWorkflow(workflowId).getStatuses();
			ArrayList<StatusTransition> list = new ArrayList<StatusTransition>();
			for (int i = 0; i < statuses.length; i++) {
				StatusTransition statusTransition = collectionService.getApplicableStatusTransition(collectionId, workflowId,
						statuses[i].getId());
				list.add(statusTransition);
			}
			statusTransitions = list.toArray(new StatusTransition[] {});
		} else {
			StatusTransition statusTransition = collectionService.getApplicableStatusTransition(collectionId, workflowId, statusId);
			statusTransitions = new StatusTransition[] { statusTransition };
		}
		return objectTransformer.transform(statusTransitions, workflowId);
	}

	public StatusInfoList getApplicableWorkflowInitialStatuses(long collectionId, String workflowIdOrName) throws QppServiceException {
		long workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
		Status[] statuses = collectionService.getApplicableWorkflowInitialStatuses(collectionId, workflowId);
		return objectTransformer.transform(statuses, workflowId);
	}
	
	public RevisionControl[] mergeRevisionControls(RevisionControl[] revisionControls, long collectionId) throws InvalidCollectionException, QppServiceException {
		RevisionControl[] existingRevisionControls = collectionService.getRevisionControls(collectionId);
		ArrayList<RevisionControl> revisionControlsList = new ArrayList<RevisionControl>();
		if (existingRevisionControls == null || existingRevisionControls.length == 0) {
			return revisionControls;
		} else {
			for (int i = 0; i < existingRevisionControls.length; i++) {
				long contentTypeId = existingRevisionControls[i].getContentTypeId();
				RevisionControl revisionControlToBeAdded = existingRevisionControls[i];
				for (int j = 0; j < revisionControls.length; j++) {
					if (contentTypeId == revisionControls[j].getContentTypeId()) {
						revisionControlToBeAdded = revisionControls[j];
						break;
					}
				}
				revisionControlsList.add(revisionControlToBeAdded);
			}
		}
		return revisionControlsList.toArray(new RevisionControl[0]);
	}

}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebResourcePathParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

@Controller("publishByPathFacade")
@RequestMapping("/publishbypath/**")
public class PublishByPathFacade {
	
	private final static String PATH_IDENTIFIER = "publishbypath"; 
	
	@Autowired
	private PublishFacade publishFacade;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private ObjectTransformer objectTransformer;
	
	/**
	 * Publishes an asset using a publishing channel. To deliver an asset using a delivery channel, specify delivery channel id.
	 * To both publish and then deliver the publishing channel output, specify both publishing and delivery channel id.
	 * Specify channel parameters for both publishing and delivery channels in parametersMap.
	 * 
	 * @param assetPath
	 *            path of the asset in format (Home/MyCollection/assset.jpg)
	 * @param majorVersion
	 * 				majorVersion of the asset to be published.
	 * @param minorVersion
	 * 				minorVersion of the asset to be published.If major and minor version, both are not supplied, then the latest version of the asset will be published.              
	 * @param outputStream
	 *            Specify an outputStream to pipe the publishing channel output into. The published content is streamed into the specified outputStream IF no delivery channel is specified.
	 * @param publishingChannelId
	 *            id of the publishing channel or null if asset is to be processed by delivery channel only.
	 * @param deliveryChannelId
	 *            Id of the delivery channel or null if published output is required to be streamed back.
	 * @param parametersMap
	 *            Map containing publishing parameters.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type header value.
	 *            The value of this argument is set by the QPP REST framework.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 */
	@RequestMapping(method = RequestMethod.GET)
	public void publishAsset(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, @WebOutputStream OutputStream outputStream, @RequestParam(value = "publishingchannel", required = false) String publishingChannelId, 
			@RequestParam(value = "deliverychannel", required = false) String deliveryChannelId, @WebParameterMap Map<String, String> parametersMap, HttpServletResponse httpServletResponse) throws QppServiceException, StreamingException{
		long assetId = facadeUtility.getAssetId(assetPath);
		publishFacade.publishAsset(assetId, majorVersion, minorVersion, outputStream, publishingChannelId, deliveryChannelId, parametersMap, httpServletResponse);
	}
	
	/**
	 * Updates the existing datadoc asset by creating its new version. Latest content of the asset is fetched by executing the desired
	 * datadoc channel. The datadoc channel to be used is defined in the attribute {@link DefaultAttributes#DATADOC_CHANNEL_ID} of the
	 * asset. <br/>
	 * This asset needs to be a datadoc asset. Whether the asset is datadoc asset or not - is determined by the attribute
	 * {@link DefaultAttributes#IS_DATADOC} of the asset.	 * 
	 * 
	 * @param assetPath
	 *            path of the asset in format (Home/MyCollection/assset.xml)
	 * 
	 * @param attributeValueList
	 *            List of attribute values to be used as metadata of the datadoc asset while checking-in to the Platform.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in the datadoc asset as a new minor version or as a new major version.
	 * @return Metadata of the datadoc updated asset whose version is created.
	 * @throws InvalidAssetException
	 *             If the given asset is not the datadoc asset. The datadoc asset is determined by the attribute
	 *             {@link DefaultAttributes#IS_DATADOC} of the asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             Streaming exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=updatedatadoc")
	@WebReturnType("xmlView")
	public AssetInfo updateDatadoc(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, 
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws InvalidAssetException, InvalidAttributeValueException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return publishFacade.updateDatadoc(assetId, attributeValueList, createMinorVersion);
	}
	
	/**
	 * Detach or unlinks the given datadoc asset from its source content and creates a new version of the asset. After detaching/unlinking,
	 * the given asset will no more be a datadoc asset and thus can be checked-out and checked-in by the end user like other
	 * conventional assets in the Platform.
	 * 
	 * @param assetPath
	 *            path of the datadoc asset in format (Home/MyCollection/assset.xml)	 * 
	 * @param attributeValueList
	 *            List of attribute values to be used as metadata of the datadoc asset while checking-in to the Platform.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in the datadoc asset as a new minor version or as a new major version.
	 * @return Metadata of the datadoc updated asset whose version is created.
	 * @throws InvalidAssetException
	 *             If the given asset is not the datadoc asset. The datadoc asset is determined by the attribute
	 *             {@link DefaultAttributes#IS_DATADOC} of the asset.
	 * @throws AssetNotFoundException
	 *             If the asset with the given id does not exist.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case streaming of the content fails while creating a new version.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=detachdatadoc")
	@WebReturnType("xmlView")
	public AssetInfo detachDatadocFromSource(@WebResourcePathParam(PATH_IDENTIFIER) String assetPath, @WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws AssetNotFoundException,
			InvalidAssetException, InvalidAttributeValueException, QppServiceException, StreamingException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return publishFacade.detachDatadocFromSource(assetId, attributeValueList, createMinorVersion);
	}
	
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
		
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.exception;

import com.quark.qpp.common.exceptions.QppServiceException;

/**
 * This exception is thrown if the loggedOn user doesn't have a specific privilege.
 * Additional Info will refer to the disabled privilege for which exception has been thrown.
 * 
 */
public class UserPrivilegeException extends QppServiceException {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public UserPrivilegeException() {
		super(UserPrivilegeExceptionCodes.USER_DOES_NOT_HAVE_THE_PRIVILEGE);
	}

	/**
	 * Parameterized constructor that creates a new UserPrivilegeException
	 * object with the given exceptionCode.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 */
	public UserPrivilegeException(String exceptionCode) {
		super(exceptionCode);
	}

	/**
	 * Parameterized constructor that creates a new UserPrivilegeException
	 * object with the given exceptionCode and additional information.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 * @param additionalInfo additionalInfo that is to be set for this exception.
	 */
	public UserPrivilegeException(String exceptionCode, String[] additionalInfo) {
		super(exceptionCode, additionalInfo);
	}
}

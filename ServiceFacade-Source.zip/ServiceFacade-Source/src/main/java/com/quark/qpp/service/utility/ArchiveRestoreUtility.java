/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateTimeValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.DomainValueList;
import com.quark.qpp.common.dto.MeasurementValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.TimeValue;
import com.quark.qpp.common.dto.Value;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeDomain;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.local.AttributeDomainService;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.query.service.constants.DefaultDisplayModes;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.query.service.local.QueryService;

/**
 * Utility methods for archive restore.
 * 
 */
public class ArchiveRestoreUtility {

	@Autowired
	private QueryService queryService;

	@Autowired
	private AssetService assetService;

	@Autowired
	private AttributeDomainService attributeDomainService;

	@Autowired
	private CollectionService collectionService;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	private Logger logger = Logger.getLogger(ArchiveRestoreUtility.class);

	/**
	 * Return query result assets for the given query id.
	 * 
	 * @param queryId
	 * @param attributeIds
	 * @return {@link QueryResultElement} objects.
	 * @throws QppServiceException
	 */
	public QueryResultElement[] executeQuery(long queryId, long[] attributeIds) throws QppServiceException {
		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumnsArray = new DisplayColumn[attributeIds.length];
		for (int i = 0; i < attributeIds.length; i++) {
			DisplayColumn disColumn = new DisplayColumn();
			disColumn.setColumnId(attributeIds[i]);
			disColumn.setWidth(50);
			disColumn.setAttributeColumn(true);
			displayColumnsArray[i] = disColumn;
		}
		queryDisplay.setDisplayColumns(displayColumnsArray);
		queryDisplay.setDisplayMode(DefaultDisplayModes.PLAIN);
		return queryService.getQueryResult(queryId, queryDisplay);
	}

	/**
	 * Return assets belonging to the given collection id.
	 * 
	 * @param collectionId
	 * @param attributeIds
	 * @return {@link QueryResultElement} objects.
	 * @throws InvalidQueryDefinitionException
	 * @throws InvalidQueryDisplayException
	 * @throws QppServiceException
	 */
	public QueryResultElement[] getCollectionAssets(long collectionId, long[] attributeIds) throws InvalidQueryDefinitionException,
			InvalidQueryDisplayException, QppServiceException {
		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.ASSET);
		queryContext.setCollections(new long[] { collectionId });
		queryContext.setRecursive(true);

		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[attributeIds.length];
		for (int i = 0; i < attributeIds.length; i++) {
			DisplayColumn disColumn = new DisplayColumn();
			disColumn.setColumnId(attributeIds[i]);
			disColumn.setWidth(50);
			disColumn.setAttributeColumn(true);
			displayColumns[i] = disColumn;
		}
		queryDisplay.setDisplayColumns(displayColumns);
		return queryService.getQueryResultForConditions(new QueryCondition[0], queryContext, queryDisplay);
	}

	/**
	 * Return value for the given attribute id by looping through the given attribute values.
	 * 
	 * @param attributeId
	 * @param attributeValues
	 * @return {@link Value} object.
	 */
	public Value getAttributeValue(long attributeId, AttributeValue[] attributeValues) {
		if (attributeValues == null)
			return null;

		AttributeValue attrValue = null;
		boolean flag = false;
		for (int i = 0; i < attributeValues.length; i++) {
			attrValue = attributeValues[i];
			if (attrValue.getAttributeId() == attributeId) {
				flag = true;
				break;
			}
		}
		if (flag)
			return attrValue.getAttributeValue();
		else
			return null;
	}

	/**
	 * Return primitive value of an attribute, except in case of domain type, where a map containing domain value and domain name is
	 * returned.
	 * 
	 * @param attributeValue
	 * @return Primitive value for the given {@link AttributeValue} type.
	 * @throws DomainNotFoundException
	 * @throws QppServiceException
	 */
	public Object getValueForAttributeType(AttributeValue attributeValue) throws DomainNotFoundException, QppServiceException {
		Value value = attributeValue.getAttributeValue();
		switch (attributeValue.getType()) {
		case AttributeValueTypes.BOOLEAN:
			BooleanValue booleanValue = (BooleanValue) value;
			return booleanValue.getValue();
		case AttributeValueTypes.DATE:
			DateValue dateValue = (DateValue) value;
			return dateValue.getValue();
		case AttributeValueTypes.DATETIME:
			DateTimeValue dateTimeValue = (DateTimeValue) value;
			return dateTimeValue.getValue();
		case AttributeValueTypes.DOMAIN:
			if (attributeValue.isMultiValued()) {
				DomainValue[] domainValues = ((DomainValueList) value).getDomainValues();
				Map<String, String[]> map = new HashMap<String, String[]>();
				List<String> domainValueIds = new ArrayList<String>();
				List<String> domainValueNames = new ArrayList<String>();
				AttributeDomain attributeDomain = null;

				for (int i = 0; i < domainValues.length; i++) {
					DomainValue domainValue = domainValues[i];
					long domainValueId = domainValue.getId();
					String domainValueText = domainValue.getName();

					if (domainValueText == null){
						domainValueText = attributeDomainService.getDomainValue(domainValue.getDomainId(), domainValueId).getName();
					}

					if (i == 0) {
						attributeDomain = attributeDomainService.getDomain(domainValue.getDomainId());
					}

					domainValueIds.add(Long.toString(domainValueId));
					domainValueNames.add(domainValueText);
				}

				// for hierarchical domains
				if (attributeDomain.isHierarchical()) {
					Map<Long,String> domainValueMap = new HashMap<Long, String>();
					// create map of all domain Id and values with full path of value
					getMapOfHierarchicalDomains(domainValueMap,domainValues[0].getDomainId());
					domainValueNames.clear();

					for (String domainValId : domainValueIds) {
						domainValueNames.add(domainValueMap.get(Long.parseLong(domainValId)));
					}
				}

				map.put("valueId", domainValueIds.toArray(new String[0]));
				map.put("valueText", domainValueNames.toArray(new String[0]));
				map.put("domainName", new String[] {attributeDomain.getName()});

				return map;
			} else {
				DomainValue attributeDomainValue = (DomainValue) value;
				long domainValueId = attributeDomainValue.getId();
				String domainValueText = attributeDomainValue.getName();
				if (domainValueText == null){
					domainValueText = attributeDomainService.getDomainValue(attributeDomainValue.getDomainId(), domainValueId).getName();
				}

				AttributeDomain attributeDomain = attributeDomainService.getDomain(attributeDomainValue.getDomainId());

				if (attributeDomain.isHierarchical()) {
					// create map of all domain Id and values with full path of value
					Map<Long,String> domainValueMap = new HashMap<Long, String>();
					getMapOfHierarchicalDomains(domainValueMap,attributeDomain.getId());

					domainValueText = domainValueMap.get(domainValueId);
				}

				Map<String, String> map = new HashMap<String, String>();

				map.put("valueId", String.valueOf(domainValueId));
				map.put("valueText", domainValueText);
				map.put("domainName", attributeDomain.getName());
				return map;
			}
		case AttributeValueTypes.MEASUREMENT:
			MeasurementValue measurementValue = (MeasurementValue) value;
			return measurementValue.getValue();
		case AttributeValueTypes.NUMERIC:
			NumericValue numericValue = (NumericValue) value;
			return numericValue.getValue();
		case AttributeValueTypes.TEXT:
			TextValue textValue = (TextValue) value;
			return textValue.getValue();
		case AttributeValueTypes.TIME:
			TimeValue timeValue = (TimeValue) value;
			return timeValue.getValue();
		default:
			logger.error("Invalid Value Type");
			break;
		}
		return null;
	}

	/**
	 * getMapOfHierarchicalDomains
	 * 
	 * 		makes map of key as domianValueId and value as Full DomainValue path
	 * 
	 * @param map	Empty map to fill with DomainValue ID/Name.
	 * @param parent	parent of domain Value
	 * @param domainId	hierarchical domain Id 
	 */
	public void getMapOfHierarchicalDomains(Map<Long,String> map, int domainId) 
			throws DomainNotFoundException, QppServiceException {
		AttributeDomain attributeDomain = attributeDomainService.getDomain(domainId);
		
		if (attributeDomain.isHierarchical()) {
			DomainValue[] domainValues = attributeDomainService.getDomainValues(domainId);
			//Initially parent would be empty
			constructHierarchicalDomainMap(map,domainValues,"");
		}
	}

	private void constructHierarchicalDomainMap(Map<Long,String> map,DomainValue[] domainValues,String parent) {
		for (DomainValue domainValue : domainValues) {
			if (parent != null && parent.trim().length() > 0)
				map.put(domainValue.getId(),parent + ";" + domainValue.getName());
			else 
				map.put(domainValue.getId(),domainValue.getName());

			if (domainValue.getChildDomainValues() != null) {
				if (parent != null && parent.length() > 0)
					constructHierarchicalDomainMap(map,domainValue.getChildDomainValues(),parent + ";" + domainValue.getName());
				else
					constructHierarchicalDomainMap(map,domainValue.getChildDomainValues(),domainValue.getName());
			}
		}
	}
	
	/**
	 * getMValueBasedMapOfHierarchicalDomains
	 * 
	 * 		makes map of key as domianValueName vs Id map.
	 * 		used in case when we required domain value id 
	 * 		from domain value name.
	 * 
	 * @param map	Empty map to fill with DomainValue Name/Id.
	 * @param parent	parent of domain Value
	 * @param domainId	hierarchical domain Id  
	 */
	public void getMValueBasedMapOfHierarchicalDomains(Map<String,Long> map,int domainId) 
			throws DomainNotFoundException, QppServiceException {
		AttributeDomain attributeDomain = attributeDomainService.getDomain(domainId);
		
		if (attributeDomain.isHierarchical()) {
			DomainValue[] domainValues = attributeDomainService.getDomainValues(domainId);
			//Initially parent would be empty
			construcValueBasedtHierarchicalDomainMap(map,domainValues,"");
		}
	}

	private void construcValueBasedtHierarchicalDomainMap(Map<String,Long> map,DomainValue[] domainValues,String parent) {
		String domainName = "";

		for (DomainValue domainValue : domainValues) {
			if (parent != null && parent.length() > 0) {
				domainName = (parent + ";" + domainValue.getName()).toLowerCase();
				map.put(domainName.toLowerCase(),domainValue.getId());
			}
			else {
				domainName = domainValue.getName().toLowerCase();
				map.put(domainName,domainValue.getId());
			}

			if (domainValue.getChildDomainValues() != null) {
				if (parent != null && parent.length() > 0)
					construcValueBasedtHierarchicalDomainMap(map,domainValue.getChildDomainValues(),domainName);
				else
					construcValueBasedtHierarchicalDomainMap(map,domainValue.getChildDomainValues(),domainName);
			}
		}
	}

	/**
	 * Filter and replace unsupported xml characters.
	 * 
	 * @param strText
	 * @return String value filtered for unsupported xml characters.
	 */
	public String filterXmlText(String strText) {
		String javaString = new String(strText);
		char[] chars = javaString.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (!(chars[i] == 0x9 || chars[i] == 0xA || chars[i] == 0xD || (chars[i] >= 0x20 && chars[i] <= 0xD7FF)
					|| (chars[i] >= 0xE000 && chars[i] <= 0xFFFD) || (chars[i] >= 0x10000 && chars[i] <= 0x10FFFF))) {
				chars[i] = ' ';
			}
		}
		return new java.lang.String(chars);
	}

	/**
	 * Return domain value id for the given domain id and value string.
	 * 
	 * @param domainId
	 * @param domainValText
	 * @return The value for given {@link DomainValue}.
	 * @throws DomainNotFoundException
	 * @throws QppServiceException
	 */
	public long getDomainValueId(int domainId, String domainValText) throws DomainNotFoundException, QppServiceException {
		DomainValue fetchedDomainValue = facadeUtility.fetchDomainValue(domainId, domainValText, 0, null);
		if (fetchedDomainValue != null) {
			return fetchedDomainValue.getId();
		}
		return -1;
	}

	/**
	 * Create and return an AttributeValue object from the given id, type, and value.
	 * 
	 * @param attributeId
	 * @param type
	 * @param value
	 * @return {@link AttributeValue} object.
	 */
	public AttributeValue createAttributeValue(long attributeId, int type, String value) {
		Value attValue = null;
		if (value == null || value == "") {
			attValue = null;
		} else if (type == AttributeValueTypes.NUMERIC) {
			attValue = new NumericValue(Long.parseLong(value));
		} else if (type == AttributeValueTypes.MEASUREMENT) {
			attValue = new MeasurementValue(Double.parseDouble(value));
		} else if (type == AttributeValueTypes.DATE) {
			attValue = new DateValue(value);
		} else if (type == AttributeValueTypes.DATETIME) {
			attValue = new DateTimeValue(value);
		} else if (type == AttributeValueTypes.TIME) {
			attValue = new TimeValue(value);
		} else if (type == AttributeValueTypes.BOOLEAN) {
			attValue = new BooleanValue(Boolean.parseBoolean(value));
		} else if (type == AttributeValueTypes.TEXT) {
			attValue = new TextValue(value);
		} else if (type == AttributeValueTypes.DOMAIN) {
			attValue = new DomainValue(Long.parseLong(value));
		}
		AttributeValue attributeValue = new AttributeValue(attributeId, attValue, type);
		return attributeValue;
	}

	/**
	 * Return a valid content type id for the given component type string.
	 * 
	 * @param componentTypeValue
	 * @return Id for the given component content type string.
	 * @throws QppServiceException 
	 * @throws InvalidContentTypeException 
	 */
	public long getComponentTypeId(String componentTypeValue) throws InvalidContentTypeException, QppServiceException {
		long componentTypeId = 0;
		if (componentTypeValue.equals("Text Component Body"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_BODY;
		if (componentTypeValue.equals("Text Component Byline"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_BYLINE;
		if (componentTypeValue.equals("Text Component Byline (Author)"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_BYLINE_AUTHOR;
		if (componentTypeValue.equals("Text Component Figure Caption"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_FIGURE_CAPTION;
		if (componentTypeValue.equals("Text Component Figure Credit"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_FIGURE_CREDIT;
		if (componentTypeValue.equals("Text Component Headline"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_HEADLINE;
		if (componentTypeValue.equals("Text Component Headline 2"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_HEADLINE_2;
		if (componentTypeValue.equals("Text Component Indented Paragraph"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_INDENTED_PARAGRAPH;
		if (componentTypeValue.equals("Text Component Ordered List"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_ORDERED_LIST;
		if (componentTypeValue.equals("Text Component Pullquote"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_PULLQUOTE;
		if (componentTypeValue.equals("Text Component Section or Chapter Name"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_SECTION_CHAPTER_NAME;
		if (componentTypeValue.equals("Text Component Title"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_TITLE;
		if (componentTypeValue.equals("Text Component Title 2"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_TITLE_2;
		if (componentTypeValue.equals("Text Component Unordered List"))
			componentTypeId = DefaultContentTypes.TEXT_COMPONENT_UNORDERED_LIST;
		if (componentTypeValue.equals("Picture Component Body"))
			componentTypeId = DefaultContentTypes.PICTURE_COMPONENT_BODY;
		if (componentTypeValue.equals("Picture Component Byline"))
			componentTypeId = DefaultContentTypes.PICTURE_COMPONENT_BYLINE;
		if (componentTypeValue.equals("Picture Component Figure"))
			componentTypeId = DefaultContentTypes.PICTURE_COMPONENT_FIGURE_CAPTION;
		if (componentTypeValue.equals("Picture Component Headline"))
			componentTypeId = DefaultContentTypes.PICTURE_COMPONENT_HEADLINE;
		
		if(componentTypeId <= 0) {
			// if content type is one amongst the system defined types, then componentTypeId value will be > 0
			// if content type is user defined, fetch the id from content type name and its parent content type id
			if(componentTypeValue.startsWith("Text Component")) {
				String customComponentTypeValue =  componentTypeValue.replace("Text Component", "").trim();
				componentTypeId = facadeUtility.getContentTypeWithName(customComponentTypeValue, DefaultContentTypes.TEXT_COMPONENT);
			}
			if(componentTypeValue.startsWith("Picture Component")) {
				String customComponentTypeValue =  componentTypeValue.replace("Picture Component", "").trim();
				componentTypeId = facadeUtility.getContentTypeWithName(customComponentTypeValue, DefaultContentTypes.PICTURE_COMPONENT);
			}
		}
		return componentTypeId;
	}

	/**
	 * Fetch asset path for the given asset id.
	 * 
	 * @param assetId
	 * @return The asset path (collection path and name) for the given asset id.
	 * @throws QppServiceException
	 * @throws InvalidAttributeException
	 * @throws AssetNotFoundException
	 */
	public String getAssetPath(long assetId) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.COLLECTION_PATH,
				DefaultAttributes.NAME });
		String assetPath = ((TextValue) getAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValues)).getValue() + "/"
				+ ((TextValue) getAttributeValue(DefaultAttributes.NAME, attributeValues)).getValue();
		return assetPath;
	}

	/**
	 * Returns true or false based on whether the given query id is an asset based query or collection based query.
	 * 
	 * @param queryId
	 * @return true or false
	 * @throws QueryNotFoundException
	 * @throws QppServiceException
	 */
	public boolean isCollectionQuery(long queryId) throws QueryNotFoundException, QppServiceException {
		QueryDefinition queryDefinition = queryService.getQueryDefinition(queryId);
		QueryContext queryContext = queryDefinition.getQueryContext();
		long contentTypeId = queryContext.getContentType();
		if (contentTypeId == DefaultContentTypes.COLLECTION)
			return true;
		else
			return false;
	}

	/**
	 * Returns additional information for the given QppServiceException.
	 * 
	 * @param qppServiceException
	 *            {@link QppServiceException}
	 * @return Additional information.
	 */
	public String getAdditionalInfoForException(QppServiceException qppServiceException) {
		String[] additionalInfo = qppServiceException.getAdditionalInfo();
		String info = "Additional Info of exception: ";
		if (additionalInfo != null && additionalInfo.length > 0) {
			for (int i = 0; i < additionalInfo.length; i++) {
				if (additionalInfo[i] != null)
					info += additionalInfo[i] + " ";
			}
		}
		else{
			info += additionalInfo;
		}
		return info;
	}

	/**
	 * @param collectionId
	 * @return Collection Path
	 * @throws InvalidCollectionException
	 * @throws QppServiceException
	 */
	public String getCollectionPath(long collectionId) throws InvalidCollectionException, QppServiceException {
		String collectionPath = null;
		AttributeValue[] collectionPathAttrValue = collectionService.getCollectionAttributeValues(collectionId,
				new long[] { DefaultAttributes.COLLECTION_PATH });
		collectionPath = ((TextValue) collectionPathAttrValue[0].getAttributeValue()).getValue();
		return collectionPath;
	}
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.collection.service.dto.Collection;
import com.quark.qpp.core.collection.service.dto.CollectionGroup;
import com.quark.qpp.core.collection.service.dto.CollectionInfo;
import com.quark.qpp.core.collection.service.dto.CollectionUser;
import com.quark.qpp.core.collection.service.dto.JobJacket;
import com.quark.qpp.core.collection.service.dto.RevisionControl;
import com.quark.qpp.core.collection.service.dto.Routing;
import com.quark.qpp.core.collection.service.exceptions.CollectionInUseException;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.exceptions.InvalidJobJacketException;
import com.quark.qpp.core.collection.service.exceptions.InvalidRevisionControlException;
import com.quark.qpp.core.collection.service.exceptions.InvalidRoutingException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.privilege.service.dto.ApplicablePrivileges;
import com.quark.qpp.core.privilege.service.dto.ContentTypePrivileges;
import com.quark.qpp.core.privilege.service.exceptions.InvalidUserClassException;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.CollectionDisplay;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.security.service.exceptions.InvalidGroupException;
import com.quark.qpp.core.security.service.exceptions.InvalidUserException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.workflow.service.constants.ConstraintTypes;
import com.quark.qpp.core.workflow.service.dto.AttributeConstraint;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowInUseException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.controller.CollectionController;
import com.quark.qpp.service.exception.UserPrivilegeException;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.AttributeUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.ApplicablePrivilegesInfo;
import com.quark.qpp.service.xmlBinding.AttributeConstraintsInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.CollectionInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypePrivList;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.JobJacketInfo;
import com.quark.qpp.service.xmlBinding.JobJacketInfoList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.RevisionControlInfoList;
import com.quark.qpp.service.xmlBinding.RoutingInfo;
import com.quark.qpp.service.xmlBinding.RoutingInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.UserInfoList;

/**
 * A facade that defines methods to create, fetch, update and delete collections on the basis of collection id. Also
 * provides the functionality to create, update, delete and fetch job jackets.
 */
@Controller(value = "collectionFacade")
@RequestMapping("/collections")
public class CollectionFacade {

	@Autowired
	private CollectionService collectionService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private AssetService assetService;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private AttributeUtility attributeUtility;
	
	@Autowired
	private PrivilegeValidator privilegeValidator;

	@Autowired
	private CollectionController collectionController;

	/**
	 * Returns default jobjacket of the collection. Returns null if no jobjacket is specified as default for this
	 * collection or content of the jobjacket is not found.
	 * 
	 * @param collectionId
	 *            id of the collection whose default jobjacket is required.
	 * @return {@link JobJacketInfo} object containing detail about the job jacket.
	 * @throws InvalidCollectionException
	 *             if the collection id supplied is invalid or inaccessible to the logged-on user
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "op=defaultjobjacket")
	@WebReturnType("xmlView")
	public JobJacketInfo getCollectionDefaultJobJacket(@PathVariable("collectionId") long collectionId) throws InvalidCollectionException,
			QppServiceException {
		JobJacket jobJacket = collectionService.getCollectionDefaultJobJacket(collectionId);
		if(jobJacket != null){
			return objectTransformer.transform(jobJacket, true/*getDetailedInfo*/, collectionId);
		}
		return null;
	}

	/**
	 * Returns default ticket of the collection.
	 * 
	 * @param collectionId
	 *            id of the collection whose default job ticket is required.
	 * @return Name of the default ticket specified for this collection.
	 * @throws InvalidCollectionException
	 *              if the collection id supplied is invalid or inaccessible to the logged-on user
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "op=defaultticket")
	@WebReturnType("textView")
	public String getCollectionDefaultTicket(@PathVariable("collectionId") long collectionId) throws InvalidCollectionException, QppServiceException {
		String defaultTicket = collectionService.getCollectionDefaultTicket(collectionId);
		return defaultTicket;
	}

	/**
	 * Writes the content of job jacket in an output stream for the job jacket with the given  id and mapped to the collection with given id.
	 * 
	 * @param outputStream
	 *            output stream onto which the jobjacket content is to be written
	 * @param collectionId
	 *            Id of the collection whose jobajcket XML content is required
	 * @param jobJacketId
	 *            Id of the jobjacket whose XML content is required.
	 * @throws InvalidCollectionException
	 *             if the collection to which the given jobjacket belongs is inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 *             In case of failed or interrupted I/O operations.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "op=jobjacketcontent")
	public void getJobJacketContent(@WebOutputStream OutputStream outputStream, @PathVariable("collectionId") long collectionId,
			@RequestParam(value = "jobjacket") long jobJacketId) throws InvalidCollectionException, QppServiceException, IOException {
		byte[] bytes = collectionService.getJobJacketContent(collectionId, jobJacketId);
		outputStream.write(bytes);
	}

	/**
	 * Returns applicable userclass of the logged-in user for the given collection. This would return the default userclass of the user if
	 * there is no userclass overridden for the given collection.
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable role is to be retrieved.
	 * @return {@link RoleInfo} object containing role info.
	 * @throws InvalidCollectionException
	 *             if the collection id supplied is invalid or inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
//	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "op=applicablerole")
//	@WebReturnType("xmlView")
//	public RoleInfo getApplicableRole(@PathVariable("collectionId") long collectionId) throws InvalidCollectionException,
//			QppServiceException {
//		UserClass userClass = collectionService.getApplicableUserClass(collectionId);
//		return objectTransformer.transform(userClass);
//	}
	
	/**
	 * Returns privileges applicable to the logged-in user for the given collection. These privileges are union of privileges of following
	 * userclasses:
	 * <ul>
	 * <li>Userclass of the logged in user in the given collection, only if the user is mapped to the given collection.</li>
	 * <li>Userclasses of collection mapped groups of which the logged in user is member of.</li>
	 * </ul>
	 * Depending upon the input parameters, appropriate applicable privileges will be returned.<br>
	 * Supported input combinations to retrieve applicable privileges are :<br>
	 * <br>
	 * <ul>
	 * <li>Default case : Get all applicable privileges for this collection:<br>
	 * Example:....collections/1?op=applicableprivileges</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled status privileges:<br>
	 * Example:....collections/1?op=applicableprivileges&status=10</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled status privileges for a content type:<br>
	 * Example:....collections/1?op=applicableprivileges&status=10&contenttype=asset</li>
	 * <br>
	 * <br>
	 * <li>Get enabled status privileges for a content type from the mentioned privileges list:<br>
	 * Example:....collections/1?op=applicableprivileges&status=10&contenttype=Picture&privileges=11000,20000,...,...</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled content type privileges:<br>
	 * Example:...collections/1?op=applicableprivileges&contenttype=asset</li><br>
	 * <br>
	 * <li>Get enabled content type privileges from the mentioned privileges list<br>
	 * Example:...collections/1?op=applicableprivileges&contenttype=Picture&privileges=110000,20000,...,...</li><br>
	 * <br>
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable privileges are to be evaluated.
	 * @param statusIdOrNameOrStatusWorkflowCombination
	 *            Id, name or status workflow combination of the status.For example, status=10 or status=ReadyForPublish or status=EditorialWorkflow/ReadyForPublish
	 * @param contentTypeIdOrPathOrName
	 *            Id, name or hierarchy of the content type.
	 * @param privilegeIdsOrNames
	 *            Id or name of the privileges to be retrieved.
	 * @return ApplicablePrivilegesInfo object containing enabled privilege ids depending upon the input parameters.
	 * @throws InvalidCollectionException
	 *             In case of invalid collection id or the collection is inaccessible to the logged on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "applicableprivileges=true")
	@WebReturnType("xmlView")
	public ApplicablePrivilegesInfo getApplicablePrivileges(@PathVariable("collectionId") long collectionId,
			@RequestParam(value="status", required=false) String statusIdOrNameOrStatusWorkflowCombination, @RequestParam(value="contenttype", required=false) String contentTypeIdOrPathOrName,
			@RequestParam(value="privileges", required=false) String[] privilegeIdsOrNames) throws InvalidCollectionException, QppServiceException {
		long statusId = -1;
		if(statusIdOrNameOrStatusWorkflowCombination != null && statusIdOrNameOrStatusWorkflowCombination.trim().length() > 0){
			statusId = facadeUtility.getWorkflowAndStatusId(statusIdOrNameOrStatusWorkflowCombination)[1];
		}
		long contentTypeId = -1;
		if(contentTypeIdOrPathOrName != null &&  contentTypeIdOrPathOrName.trim().length()>0){
			contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrPathOrName);
		}
		long[] privilegeIds = null;
		if(privilegeIdsOrNames != null &&  privilegeIdsOrNames.length > 0){
			privilegeIds = facadeUtility.getPrivilegeIds(privilegeIdsOrNames);
		}

		ContentTypePrivileges[] contentTypePrivileges = null;
		if(statusId > 0){
			if(contentTypeId > 0 && privilegeIds != null && privilegeIds.length>0){
				long[] enabledPrivilegeIds = collectionService.getApplicableStatusPrivilegesForPrivIds(collectionId, statusId, contentTypeId, privilegeIds);
				ContentTypePrivileges contentTypePriv = new ContentTypePrivileges();
				contentTypePriv.setContentTypeId(contentTypeId);
				contentTypePriv.setPrivilegeIds(enabledPrivilegeIds);
				contentTypePrivileges = new ContentTypePrivileges[]{contentTypePriv};
			}else if(contentTypeId > 0){
				long[] enabledPrivilegeIds = collectionService.getApplicableStatusPrivilegesForContentType(collectionId, statusId, contentTypeId);
				ContentTypePrivileges contentTypePriv = new ContentTypePrivileges();
				contentTypePriv.setContentTypeId(contentTypeId);
				contentTypePriv.setPrivilegeIds(enabledPrivilegeIds);
				contentTypePrivileges = new ContentTypePrivileges[]{contentTypePriv};
			}else{
				 contentTypePrivileges = collectionService.getApplicableStatusPrivileges(collectionId, statusId);
			}
			ContentTypePrivList contentTypePrivList = objectTransformer.transform(contentTypePrivileges);
			ApplicablePrivilegesInfo applicablePrivilegesInfo = new ApplicablePrivilegesInfo();
			applicablePrivilegesInfo.setContentTypePrivList(contentTypePrivList);
			return applicablePrivilegesInfo;
		}
		
		if(contentTypeId >0){
			if(privilegeIds != null &&  privilegeIds.length > 0){
				long[] enabledPrivIds = collectionService.getApplicablePrivilegesForPrivIds(collectionId, contentTypeId, privilegeIds);
				ContentTypePrivileges contentTypePriv = new ContentTypePrivileges();
				contentTypePriv.setContentTypeId(contentTypeId);
				contentTypePriv.setPrivilegeIds(enabledPrivIds);
				contentTypePrivileges = new ContentTypePrivileges[]{contentTypePriv};
			}else{
				long[] enabledPrivIds = collectionService.getApplicablePrivilegesForContentType(collectionId, contentTypeId);
				ContentTypePrivileges contentTypePriv = new ContentTypePrivileges();
				contentTypePriv.setContentTypeId(contentTypeId);
				contentTypePriv.setPrivilegeIds(enabledPrivIds);
				contentTypePrivileges = new ContentTypePrivileges[]{contentTypePriv};
			}
			ContentTypePrivList contentTypePrivList = objectTransformer.transform(contentTypePrivileges);
			ApplicablePrivilegesInfo applicablePrivilegesInfo = new ApplicablePrivilegesInfo();
			applicablePrivilegesInfo.setContentTypePrivList(contentTypePrivList);
			return applicablePrivilegesInfo;
		}
	
		ApplicablePrivileges applicablePrivileges = collectionService.getApplicablePrivileges(collectionId);
		return objectTransformer.transform(applicablePrivileges);
	}
	
	/**
	 * Returns complete collection hierarchy of the given collection. By default the below mentioned flags are false and thus this method
	 * will return metadata of each collection in the hierarchy. The parameters like getAssets/getUsers/,,,/attributes will be considered for
	 * every collection in the hierarchy. For example if getUsers flag is true, it will retrieve users for all the collections down the
	 * hierarchy. Thus the behavior of parameters like getAssets/attributes/getUsers/... will be replicated to every collection in the
	 * hierarchy.
	 * 
	 * @param collectionId
	 * 			id of the collection for which complete collection hierarchy is to be retrieved.
	 * @param attributes
	 *            array of collection attributes to be retrieved. An attribute can be specified by id or name. Example : 2,created, Is
	 *            Template, 57,Content Type Hierarchy,.......These attribute values will be retrieved for each collection in the hierarchy.
	 * @param getAssets
	 *            boolean flag to retrieve each collection's assets.
	 * @param getWorkflows
	 *            get all applicable worklfow's for each collection in the hierarchy. Specify contenttypes parameter in order to get
	 *            workflow's associated with these content types only.
	 * @param getUsers
	 *            get users mapped to each collection
	 * @param getGroups
	 *            get groups mapped to each collection
	 * @param getRoutings
	 *            get status routings for each collection for mentioned workflow.
	 * @param getRevisionControls
	 *            get revision controls for each collection.
	 * @param getJobJackets
	 *            get jobjacket's mapped to each collection
	 * @param contentTypes
	 *            array of content types (id, path (e.g. System;Asset;Document) or name(e.g. Document)) corresponding to which workflow's will be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required. If workflow is not given but workflows=true, then status
	 *            routing preferences of all applicable workflow in the collection is being provided.It is mandatory to specify either the
	 *            workflow parameter or enable the getWorkflows flag to fetch status routings.
     * @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return CollectionInfoList encapsulating the complete collection hierarchy of the collection with the given id.
	 * @throws InvalidCollectionException
	 * 			In case the collection with the given id does not exist or the collection is not accessible to the logged in user.
	 * 			The exception code will specify the exact cause of exception.
	 * @throws UserPrivilegeException This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will
	 *        refer to the disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params="hierarchy=true")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfoList getCollectionHierarchy(@PathVariable("collectionId") long collectionId,
			@WebArrayParam(value = "attributes") String[] attributes, @RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets, @WebArrayParam("contenttypes") String[] contentTypes,
			@RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes) throws InvalidCollectionException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("collectionBrowsing");
		com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = collectionController.getCollectionHierarchy(collectionId, attributes, getAssets, getWorkflows, getUsers,
				getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
		CollectionInfoList collectionInfoList = new CollectionInfoList();
		collectionInfoList.getCollectionInfo().add(colInfo);
		return collectionInfoList;
	}
	
	
	/**
	 * Returns collection metadata. Depending upon the flag value, the collection metadata is returned. For instance if
	 * only collection mapped workflows are to be retrieved, then set workflows flag as true.If only collection assets
	 * are to be retrieved then set assets flag as true and so on.
	 * 
	 * 
	 * @param collectionId
	 *            Id of the collection whose details are required.
	 * @param attributes
	 *            list of attribute ids or names to be fetched. Attribute name is given preference over id.
	 * @param getAssets
	 *            boolean flag to indicate if collection assets are also to be retrieved.
	 * @param getChildCollections
	 *            boolean flag if true, will return complete hierarchy of children, grand children & so on, up till the leaf collection down the hierarchy. 
	 * @param getParentCollections
	 *            Returns collection info of ancestor collections up the hierarchy based on access control. While going
	 *            up the hierarchy if there exists any inaccessible collection (on which the logged on user does not
	 *            have access to), collection path array would contain CollectionInfo objects of only those collections
	 *            which are lying below that collection.
	 * @param getWorkflows
	 *            Returns workflows mapped for given collection
	 * @param getUsers
	 *            Returns users mapped for given collection
	 * @param getGroups
	 *            Returns groups mapped for given collection.
	 * @param getRoutings
	 *            Returns status routings of the workflow defined in workflow request parameter for given collection.
	 * @param getRevisionControls
	 *            Get revision control settings of the Collection for all content types or for the specified content
	 *            types defined in contentTypes request parameter.
	 * @param getJobJackets
	 *            Returns jobjackets mapped to the given collection.
	 * @param contentTypes
	 *            list of content types for which revision control settings are to be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required.
	 *            if workflow is not given then status routing preferences of all applicable workflow in the collection is being provided
	 * @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return {@link com.quark.qpp.service.xmlBinding.CollectionInfoList} object containing collection details.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 * 
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfoList getCollection(@PathVariable("collectionId") long collectionId,
			@WebArrayParam(value = "attributes") String[] attributes, @RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "childcollections", defaultValue = "false") boolean getChildCollections,
			@RequestParam(value = "parentcollections", defaultValue = "false") boolean getParentCollections,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets, @WebArrayParam("contenttypes") String[] contentTypes,
			@RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes) throws InvalidCollectionException, QppServiceException {
		com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = collectionController.getSpecificCollectionInfo(collectionId, attributes, getAssets, getChildCollections, getParentCollections, getWorkflows, getUsers,
				getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
		CollectionInfoList collectionInfoList = new CollectionInfoList();
		collectionInfoList.getCollectionInfo().add(colInfo);
		return collectionInfoList;
	}
	
	/**
	 * Returns list of applicable routing users for the given collection for specified workflow and status. This will return all collection
	 * mapped users having their userclass same as any of the status mapped userclasses.
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable routing users are to be fetched
	 * @param workflowIdOrName
	 *            Id or name of the workflow for which collection applicable users are to be fetched. This is an optional field.If not
	 *            mentioned, the workflow will be evaluated on the basis of status input.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or workflow-status combination for the status to be considered.For example : status=10 or status=New Status 001
	 *            or status=Default Workflow/New Status 001.
	 * @param considerRoutingGroups
	 *            If true, applicable routing groups will also be considered and all users of these groups will be included in the list of users being returned. 
	 * @return List of collection applicable routing users.
	 * @throws WorkflowNotFoundException
	 *             In case workflow with the given id or name does not exist.
	 * @throws InvalidStatusException
	 *             In case of an invalid status id or the status is not applicable to the mentioned workflow.Exception code will specify the
	 *             exact cause of exception.
	 * @throws StatusNotFoundException
	 *             In case status with the given id does not exist.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "routingusers=true")
	@WebReturnType("xmlView")
	public UserInfoList getApplicableRoutingUsers(@PathVariable("collectionId") long collectionId,
			@RequestParam(value = "workflow", required = false) String workflowIdOrName,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination,
			@RequestParam(value = "considerroutinggroups", defaultValue = "false") boolean considerRoutingGroups) throws WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, InvalidCollectionException, QppServiceException {
		long workflowId = 0;
		long statusId = 0;
		if (workflowIdOrName == null || workflowIdOrName.trim().length() == 0) {
			long[] workflowAndStatusId = facadeUtility.getWorkflowAndStatusId(statusIdOrNameOrWorkflowStatusCombination);
			workflowId = workflowAndStatusId[0];
			statusId = workflowAndStatusId[1];
		} else {
			workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
			statusId = facadeUtility.getStatusId(workflowId, statusIdOrNameOrWorkflowStatusCombination);
		}
		CollectionUser[] collectionUsers = null;
		if(considerRoutingGroups){
			collectionUsers = collectionService.getAllApplicableRoutingUsers(collectionId, workflowId, statusId);
		}
		else {
			collectionUsers = collectionService.getApplicableRoutingUsers(collectionId, workflowId, statusId);
		}
		return objectTransformer.transform(collectionUsers);
	}
	
	/**
	 * Returns array of applicable routings groups for the given collection for specified workflow & status. This will return all collection
	 * mapped groups having their userclass same as one of the status mapped userclasses.
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable routing groups are to be fetched
	 * @param workflowIdOrName
	 *            Id of the workflow against which applicable routings groups are to be fetched for a collection.This is an optional
	 *            parameter.If not mentioned, then workflow will be retrieved on the basis of status input.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or workflow-status combination of the status to be considered. For example : status=10 or status=New Status 001
	 *            or status=Default Workflow/New Status 001.
	 * @return List of collection groups applicable for the given collection, workflow & status combination.
	 * @throws WorkflowNotFoundException
	 *             If the workflow with the given id doesn't exist.
	 * @throws StatusNotFoundException
	 *             If the status with the specified id does not exist
	 * @throws InvalidStatusException
	 *             If the status does not belong to the specified workflow.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "routinggroups=true")
	@WebReturnType("xmlView")
	public GroupInfoList getApplicableRoutingGroups(@PathVariable("collectionId") long collectionId,
			@RequestParam(value = "workflow", required = false) String workflowIdOrName,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination) throws WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, InvalidCollectionException, QppServiceException {
		long workflowId = 0;
		long statusId = 0;
		if (workflowIdOrName == null || workflowIdOrName.trim().length() == 0) {
			long[] workflowAndStatusId = facadeUtility.getWorkflowAndStatusId(statusIdOrNameOrWorkflowStatusCombination);
			workflowId = workflowAndStatusId[0];
			statusId = workflowAndStatusId[1];
		} else {
			workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
			statusId = facadeUtility.getStatusId(workflowId, statusIdOrNameOrWorkflowStatusCombination);
		}
		CollectionGroup[] collectionGroups = collectionService.getApplicableRoutingGroups(collectionId, workflowId, statusId);
		return objectTransformer.transform(collectionGroups, false);
	}
	
	/**
	 * Returns attribute constraints applicable for the given status and collection for logged-in user.<BR>
	 * User may have multiple userclasses, due to its membership in multiple groups which are mapped to the collection with different
	 * userclasses. <b>Since attribute constraints are defined per userclass, multiple constraints in such cases are evaluated and the most
	 * permissive set of attribute constraints are returned.</b> <br/>
	 * Following is the order of constraints permissiveness:
	 * <ol>
	 * <li>No constrained applied</li>
	 * <li>{@link ConstraintTypes#REQUIRE_VALUE}</li>
	 * <li>{@link ConstraintTypes#REQUIRE_CHANGE}</li>
	 * <li>{@link ConstraintTypes#PREVENT_CHANGE}</li>
	 * </ol>
	 * 
	 * For example: If the collection is mapped to 3 Groups - G1, G2 and G3 with userclasses U1, U2 and U3 respectively and logged-on user
	 * is a member of all of these groups.
	 * <ul>
	 * <li>For U1 there is no constraint applied, for U2 {@link ConstraintTypes#REQUIRE_CHANGE} and for U3
	 * {@link ConstraintTypes#PREVENT_CHANGE} - then applicable constraint would be no constraint.</li>
	 * <li>For U1 there is {@link ConstraintTypes#REQUIRE_CHANGE} applied, for U2 {@link ConstraintTypes#REQUIRE_VALUE} and for U3
	 * {@link ConstraintTypes#PREVENT_CHANGE} - then applicable constraint would be {@link ConstraintTypes#REQUIRE_VALUE}.</li>
	 * </ul
	 * 
	 * @param collectionId
	 *            Id of the collection whose applicable constraints are required.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or status workflow combination of the status.For example, status=10 or status=ReadyForPublish or
	 *            status=EditorialWorkflow/ReadyForPublish
	 * @param attributeIdsOrNames
	 *            Array of attribute ids or names whose constraints are required.For example, attributes=2,510,resource id,...
	 * @return List of <code>AttributeConstraintsInfo</code> objects for the given set of attributes applicable for the logged-in user for
	 *         the given status and collection.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws StatusNotFoundException
	 *             If the status with the given id or name or workflow status combination does not exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "applicableconstraints=true")
	@WebReturnType("xmlView")
	public AttributeConstraintsInfoList getApplicableAttributeConstraints(@PathVariable("collectionId") long collectionId,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination,
			@WebArrayParam("attributes") String[] attributeIdsOrNames) throws InvalidCollectionException, StatusNotFoundException,
			QppServiceException {
		long[] attributeIds = facadeUtility.getAttributeIds(attributeIdsOrNames);
		long[] workflowAndStatusId = facadeUtility.getWorkflowAndStatusId(statusIdOrNameOrWorkflowStatusCombination);
		AttributeConstraint[] attributeConstraints = collectionService.getApplicableAttributeConstraints(collectionId,
				workflowAndStatusId[1], attributeIds);
		return objectTransformer.transform(attributeConstraints);
	}

	/**
	 * 
	 * Returns applicable status transition for the given workflow, status and collection for the logged-in user.<br>
	 * If the status transition is overridden for the given userclass, then overridden will be considered.But, if there are no userclass
	 * overridden status transitions then the default status transition is returned.And if the
	 * {@link Workflow#isConstrainedStatusTransition()} flag of workflow is false,then all the statuses of the workflow(expect for the given
	 * status)will be returned in next possible array of statuses.<br>
	 * User may have multiple userclasses, due to its membership in multiple groups which are mapped to the collection with different
	 * userclasses. Thus the overridden status transitions are evaluated in the following manner:
	 * <ul>
	 * <li>Userclasses of the collection mapped logged-in-user and groups (of which logged-in-user is member of) are determined.</li>
	 * <li>For all the applicable userclasses, applicable (default if not overridden for the userclass) status transitions are retrieved.</li>
	 * <li>The set of {@link StatusTransition#getNextPossibleStatusIds()} is union of {@link StatusTransition#getNextPossibleStatusIds()}
	 * from all the status transitions corresponding to the applicable userclasses.</li> </br>
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable status transition is to be evaluated for given status.
	 * @param workflowIdOrName
	 *            Id of the workflow for which applicable status transitions are to be evaluated.
	 * @param statusIdOrName
	 *            Id or name of the status for which status transition is to be retrieved.For example status=10 or
	 *            status=ReadyForPublish.This is an optional parameter if not mentioned then the complete workflow status transitions will
	 *            be returned.
	 * @return List of applicable status transitions for the entire workflow or a particular status and collection.
	 * @throws InvalidCollectionException
	 *             In case collection with the given id doesn't exist or the collection is inaccessible to the logged-in user.
	 * @throws StatusNotFoundException
	 *             In case status with the given id or name doesn't exist.
	 * @throws InvalidStatusException
	 *             In case status doesn't belong to the given workflow.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "statustransitions=true")
	@WebReturnType("xmlView")
	public StatusTransitionInfoList getApplicableStatusTransition(@PathVariable("collectionId") long collectionId,
			@RequestParam(value = "workflow", required = true) String workflowIdOrName,
			@RequestParam(value = "status", required = false) String statusIdOrName)
			throws InvalidCollectionException, StatusNotFoundException, InvalidStatusException, QppServiceException {
		return collectionController
				.getApplicableStatusTransition(collectionId, workflowIdOrName, statusIdOrName);
	}

	/**
	 * Returns initial applicable statuses for the given workflow and collection. In case the given workflow has constrained status
	 * transitions and the collection has multiple applicable userclasses due to its membership, then "Workflow Initiating Statuses" from
	 * all the user classes are merged & returned. However, if workflow does not have constrained status transitions then all statues of the
	 * workflow are returned.
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable "Workflow Initiating Statuses" are to be fetched in context of the given
	 *            workflow.
	 * @param workflowIdOrName
	 *            Id or name of the workflow whose "Workflow Initiating Statuses" are to be fetched.
	 * @return List of applicable "Workflow Initiating Statuses" for the given collection and workflow.
	 * @throws InvalidCollectionException
	 *             In case collection with the given id doesn't exist or the collection is inaccessible to the logged-in user.
	 * @throws WorkflowNotFoundException
	 *             If workflow with the given id or name does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{collectionId}", params = "workflowinitiatingstatuses=true")
	@WebReturnType("xmlView")
	public StatusInfoList getApplicableWorkflowInitialStatuses(@PathVariable("collectionId") long collectionId,
			@RequestParam("workflow") String workflowIdOrName) throws InvalidCollectionException, WorkflowNotFoundException,
			QppServiceException {
		return collectionController.getApplicableWorkflowInitialStatuses(collectionId, workflowIdOrName);
	}
	

	/**
	 * Returns details of the job jacket with the given id.
	 * 
	 * @param jobJacketId
	 *            id of the jobjacket whose definition is required.
	 * @return {@link JobJacketInfoList} object containing job jacket details.
	 * @throws InvalidJobJacketException
	 *             In case jobjacket with the given id doesn't exist
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/jobjackets/{jobJacketId}")
	@WebReturnType("xmlView")
	public JobJacketInfoList getJobjacket(@PathVariable("jobJacketId") long jobJacketId) throws InvalidJobJacketException, QppServiceException {
		return collectionController.getJobJacket(jobJacketId);
	}

	/**
	 * Creates a new jobjacket after parsing the content supplied in input stream or create multiple job jackets from the jobJacketInfoList object & return the 
	 * list of created job jackets. Client can specify either the stream to create one jobjacket or jobjacketinfolist to create multiple jobjackets.
	 * 
	 * @param inputStream
	 *            job jacket xml as input stream. 
	 * @param jobJacketInfoList
	 *            list of job jackets to be created.
	 * @return {@link JobJacketInfoList} list of successfully created job jackets.
	 * @throws InvalidJobJacketException
	 *             Indicates that an invalid job jacket was passed as an argument.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Any unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/jobjackets", params = "op=create")
	@WebReturnType("xmlView")
	public JobJacketInfoList createJobJackets(@WebInputStream InputStream inputStream,
			@WebSerializedParam(value = "jobjacketinfolist") JobJacketInfoList jobJacketInfoList) throws InvalidJobJacketException,
			UserPrivilegeException, QppServiceException{
		return collectionController.createJobJackets(inputStream, jobJacketInfoList);
	}

	/**
	 * Deletes the jobjacket with the given id.
	 * 
	 * @param jobJacketId
	 *            id of the job jacket to be deleted.
	 * @throws InvalidJobJacketException
	 *             If jobjacket with given id does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/jobjackets/{jobJacketId}", params = "op=delete")
	public void deleteJobJacket(@PathVariable("jobJacketId") long jobJacketId) throws InvalidJobJacketException, QppServiceException {
		collectionService.deleteJobJacket(jobJacketId);
	}

	/**
	 * Parses jobjacket xml and return JobJacket object containing jobjacket name and ticket names.
	 * 
	 * @param inputStream
	 *            jobjacket xml as an input stream
	 * @return jobjacketinfo object containing jobjacket name and ticket names.
	 * @throws InvalidJobJacketException
	 *             If xml supplied is not valid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 *             caused by failed or interrupted I/O operations.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/jobjackets", params = "op=parsexml")
	@WebReturnType("xmlView")
	public JobJacketInfo parseJobJacketXml(@WebInputStream InputStream inputStream) throws InvalidJobJacketException, QppServiceException,
			IOException {
		byte[] jobJacketContent = collectionController.getBytes(inputStream);
		JobJacket jobJacket = collectionService.parseJobJacketXml(jobJacketContent);
		return objectTransformer.transform(jobJacket, true/*getDetailedInfo*/, -1);
	}

	/**
	 * Updates the given jobjacket.
	 * 
	 * @param jobJacketId
	 *            id of the jobjacket to be updated.
	 * @param inputStream
	 *            job jacket xml as input stream
	 * @throws InvalidJobJacketException
	 *             Jobjacket with given id does not exist OR jobjacket xml content supplied is not valid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 *             caused by failed or interrupted I/O operations.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/jobjackets/{jobJacketId}", params = "op=update")
	public void updateJobJacket(@PathVariable("jobJacketId") long jobJacketId, @WebInputStream InputStream inputStream)
			throws InvalidJobJacketException, QppServiceException, IOException {
		byte[] jobJacketContent = collectionController.getBytes(inputStream);
		collectionService.updateJobJacket(jobJacketId, jobJacketContent);
	}

	/**
	 * Move collection along with child collections and assets under new parent collection
	 * 
	 * @param collectionId
	 *            Id of the collection to be moved.
	 * @param targetParentColIdOrPathOrName
	 *            Id or collection path or name of the collection in which collection is to be moved.
	 * @return CollectionInfo object of the moved collection.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{collectionId}", params = "op=move")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo moveCollection(@PathVariable("collectionId") long collectionId,
			@RequestParam("targetparent") String targetParentColIdOrPathOrName) throws InvalidCollectionException, RepositoryActionException,
			QppServiceException {
		boolean isCollectionTemplate = collectionService.getCollectionInfo(collectionId).isCollectionTemplate(); 
		if(isCollectionTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("moveCollectionTemplate", collectionId);
		}else{
			privilegeValidator.validateApplicationPrivilegesForCollection("moveCollection", collectionId);
		}
		long targetParentCollectionId = facadeUtility.getCollectionId(targetParentColIdOrPathOrName);
		Collection collection = collectionService.moveCollection(collectionId, targetParentCollectionId);
		return objectTransformer.transform(collection);
	}

	
	/**
	 * Duplicates a collection. By default the metadata of the original collection like workflows, users, routings, revisioncontrols etc..will be mapped to the new collection being created.
	 * In order to prevent the original collection metadata being mapped to new collection, set the boolean flags like duplicateWorkflows, duplicateMembers,..as false.
	 * If assets flag is true, then assets are also duplicated along with the collection. In case the assets are also to be duplicated then metadata flags like
	 * duplicateHierarchy, duplicateWorkflows, duplicateMembers, etc will be overridden as true.
	 * 
	 * @param collectionId
	 *            Id of the collection that needs to be duplicated.
	 * @param collectionName
	 *            Name to be used for duplicated collection.
	 * @param targetParentColIdOrPathOrName
	 *            Id or collection path or name of the collection under which the given collection would be duplicated. If
	 *            specified 0, collection would be duplicated parallel to the source collection.
	 * @param duplicateHierarchy
	 *            A boolean flag indicating whether to duplicate only given collection or collection with complete
	 *            hierarchy. While duplicating the collection hierarchy, only collections would be duplicated and
	 *            collection templates would be ignored.
	 * @param duplicateWorkflows
	 *            A boolean flag indicating whether to duplicate collection workflows.
	 * @param duplicateMembers
	 *            A boolean flag indicating whether to duplicate collection users and groups.
	 * @param duplicateStatusRoutings
	 *            A boolean flag indicating whether to duplicate collection status routings. This argument has
	 *            dependency on duplicateWorkflows and duplicateMembers. So if it is true but one of duplicateWorkflows
	 *            and duplicateMembers is false then it would be considered as false.
	 * @param duplicateJobjackets
	 *            A boolean flag indicating whether to duplicate collection jobjackets.
	 * @param duplicateRevisionControls
	 *            A boolean flag indicating whether to duplicate collection revision control settings.
	 * @param duplicateWithAssets
	 *            boolean flag to indicate whether the assets are also to be duplicated along with collection.
	 * @param createAssetsMinorVersion
	 *            boolean flag specifying whether to duplicate collection assets as a minor version or as a major
	 *            version.
	 * @return {@link com.quark.qpp.service.xmlBinding.CollectionInfo} object of the new duplicated collection.
	 * @throws InvalidCollectionException
	 *             This exception is thrown in case of following cases: <li>If collectionId is invalid. <li>If you don't
	 *             have access to parent collection of the collection that is being duplicated. <li>If the name being
	 *             supplied is not unique.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{collectionId}", params = "op=duplicate")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo duplicateCollection(@PathVariable("collectionId") long collectionId,
			@RequestParam("name") String collectionName, @RequestParam("targetparent") String targetParentColIdOrPathOrName,
			@RequestParam(value = "duphierarachy", defaultValue = "true") boolean duplicateHierarchy,
			@RequestParam(value = "dupworkflows", defaultValue = "true") boolean duplicateWorkflows,
			@RequestParam(value = "dupmembers", defaultValue = "true") boolean duplicateMembers,
			@RequestParam(value = "duproutings", defaultValue = "true") boolean duplicateStatusRoutings,
			@RequestParam(value = "dupjobjackets", defaultValue = "true") boolean duplicateJobjackets,
			@RequestParam(value = "duprevisioncontrols", defaultValue = "true") boolean duplicateRevisionControls,
			@RequestParam(value = "assets", defaultValue = "false") boolean duplicateWithAssets,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createAssetsMinorVersion) throws InvalidCollectionException,
			RepositoryActionException, QppServiceException {
		boolean isCollectionTemplate = collectionService.getCollectionInfo(collectionId).isCollectionTemplate(); 
		if(isCollectionTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("duplicateCollectionTemplate", collectionId);
		}else{
			privilegeValidator.validateApplicationPrivilegesForCollection("duplicateCollection", collectionId);
		}
		
		long targetParentCollectionId = facadeUtility.getCollectionId(targetParentColIdOrPathOrName);
		Collection duplicatedCollection = null;
		if (duplicateWithAssets) {
			duplicatedCollection = collectionService.duplicateCollectionWithAssets(collectionId, targetParentCollectionId, collectionName,
					createAssetsMinorVersion);
		} else {
			CollectionInfo collectionInfo = collectionService
					.duplicateCollection(collectionId, collectionName, targetParentCollectionId, duplicateHierarchy, duplicateWorkflows,
							duplicateMembers, duplicateStatusRoutings, duplicateJobjackets, duplicateRevisionControls);
			duplicatedCollection = collectionService.getCollection(collectionInfo.getId());
		}
		return objectTransformer.transform(duplicatedCollection);
	}

	/**
	 * Creates new collection in the given parent collection and with the given metadata. Only users having access to the parent collection
	 * (in which collection is being created) would be allowed to create the collection.By default, the metadata like workflows, users,
	 * revisioncontrols, etc are mapped from the parent collection to the new collection being created. Admin user and logged-in user are
	 * implicitly mapped to the newly created collection. But when you instantiate a collection from template the parent collection's
	 * users/workflows/groups/.. will not be copied to newly instantiated collection instead the collection template's users/groups,... will
	 * be implicitly mapped to the new collection.
	 * 
	 * @param newCollectionName
	 *            name for new collection to be created.
	 * @param parentcollectionIdOrPathOrName
	 *            id or path or name of the collection under which the new collection would be created.
	 *            Example the input can be 10 or MyCollection or Home/MyCollectionA/MyCollection
	 * @param isTemplate
	 *            boolean flag if true indicates create a collection template else will create a new collection.
	 * @param contentTypeIdOrPathOrName
	 *            type of the collection to be created. Default value is {@link DefaultContentTypes#GENERAL}
	 * @param attributeValueList
	 *            Metadata to be associated with the collection.
	 * @return collectionInfo object of the newly created collection
	 * @throws InvalidCollectionException
	 *             If the collection, having id or collection path specified in parentCollection parameter, either does not exist or the
	 *             logged on user has not access to this collection.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values in supplied in the attributeValueList array is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{newCollectionName}", params = "op=create")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo createCollection(@PathVariable("newCollectionName") String newCollectionName,
			@RequestParam("targetparent") String parentcollectionIdOrPathOrName, @RequestParam(value = "istemplate", defaultValue = "false") boolean isTemplate,
			@RequestParam(value = "contenttype", required = false) String contentTypeIdOrPathOrName,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList) throws InvalidCollectionException,
			InvalidAttributeValueException, RepositoryActionException, QppServiceException {
		
		long parentcollectionId = facadeUtility.getCollectionId(parentcollectionIdOrPathOrName);
		
		if(isTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("createEditCollectionTemplate", parentcollectionId);
		}else{
			privilegeValidator.validateApplicationPrivilegesForCollection("createCollection",parentcollectionId );
		}
		
		com.quark.qpp.core.attribute.service.dto.AttributeValue[] attributeValues = objectTransformer.transform(attributeValueList);
		attributeValues = attributeUtility.addAttributeValue(attributeValues, DefaultAttributes.NAME, AttributeValueTypes.TEXT, new TextValue(
				newCollectionName));
		attributeValues = attributeUtility.addAttributeValue(attributeValues, DefaultAttributes.IS_COLLECTION_TEMPLATE, AttributeValueTypes.BOOLEAN,
				new BooleanValue(isTemplate));
		long contentTypeId = 0;
		if (contentTypeIdOrPathOrName == null) {
			contentTypeId = DefaultContentTypes.GENERAL;
		} else {
			contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrPathOrName);
		}
		attributeValues = attributeUtility.addAttributeValue(attributeValues, DefaultAttributes.CONTENT_TYPE, AttributeValueTypes.DOMAIN,
				new DomainValue(contentTypeId));
		Collection newCollection = collectionService.createCollection(parentcollectionId, attributeValues);
		
		AttributeValue[] attValues = collectionService.getCollectionAttributeValues(newCollection.getId(),
				new long[] { DefaultAttributes.COLLECTION_TEMPLATE });
		/*
		 * In case the collection is not instantiated from a collection template, copy the parent collection's users/groups/workflows/... to
		 * the newly created child collection.
		 */
		if (attValues == null || attValues.length == 0) {
			Collection parentCollection = collectionService.getCollection(parentcollectionId);

			long[] workflowIds = getCollectionWorkflowIds(parentCollection.getWorkflows());

			collectionService.setCollectionWorkflows(newCollection.getId(), workflowIds, true, true);

			collectionService.setCollectionTrustees(newCollection.getId(), parentCollection.getCollectionGroups(), parentCollection.getCollectionUsers(), true, true, true, true);

			collectionService.setRevisionControls(newCollection.getId(), parentCollection.getRevisionControls(), true);

			for (int i = 0; i < workflowIds.length; i++) {
				Routing[] routings = collectionService.getStatusRoutings(parentCollection.getId(), workflowIds[i]);
				collectionService.setStatusRoutings(newCollection.getId(), workflowIds[i], routings, true, true);
			}

			long[] jobJacketIds = getJobJacketIds(parentCollection.getJobJackets());

			collectionService.setCollectionJobjackets(newCollection.getId(), jobJacketIds, true, true);
		}
		return objectTransformer.transform(collectionService.getCollection(newCollection.getId()));
	}

	private long[] getJobJacketIds(JobJacket[] jobJackets) {
		long[] jobJacketIds = new long[jobJackets.length];
		for (int i = 0; i < jobJackets.length; i++) {
			jobJacketIds[i] = jobJackets[i].getId();
		}
		return jobJacketIds;
	}

	private long[] getCollectionWorkflowIds(Workflow[] workflows) {
		long[] workflowIds = new long[workflows.length];
		for (int i = 0; i < workflows.length; i++) {
			workflowIds[i] = workflows[i].getId();
		}
		return workflowIds;
	}

	/**
	 * Updates the collection metadata depending upon the supplied data.
	 * 
	 * @param collectionId
	 *            id of the collection whose metadata is to be updated.
	 * @param attributeValueList
	 *            attributeValueList object containing the attributes to be updated.
	 * @param groupInfoList
	 *            List of groups to be mapped to the given collection. In groupInfo, either the group id or name must be specified to
	 *            identify the group.
	 * @param jobjacketIds
	 *            Ids of the jobjackets to be mapped for given collection.
	 * @param userInfoList
	 *            {@link UserInfoList} object containing info of users to be mapped for given collection. Id or name of the user is
	 *            mandatory to map a user to collection.
	 * @param workflows
	 *            Names or Ids of the workflows to be mapped for given collection.
	 * @param revisionControlInfoList
	 *            {@link RevisionControlInfoList} object containing list of revision controls to be set.
	 * @param routingInfoList
	 *            {@link RoutingInfoList} object containing routing info to be set.
	 * @param defaultTicketName
	 *            name of the ticket template to be set as default for the collection.
	 * @param applyToChildren
	 *            true if the updations(like groups/workflows/..) need to be applied to all of the sub-collections as well. In this case
	 *            existing mapped(groups/workflows/..) of all the sub-collections would be overridden.
	 * @param appendToChildren
	 *            true if the updations(like groups/workflows/..) need to be merged to all sub-collections. In this case existing
	 *            mapped(workflows/groups/...) of sub-collections would remain intact whereas any additional would be added to the
	 *            sub-collections.
	 * @return CollectionInfo containing updated details of the collection
	 * @throws InvalidCollectionException
	 *             If the collection, having id or collection path specified in parentCollection parameter, either does not exist or the
	 *             logged on user has not access to this collection.
	 * @throws InvalidJobJacketException
	 *             In case the jobjacket with given id is invalid.
	 * @throws WorkflowInUseException
	 *             If any Asset in specified Collection is assigned a Workflow which is not in the specified list of workflowIds. The
	 *             Workflow cannot be dissociated from the collection until any Asset in the collection is assigned to that Workflow.
	 *             AdditionalInfo of exception would contain the workflowId and collectionId for which exception has occured.
	 * @throws WorkflowNotFoundException
	 *             If the workflow with given id or name doesnot exist.
	 * @throws StatusNotFoundException
	 *             If the status with given id doesnot exist.
	 * @throws TrusteeNotFoundException
	 *             If the trustee with given id doesnot exist.
	 * @throws AttributeNotFoundException
	 *             In case attribute with given id/name doesn't exist.
	 * @throws InvalidRevisionControlException
	 *             If revision control details are invalid. The exception code specifies exact reason.
	 * @throws InvalidUserException
	 *             If the user id specified in invalid.
	 * @throws InvalidGroupException
	 *             If the group id/name specified is invalid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{collectionId}", params = "op=update")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo updateCollection(@PathVariable("collectionId") long collectionId,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @WebSerializedParam("groups") GroupInfoList groupInfoList,
			@WebArrayParam("jobjackets") long[] jobjacketIds, @WebSerializedParam("users") UserInfoList userInfoList,
			@WebArrayParam("workflows") String[] workflows, @WebSerializedParam("revisioncontrols") RevisionControlInfoList revisionControlInfoList,
			@WebSerializedParam("routings") RoutingInfoList routingInfoList,
			@RequestParam(value = "ticketname", required = false) String defaultTicketName,
			@RequestParam(value = "applytochildren", defaultValue = "false") boolean applyToChildren,
			@RequestParam(value = "appendtochildren", defaultValue = "false") boolean appendToChildren) throws InvalidCollectionException,
			 WorkflowInUseException, WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException,
			InvalidRevisionControlException, InvalidUserException, AttributeNotFoundException, InvalidJobJacketException, InvalidGroupException,
			RepositoryActionException, QppServiceException {
		
		
		boolean isCollectionTemplate = collectionService.getCollectionInfo(collectionId).isCollectionTemplate(); 
		if(isCollectionTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("createEditCollectionTemplate", collectionId);
		}
		
		if (attributeValueList != null && attributeValueList.getAttributeValue().size() > 0) {
			if(!isCollectionTemplate){
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyCollectionGeneralProperties", collectionId);
			}
			AttributeValue[] attributeValues = objectTransformer.transform(attributeValueList);
			attributeValues = collectionService.setAttributeValues(collectionId, attributeValues);
		}
		
		if(groupInfoList != null || userInfoList != null){
			if(!isCollectionTemplate){
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyCollectionUsersGroups", collectionId);
			}
			collectionController.setCollectionTrustees(collectionId, groupInfoList, userInfoList, applyToChildren, appendToChildren);
		}
		if (jobjacketIds != null && jobjacketIds.length > 0) {
			if(!isCollectionTemplate){
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyCollectionJobJackets", collectionId);
			}
			collectionService.setCollectionJobjackets(collectionId, jobjacketIds, applyToChildren, appendToChildren);
		}
		
		if (revisionControlInfoList != null && revisionControlInfoList.getRevisionControlInfo().size() > 0) {
			if(!isCollectionTemplate){
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyCollectionRevisionControls", collectionId);
			}
			RevisionControl[] revisionControls = objectTransformer.transform(revisionControlInfoList);
			RevisionControl[] mergedRevisionControls = collectionController.mergeRevisionControls(revisionControls, collectionId);
			collectionService.setRevisionControls(collectionId, mergedRevisionControls, applyToChildren);
		}
		if (workflows!= null && workflows.length >= 0) {
			if(!isCollectionTemplate){
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyCollectionWorkflows", collectionId);
			}
			long[] workflowIds =  facadeUtility.getWorkflowIds(workflows);
			collectionService.setCollectionWorkflows(collectionId, workflowIds, applyToChildren, appendToChildren);
		}
		if (routingInfoList != null && routingInfoList.getRoutingInfo().size() > 0) {
			if (!isCollectionTemplate) {
				privilegeValidator.validateApplicationPrivilegesForCollection("modifyStatusBasedRoutings", collectionId);
			}
			List<RoutingInfo> list = routingInfoList.getRoutingInfo();
			long workflowId = -1;
			if (workflows != null && workflows.length > 0) {
				workflowId = facadeUtility.getWorkflowIds(new String[] { workflows[0] })[0];
			}
			for (int i = 0; i < list.size(); i++) {
				RoutingInfo routingInfo = list.get(i);
				if ((routingInfo.getWorkflow() == null || routingInfo.getWorkflow().trim().length() == 0)
						&& routingInfo.getWorkflowId() <= 0) {
					routingInfo.setWorkflowId(workflowId);
				}
			}
			collectionController.setCollectionRouting(collectionId, routingInfoList, applyToChildren, appendToChildren);
		}
		
		if (defaultTicketName != null && jobjacketIds.length > 0) {
			collectionService.setCollectionDefaultJobJacket(collectionId, jobjacketIds[0], defaultTicketName, applyToChildren);
		}
		Collection collection = collectionService.getCollection(collectionId);
		return objectTransformer.transform(collection);
	}
	
	

	/**
	 * Deletes the given collection from the system. Only empty collections are allowed for deletion. This means
	 * collection can only be deleted if the collection and all its child collection do not have any assets in them.
	 * Moreover, only users who have access to the given collection are allowed to delete the collection.
	 * 
	 * @param collectionId
	 *            id of the collection to be deleted.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 *             Exact reason of the exception can be known by calling getExceptionCode() of the exception.
	 * @throws CollectionInUseException
	 *             If collection being deleted is not empty i.e. either collection or some of its child collection
	 *             contains assets in them.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method=RequestMethod.POST, value="/{collectionId}", params="op=delete")
	public void deleteCollection(@PathVariable long collectionId) throws InvalidCollectionException, CollectionInUseException, QppServiceException{
		boolean isCollectionTemplate = collectionService.getCollectionInfo(collectionId).isCollectionTemplate(); 
		if(isCollectionTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("deleteCollectionTemplate",collectionId);
		}else{
			privilegeValidator.validateApplicationPrivilegesForCollection("deleteCollection",collectionId);
		}
		collectionService.deleteCollection(collectionId);
	}
	
	/**
	 * Deletes the given collection from the system along with its sub-collections and assets. 
	 * Only users who have access to the given collection are allowed to delete the collection.
	 * 
	 * @param collectionId
	 *            id of the collection to be deleted.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 *             Exact reason of the exception can be known by calling getExceptionCode() of the exception.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method=RequestMethod.POST, value="/{collectionId}", params="op=deletewithassets")
	public void deleteCollectionWithAssets(@PathVariable long collectionId) throws InvalidCollectionException, QppServiceException{
		boolean isCollectionTemplate = collectionService.getCollectionInfo(collectionId).isCollectionTemplate(); 
		if(isCollectionTemplate){
			privilegeValidator.validateApplicationPrivilegesForCollection("deleteCollectionTemplate",collectionId );
		}else{
			privilegeValidator.validateApplicationPrivilegesForCollection("deleteCollection",collectionId);
		}
		deleteAllAssetsInCollection(collectionId, true);
		
		collectionService.deleteCollection(collectionId);
	}

	/**
	 * This method deletes all the assets in a collection. In order to delete the assets of the child collections recursively, set the recursive flag true. 
	 * @param collectionId
	 * 			id of the collection whose assets are to be deleted.
	 * @param recursive
	 * 			boolean flag to indicate whether the assets are to be deleted recursively in child collections
	 * @throws InvalidQueryDefinitionException
	 * @throws InvalidQueryDisplayException
	 * @throws QppServiceException
	 */
	private void deleteAllAssetsInCollection(long collectionId, boolean recursive) throws QppServiceException  {
		
		AssetElement[] assets = collectionController.getAssetsInCollection(collectionId, recursive, null);
		
		//Validate privileges for all assets
		for (int i = 0;assets != null && i < assets.length; i++) {
			long assetId = assets[i].getAssetId();
			boolean isAssetAssignedToOtherUser = privilegeValidator.isAssetAssignedToOtherUser(assetId);
			if (isAssetAssignedToOtherUser) {
				privilegeValidator.validateContentTypePrivileges(assetId, null, "getAssetAssignedToOtherUser");
			}
			privilegeValidator.validateContentTypePrivileges(assetId, assets[i].getAttributeValues(), "deleteAsset");
		}
		
		//Delete assets
		for (int i = 0;assets != null && i < assets.length; i++) {
			assetService.lockAsset(assets[i].getAssetId());
			assetService.deleteAsset(assets[i].getAssetId());			
		}
		if(assets.length > 0)
			deleteAllAssetsInCollection(collectionId, recursive);
		else
			return;
	}
	
	/**
	 * Returns all the accessible collection hierarchies to the logged on user. By default the below mentioned flags are false and thus this method
	 * will return metadata of each collection in the hierarchy. The parameters like getAssets/getUsers/,,,/attributes will be considered for
	 * every collection in the hierarchy. For example if getUsers flag is true, it will retrieve users for all the collections down the
	 * hierarchy. Thus the behaviour of parameters like getAssets/attributes/getUsers/... will be replicated to every collection in the
	 * hierarchy.
	 * 
	 * @param attributes
	 *            array of collection attributes to be retrieved. An attribute can be specified by id or name. Example : 2,created, Is
	 *            Template, 57,Content Type Hierarchy,......
	 * @param getAssets
	 *            boolean flag to retrieve each collection's assets.
	 * @param getWorkflows
	 *            get all applicable worklfow's for each collection in the hierarchy. Specify contenttypes parameter in order to get
	 *            workflow's associated with these content types only.
	 * @param getUsers
	 *            get users mapped to each collection
	 * @param getGroups
	 *            get groups mapped to each collection
	 * @param getRoutings
	 *            get status routings for each collection for mentioned workflow.
	 * @param getRevisionControls
	 *            get revision controls for each collection.
	 * @param getJobJackets
	 *            get jobjacket's mapped to each collection
	 * @param contentTypes
	 *            array of content types (id, path (e.g. System;Asset;Document) or name(e.g. Document)) corresponding to which workflow's will be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required. If workflow is not given but worklfows=true, then status
	 *            routing preferences of all applicable workflow in the collection is being provided.Thus it is mandatory to specify either the
	 *            workflow parameter or enable the getWorkflows flag to fetch status routings.
	 *  @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return CollectionInfoList encapsulating the accessible collection hierarchies to the logged on user.
	 * @throw UserPrivilegeException This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will
	 *        refer to the disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, params = "hierarchy=true")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfoList getAccessibleCollectionHierarchies(
			@WebArrayParam(value = "attributes") String[] attributes,
			@RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets,
			@WebArrayParam("contenttypes") String[] contentTypes, @RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes)
			throws InvalidCollectionException, QppServiceException {
		return collectionController.getAccessibleCollectionHierarchies(attributes, getAssets, getWorkflows, getUsers, getGroups,
				getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
	}

	/**
	 * Returns accessible top level collections for the logged on user. By default all the below mentioned flags are false. These flags are
	 * considered only for top level collections & will not be considered for child collections/parent collections, in case childCollections
	 * or parentCollections is true. In case none of the below flag is enabled, the returned CollectionInfoList will contain each
	 * collections meta data i.e. attributeValueList containing collection attributes.
	 * 
	 * @param attributes
	 *            array of collection attributes to be retrieved. An attribute can be specified by id or name. Example : 2,created, Is
	 *            Template, 57,Content Type Hierarchy,......
	 * @param getAssets
	 *            boolean flag to retrieve top level collection's assets.
	 * @param getChildCollections
	 *            boolean flag if true, will return immediate children of each top level collection.
	 * @param getWorkflows
	 *            get all applicable worklfow's for each top level collection. Specify contenttypes parameter inorder to get workflow's
	 *            associated with these content types.
	 * @param getUsers
	 *            get users mapped to each top level collection
	 * @param getGroups
	 *            get groups mapped to each top level collection
	 * @param getRoutings
	 *            get status routings for each top level collection for mentioned workflow.
	 * @param getRevisionControls
	 *            get revision controls for each top level collection.
	 * @param getJobJackets
	 *            get jobjackets mapped to each top level collection
	 * @param contentTypes
	 *            array of content types (id, path or name) corresponding to which workflow's will be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required. If workflow is not given but worklfows=true, then status
	 *            routing preferences of all applicable workflow in the collection is being provided. Thus it is mandatory to specify either the
	 *            workflow parameter or enable the getWorkflows flag to fetch status routings.
	 *  @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return List of accessible top level collections to the logged on user.
	 * @throw UserPrivilegeException This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will
	 *        refer to the disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType("xmlView")
	public CollectionInfoList getAccessibleTopLevelCollections(@WebArrayParam(value = "attributes") String[] attributes,
			@RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "childcollections", defaultValue = "false") boolean getChildCollections,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets,
			@WebArrayParam("contenttypes") String[] contentTypes, @RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes)
			throws UserPrivilegeException, QppServiceException {
		return collectionController.getAccessibleTopLevelCollections(attributes, getAssets, getChildCollections, getWorkflows, getUsers, getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
	}

	/**
	 * Creates new collection in the given parent collection and with the given metadata. Only users having access to the parent collection
	 * (in which collection is being created) would be allowed to create the collection. Admin user and logged-in user are implicitly mapped
	 * to the newly created collection.
	 * Minimal XML to create a collection
	 * 
	 * <collectionInfo collectionPath="Home/demo/star">
			<attributeValueList>
				<attributeValue valueId="0" type="text" name="Name" id="2">star</attributeValue>
				<attributeValue valueId="0" type="boolean" name="Is Template" id="59">false</attributeValue>
				<attributeValue valueId="1416" type="popup" name="Content Type" id="62">General</attributeValue>
			</attributeValueList>
		</collectionInfo>
	 * 
	 * <p>
	 * Collection metadata is represented by array of <code>AttributeValueList</code> objects. Thus, while creating collection you can set
	 * any attribute as a part of metadata. However, there are certain set of attributes whose value is mandatory for the creation of new
	 * collection. Collection cannot be created without specifying values for such attributes. Mandatory attributes are like :
	 * {@link DefaultAttributes#NAME} name of the collection to be created {@link DefaultAttributes#CONTENT_TYPE} the content type of the
	 * collection to be created like General, {@link DefaultAttributes#IS_COLLECTION_TEMPLATE} is collection template
	 * {@link DefaultAttributes#COLLECTION_PATH} Collection path will help in fetching the hierarchy where collection is to be created. For
	 * instance in order to create collection 'Test' under Home, specify collection path as 'Home/Test'
	 * 
	 * @param collectionInfoList
	 *            list of collections and their subsequent children to be created.
	 * @return list of the newly created collections including the child hierarchy.
	 * @throws WorkflowInUseException
	 *             If any Asset in specified Collection is assigned a Workflow which is not in the specified list of workflowIds. The
	 *             Workflow cannot be dissociated from the collection until any Asset in the collection is assigned to that Workflow.
	 *              AdditionalInfo of exception would contain the workflowId and collectionId for which exception has occurred.
	 * @throws InvalidUserException
	 *             if user id specified in any of the elements is invalid.
	 * @throws InvalidUserClassException
	 *             if role id specified in any of the elements is invalid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws InvalidGroupException
	 *             if group id specified in any of the elements is invalid.
	 * @throws InvalidRevisionControlException
	 *             If revision control details are invalid.
	 * @throws InvalidJobJacketException
	 *             If given defaultJobJacketId or defaultTicketName is not valid.
	 * @throws TrusteeNotFoundException
	 *             if the trustee(user/group) id in any of the supplied routing objects is invalid.
	 * @throws StatusNotFoundException
	 *             if status name or id specified is invalid
	 * @throws WorkflowNotFoundException
	 *             if workflow name or id specified is invalid.
	 * @throws InvalidRoutingException
	 *             if the routing type in any of the supplied routing objects is invalid.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values in supplied in the attributeValues array is not valid.
	 * @throws InvalidCollectionException
	 *             if provided collection information is not appropriate.
	 * @throws QppServiceException
	 *             unhandled exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=create")
	@WebReturnType("xmlView")
	public CollectionInfoList createCollections(@WebSerializedParam("collectioninfolist") CollectionInfoList collectionInfoList) throws InvalidCollectionException, UserPrivilegeException,
			InvalidAttributeValueException, InvalidRoutingException, WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException, InvalidJobJacketException, InvalidRevisionControlException, InvalidGroupException, RepositoryActionException,
			InvalidUserClassException, InvalidUserException, WorkflowInUseException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createCollection");
		return collectionController.createCollections(collectionInfoList);
	}

	/**
	 * Updates attribute values, workflows, users, groups, routings, jobjackets and revision controls of the collection with given name or
	 * id. Only users having access to the given collection would be allowed to update the metadata of the collection.
	 * <p>
	 * Only attribute values supplied in the <code>attributeValueList</code> will be updated and remaining attributes value would remain
	 * intact. Whereas users, groups, workflows,routings, jobjackets & revision controls will be overridden completely.
	 * 
	 * @param collectionInfoList
	 *            {@link CollectionInfoList} object consisting list of collections to be updated.
	 * @return {@link CollectionInfoList} list of collections updated successfully.
	 * @throws AttributeNotFoundException
	 *             if provided attribute with given name or id is not available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values in supplied in the attributeValues array is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws InvalidRoutingException
	 *             if the routing type in any of the supplied routing objects is invalid.
	 * @throws WorkflowNotFoundException
	 *             if workflow name or id specified is invalid.
	 * @throws StatusNotFoundException
	 *             if status name or id specified is invalid
	 * @throws TrusteeNotFoundException
	 *             if the trustee(user/group) id in any of the supplied routing objects is invalid.
	 * @throws InvalidJobJacketException
	 *             If given defaultJobJacketId or defaultTicketName is not valid.
	 * @throws InvalidRevisionControlException
	 *             If revision control details are invalid.
	 * @throws InvalidGroupException
	 *             if group id specified in any of the elements is invalid.
	 * @throws InvalidUserClassException
	 *             if role id specified in any of the elements is invalid.
	 * @throws InvalidUserException
	 *             if user id specified in any of the elements is invalid.
	 * @throws WorkflowInUseException
	 *             If any Asset in specified Collection is assigned a Workflow which is not in the specified list of workflowIds. The
	 *             Workflow cannot be dissociated from the collection until any Asset in the collection is assigned to that Workflow.
	 * @throw UserPrivilegeException This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will
	 *        refer to the disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=update")
	@WebReturnType("xmlView")
	public CollectionInfoList updateCollections(@WebSerializedParam("collectioninfolist") CollectionInfoList collectionInfoList) throws AttributeNotFoundException,
			InvalidCollectionException, InvalidAttributeValueException, RepositoryActionException,
			InvalidRoutingException, WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException,
			InvalidJobJacketException, InvalidRevisionControlException, InvalidGroupException, InvalidUserClassException,
			InvalidUserException, WorkflowInUseException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("updateCollection");
		return collectionController.updateCollections(collectionInfoList);
	}
	
	/**
	 * It returns all the jobjackets available in the system.
	 * 
	 * @return {@link JobJacketInfoList} list of all the job jackets in the system.
	 * @throws InvalidJobJacketException Indicates that an invalid job jacket was passed as an argument. For example, this exception could
	 *         be thrown when the name of the job jacket is null or empty string, or the job jacket object itself is null.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/jobjackets")
	@WebReturnType("xmlView")
	public JobJacketInfoList getAllJobJackets() throws UserPrivilegeException, QppServiceException {
		return collectionController.getAllJobJackets();
	}

	/**
	 * Updates jobjacket's content on the basis of id or name.  
	 * 
	 * @param jobJacketInfoList
	 *            list of job jackets to be updated.
	 * @return {@link JobJacketInfoList} list of updated jobjackets.
	 * @throws InvalidJobJacketException
	 *             In case of an invalid job jacket.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/jobjackets", params = "op=update")
	@WebReturnType("xmlView")
	public JobJacketInfoList updateJobJackets(@WebSerializedParam(value = "jobjacketinfolist") JobJacketInfoList jobJacketInfoList) throws InvalidJobJacketException,
			UserPrivilegeException, QppServiceException{
		return collectionController.updateJobJackets(jobJacketInfoList);
	}
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * @param qppServiceException
	 *            QppServiceException that is to be handled
	 * @return QppServiceExceptionInfo object containing details of the exception thrown
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
}

package com.quark.qpp.service.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.publishing.service.dto.PublishingChannel;
import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.local.PublishingService;
import com.quark.qpp.core.configuration.service.dto.CustomXmlMimeType;
import com.quark.qpp.core.configuration.service.dto.ReInitializeConfigSettings;
import com.quark.qpp.core.configuration.service.exceptions.ConfigurationServiceExceptionCodes.InvalidXmlMimeTypeExceptionCodes;
import com.quark.qpp.core.configuration.service.exceptions.InvalidChannelConfigException;
import com.quark.qpp.core.configuration.service.exceptions.InvalidPublishingProcessException;
import com.quark.qpp.core.configuration.service.exceptions.InvalidXmlMimeTypeException;
import com.quark.qpp.core.configuration.service.local.ConfigurationService;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.MimeTypeInfoList;
import com.quark.qpp.service.xmlBinding.NameValueList;
import com.quark.qpp.service.xmlBinding.Parameter;
import com.quark.qpp.service.xmlBinding.PublishingChannelInfo;
import com.quark.qpp.service.xmlBinding.PublishingChannelList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * This facade defines the APIs to perform configuration related operations create, delete, re-initialize : xml mime-types, channels, 
 * publishing processes, content mime-type mappings, content-type to channel mappings, content-type to indexing channel mappings etc...
 */

@Controller("configurationFacade")
@RequestMapping("/config")
public class ConfigurationFacade {
	
	@Autowired
	private ConfigurationService configurationService;
	
	@Autowired
	private PublishingService publishingService;
	
	@Autowired
	private ObjectTransformer objectTransformer;
	
	@Autowired
	private FacadeUtility facadeUtility;

	/**
	 * Creates a mime-type for an xml document. It is mandatory to specify
	 * either the xPath (to detect mime-type based on xpath) or the piName and
	 * piValue (processing instruction and value, to detect mime-type based on
	 * piName and piValue). It is also mandatory to specify the parent mime
	 * type. Mime Type will be added to its configuration file
	 * "custom-xml-types-ext.xml".
	 * 
	 * @param mimeType
	 *            xml mime-type to be created.
	 * @param parentMimeType
	 *            parent mime-type of the xml mime-type to be created.
	 * @param xPath
	 *            the xpath based on which an xml-asset's mime-type will be
	 *            detected.
	 * @param piName
	 *            the processing instruction name based on which an xml-asset's
	 *            mime-type will be detected.
	 * @param piValue
	 *            the processing instruction value based on which an xml-asset's
	 *            mime-type will be detected.
	 * @throws InvalidXmlMimeTypeException
	 *             if mimeType is invalid or it already exists. if
	 *             parentMimeType is invalid. if both xPath or piName and
	 *             piValue are not specified.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/xmlmimetypes", params = "op=create")
	public void createXmlMimeType(
			@RequestParam(value = "mimetype") String mimeType,
			@RequestParam(value = "parentmimetype") String parentMimeType,
			@RequestParam(value = "xpath", defaultValue = "") String xPath,
			@RequestParam(value = "piname", defaultValue = "") String piName,
			@RequestParam(value = "pivalue", defaultValue = "") String piValue)
			throws InvalidXmlMimeTypeException, QppServiceException {
		configurationService.createXmlMimeType(new CustomXmlMimeType(mimeType, parentMimeType, xPath, piName, piValue));
	}
	
	/**
	 * Deletes an xml mime-type and if this mime-type is mapped to a
	 * content-type, that mapping is also deleted.
	 * 
	 * @param mimeType
	 *             xml mime-type to be deleted.
	 * @throws InvalidXmlMimeTypeException
	 *             if mimeType is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/xmlmimetypes", params = "op=delete")
	public void deleteXmlMimeType(@RequestParam("mimetype") String mimeType)
			throws InvalidXmlMimeTypeException, QppServiceException {
		configurationService.deleteXmlMimeType(mimeType);
	}

	/**
	 * Maps a content-type to a list of mime-types. Content Type to Mime Type
	 * mappings will be added to their configuration file
	 * "content-mimetype-mappings-ext.xml".
	 * 
	 * @param contentTypeIdOrName
	 *            content type to which the mime types are to be mapped.
	 * @param mimeTypes
	 *            Array of mime types which are to be mapped to the given
	 *            content type.
	 * @throws InvalidXmlMimeTypeException If mime types are invalid. If the mime
	 *        		types are already mapped to a content type.
	 * @throws InvalidContentTypeException
	 *             If content type id or name is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/xmlmimetypes", params = "op=mapcontenttype")
	public void mapMimeTypes(
			@RequestParam(value = "contenttype") String contentTypeIdOrName,
			@WebArrayParam(value = "mimetypes") String[] mimeTypes)
			throws InvalidXmlMimeTypeException, InvalidContentTypeException,
			QppServiceException {
		configurationService.mapMimeTypes(facadeUtility.getContentTypeId(contentTypeIdOrName), mimeTypes);
	}

	/**
	 * Deletes the content-type mappings for given mime-types.
	 * 
	 * @param mimeTypes
	 *            Array of mime types whose content-type mappings are to be
	 *            deleted.
	 * @throws InvalidXmlMimeTypeException
	 *             If mime types are invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/xmlmimetypes", params = "op=unmapcontenttype")
	public void unmapMimeTypes(
			@WebArrayParam(value = "mimetypes") String[] mimeTypes)
			throws InvalidXmlMimeTypeException, QppServiceException {
		configurationService.unmapMimeTypes(mimeTypes);
	}
	
	/**
	 * Create a new process based on the publishingProcessXML. Creates config file for the
	 * process and updates ProcessConfig-ext.xml. The name of config file
	 * created for the process will be processId appended by
	 * "ProcessConfig.xml". For example: If processId is "researchReportToPdf"
	 * then the name of its config file will be
	 * "ResearchReportToPdfProcessConfig.xml".
	 * 
	 * @param publishingProcessXML
	 *            xml configuration for the process to be created.
	 * @throws InvalidPublishingProcessException
	 * 				If process-xml configuration is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingprocess", params ="op=create")
	public void createPublishingProcess(@RequestParam("processxml") String processXML) throws InvalidPublishingProcessException, QppServiceException {
		configurationService.createPublishingProcess(processXML);
	}
	
	/**
	 * Deletes the process with the given process name. Deletes the channels
	 * where this process is used. Deletes corresponding configuration file of
	 * the process and updates ProcessConfig-ext.xml.
	 * 
	 * @param processName
	 * 			   	name of the process to be deleted.
	 * @throws InvalidPublishingProcessException
	 * 				If process name is invalid.
	 * @throws InvalidChannelConfigException
	 * 				If there is an error in deleting channels where this process is used.
	 * @throws QppServiceException
	 * 				Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingprocess/{processName}", params ="op=delete")
	public void deletePublishingProcess(@PathVariable String processName) throws InvalidPublishingProcessException, InvalidChannelConfigException, QppServiceException {
		configurationService.deletePublishingProcess(processName);
	}
	
	/**
	 * Creates new channels as specified in the publishingChannelList. It is
	 * mandatory to provide channel id, name, type and process name for each
	 * channel to be created. Channels will be added to their configuration file
	 * "ChannelConfig-ext.xml".
	 * 
	 * @param publishingChannelList
	 *            list of channels to be created.
	 * @throws InvalidChannelConfigException
	 *             If channel id, name, type or process name are invalid. If
	 *             channel with given id already exists. If duplicate channels 
	 *             are provided.
	 * @throws InvalidPublishingProcessException
	 * 			  If no process with given process name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=create")
	@WebReturnType("xmlView")
	public void createPublishingChannels(@WebSerializedParam("publishingchannellist") PublishingChannelList publishingChannelList) 
			throws InvalidChannelConfigException, InvalidPublishingProcessException, QppServiceException {
		if (publishingChannelList != null && publishingChannelList.getPublishingChannelInfo() != null) {
			PublishingChannel[] channelToBeCreated = createPublishingChannel(publishingChannelList.getPublishingChannelInfo());
			configurationService.createPublishingChannels(channelToBeCreated);
		}
	}

	/**
	 * Deletes channels whose channel ids are specified. ChannelConfig-ext.xml is updated accordingly.
	 * Additionally, it also deletes mapping of these channels from content type and indexing. 
	 * 
	 * @param channelIds
	 *            Array of ids of the channels to be deleted.
	 * @throws InvalidChannelConfigException
	 * 			  If channel ids are invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=delete")
	public void deletePublishingChannels(@WebArrayParam("channelids") String[] channelIds) throws InvalidChannelConfigException, QppServiceException {
		configurationService.deletePublishingChannels(channelIds);
	}
	
	/**
	 * Maps content-types to channels and updates "PublishingConfig-ext.xml" for
	 * the new mappings.
	 * 
	 * @param contentTypes
	 *            ids or names of content types to which channels are to be
	 *            mapped.
	 * @param channels
	 *            array of channel ids which are to be mapped to the content
	 *            types.
	 * @param applyToChildContentTypes
	 * 			  boolean flag to specify whether the given channels are applicable for child content-types of the given content-types or not.
	 * @throw InvalidChannelConfigException 
	 * 				If channel ids are invalid.
	 * @throws InvalidContentTypeException
	 *             If content type ids are invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=mapcontenttype")
	public void createContentChannelMappings(@WebArrayParam("contenttypes") String[] contentTypes, @WebArrayParam("channels") String[] channels, 
			@RequestParam(value = "applytochildcontenttypes", defaultValue = "true") boolean applyToChildContentTypes) 
			throws InvalidChannelConfigException, InvalidContentTypeException, QppServiceException {
		
			long[] contentTypeIds = transformContentTypesToId(contentTypes);
			configurationService.createContentChannelMappings(contentTypeIds, channels, applyToChildContentTypes);
	}
	
	/**
	 * Deletes content type to channel mappings and updates
	 * "PublishingConfig-ext.xml". Specifying channels is mandatory. If content
	 * type is specified, channel mappings are deleted for this content type
	 * only. If content type is not specified, then mappings with all content
	 * types of the specified channel are deleted.
	 * 
	 * @param channels
	 *            array of channel ids whose content type mappings are to be
	 *            deleted.
	 * @param contentType
	 *            name or id of content type whose channel mapping is to be
	 *            deleted.
	 * @throw InvalidChannelConfigException 
	 * 			  If channel ids are invalid.
	 * @throws InvalidContentTypeException
	 *             If content type is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=unmapcontenttype")
	public void deleteContentChannelMappings(@WebArrayParam("channels") String[] channels, @RequestParam(value = "contenttype", required = false) String contentType) 
			throws InvalidChannelConfigException, InvalidContentTypeException, QppServiceException {
		
		configurationService.deleteContentChannelMappings((contentType != null && contentType.trim().length() > 0) ? facadeUtility.getContentTypeId(contentType) : 0, channels);
	}
	
	/**
	 * Maps content-types to indexing channels and updates "IndexingChannels-ext.xml" for the new mappings.
	 * 
	 * @param contentType
	 *            id or name of the content type to which indexing channel is to be mapped.
	 * @param channel
	 *            id of indexing channel which is to be mapped to the content type.
	 * @param applyToChildContentTypes
	 *            boolean flag to specify whether the given channel is applicable for child content-types of the given content-type or not.
	 * @param parameterMap
	 * 			  map of publishing parameters for the channel.
	 * @throw InvalidChannelConfigException
	 * 			  If channel id is invalid.
	 * @throws InvalidContentTypeException
	 * 			  If content type id is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=mapindexingchannel")
	public void createIndexingChannelMapping(@RequestParam("contenttype") String contentType, @RequestParam("channel") String channel,
			@RequestParam(value = "applytochildcontenttypes", defaultValue = "true") boolean applyToChildContentTypes,
			@WebParameterMap HashMap<String, String> parameterMap) throws InvalidChannelConfigException, InvalidContentTypeException, QppServiceException {
		if (contentType.trim().length() > 0) {
				filterIndexingParameterMap(parameterMap);		
				List<PublishingParameter> publishingParameterList = new ArrayList<PublishingParameter>(parameterMap.size());
				
				for (Map.Entry<String, String> entry : parameterMap.entrySet()) {
					publishingParameterList.add(new PublishingParameter(entry.getKey(), entry.getValue()));
				}
				configurationService.createIndexingChannelMapping(facadeUtility.getContentTypeId(contentType), channel, applyToChildContentTypes,
						publishingParameterList.toArray(new PublishingParameter[publishingParameterList.size()]));
		} else {
			throw new InvalidXmlMimeTypeException(InvalidXmlMimeTypeExceptionCodes.CONTENT_TYPE_MANDATORY);
		}
	}
	
	/**
	 * Deletes content type to indexing channel mapping and updates
	 * "IndexingChannels-ext.xml". Specifying channel is mandatory. If content
	 * type is specified, channel mapping is deleted for the given content type only.
	 * If content type is not specified, then mappings with all content types of
	 * the specified channel are deleted.

	 * @param channel
	 *            channel id whose content type mapping is to be deleted.
	 * @param contentType
	 *            name or id of content type whose channel mapping is to be
	 *            deleted.
	 * @throw InvalidChannelConfigException 
	 * 				If channel ids are invalid.
	 * @throws InvalidContentTypeException
	 *             If content type is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/publishingchannels", params = "op=unmapindexingchannel")
	public void deleteIndexingChannelMapping(@RequestParam("channel") String channel, @RequestParam(value = "contenttype", required = false) String contentType) 
			throws InvalidChannelConfigException, InvalidContentTypeException, QppServiceException {
		configurationService.deleteIndexingChannelMapping((contentType != null && contentType.trim().length() > 0) ? facadeUtility.getContentTypeId(contentType) : 0, channel);
	}
	
	private void filterIndexingParameterMap(Map<String, String> parameterMap){
		parameterMap.remove("op");
		parameterMap.remove("contenttype");
		parameterMap.remove("channel");
		parameterMap.remove("loginpassword");
		parameterMap.remove("loginname");
		parameterMap.remove("qppsessionid");
		parameterMap.remove("view");
		parameterMap.remove("applytochildcontenttypes");
	}
	
	private long[] transformContentTypesToId(String[] contentTypes) throws InvalidContentTypeException, QppServiceException {
		if (contentTypes != null && contentTypes.length > 0) {
			Set<Long> contentTypeIds = new HashSet<Long>(contentTypes.length);
			for (String contentType : contentTypes) {
				contentTypeIds.add(facadeUtility.getContentTypeId(contentType));
			}
			return ArrayUtils.toPrimitive(contentTypeIds.toArray(new Long[contentTypes.length]));
		} else {
			throw new InvalidXmlMimeTypeException(InvalidXmlMimeTypeExceptionCodes.CONTENT_TYPE_MANDATORY);
		}
	}
	
	private PublishingChannel[] createPublishingChannel(List<PublishingChannelInfo> publishingChannelInfos) {
		
		List<PublishingChannel> publishingChannelList = new ArrayList<PublishingChannel>(publishingChannelInfos.size());
		
		for (PublishingChannelInfo publishingChannelInfo : publishingChannelInfos) {
			
			List<PublishingParameter> publishingParameters = new ArrayList<PublishingParameter>(publishingChannelInfo.getParameter().size());
			
			for (Parameter channelParameter : publishingChannelInfo.getParameter()) {
				PublishingParameter publishingParameter = new PublishingParameter(channelParameter.getName(), channelParameter.getValue(), channelParameter.isAsk());
				publishingParameters.add(publishingParameter);
			}
			
			PublishingChannel publishingChannel = new PublishingChannel(publishingChannelInfo.getId(), publishingChannelInfo.getName(),
					publishingParameters.toArray(new PublishingParameter[publishingParameters.size()]), publishingChannelInfo.getProcess(), publishingChannelInfo.getType());
			publishingChannelList.add(publishingChannel);
		}
		return publishingChannelList.toArray(new PublishingChannel[publishingChannelList.size()]);
	}
	
	/**
	 * ReInitialise the mime-type, channel and process definitions from their config files. ReInitialize content-mime-type mappings configuration,
	 * content type to channel mappings configuration and content type to indexing channel mappings configuration.
	 * 
	 * @param reInitializeMimeTypes
	 * 			set true if mime-types configuration is to be re-initialized.
	 * @param reInitializeChannels
	 * 			set true if channels configuration is to be re-initialized.
	 * @param reInitializeProcesses	
	 * 			set true if processes configuration is to be re-initialized.
	 * 
	 * 
	 * @throws InvalidXmlMimeTypeException 
	 * 			If xml mime type configuration file is invalid or content mime type mapping configuration file is invalid.
	 * @throws InvalidChannelConfigException
	 * 			If channel configuration file is invalid or content channel mapping configuration is invalid.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params ="op=reinitializeconfigs")
	public void reInitialize(@RequestParam(value = "reinitializemimetypes", required = false) boolean reInitializeMimeTypes,
			@RequestParam(value = "reinitializechannels", required = false) boolean reInitializeChannels,
			@RequestParam(value = "reinitializeprocesses", required = false) boolean reInitializeProcesses) throws InvalidXmlMimeTypeException, InvalidChannelConfigException, QppServiceException {
		configurationService.reInitializeConfigs(new ReInitializeConfigSettings(reInitializeMimeTypes, reInitializeChannels, reInitializeProcesses));
	}
	

	/**
	 * Handles {@link QppServiceException} thrown by handler methods of this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	/**
	 * Returns the definition of the given xml mime-type. The returned definition consists of information like parent mime-type,
	 * xpath and/or processing instruction name and value based on which given mime-type is detected.
	 * 
	 * @param 	xmlMimeType
	 *            	xml mime-type whose definition is to be retrieved.
	 *            
	 * @return 	MimeInfo encapsulating the required xml mime-type definition.
	 * 
	 * @throws 	InvalidXmlMimeTypeException
	 *             If given xml mime-type doesn't exist.
	 * @throws 	QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/xmlmimetypes", params ="mimetype")
	@WebReturnType("xmlView")
	public MimeTypeInfoList getXmlMimeType(@RequestParam("mimetype") String mimeType) throws InvalidXmlMimeTypeException, QppServiceException {	
		CustomXmlMimeType customXmlMimeType = configurationService.getXmlMimeType(mimeType);
		return objectTransformer.transform(new CustomXmlMimeType[] { customXmlMimeType });
	}

	/**
	 * Returns the definitions of all xml mime-types.
	 *            
	 * @return 	List of MimeType objects encapsulated in MimeInfo object.
	 * 
	 * @throws 	QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/xmlmimetypes")
	@WebReturnType("xmlView")
	public MimeTypeInfoList getAllXmlMimeTypes() throws QppServiceException {
		CustomXmlMimeType[] customXmlMimeTypes = configurationService.getAllXmlMimeTypes();
		return objectTransformer.transform(customXmlMimeTypes);
	}

	/**
	 * Returns the list of mime-types mapped to the given content-type.
	 * 
	 * @param contentTypeIdOrName
	 *            id or name of the content type whose mime-type mappings are to be retrieved.
	 *            
	 * @return Array of mime-types mapped to the given content-type.
	 * 
	 * @throws InvalidContentTypeException
	 *             If no content-type with the given id or name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/xmlmimetypes", params = "contenttype")
	@WebReturnType("xmlView")
	public MimeTypeInfoList getMappedMimeTypes(@RequestParam("contenttype") String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException {
		CustomXmlMimeType[] customXmlMimeTypes = configurationService.getMappedMimeTypes(facadeUtility.getContentTypeId(contentTypeIdOrName));
		return objectTransformer.transform(customXmlMimeTypes);
	}

	/**
	 * Returns the xml configuration of the process with the given process-name.
	 * 
	 * @param processName
	 *            name of the process whose xml configuration is to be retrieved. .
	 * @return xml configuration of the process with the given process-name.
	 * 
	 * @throws InvalidPublishingProcessException
	 *             If no process with the given name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingprocess/{processName}")
	@WebReturnType("textView")
	public String getPublishingProcess(@PathVariable String processName) throws InvalidPublishingProcessException, QppServiceException {
		return configurationService.getPublishingProcess(processName);
	}
	
	/**
	 * Returns the definition of indexing channel mapped to the given content type.
	 * 
	 * @param contentTypeIdOrName
	 *            id or name of the content type whose indexing channel mapping is to be retrieved.
	 *            
	 * @return PublishingChannelList object encapsulating PublishingChannel object which encapsulates the definition of channel mapped to the given content-type.
	 * 
	 * @throws InvalidContentTypeException
	 *             If no content-type with the given id or name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels", params = { "contenttype", "indexingchannel=true" })
	@WebReturnType("xmlView")
	public PublishingChannelList getMappedIndexingChannel(@RequestParam("contenttype") String contentTypeIdOrName)
			throws InvalidContentTypeException, QppServiceException {
		PublishingChannel channel = configurationService.getMappedIndexingChannel(facadeUtility.getContentTypeId(contentTypeIdOrName));
		if (channel != null) {
			return objectTransformer.transform(new PublishingChannel[] { channel });
		} else {
			return objectTransformer.transform(new PublishingChannel[0]);
		}
	}
	
	/**
	 * Get definitions of all publishing channels of type publish, deliver and datadoc. 
	 * 
	 * @return list of all publishing channels
	 * 
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels")
	@WebReturnType("xmlView")
	public PublishingChannelList getAllPublishingChannelDefinitions() throws QppServiceException{
		PublishingChannel[] allPublishingChannels = configurationService.getAllPublishingChannelDefinitions();
		return objectTransformer.transform(allPublishingChannels);
	}
	
	/**
	 * Get definitions of publishing channels of type publish, deliver and datadoc which are mapped to a particular content type. 
	 * 
	 * @param contentTypeIdOrName
	 * 			Id or name of the content type. The input is assumed to be an id first, if an exception, the input is checked for name.
	 * 
	 * @return list of all publishing channels available for given content type.
	 * 
	 * @throws InvalidContentTypeException
	 *             If the content type with the given Id or name does not exist.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels", params = { "contenttype"})
	@WebReturnType("xmlView")
	public PublishingChannelList getPublishingChannelDefinitions(@RequestParam("contenttype") String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException{
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrName);
		PublishingChannel[] publishingChannels = configurationService.getPublishingChannelDefinitions(contentTypeId);
		return objectTransformer.transform(publishingChannels);
	}
	
	/**
	 * Returns the definition of the channel with the given id. The returned definition consists of information like channel id, 
	 * name, channel type, channel's process name and channel parameters.
	 * 
	 * @param channelId
	 *            id of the channel to be retrieved.
	 *            
	 * @return PublishingChannelList object encapsulating the required PublishingChannel object.
	 * 
	 * @throws InvalidChannelConfigException
	 *             If no channel with the given id exists.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels/{channelId}")
	@WebReturnType("xmlView")
	public PublishingChannelList getPublishingChannelDefinition(@PathVariable String channelId) throws InvalidChannelConfigException, QppServiceException {
		PublishingChannel publishingChannel = configurationService.getPublishingChannelDefinition(channelId);
		return objectTransformer.transform(new PublishingChannel[] { publishingChannel });
	}

	/**
	 * Returns version of the custom deployment. 
	 * The deployment version is specified under the property 'deployment.version' in the file Deployment.properties.
	 * 
	 * @return version of the custom deployment.
	 * @throws QppServiceException
	 *					 Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/deploymentversion")
	@WebReturnType("textView")
	public String getDeploymentVersion() throws QppServiceException {
		return	configurationService.getDeploymentVersion();	
	}
	
	/**
	 * Return all properties specified for the deployment in Deployment.properties file.
	 * 
	 * @return All properties specified for the deployment
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/deploymentproperties")
	@WebReturnType("xmlView")
	public NameValueList getDeploymentProperties() throws QppServiceException {
		NameValue[] nameValues = configurationService.getDeploymentProperties();
		return objectTransformer.transform(nameValues);
	}
	
}

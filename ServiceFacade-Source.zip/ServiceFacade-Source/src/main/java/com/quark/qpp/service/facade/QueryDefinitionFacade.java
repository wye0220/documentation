/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.facade;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.query.service.constants.DefaultDisplayModes;
import com.quark.qpp.core.query.service.constants.ExploreModeTypes;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.SortInfo;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.SearchInfo;
import com.quark.qpp.service.xmlBinding.SearchInfoList;
import com.quark.qpp.service.xmlBinding.TrusteeInfo;
import com.quark.qpp.service.xmlBinding.TrusteeInfoList;

/**
 * Facade that defines APIs to perform query related operations like get, create, update and delete searches.
 */

@Controller("queryDefinitionFacade")
@RequestMapping("/searchdefinitions")
public class QueryDefinitionFacade {

	@Autowired
	private QueryService queryService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private PrivilegeValidator privilegeValidator;
	
	private static long[] defaultDisplayColumns = new long[] { DefaultAttributes.NAME, DefaultAttributes.WORKFLOW,
		DefaultAttributes.COLLECTION, DefaultAttributes.ROUTED_TO, DefaultAttributes.STATUS, DefaultAttributes.CONTENT_TYPE };

	private static int displayColumnWidth = 150;
	
	private static int defaultDisplayMode = DefaultDisplayModes.PLAIN;
	
	private static int defaultExploreMode = ExploreModeTypes.PLAIN;

	private final Logger logger = Logger.getLogger(this.getClass());

	/**
	 * Retrieves the list of all searches accessible to a user, including shared queries. By default only basic information like id,
	 * name, parameterized & owner details of a search are returned. In order to get information like query context, query conditions &
	 * query display set the appropriate boolean flag to true.
	 * 
	 * @param getConditions
	 *            A boolean flag to retrieve query conditions. By default this flag is false. Set this flag to true to retrieve query
	 *            conditions.
	 * @param getDisplay
	 *            A boolean flag to retrieve query display. By default this flag is false. Set this flag to true to retrieve query display.
	 * @param getContext
	 *            A boolean flag to retrieve query context. By default this flag is false. Set this flag to true to retrieve query context.
	 * @return {@link SearchInfoList} object that encapsulates list of all searches accessible to this logged on user.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType("xmlView")
	public SearchInfoList getAllSearches(@RequestParam(value = "conditions", defaultValue = "false") boolean getConditions,
			@RequestParam(value = "display", defaultValue = "false") boolean getDisplay,
			@RequestParam(value = "context", defaultValue = "false") boolean getContext, 
			@RequestParam(value = "sharedsearchtrustees", defaultValue = "false") boolean getSharedSearchTrustees) throws QppServiceException {
		QueryDefinition[] queryDefinitions = queryService.getAllQueries();
		return objectTransformer.transform(queryDefinitions, getConditions, getDisplay, getContext, getSharedSearchTrustees);
	}

	/**
	 * Retrieves the search/query definition for given query name or id. By default only basic information of query definition is
	 * returned. In order to get query conditions, context & display set the appropriate boolean flag as true.
	 * 
	 * @param searchIdOrName
	 *            id or name of the search to be retrieved. The input is assumed to be an id first.
	 * @param getConditions
	 *            A boolean flag to retrieve query conditions. By default this flag is false. Set this flag to true to retrieve query
	 *            conditions.
	 * @param getDisplay
	 *            A boolean flag to retrieve query display. By default this flag is false. Set this flag to true to retrieve query display.
	 * @param getContext
	 *            A boolean flag to retrieve query context. By default this flag is false. Set this flag to true to retrieve query context.
	 * @return {@link SearchInfoList} object, that encapsulates list of all searches accessible to this logged on user.
	 * @throws QueryNotFoundException
	 *             In case there doesnot exist query with the given query name or id.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{searchIdOrName}")
	@WebReturnType("xmlView")
	public SearchInfoList getSearch(@PathVariable String searchIdOrName,
			@RequestParam(value = "conditions", defaultValue = "false") boolean getConditions,
			@RequestParam(value = "display", defaultValue = "false") boolean getDisplay,
			@RequestParam(value = "context", defaultValue = "false") boolean getContext,
			@RequestParam(value = "sharedsearchtrustees", defaultValue = "false") boolean getSharedSearchTrustees) throws QueryNotFoundException, QppServiceException {
		long queryId = facadeUtility.getQueryId(searchIdOrName);
		QueryDefinition queryDefinition = queryService.getQueryDefinition(queryId);
		return objectTransformer.transform(new QueryDefinition[] { queryDefinition }, getConditions, getDisplay, getContext, getSharedSearchTrustees);
	}

	/**
	 * Creates search on platform server using the {@link com.quark.qpp.service.xmlBinding.QueryContext}, {@link QueryConditions} and
	 * {@link com.quark.qpp.service.xmlBinding.QueryDisplay} mentioned in SearchInfo object.
	 * <p>
	 * In case query context is not mentioned, by default ASSET content type & all collections will be considered.</br> In case query
	 * display is not mentioned, by default attribute columns : NAME, WORKLFOW, STATUS, COLLECTION, ROUTED TO & CONTENT TYPE are considered
	 * as display columns with default column width as 150. By default the display mode is set as {@link DefaultDisplayModes#PLAIN} &
	 * explore mode as {@link ExploreModeTypes#PLAIN}
	 * </p>
	 * 
	 * @param SearchInfoList
	 *            {@link SearchInfoList} object containing information of the search queries to be created.
	 * @return {@link SearchInfoList} object containing information of all successfully created search queries.
	 * @throws InvalidQueryDefinitionException
	 *             In case of invalid query definition.
	 * @throws InvalidQueryDisplayException
	 *             In case the QueryDisplay provided by the client is null, contains no attribute ids, or has an invalid attribute id. An
	 *             attribute id is also considered invalid if it is not displayable.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=create")
	@WebReturnType("xmlView")
	public SearchInfoList createSearches(@WebSerializedParam("searchinfolist") SearchInfoList searchInfoList)
			throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createEditSearch");
		SearchInfoList createdSearches = new SearchInfoList();
		if (searchInfoList != null && searchInfoList.getSearchInfo() != null) {
			Iterator<SearchInfo> iterator = searchInfoList.getSearchInfo().iterator();
			while (iterator.hasNext()) {
				SearchInfo search = iterator.next();
				try {
					SearchInfo newSearchInfo = createSearch(search);
					createdSearches.getSearchInfo().add(newSearchInfo);
				} catch (QppServiceException e) {
					logger.error("Error while creating search with name : " + search.getSearchName(), e);
					if (searchInfoList.getSearchInfo().size() == 1) {
						throw e;
					}
				}
			}
		}
		return createdSearches;
	}

	/**
	 * Updates given searches. Specify either the search Id or name within {@link SearchInfo} object, inorder to refer to search
	 * to be updated. API updates query conditions, query context & query display. If either of query condition/display/context is not
	 * mentioned, it will not be updated, thus only the information provided in the searchInfo object is updated for corresponding search.
	 * 
	 * @param searchInfoList
	 *            list of searches that are to be updated.
	 * @return List of searches that have been updated successfully
	 * @throws QueryNotFoundException
	 *             In case there doesn't exist a search/query with given name or id.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=update")
	@WebReturnType("xmlView")
	public SearchInfoList updateSearches(@WebSerializedParam("searchinfolist") SearchInfoList searchInfoList)
			throws QueryNotFoundException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createEditSearch");
		SearchInfoList updatedSearches = new SearchInfoList();
		if (searchInfoList != null && searchInfoList.getSearchInfo() != null) {
			List<SearchInfo> list = searchInfoList.getSearchInfo();
			for (int i = 0; i < list.size(); i++) {
				try {
					SearchInfo updatedSearchInfo = updateSearch(list.get(i));
					updatedSearches.getSearchInfo().add(updatedSearchInfo);
				} catch (QppServiceException e) {
					logger.error("Error while updating search.", e);
					if(searchInfoList.getSearchInfo().size() ==1){
						throw e;
					}
				}
			}
		} 
		return updatedSearches;
	}

	/**
	 * Returns the list of users & groups to which this search has been shared. 
	 * 
	 * @param searchIdOrName
	 *            id or name of the search for which shared query trustees are to be fetched.
	 * @return list of trustees to which this search has been shared.
	 * @throws QueryNotFoundException
	 *             If there doesn't exist a search with the given id or name.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{searchIdOrName}", params = "op=getsharedsearchtrustees")
	@WebReturnType("xmlView")
	public TrusteeInfoList getSharedSearchTrustees(@PathVariable String searchIdOrName) throws QueryNotFoundException,
			QppServiceException {
		long queryId = facadeUtility.getQueryId(searchIdOrName);
		return objectTransformer.fetchAndTransformSharedQueryTrustees(queryId);
	}


	/**
	 * Share the search with trustees(users/groups) other than the owner. The trustees will be able to access and execute the
	 * search. If the search is shared to a group then all users belonging to the group will be able to access the query. However,
	 * QueryConditions cannot be modified by recipients. The results obtained on executing a shared query may differ for different users
	 * based on each user's access to collections. The given trusteeInfoList will override existing list of search trustees.
	 * 
	 * @param searchIdOrName
	 *            id or name of the search for which the shared search trustees are to be set. The input is assumed to be an id
	 *            first.
	 * @param trusteeInfoList
	 *            list of trustees to whom the search will be shared. Specify either id or name of the trustee (in
	 *            {@link TrusteeInfo} object).
	 * @return List of trustees to whom the specified search has been shared.
	 * @throws QueryNotFoundException
	 *             If there does not exist a search/query with given name or id.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{searchIdOrName}", params = "op=setsharedsearchtrustees")
	@WebReturnType("xmlView")
	public TrusteeInfoList setSharedSearchTrustees(@PathVariable String searchIdOrName,
			@WebSerializedParam("trusteeinfolist") TrusteeInfoList trusteeInfoList) throws QueryNotFoundException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("shareUnshareSearch");
		long queryId = facadeUtility.getQueryId(searchIdOrName);
		long[] currentMappedTrustees = queryService.getSharedQueryTrustees(queryId);
		long[] givenTrusteeIds = new long[0];
		if (trusteeInfoList != null && trusteeInfoList.getTrusteeInfo() != null && trusteeInfoList.getTrusteeInfo().size() > 0) {
			givenTrusteeIds = getTrusteeIds(trusteeInfoList);
		}
		Arrays.sort(givenTrusteeIds);
		Arrays.sort(currentMappedTrustees);
		long ownerId = queryService.getQueryDefinition(queryId).getOwnerId();
		for (int i = 0; i < currentMappedTrustees.length; i++) {
			long currentMappedTrusteeId = currentMappedTrustees[i];
			int exists = Arrays.binarySearch(givenTrusteeIds, currentMappedTrusteeId);
			if (exists < 0 && ownerId != currentMappedTrusteeId) {
				queryService.removeSharedQuery(queryId, currentMappedTrusteeId);
			}
		}
		for (int i = 0; i < givenTrusteeIds.length; i++) {
			long givenTrusteeId = givenTrusteeIds[i];
			int alreadyMapped = Arrays.binarySearch(currentMappedTrustees, givenTrusteeId);
			if (alreadyMapped < 0) {
				queryService.shareQuery(queryId, givenTrusteeId);
			}
		}
		return objectTransformer.fetchAndTransformSharedQueryTrustees(queryId);
	}

	/**
	 * Deletes the search with the given id or name. If the query was shared to other users, it is no longer available.
	 * 
	 * @param searchIdOrName
	 *            Id or name of the search to be deleted.
	 * @throws QueryNotFoundException
	 *             If there doesn't exist a search with the given id or name.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{searchIdOrName}", params = "op=delete")
	public void deleteSearch(@PathVariable String searchIdOrName) throws QueryNotFoundException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteSearch");
		long queryId = facadeUtility.getQueryId(searchIdOrName);
		queryService.deleteQuery(queryId);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

	private SearchInfo createSearch(SearchInfo searchInfo) throws InvalidQueryDefinitionException, InvalidQueryDisplayException,
			QppServiceException {
		QueryDefinition queryDefinition = objectTransformer.transform(searchInfo);
		if (queryDefinition.getQueryDisplay() == null) {
			queryDefinition.setQueryDisplay(getDefaultQueryDisplay());
		}
		long newId = queryService.createQuery(queryDefinition);
		setSharedSearchTrustees(newId+"", searchInfo.getTrusteeInfoList());
		SearchInfo newSearchInfo = objectTransformer.transform(queryService.getQueryDefinition(newId), /* getConditions */true, /* getDisplay */
				true, /* getContext */true, /*getSharedSearchTrustees*/true);
		return newSearchInfo;
	}

	private SearchInfo updateSearch(SearchInfo searchInfo) throws UserNotFoundException, InvalidQueryDefinitionException,
			QppServiceException {
		QueryDefinition queryDefinition = objectTransformer.transform(searchInfo);
		String queryName = queryDefinition.getQueryName();
		long queryId = -1;
		if (queryDefinition.getQueryId() <= 0) {
			queryId = facadeUtility.getQueryId(queryName);
			queryDefinition.setQueryId(queryId);
		} else {
			queryId = queryDefinition.getQueryId();
		}
		if (queryName != null) {
			queryService.setQueryName(queryId, queryName);
		}
		if (queryDefinition.getQueryConditions() != null) {
			QueryContext queryContext = queryDefinition.getQueryContext();
			if (queryContext == null) {
				queryContext = queryService.getQueryDefinition(queryId).getQueryContext();
			}
			queryService.setQueryConditions(queryId, queryDefinition.getQueryConditions(), queryContext);
		}
		if (queryDefinition.getQueryDisplay() != null) {
			queryService.setQueryDisplay(queryId, queryDefinition.getQueryDisplay());
		}
		if(searchInfo.getTrusteeInfoList() != null){
			setSharedSearchTrustees(queryId+"", searchInfo.getTrusteeInfoList());
		}
		return objectTransformer
				.transform(queryService.getQueryDefinition(queryId), true/* getConditions */, true/* getDisplay */, true/* getContext */, true/*getSharedSearchTrustees*/);

	}
	
	/**
	 * This method returns trustee ids from the given TrusteeInfoList. Each TrusteeInfo object in TrusteeInfoList should have either the
	 * trustee id or name specified.
	 * 
	 * @param trusteeInfoList
	 *            List of trusteeInfo objects.
	 * @return array of trustee ids
	 * @throws TrusteeNotFoundException
	 *             In case trustee with given name or id doesnot exist.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	private long[] getTrusteeIds(TrusteeInfoList trusteeInfoList) throws TrusteeNotFoundException, QppServiceException {
		List<TrusteeInfo> list = trusteeInfoList.getTrusteeInfo();
		String[] trusteeIdsOrNames = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			String trusteeName = list.get(i).getName();
			Long trusteeId = list.get(i).getId();
			if (trusteeName != null && !trusteeName.isEmpty()) {
				trusteeIdsOrNames[i] = trusteeName;
			} else {
				trusteeIdsOrNames[i] = String.valueOf(trusteeId);
			}
		}
		long[] givenTrusteeIds = facadeUtility.getTrusteeIds(trusteeIdsOrNames);
		return givenTrusteeIds;
	}
	
	public QueryDisplay getDefaultQueryDisplay() {
		DisplayColumn[] displayColumns = new DisplayColumn[defaultDisplayColumns.length];
		for (int i = 0; i < defaultDisplayColumns.length; i++) {
			displayColumns[i] = new DisplayColumn(defaultDisplayColumns[i], displayColumnWidth, true);
		}
		SortInfo[] sortInfos = new SortInfo[1];
		sortInfos[0] = new SortInfo(DefaultAttributes.NAME);
		sortInfos[0].setAttributeColumn(true);
		sortInfos[0].setDescending(false);
		
		QueryDisplay queryDisplay = new QueryDisplay();
		queryDisplay.setDisplayColumns(displayColumns);
		queryDisplay.setSorting(sortInfos);
		queryDisplay.setDisplayMode(defaultDisplayMode);
		queryDisplay.setExploreMode(defaultExploreMode);
		return queryDisplay;
	}
}

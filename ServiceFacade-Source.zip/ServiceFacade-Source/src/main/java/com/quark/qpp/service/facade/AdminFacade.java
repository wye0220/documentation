/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import javax.management.relation.InvalidRoleInfoException;
import javax.xml.xpath.XPathExpressionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.DatabaseException;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainValueNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidDomainException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidDomainValueException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidXpathException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.form.service.exceptions.InvalidFormException;
import com.quark.qpp.core.preference.service.constants.PreferenceConstants;
import com.quark.qpp.core.preference.service.exceptions.InvalidFavoriteItemException;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceException;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceValueException;
import com.quark.qpp.core.preference.service.exceptions.InvalidUserPreferenceException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceNotFoundException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceValueNotFoundException;
import com.quark.qpp.core.privilege.service.dto.PrivilegeDefinition;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeGroupException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidUserClassException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeGroupNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassInUseException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotEditableException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.relation.service.exceptions.InvalidRelationTypeException;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.GroupNotFoundException;
import com.quark.qpp.core.security.service.exceptions.InvalidGroupException;
import com.quark.qpp.core.security.service.exceptions.InvalidUserException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserInUseException;
import com.quark.qpp.core.security.service.exceptions.UserNotEditableException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryException;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryTypeException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryInUseException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryNotFoundException;
import com.quark.qpp.core.userprovisioning.service.constants.LdapAuthenticationTypes;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapQueryDefinitionException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapSearchCriteriaException;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapProfileExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapQueryDefinitionExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapSearchCriteriaExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserSourceAccessException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidColorException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidUserColorException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidWorkflowDefinitionException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowInUseException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.controller.AttributeController;
import com.quark.qpp.service.controller.AttributeDomainController;
import com.quark.qpp.service.controller.ContentTypeController;
import com.quark.qpp.service.controller.FormController;
import com.quark.qpp.service.controller.PreferenceController;
import com.quark.qpp.service.controller.PrivilegeController;
import com.quark.qpp.service.controller.RelationController;
import com.quark.qpp.service.controller.RoleController;
import com.quark.qpp.service.controller.StorageController;
import com.quark.qpp.service.controller.TrusteeController;
import com.quark.qpp.service.controller.UserProvisioningController;
import com.quark.qpp.service.controller.WorkflowController;
import com.quark.qpp.service.exception.UserPrivilegeException;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.ApplicationPrivList;
import com.quark.qpp.service.xmlBinding.AttributeDomainInfoList;
import com.quark.qpp.service.xmlBinding.AttributeInfo;
import com.quark.qpp.service.xmlBinding.AttributeInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeAttributeMappingInfo;
import com.quark.qpp.service.xmlBinding.ContentTypeAttributeMappingInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypePriv;
import com.quark.qpp.service.xmlBinding.DomainValue;
import com.quark.qpp.service.xmlBinding.DomainValueList;
import com.quark.qpp.service.xmlBinding.FavoriteItemlist;
import com.quark.qpp.service.xmlBinding.FormAttributeList;
import com.quark.qpp.service.xmlBinding.FormInfo;
import com.quark.qpp.service.xmlBinding.FormInfoList;
import com.quark.qpp.service.xmlBinding.GroupInfo;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.ImportedGroupInfoList;
import com.quark.qpp.service.xmlBinding.LdapProfileInfoList;
import com.quark.qpp.service.xmlBinding.LdapSearchInfo;
import com.quark.qpp.service.xmlBinding.LdapSearchInfoList;
import com.quark.qpp.service.xmlBinding.PreferenceInfoList;
import com.quark.qpp.service.xmlBinding.PreferenceValueList;
import com.quark.qpp.service.xmlBinding.PrivilegeDefinitionList;
import com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinitionList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.RedlineInfoList;
import com.quark.qpp.service.xmlBinding.RelationTypeInfoList;
import com.quark.qpp.service.xmlBinding.RoleInfo;
import com.quark.qpp.service.xmlBinding.RoleInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfo;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfoList;
import com.quark.qpp.service.xmlBinding.TrusteeInfo;
import com.quark.qpp.service.xmlBinding.UserInfo;
import com.quark.qpp.service.xmlBinding.UserInfoList;
import com.quark.qpp.service.xmlBinding.WorkflowInfo;
import com.quark.qpp.service.xmlBinding.WorkflowInfoList;

/**
 * This facade defines the APIs to perform admin related operations like get, create, update, delete : storage repositories, domains, attributes,
 * content types, workflows, forms, users, groups, relation types, roles & privileges, ldap profiles etc...
 */

@Controller("adminFacade")
@RequestMapping("/admin")
public class AdminFacade {
	
	@Autowired
	private ObjectTransformer objectTransformer;
	
	@Autowired
	private AttributeController attributeController;

	@Autowired
	private ContentTypeController contentTypeController;
	
	@Autowired
	private WorkflowController workflowController;

	@Autowired
	private RoleController roleController;
	
	@Autowired
	private StorageController storageController;
	
	@Autowired
	private TrusteeController trusteeController;
	
	@Autowired
	private FormController formController;
	
	@Autowired
	private RelationController relationController;
	
	@Autowired
	private PrivilegeValidator privilegeValidator;
	
	@Autowired
	private AttributeDomainController attributeDomainController;
	
	@Autowired
	private UserProvisioningController userProvisioningController;
	
	@Autowired
	private PreferenceController preferenceController;

	@Autowired
	private PrivilegeController privilegeController;


	/**
	 * Returns the domain definitions of all the domains that exist in the system.
	 * 
	 * @return List of AttributeDomainInfo objects encapsulated in AttributeDomainInfoList object.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/domains")
	@WebReturnType("xmlView")
	public AttributeDomainInfoList getAllDomains() throws QppServiceException {
		return attributeDomainController.getAllDomains();
	}

	/**
	 * Returns the definition of the domain with the given id or name. The returned definition consists of information like name,
	 * systemDefined, userModifiable, itemsSorted, expandable, warnBeforeExpansion, domainValueList.
	 * 
	 * @param domainIdOrName
	 *            id or name of the domain to be retrieved. The parameter is first assumed to be domain Id, if not then the domain name.
	 * @return AttributeDomainInfoList encapsulating the required domain definition.
	 * @throws DomainNotFoundException
	 *             If no domain with the given id or name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/domains/{domainIdOrName}")
	@WebReturnType("xmlView")
	public AttributeDomainInfoList getDomain(@PathVariable(value = "domainIdOrName") String domainIdOrName) throws DomainNotFoundException,
			QppServiceException {
		return attributeDomainController.getDomain(domainIdOrName);
	}

	/**
	 * Returns desired DomainValue information.
	 * 
	 * @param domainIdOrName
	 *            id or name of the domain to be retrieved. The parameter is first assumed to be domain Id, if not then the domain name.
	 * @param valueId
	 *            id of the domain value whose xml value is required
	 * @return Desired DomainValue information
	 * @throws DomainNotFoundException
	 *             If no domain with the given id exists.
	 * @throws DomainValueNotFoundException
	 * 				If no domain value exists with the given valueId.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/domains/{domainIdOrName}/{valueId}")
	@WebReturnType("xmlView")
	public DomainValue getDomainValue(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@PathVariable(value = "valueId") long valueId) throws DomainNotFoundException, DomainValueNotFoundException, QppServiceException {
		return attributeDomainController.getDomainValue(domainIdOrName, valueId);
	}
	
	/**
	 * Add a new value in domain under the mentioned parent value. If the parent value Id is less than or equal to zero, then the domain value will be added at
	 * root level. The position refers to the location/index where domain value will be added.For example, in order to add domain value in
	 * the beginning, mention the position as 1. If the position is -1 or an invalid number, then the domain value will be added at the last
	 * among its siblings.
	 * 
	 * @param domainIdOrName
	 *            Id or name of the domain where domain value is to be added
	 * @param parentDomainValueId
	 *            Id of the domain value under which new domain value is to be added.
	 * @param name
	 *            name of the new domain value
	 * @param sourceReference
	 *            source reference of the new domain value.
	 * @param position
	 *            position among siblings where the domain value will be added.Can have values like 1, 5,....,(use -1 in order to add domain
	 *            value at the end)
	 * @return newly created domain value
	 * @throws DomainNotFoundException
	 *             If no domain with the given id exists.
	 * @throws InvalidDomainException
	 *             If the given domain is a system-defined domain and not user modifiable or DomainValue or its name is not supplied. The
	 *             specific reason for the exception can be found by calling getExceptionCode(...) on the exception.
	 * @throws DomainValueNotFoundException
	 *             In case there doesn't exist domain value with the given parentDomainValueId
	 * @throws InvalidDomainValueException
	 *             If there already exists a domain value with the same name among children of parentDomainValueId
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}/{newValueName}", params = "op=create")
	@WebReturnType("xmlView")
	public DomainValue addDomainValue(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@RequestParam(value = "parentvalue", required = false) Long parentDomainValueId,
			@PathVariable(value = "newValueName") String name,
			@RequestParam(value = "sourcereference", required = false) String sourceReference,
			@RequestParam(value = "position", required = false) Integer position) throws DomainNotFoundException, InvalidDomainException,
			DomainValueNotFoundException, InvalidDomainValueException, QppServiceException {
		return attributeDomainController.addDomainValue(domainIdOrName, parentDomainValueId, name, sourceReference, position);
	}

	/**
	 * Updates name and source reference of the domain value with the given id.
	 * 
	 * @param domainIdOrName
	 *            Id of the domain whose domain value is to be renamed & source reference is to be updated.
	 * @param valueId
	 *            Id of the domain value whose name & source reference are to be updated.
	 * @param name
	 *            new name for the domain value
	 * @param sourceReference
	 *            new source reference to be set for the given domain value.
	 * @throws DomainNotFoundException
	 *             If no domain with the given id exists.
	 * @throws InvalidDomainException
	 *             If the given domain is a system-defined domain and not user modifiable or DomainValue or its name is not supplied. The
	 *             specific reason for the exception can be found by calling getExceptionCode(...) on the exception.
	 * @throws DomainValueNotFoundException
	 *             If no domain value exists with the given id in this domain.
	 * @throws InvalidDomainValueException
	 *             If there already exists a domain value with the new name among siblings of the given domain value id.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}/{valueId}", params = "op=update")
	@WebReturnType("xmlView")
	public DomainValue updateDomainValue(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@PathVariable(value = "valueId") long valueId, @RequestParam(value = "name") String name,
			@RequestParam(value = "sourcereference") String sourceReference) throws DomainNotFoundException, InvalidDomainException,
			DomainValueNotFoundException, InvalidDomainValueException, QppServiceException {
		return attributeDomainController.updateDomainValueName(domainIdOrName, valueId, name, sourceReference);
	}

	/**
	 * Deletes the value of a domain.
	 * 
	 * @param domainId
	 *            Id of the domain whose value is to be deleted.
	 * @param valueId
	 *            Id of the value that is to be deleted.
	 * @throws DomainNotFoundException
	 *             If no domain with the specified id exists.
	 * @throws DomainValueNotFoundException
	 *             If no value exists with the given value id in this domain.
	 * @throws InvalidDomainException
	 *             If the domain whose value is requested for deletion is a not user modifiable domain.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}/{valueId}", params = "op=delete")
	@WebReturnType("xmlView")
	public void deleteDomainValue(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@PathVariable(value = "valueId") long valueId) throws DomainNotFoundException, DomainValueNotFoundException,
			InvalidDomainException, QppServiceException {
		attributeDomainController.deleteDomainValue(domainIdOrName, valueId);
	}

	/**
	 * Returns xml value of the given domain value.
	 * 
	 * @param domainIdOrName
	 *            id or name of the domain to be retrieved. The parameter is first assumed to be domain Id, if not then the domain name.
	 * @param valueId
	 *            id of the domain value whose xml value is required
	 * @return XML stored for the given domain value
	 * @throws DomainNotFoundException
	 *             If no domain with the given id exists.
	 * @throws DomainValueNotFoundException
	 *             If the value with the given value is does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/domains/{domainIdOrName}/{valueId}", params = "op=fetchxml")
	@WebReturnType("textView")
	public String getDomainValueXml(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@PathVariable(value = "valueId") long valueId) throws DomainNotFoundException, DomainValueNotFoundException,
			QppServiceException {
		return attributeDomainController.getDomainValueXml(domainIdOrName, valueId);
	}

	/**
	 * Sets xml for the given domain value.
	 * 
	 * @param domainIdOrName
	 *            id or name of the domain to be retrieved. The parameter is first assumed to be domain Id, if not then the domain name.
	 * @param valueId
	 *            id of the value whose xml is to be set
	 * @param xmlValue
	 *            XML to be set for the given domain value
	 * @throws DomainNotFoundException
	 *             If no domain with the given id exists.
	 * @throws DomainValueNotFoundException
	 *             If the value with the given value is does not exist.
	 * @throws DatabaseException
	 *             if the underlying Database does not support xml type of data.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}/{valueId}", params = "op=setxmlvalue")
	@WebReturnType("xmlView")
	public void setDomainValueXml(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@PathVariable(value = "valueId") long valueId, @RequestParam(value = "xmlvalue", defaultValue = "false") String xmlValue)
			throws DomainNotFoundException, DomainValueNotFoundException, DatabaseException, QppServiceException {
		attributeDomainController.setDomainValueXml(domainIdOrName, valueId, xmlValue);
	}

	/**
	 * Finds domain values whose xml matches with the given xpath. Thus it returns array of domain values whose xml values contains content
	 * as per the given xpath expression.
	 * 
	 * @param domainIdOrName
	 *            id or name of the domain to be retrieved. The parameter is first assumed to be domain Id, if not then the domain name.
	 * @param xpath
	 *            xpath expression to be used for finding required domain values. This xpath expression is executed on xml values and if
	 *            there exists any content as per the xpath expression, then that domain value is selected.
	 * @return Returns domain values whose xml values contains content as per the given xpath expression * @throws DomainNotFoundException
	 *         If no domain with the given id exists.
	 * @throws InvalidXpathException
	 *             if the xpath expression supplied is invalid.
	 * @throws DatabaseException
	 *             if the underlying Database does not support xml type of data.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/domains/{domainIdOrName}", params = "op=searchvalues")
	@WebReturnType("xmlView")
	public DomainValueList searchDomainValues(@PathVariable(value = "domainIdOrName") String domainIdOrName,
			@RequestParam(value = "xpath") String xpath) throws DomainNotFoundException, InvalidXpathException, DatabaseException, QppServiceException {
		return attributeDomainController.searchDomainValues(domainIdOrName, xpath);
	}
	
	/**
	 * Creates new domains with the given definition and sets the possible values of the domain. The domain created has its SystemDefined
	 * flag set to false and UserModifiable flag set to true. These flags are overwritten if sent by the client. Also domain id for the
	 * domain is generated by the server. Fields honored while domain creation are name, itemsSorted, 
	 * expandable, warnBeforeExpansion, domainValueList. But minimum field required to create a domain is its name.
	 * 
	 * 
	 * @param attributeDomainInfoList
	 *            list of domains to be created.
	 * @return List of successfully created domains.
	 * @throws InvalidDomainException
	 *             If there is any wrong data in the given AttributeDomainInfo object.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains", params = "op=create")
	@WebReturnType("xmlView")
	public AttributeDomainInfoList createDomains(
			@WebSerializedParam(value = "attributedomaininfolist") AttributeDomainInfoList attributeDomainInfoList)
			throws InvalidDomainException, QppServiceException {
		return attributeDomainController.createDomains(attributeDomainInfoList);
	}

	/**
	 * Updates the specified domains. This API can be used to update domain name, flags like itemsSorted, expandable, warnBeforeExpansion &
	 * set domain values. New domain values are inserted, existing values are updated, and missing values are deleted. A domain can be
	 * updated on the basis of id or name, but id is given preference over name. In order to update domain name, domain Id is mandate.
	 * 
	 * @param attributeDomainInfoList
	 *            list of domains to be updated.
	 * @return AttributeDomainInfoList object containing list of domains updated successfully.
	 * @throws DomainNotFoundException
	 *             In case there is no domain with given id or name.
	 * @throws InvalidDomainException
	 *             In case of invalid domain. The exceptionCode will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains", params = "op=update")
	@WebReturnType("xmlView")
	public AttributeDomainInfoList updateDomains(
			@WebSerializedParam(value = "attributedomaininfolist") AttributeDomainInfoList attributeDomainInfoList)
			throws DomainNotFoundException, InvalidDomainException, QppServiceException{
		return attributeDomainController.updateDomains(attributeDomainInfoList);
	}

	/**
	 * Deletes the user-defined domain. A domain can be deleted on the basis of domain id or name. Generally id is given preference over name.
	 * 
	 * @param domainIdOrName
	 *            Id or name of the domain to be deleted.
	 * @throws DomainNotFoundException
	 *             If no domain with the given id or name exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}", params = "op=delete")
	@WebReturnType("xmlView")
	public void deleteDomain(@PathVariable(value = "domainIdOrName") String domainIdOrName) throws DomainNotFoundException, QppServiceException {
		attributeDomainController.deleteDomain(domainIdOrName);
	}
	

	// Api's related to attributes get, create, update & delete.

	/**
	 * Get all attributes defined in the system. In order to get attributes mapped to a specific content type, specify valid content type
	 * id/path/name as the parameter. The boolean flag includeSubContentTypes indicates whether to include attributes mapped to child
	 * content types as well.A null content type value indicates to return all existing attributes in the system.
	 * 
	 * @param contentTypeIdOrPathOrName
	 *            id or path or name of the content type for which attributes are to be fetched. The input is assumed to be an id first, if
	 *            invalid, then path & if with path we are not able to fetch the content type,then the input is assumed to be a name. In
	 *            case of name, the first content type fetched with given name is given preference.
	 * @param includeSubContentTypes
	 *            A boolean flag indicating if child content types of the given content type would be considered for getting the required
	 *            attributes.
	 * @return {@link AttributeInfoList} object encapsulating list of {@link AttributeInfo} objects.
	 * @throws InvalidContentTypeException
	 *             This exception is thrown whenever the content type supplied is invalid for the given context. The exact reason of the
	 *             exception can be determined by calling getExceptionCode() of the exception.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/attributes")
	@WebReturnType("xmlView")
	public AttributeInfoList getAllAttributes(@RequestParam(value = "contenttype", required = false) String contentTypeIdOrPathOrName,
			@RequestParam(value = "includesubcontenttypes", defaultValue = "false") boolean includeSubContentTypes)
			throws InvalidContentTypeException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewAttributes");
		return attributeController.getAllAttributes(contentTypeIdOrPathOrName, includeSubContentTypes);
	}

	/**
	 * Returns the definition of an attribute with the given id or name.
	 * 
	 * @param attributeIdOrName
	 *           id or name of the attribute whose definition is required. Id is given preference over name.
	 * @return {@link AttributeInfoList} object containing definition of the required attribute.
	 * @throws AttributeNotFoundException
	 *             If attribute with the given id or name does not exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/attributes/{attributeIdOrName}")
	@WebReturnType("xmlView")
	public AttributeInfoList getAttribute(@PathVariable("attributeIdOrName") String attributeIdOrName) throws AttributeNotFoundException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewAttributes");
		return attributeController.getAttribute(attributeIdOrName);
	}

	/**
	 * Creates attributes and returns its definition. Minimal fields required to create an attribute are <li/>name</li><li>
	 * id or name of the attribute value type</li><br/>
	 * But for a domain type attribute, it is also mandatory to specify the domain information in attributeValuePreferenceInfo. The
	 * attribute id is automatically generated by the server. If an id is supplied, it is discarded and a new id is generated. The attribute
	 * generated is a user-defined and user-modifiable. Besides this there are other certain properties of the attribute that are
	 * automatically set overriding the values sent by client. Following properties of an attribute are set implicitly:
	 * <p>
	 * <li>userDefined</li>
	 * <li>modificationLevel</li>
	 * <li>created</li>,
	 * <li>creator</li>,
	 * <li>creatorName</li>,
	 * <li>lastModified</li>,
	 * <li>lastModifier</li>,
	 * <li>lastModifierName</li>,
	 * <li>valuePreferencesChangeable</li>,
	 * <li>constraintsChangeable</li>,
	 * <li>displayable</li>,
	 * <li>limitedAccessChangeable</li>,
	 * <li>ModificationLevel</li>,
	 * <li>Queryable</li>,
	 * <p>
	 * So client need not set these values while creating an attribute.
	 * </p>
	 * 
	 * @param attributeInfoList
	 *            {@link AttributeInfoList} object containing list of {@link AttributeInfo}'s to be created.
	 * @return {@link AttributeInfoList} encapsulating the successfully created attributes
	 * @throws InvalidAttributeException
	 *             If any invalid/inconsistent data is provided in the attribute definition. Specific reason for the exception can be
	 *             determined from its exception code.
	 * @throws InvalidAttributeValueException
	 *             If the default value specified is not the correct one (as per preferences defined). Specific reason for the exception can
	 *             be determined by calling <code>getExceptionCode()</code> of the exception.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/attributes", params = "op=create")
	@WebReturnType("xmlView")
	public AttributeInfoList createAttributes(@WebSerializedParam("attributeinfolist") AttributeInfoList attributeInfoList)
			throws InvalidAttributeException, InvalidAttributeValueException, RepositoryActionException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyAttributes");
		return attributeController.createAttributes(attributeInfoList);
	}

	/**
	 * Updates an attribute name, value type, value type preferences & limited access option. Only user-defined attributes are update able.
	 * An attribute can be updated on the basis of either id or name, but id is given preference over name. Attribute id is mandate in case
	 * attribute is to be renamed.
	 * 
	 * @param attributeInfoList
	 *            {@link AttributeInfoList} object containing updated information for list of attributes to be updated
	 * @return {@link AttributeInfoList} list encapsulating the successfully updated attributes.
	 * @throws AttributeNotFoundException
	 *             In case the attribute with given id or name doesn't exist.
	 * @throws InvalidAttributeException
	 *             In case of an invalid attribute. The exception code will describe the exact cause of exception.
	 * @throws DomainNotFoundException
	 *             In case there is no domain corresponding to the given domainId.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/attributes", params = "op=update")
	@WebReturnType("xmlView")
	public AttributeInfoList updateAttributes(@WebSerializedParam("attributeinfolist") AttributeInfoList attributeInfoList) throws AttributeNotFoundException,
			InvalidAttributeException, DomainNotFoundException, RepositoryActionException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyAttributes");
		return attributeController.updateAttributes(attributeInfoList);
	}
	
	/**
	 * Deletes an attribute definition with given id or name. System defined attributes cannot be deleted.
	 * 
	 * @param attributeIdOrName
	 *            Id or name of the attribute to be deleted. Id is given preference over name.
	 * @throws InvalidAttributeException
	 *             If it is one of the default attributes that cannot be deleted.
	 * @throws AttributeNotFoundException
	 *             If no attribute with given Id/name exists on the server.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/attributes/{attributeIdOrName}", params = "op=delete")
	public void deleteAttribute(@PathVariable String attributeIdOrName) throws InvalidAttributeException, AttributeNotFoundException,
			RepositoryActionException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteAttributes");
		attributeController.deleteAttribute(attributeIdOrName);
	}


	// Api's related to content types get, create, update & delete.

	/**
	 * It returns complete information of all content types in the system in hierarchical structure. Each ContentTypeInfo object
	 * encapsulates information like
	 * <p>
	 * <li>name</li>,
	 * <li>contentTypeHierarchy</li>,
	 * <li>parentContentTypeId</li>,
	 * <li>domainId</li>,
	 * <li>systemDefined</li>,
	 * <li>childrenAvailable</li>,
	 * <li>extensible</li>,
	 * <li>created</li>,
	 * <li>creator</li>,
	 * <li>creatorName</li>,
	 * <li>lastModified</li>,
	 * <li>lastModifier</li>,
	 * <li>lastModifierName</li>,
	 * <li>contentTypeAttributeMappingInfoList</li>,
	 * <li>contentTypeInfoList : list of child content types. Each object in this list will further contain its children. This behavior
	 * repeats down the hierarchy.</li>
	 * </p>
	 * 
	 * @return {@link ContentTypeInfoList} object encapsulating list of {@link com.quark.qpp.service.xmlBinding.ContentTypeInfo} objects.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/contenttypes")
	@WebReturnType("xmlView")
	public ContentTypeInfoList getAllContentTypes() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewContentTypes");
		return contentTypeController.getAllContentTypes();
	}
	
	/**
	 * Returns complete information of the Content Type with the given id or name. This will also include the child content types, further
	 * their children & so on down the hierarchy. In case of name, we fetch for content type with this name. In case there exists
	 * more than one content type with this name, we return the first fetched content type with this name.
	 * 
	 * @param contentTypeIdOrName
	 *            id or name of the content type to be retrieved. The input is assumed to an id first, but if it throws exception, we check
	 *            the input for name.
	 * @return {@link ContentTypeInfoList} object containing information about requested content type inclusive of its children,
	 *         grandchildren & so on uptill the leaf content type.
	 * @throws InvalidContentTypeException
	 *             if content type is not available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             unhanlded server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/contenttypes/{contentTypeIdOrName}")
	@WebReturnType("xmlView")
	public ContentTypeInfoList getContentType(@PathVariable String contentTypeIdOrName) throws UserPrivilegeException,
			InvalidContentTypeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewContentTypes");
		return contentTypeController.getContentType(contentTypeIdOrName);
	}
	
	/**
	 * Creates one or more content types & its child content types as per the hierarchy given.
	 * For each top most ContentTypeInfo object, it is mandatory to specify either the contentTypeHeirarchy or the parentContentTypeId in
	 * order to refer to the parent content type. For subsequent children the parent content type
	 * will be fetched from the hierarchy. Following properties are mandatory in order to create a content type : <li><b>name, <li>contentTypeHierarchy or
	 * parentContentTypeId (for instance to create a content type 'My Asset' under Assets the hierarchy would look like System;Asset;My
	 * Asset;) or you may specify the parentContentTypeId as {@link DefaultContentTypes#ASSET}</b> </br> </br> The parent revision settings,
	 * workflows, forms & attributes are mapped implicitly to the child content types. But one can override the attribute-mapping by
	 * specifying the {@link ContentTypeAttributeMappingInfoList} in ContentTypeInfo object or using the API {@link #setAttributes(String[], String[])} <br/>
	 * 
	 * @param contentTypeInfo
	 *            details of the content type to be created. After the creation of this content type, the child content types defined will be
	 *            considered for creation.
	 * @param contentTypeInfoList
	 *            list of the content types to be created. After the creation of a content type, the child content types defined will be
	 *            considered for creation. When a hierarchy of content types is processed, then the next sibling is chosen for creation.
	 * @return {@link ContentTypeInfoList} List of the content types inclusive of the children that have been created successfully.
	 * @throws InvalidContentTypeException
	 *             This exception is thrown whenever the content type supplied is invalid for the given context. The exact reason of the
	 *             exception can be determined by calling getExceptionCode() of the exception. Sample scenarios : if parent content type is
	 *             null,if parent content type is not extensible,if parent content type is root type(SYSTEM),if content type with given name
	 *             is already available.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/contenttypes", params = "op=create")
	@WebReturnType("xmlView")
	public ContentTypeInfoList createContentTypes(@WebSerializedParam("contenttypeinfolist") ContentTypeInfoList contentTypeInfoList) throws InvalidContentTypeException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyContentTypes");
		return contentTypeController.createContentTypes(contentTypeInfoList);
	}

	/**
	 * Updates content types & its children if mentioned on the basis of id or contentTypeHierarchy. One may update the
	 * content type name and/or its attributes mappings. This method accepts only user mapped attributes for updation. System mapped
	 * attributes are not allowed to be updated. If supplied, System mapped attributes would be ignored. The existing set of attributes
	 * mapping would be overridden(except system mapped attributes) with the one provided. Each ContentType to attributes mapping contains
	 * attribute id/name to be mapped to the given content type and a mandatory value flag to indicate whether the attribute value for given
	 * content type is mandatory or not. The default value of mandatory flag is set false. The userMapped flag is overridden/set by the
	 * server. In @link {@link ContentTypeAttributeMappingInfo} we may specify either the id or name of the attribute to be mapped to content type.
	 * 
	 * @param contentTypeInfoList
	 *            {@link ContentTypeInfoList} Object containing list of all content type to be updated.
	 * @return {@link ContentTypeInfoList} Object containing updated list of all content types.
	 * @throws InvalidContentTypeException
	 *             In case the content type with given id/name doesn't exist in the system.
	 * @throws AttributeNotFoundException
	 *             In case the attribute with the given id or name doesn't exist in the system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/contenttypes", params = "op=update")
	@WebReturnType("xmlView")
	public ContentTypeInfoList updateContentTypes(@WebSerializedParam("contenttypeinfolist") ContentTypeInfoList contentTypeInfoList) throws UserPrivilegeException,
			AttributeNotFoundException, InvalidContentTypeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyContentTypes");
		return contentTypeController.updateContentTypes(contentTypeInfoList);
	}
	
	/**
	 * This API will completely replace the existing (user mapped)attribute mapping of each content type with the list of attributes
	 * specified. One can update only user mapped attributes. A content type can be specified either by path(e.g.
	 * Home/collection1/collectin2), id (e.g. 23) or name(e.g. ColImages). Similarly an attribute can be specified either by name or id.
	 * 
	 * @param contentTypesIdOrPathOrName
	 *            list of content types to be mapped to each given attribute. Content type can be specified either by path, id or name.
	 *            Example : 1100,System;Article Component,Picture,1200,...,..,..
	 * @param attributesIdOrName
	 *            list of attributes to be mapped to each content type. An attribute can be specified either by id or name.Example :
	 *            name,7,55,Creator,..,..
	 * @throws InvalidContentTypeException
	 *             In case of invalid content type.
	 * @throws AttributeNotFoundException
	 *             In case the attribute with given id or name does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/contenttypes", params = "op=setattributes")
	@WebReturnType("xmlView")
	public void setAttributes(@WebArrayParam("contenttypes") String[] contentTypesIdOrPathOrName, @WebArrayParam("attributes") String[] attributesIdOrName)
			throws InvalidContentTypeException, AttributeNotFoundException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyContentTypes");
		contentTypeController.setAttributes(contentTypesIdOrPathOrName, attributesIdOrName);
	}
	
	/**
	 * Deletes the content type with given id or name. Content type deletion on the basis of name will delete only in case there exists just
	 * one content type with given name. But in case there are more than one content types with given name, it leads to
	 * InvalidContentTypeException. Only user defined content types are allowed for deletion.
	 * 
	 * @param contentTypeIdOrName
	 *            id or name of the content type to be deleted.
	 * @throws InvalidContentTypeException
	 *             In case of invalid content type. The exception code will specify the exact cause of exception.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/contenttypes/{contentTypeIdOrName}", params = "op=delete")
	public void deleteContentType(@PathVariable(value="contentTypeIdOrName") String contentTypeIdOrName) throws InvalidContentTypeException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteContentTypes");
		contentTypeController.deleteContentType(contentTypeIdOrName);
	}
	
	//API's related to LDAP profiles get, create, update & delete.
	
	/**
	 * Returns all ldap profiles saved in the platform server.
	 * 
	 * @return List of ldap profiles in the system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapprofiles")
	@WebReturnType("xmlView")
	public LdapProfileInfoList getAllLdapProfiles() throws QppServiceException {
		return userProvisioningController.getAllLdapProfiles();
	}
	
	/**
	 * Get ldap profile with given id or name. Id is given preference over name.
	 * @param ldapProfileIdOrName 
	 * 			Id or name of the ldap profile to be retrieved.
	 * @return LdapProfileInfoList containing details of the ldap profile with given id or name.
	 * @throws InvalidLdapProfileException
	 *             In case the id or name of the ldap profile is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapprofiles/{ldapProfileIdOrName}")
	@WebReturnType("xmlView")
	public LdapProfileInfoList getLdapProfile(@PathVariable(value = "ldapProfileIdOrName") String ldapProfileIdOrName)
			throws InvalidLdapProfileException, QppServiceException {
		return userProvisioningController.getLdapProfile(ldapProfileIdOrName);
	}

	/**
	 * Synchronizes all users and groups imported from LDAP Server to Platform Server.<br>
	 * For each Platform Server imported user/group, the LDAP server will be queried to get user/group with the distinguished name same as
	 * imported user's/group's LDAP distinguished name. If match found, imported user's details like first name, last name, email
	 * address,... will be updated & in case of an imported group its meta data, immediate users & subgroups(along with users) will be
	 * synchronized. <br>
	 * In case a match is not found then user/group is ignored and remains in the same state in Platform Server.<br>
	 * Thus, synchronization of imported users & groups includes following actions:
	 * 
	 * <pre>
	 * 1.For an Platform Server imported group, if a match has been found in LDAP server on the basis of LDAP distinguished name, then following actions will be done:
	 * 		i Update the group meta data like email address...
	 * 		ii. Update subgroups
	 * 			- Update meta data of existing subgroups
	 * 			- Import missing users of existing subgroups
	 * 			- Import missing sub groups along with users.
	 * 		iii. Import missing users</li>
	 * 2.In case an imported LDAP group could not be fetched from LDAP server, then such a group will be ignored from sync process & will remain in the same state without any meta data update.
	 * 3.For a Platform Server imported user,if a match has been found in LDAP server on the basis of LDAP distinguished name, then the user info like first name, last name, email address, phone number will be updated.
	 * 4.But in case, when no match is found for the imported user, then it will be ignored from the sync process & remain in that same state without any meta data update.
	 * </pre>
	 * 
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapprofiles", params = "op=synchronize")
	public void synchronizeLdapUsersGroups() throws QppServiceException {
		trusteeController.synchronizeLdapUsersGroups();
	}
	
	/**
	 * Synchronizes users & groups that were imported from LDAP Server to Platform Server using the given LDAP profile. The behavior is
	 * similar to the API {@link #synchronizeLdapUsersGroups()} except for the fact that this will synchronize only those members that were
	 * imported using the given LDAP profile.
	 * 
	 * @param ldapProfileIdOrName
	 *            Id or name of the LDAP profile whose imported users & groups are to be synchronized with the LDAP server.
	 * @throws InvalidLdapProfileException
	 *             In case LDAP profile with the given id or name does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapprofiles/{ldapProfileIdOrName}", params = "op=synchronize")
	public void synchronizeLdapUsersGroupsBasedOnProfile(@PathVariable(value = "ldapProfileIdOrName") String ldapProfileIdOrName)
			throws InvalidLdapProfileException, QppServiceException {
		trusteeController.synchronizeLdapUsersGroupsBasedOnProfile(ldapProfileIdOrName);
	}
	
	/**
	 * Creates ldap profiles. Minimum fields required to create a ldap profile are <li>name : Ldap user profile display name</li> <li>realm
	 * : Realm of the user profile</li><li>userName : Domain User through which platform server will communicate to registered ldapServers
	 * to fetch/search domain users with specified authentication types</li> <li>authenticationType : Authentication types (
	 * {@link LdapAuthenticationTypes#SIMPLE} , {@link LdapAuthenticationTypes#DIGEST_MD5} or {@link LdapAuthenticationTypes#SIMPLE})
	 * through which platform server will communicate to specified ldapServers to authenticate imported users at the time of logOn.</li><li>
	 * ldapServerInfoList : List of Ldap severs/domain controllers These servers will be used by platform server to fetch domain users and
	 * to authenticate imported users at the time of logOn.</li>
	 * 
	 * @param ldapProfileInfoList
	 *            list of ldap profiles to be created.
	 * @return list of ldap profiles created successfully.
	 * @throws InvalidLdapProfileException
	 *             In case of invalid ldap profile.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapprofiles", params = "op=create")
	@WebReturnType("xmlView")
	public LdapProfileInfoList createLdapProfiles(@WebSerializedParam("ldapprofileinfolist") LdapProfileInfoList ldapProfileInfoList)
			throws InvalidLdapProfileException, QppServiceException {
		return userProvisioningController.createLdapProfiles(ldapProfileInfoList);
	}
	
	/**
	 * Used to update ldap profiles. Fields like name, realm, userName, server infos, authentication type can be updated.
	 * Ldap profiles can be updated on the basis of ldap id or name. But for renaming of ldap profile, id is mandate.
	 * 
	 * @param ldapProfileInfoList
	 *            list of ldap profiles to be updated successfully.
	 * @return list of ldap profiles updated successfully.
	 * @throws InvalidLdapProfileException
	 *            In case given ldap profile is not valid. The exceptionCode will specify the exact cause of exception.
	 * @throws InvalidLdapProfileException
	 *             In case of an invalid ldap profile.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapprofiles", params = "op=update")
	@WebReturnType("xmlView")
	public LdapProfileInfoList updateLdapProfiles(@WebSerializedParam("ldapprofileinfolist") LdapProfileInfoList ldapProfileInfoList) throws InvalidLdapProfileException,
			QppServiceException {
		return userProvisioningController.updateLdapProfiles(ldapProfileInfoList);
	}

	/**
	 * Deletes an ldap profile. LDAP profile can be deleted on the basis of ldap profile id or ldap profile name.
	 * 
	 * @param profile
	 *            Id or name of the ldap profile to be deleted.
	 * @throws InvalidLdapProfileException
	 *             In case of an invalid ldap profile. The exception code will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapprofiles/{profileIdOrName}", params = "op=delete")
	public void deleteLdapProfile(@PathVariable String profileIdOrName) throws InvalidLdapProfileException, QppServiceException {
		userProvisioningController.deleteLdapProfile(profileIdOrName);
	}
	
	/**
	 * Returns all saved LDAP search definitions.
	 * 
	 * @return List of saved LDAP search definitions.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapsearchdefinitions")
	@WebReturnType("xmlView")
	public LdapSearchInfoList getAllLdapSearches() throws QppServiceException {
		return userProvisioningController.getAllLdapQueryDefinitions();
	}

	/**
	 * Returns LDAP search definition for the given search id or name.<br>
	 * The input is assumed to be a search id first, if not resolved then the input is assumed to be search name.
	 * 
	 * @param searchIdOrName
	 *            Id or name of the saved LDAP search to be retrieved.
	 * @return List containing the LDAP search definition for the given search id or name.
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case the given search id or name is not valid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapsearchdefinitions/{searchIdOrName}")
	@WebReturnType("xmlView")
	public LdapSearchInfoList getLdapSearch(@PathVariable("searchIdOrName") String searchIdOrName)
			throws InvalidLdapQueryDefinitionException, QppServiceException {
		return userProvisioningController.getLdapQueryDefinition(searchIdOrName);
	}

	/**
	 * Creates LDAP search definitions from the mentioned list of {@link LdapSearchInfo}
	 * 
	 * @param ldapSearchInfoList
	 *            List of LDAP search definitions to be created.
	 * @return List of successfully created LDAP search definitions.
	 * 
	 * @throws InvalidLdapProfileException
	 *             In case the LDAP profile id or name is not valid.
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case given ldap search definition is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapQueryDefinitionExceptionCodes}
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapsearchdefinitions", params = "op=create")
	@WebReturnType("xmlView")
	public LdapSearchInfoList createLdapSearches(@WebSerializedParam("ldapsearchinfolist") LdapSearchInfoList ldapSearchInfoList)
			throws InvalidLdapProfileException, InvalidLdapQueryDefinitionException, InvalidLdapSearchCriteriaException,
			QppServiceException {
		return userProvisioningController.createLdapQueryDefinitions(ldapSearchInfoList);
	}

	/**
	 * Updates the given LDAP search definitions.<br>
	 * A LDAP search to be updated is identified by id or name.First preference is given to {@link LdapSearchInfo#getId()},but if
	 * {@link LdapSearchInfo#getId()} is not present then {@link LdapSearchInfo#getName()} will be used to identify the LDAP search that is
	 * to be updated.
	 * 
	 * @param ldapSearchInfoList
	 *            List of LDAP searches to be updated.
	 * @return List of successfully updated LDAP search definitions.
	 * @throws InvalidLdapProfileException
	 *             In case the LDAP profile id or name is not valid.
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case given ldap search definition is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapQueryDefinitionExceptionCodes}
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapsearchdefinitions", params = "op=update")
	@WebReturnType("xmlView")
	public LdapSearchInfoList updateLdapSearches(@WebSerializedParam("ldapsearchinfolist") LdapSearchInfoList ldapSearchInfoList)
			throws InvalidLdapProfileException, InvalidLdapQueryDefinitionException, InvalidLdapSearchCriteriaException,
			QppServiceException {
		return userProvisioningController.updateLdapQueryDefinitions(ldapSearchInfoList);
	}

	/**
	 * Deletes LDAP search definition with the given id or name.<br>
	 * The input is assumed to be a search id first, if not resolved then the input is assumed to be search name.
	 * 
	 * @param searchIdOrName
	 *            Id or name of the LDAP search to be deleted.
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case there does not exist any ldap search definition with the given id or name. The exception will contain an
	 *             exception code, specified in {@link InvalidLdapQueryDefinitionExceptionCodes}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/ldapsearchdefinitions/{searchIdOrName}", params = "op=delete")
	public void deleteLdapSearch(@PathVariable("searchIdOrName") String searchIdOrName) throws InvalidLdapQueryDefinitionException,
			QppServiceException {
		userProvisioningController.deleteLdapQueryDefinition(searchIdOrName);
	}
	
	/**
	 * Fetches LDAP users using a saved ldap query id/name or specify a combination of valid ldapprofile id/name, base string & search filter.
	 * 
	 * @param savedLdapQueryNameOrId
	 *            name or id of the saved LDAP query definition from where users
	 *            are to be fetched.
	 * @param ldapProfileNameOrId
	 *            name or id of the saved LDAP profile from where the users are
	 *            to be fetched.
	 * @param baseString
	 *            Specifies LDAP Distinguished names (DNs). The DN is the name
	 *            that uniquely identifies an entry in the directory. i.e.
	 *            cn=Ben Gray,ou=editing,o=New York Times,c=US
	 * @param searchFilter
	 *            a string to specify the value to LDAP attribute tag on whose
	 *            basis LDAP server will be searched. e.g. (samaccountname=*)
	 * @param defaultUserClassIdOrName
	 *            name or id of the userclass to be set as default userclass for
	 *            all the users that will be fetched through this API. Id will
	 *            be given preference over name.
	 * @param pageSize
	 *            No of users to be fetched from the LDAP server. 
	 * @return {@link UserInfoList} object encapsulating list of users in the platform server.
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria i.e.baseString or
	 *             searchFilter is not valid. It will contain an exception code,
	 *             specified in {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws InvalidLdapProfileException
	 *             In case ldap profile id/name specified is not valid.
	 *             Exception code will be
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case the LDAP query definition specified is invalid. The
	 *             exception code will specify the exact cause of exception.
	 *             {@link InvalidLdapProfileExceptionCodes#INVALID_PROFILE_ID}
	 * @throws UserSourceAccessException
	 *          	In case the external user source is not accessible
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapusers")
	@WebReturnType("xmlView")
	public UserInfoList getLdapUsers(@RequestParam(value = "savedldapquery", required = false) String savedLdapQueryNameOrId,
			@RequestParam(value = "ldapprofile", required = false) String ldapProfileNameOrId,
			@RequestParam(value = "basestring", required = false) String baseString,
			@RequestParam(value = "searchfilter", required = false) String searchFilter,
			@RequestParam(value = "pagesize", defaultValue = "300") int pageSize) throws InvalidLdapSearchCriteriaException,
			InvalidLdapProfileException, InvalidLdapQueryDefinitionException, UserSourceAccessException, UserPrivilegeException, QppServiceException {
			return userProvisioningController.getLdapUsers(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize);
	}
	
	/**
	 * Fetches LDAP groups using a saved LDAP query or the combination of basestring & searchfilter.
	 * 
	 * @param savedLdapQueryNameOrId
	 *            Name or id of the saved LDAP query.
	 * @param ldapProfileNameOrId
	 *            Name or id of the LDAP profile
	 * @param baseString
	 *            LDAP distinguished name of the unique entity in LDAP server wherein LDAP groups are to fetched
	 * @param searchFilter
	 *            a string to specify the value to LDAP attribute tag on whose basis LDAP server will be searched.
	 * @param pageSize
	 *            No of groups to be fetched from the LDAP server.
	 * @return List of LDAP groups on the basis of saved LDAP query or the combination of base string and search filter
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria i.e.baseString or searchFilter is not valid. It will contain an exception code,
	 *             specified in {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws InvalidLdapProfileException
	 *             In case ldap profile id/name specified is not valid. Exception code will be
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case the LDAP query definition specified is invalid. The exception code will specify the exact cause of exception.
	 *             {@link InvalidLdapProfileExceptionCodes#INVALID_PROFILE_ID}
	 * @throws UserSourceAccessException
	 *             In case the external user source is not accessible
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/ldapgroups")
	@WebReturnType("xmlView")
	public GroupInfoList getLdapGroups(@RequestParam(value = "savedldapquery", required = false) String savedLdapQueryNameOrId,
			@RequestParam(value = "ldapprofile", required = false) String ldapProfileNameOrId,
			@RequestParam(value = "basestring", required = false) String baseString,
			@RequestParam(value = "searchfilter", required = false) String searchFilter,
			@RequestParam(value = "pagesize", defaultValue = "300") int pageSize) throws InvalidLdapSearchCriteriaException,
			InvalidLdapProfileException, InvalidLdapQueryDefinitionException, UserSourceAccessException, UserPrivilegeException,
			QppServiceException {
		return userProvisioningController.getLdapGroups(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize);
	}
	
	
	/**
	 * Imports users from an LDAP server into platform server. The users are
	 * imported either on the basis of saved LDAP query definition
	 * id/name or on the combination of LDAP profile id/name, baseString &
	 * searchFilter. The defaultUserClass for all the users being imported in this
	 * call can be set through the parameter defaultUserClass.In case all the
	 * fetched users from LDAP server have already been imported, then it will
	 * return an empty UserInfoList else a valid UserInfoList of those users
	 * that have been imported to platform server through this call execution.
	 * 
	 * @param savedLdapQueryNameOrId
	 *            name or id of the saved LDAP query definition from where users
	 *            are to be imported. Name is given preference over id.
	 * @param ldapProfileNameOrId
	 *            name or id of the saved LDAP profile from where the users are
	 *            to be imported. Name is given preference over id.
	 * @param baseString
	 *            Specifies LDAP Distinguished names (DNs). The DN is the name
	 *            that uniquely identifies an entry in the directory. i.e.
	 *            cn=Ben Gray,ou=editing,o=New York Times,c=US
	 * @param searchFilter
	 *            a string to specify the value to LDAP attribute tag on whose
	 *            basis LDAP server will be searched. e.g. (samaccountname=*)
	 * @param defaultUserClassIdOrName
	 *            name or id of the userclass to be set as default userclass for
	 *            all the users that will be imported through this API. Id will
	 *            be given preference over name.
	 * @param pageSize
	 *            No of users to be fetched from the LDAP server. The number of
	 *            fetched users and users imported may not be same because few
	 *            of the ldap fetched users may have been already imported
	 *            before and those will not be returned in UserInfoList.
	 * @return UserInfoList object specifying the users imported through this
	 *         call. In case, few of the users were already imported in
	 *         platform, then only those remaining ldap users that were imported
	 *         through this call will be returned in UserInfoList.
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria i.e.baseString or
	 *             searchFilter is not valid. It will contain an exception code,
	 *             specified in {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws InvalidLdapProfileException
	 *             In case ldap profile id/name specified is not valid.
	 *             Exception code will be
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case the LDAP query definition specified is invalid. The
	 *             exception code will specify the exact cause of exception.
	 *             {@link InvalidLdapProfileExceptionCodes#INVALID_PROFILE_ID}
	 * @throws UserSourceAccessException
	 *          	In case the external user source is not accessible
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/users", params = "op=importusers")
	@WebReturnType("xmlView")
	public UserInfoList importUsersFromLdap(@RequestParam(value="savedldapquery",required=false) String savedLdapQueryNameOrId, @RequestParam(value="ldapprofile",required=false) String ldapProfileNameOrId,
			@RequestParam(value="basestring", required=false) String baseString, @RequestParam(value="searchfilter",required=false) String searchFilter,
			@RequestParam(value = "defaultuserclass", defaultValue = "Administrator") String defaultUserClassIdOrName,
			@RequestParam(value = "pagesize", defaultValue = "300") int pageSize) throws InvalidLdapProfileException,
			InvalidLdapSearchCriteriaException, InvalidLdapQueryDefinitionException, UserSourceAccessException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("importUsersFromExternalSource");
		return userProvisioningController.importUsersFromLdap(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, defaultUserClassIdOrName, pageSize);
	}
	
	/**
	 * Imports groups from LDAP server along with all of its subgroups and users into Platform. <br>
	 * While importing subgroups and users of the given group, users or groups which already exist in the Platform with same name are
	 * ignored and not imported.<br>
	 * Empty string will be the default password for all users imported.
	 * 
	 * @param savedLdapQueryNameOrId
	 *            name or id of the saved ldap query from which users & groups are to be imported.
	 * @param ldapProfileNameOrId
	 *            name or id of the ldap profile
	 * @param baseString
	 *            Specifies LDAP Distinguished names (DNs). The DN is the name that uniquely identifies an entry in the directory. i.e.
	 *            cn=Ben Gray,ou=editing,o=New York Times,c=US
	 * @param searchFilter
	 *            a string to specify the value to LDAP attribute tag on whose basis LDAP server will be searched. e.g. (samaccountname=*)
	 * @param defaultUserClassIdOrName
	 *            name or id of the userclass to be set as default userclass for all the users that will be imported through this API. Id
	 *            will be given preference over name.
	 * @param pageSize
	 *            No of users to be fetched from the LDAP server. The number of fetched users and users imported may not be same because few
	 *            of the ldap fetched users may have been already imported before and those will not be returned in UserInfoList.
	 * @return Information of all users and groups which have been successfully imported into Platform.
	 * @throws InvalidLdapProfileException
	 *             In case ldap profile with the given id does not exist.
	 * @throws InvalidLdapSearchCriteriaException
	 *             In case given ldap search criteria is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapSearchCriteriaExceptionCodes}
	 * @throws InvalidLdapQueryDefinitionException
	 *             In case given ldap query definition is not valid. It will contain an exception code, specified in
	 *             {@link InvalidLdapQueryDefinitionExceptionCodes}
	 * @throws UserSourceAccessException
	 *             In case the external user source is not accessible
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/groups", params = "op=importgroups")
	@WebReturnType("xmlView")
	public ImportedGroupInfoList importGroupsFromLdap(@RequestParam(value = "savedldapquery", required = false) String savedLdapQueryNameOrId,
			@RequestParam(value = "ldapprofile", required = false) String ldapProfileNameOrId,
			@RequestParam(value = "basestring", required = false) String baseString,
			@RequestParam(value = "searchfilter", required = false) String searchFilter,
			@RequestParam(value = "defaultuserclass", defaultValue = "Administrator") String defaultUserClassIdOrName,
			@RequestParam(value = "pagesize", defaultValue = "300") int pageSize)
			throws InvalidLdapProfileException, InvalidLdapSearchCriteriaException, InvalidLdapQueryDefinitionException,
			UserSourceAccessException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("importUsersFromExternalSource");
		return userProvisioningController.importGroupsFromLdap(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter,
				defaultUserClassIdOrName, pageSize);
	}
	
	// Api's related to workflow get, create, update & delete.
	
	/**
	 * Get details of all workflows defined in the system. The workflowInfo object contains details like : <p>
	 * <li>name
	 * <li>domainId
	 * <li>created
	 * <li>createdBy
	 * <li>creatorName
	 * <li>lastModifiedBy
	 * <li>lastModifierName
	 * <li>lastModified
	 * <li>{@link StatusInfoList} : StatusInfo consists of metadata like name, colorRed/green/blue, privilegeInfoList &
	 * attributeConstraintsInfoList.
	 * <li>{@link ContentTypeInfoList} : List of content types mapped to this workflow.
	 * </p>
	 * <br/>
	 * @return {@link WorkflowInfoList} object encapsulating list of {@link WorkflowInfo} objects containing workflow & its statuses detail
	 *         information.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/workflows")
	@WebReturnType("xmlView")
	public WorkflowInfoList getAllWorkflows() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewWorkflows");
		return workflowController.getAllWorkflows();
	}

	/**
	 * Get Workflow definition corresponding to a workflow Id or name.
	 * 
	 * @param workflow
	 *            Id or name of the workflow to be retrieved. The input will be considered an Id first , if invalid will considered to be
	 *            workflow name.
	 * @return {@link WorkflowInfoList} object containing details of the workflow with the specified id/name.
	 * @throws WorkflowNotFoundException
	 *             if workflow with given id or name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/workflows/{workflow}")
	@WebReturnType("xmlView")
	public WorkflowInfoList getWorkflow(@PathVariable String workflow) throws WorkflowNotFoundException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewWorkflows");
		return workflowController.getWorkflow(workflow);
	}

	/**
	 * Returns list of "Workflow Initiating Statuses" for the given workflow. If the roleIdOrName parameter is specified then
	 * "Workflow Initiating Statuses" will be returned on the basis of overridden status transitions for given role> If no role is specified - default
	 * initiating statuses are returned. But in case {@link WorkflowInfo#isConstrainedStatusTransition()} flag of workflowInfo is false,
	 * then all statuses of the workflow will be returned.
	 * 
	 * @param workflowIdOrName
	 *            Id or name of the workflow whose "Workflow Initiating Statuses" are to be retrieved. The input will be considered to be an
	 *            Id first, if invalid will considered to be workflow name.
	 * @param roleIdOrName
	 *            Id or name of the role for which "Workflow Initiating Statuses" are to be fetched for a workflow. This is an optional
	 *            parameter. If not mentioned then the default "Workflow Initiating Statuses" will be returned.
	 * @return List of "Workflow Initiating Statuses" will be returned.
	 * @throws WorkflowNotFoundException
	 *             If workflow with the given id or name doesn't exist.
	 * @throws UserClassNotFoundException
	 *             If role with the given id or name does not exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/workflows/{workflowIdOrName}", params = "workflowinitiatingstatuses=true")
	@WebReturnType("xmlView")
	public StatusInfoList getWorkflowInitiatingStatuses(@PathVariable String workflowIdOrName,
			@RequestParam(value = "role", required = false) String roleIdOrName) throws WorkflowNotFoundException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewWorkflows");
		return workflowController.getWorkflowInitiatingStatuses(workflowIdOrName, roleIdOrName);
	}

	/**
	 * Returns status transitions set for the given workflow. If the statusIdOrName parameter is specified, then status transitions for a
	 * particular status are returned.And in case the roleIdOrName parameter is specified, then the overridden transitions for the given role for
	 * particular workflow will be returned. Otherwise the default status transitions are returned.
	 * 
	 * @param workflowIdOrName
	 *            Id or name of the workflow for which status transitions are to be retrieved.
	 * @param statusIdOrName
	 *            Id or name of the status for which status transitions are to be fetched. This is an optional parameter. If not mentioned,
	 *            status transitions for the entire workflow will be retrieved.
	 * @param roleIdOrName
	 *            Id or name of role for which status transitions are to be fetched for a workflow or a particular status.This is an
	 *            optional parameter. If not mentioned then the default status transitions will be returned.
	 * @return List of StatusTransitions set for the given workflow or a particular status for specified role.
	 * @throws WorkflowNotFoundException
	 *             If workflow with the given id or name doesn't exist.
	 * @throws StatusNotFoundException
	 *             If status with the given id or name does not exist.
	 * @throws InvalidStatusException
	 *             If the status is invalid or does not belong to the mentioned workflow.Exception code will specify the exact cause of
	 *             exception.
	 * @throws UserClassNotFoundException
	 *             If role with the given id or name does not exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/workflows/{workflowIdOrName}", params = "statustransitions=true")
	@WebReturnType("xmlView")
	public StatusTransitionInfoList getStatusTransitions(@PathVariable String workflowIdOrName,
			@RequestParam(value = "status", required = false) String statusIdOrName,
			@RequestParam(value = "role", required = false) String roleIdOrName) throws WorkflowNotFoundException, StatusNotFoundException,
			InvalidStatusException, UserClassNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewWorkflows");
		return workflowController.getStatusTransitions(workflowIdOrName, statusIdOrName, roleIdOrName);
	}
	
	/**
	 * Creates workflows defined by its name, set of Statuses, status level privileges, content type mappings and options like redLine
	 * tracking, checkInLayoutEvaluation and outputLayoutEvaluation. By default the workflow is not assigned to any collection.
	 * 
	 * @param workflowInfoList
	 *            {@link WorkflowInfoList} encapsulating {@link WorkflowInfo} objects to be created.
	 * @return {@link WorkflowInfoList} of the workflows successfully created in the system.
	 * @throws InvalidWorkflowDefinitionException
	 *             In case of invalid workflow definition like invalid worklfow name. The exception code & additional info will specify the
	 *             exact cause of exception.
	 * @throws InvalidContentTypeException
	 *             In case of invalid content type.
	 * @throws InvalidStatusException
	 *             If any other information in the status object is invalid. Exception code and additional info the exception would contain
	 *             the exact cause and more information.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/workflows", params = "op=create")
	@WebReturnType("xmlView")
	public WorkflowInfoList createWorkFlows(@WebSerializedParam("workflowinfolist") WorkflowInfoList workflowInfoList)
			throws InvalidWorkflowDefinitionException, InvalidContentTypeException, InvalidStatusException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyWorkflows");
		return workflowController.createWorkFlows(workflowInfoList);
	}

	/**
	 * Updates workflow name, statuses, status level privileges, content type mappings and other options like redline tracking, checkin layout
	 * evaluation, output layout evaluation of workflow/s. Workflow can be updated on the basis of id or name. But statuses are updated on
	 * the basis of id.
	 * <br/>
	 * <li>In order to remove all statuses from existing workflow provide blank statusInfoList for that workflow (i.e &ltstatusInfoList&gt&lt/statusInfoList&gt)
	 * <li>In order to remove all content types from existing workflow provide blank contentTypeInfoList for that workflow (i.e &ltcontentTypeInfoList&gt&lt/contentTypeInfoList&gt)
	 * <li>In order to rename workflow, workflow id is mandate, similarly to rename status, status id is mandate.
	 * <br/>
	 * @param workflowInfoList
	 *            list of all the workflows to be updated
	 * @return {@link WorkflowInfoList} list of all the updated workflows
	 * @throws StatusNotFoundException
	 *             if status with given name/id is not available
	 * @throws InvalidStatusException
	 *             if status is not mapped to given workflow.
	 * @throws WorkflowNotFoundException
	 *             if workflow with given name/id is not available in system.
	 * @throws InvalidWorkflowDefinitionException
	 *             if workflow name is null or duplicate.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/workflows", params = "op=update")
	@WebReturnType("xmlView")
	public WorkflowInfoList updateWorkflows(@WebSerializedParam("workflowinfolist") WorkflowInfoList workflowInfoList) throws UserPrivilegeException,
			InvalidWorkflowDefinitionException, WorkflowNotFoundException, InvalidStatusException, StatusNotFoundException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyWorkflows");
		return workflowController.updateWorkflows(workflowInfoList);
	}
	
	/**
	 * Deletes a workflow with given id or name.
	 * 
	 * @param workflowIdOrName
	 *            id or name of the workflow to be deleted.Id is given preference over name.
	 * @throws WorkflowInUseException
	 *             If the workflow is in use. A Workflow cannot be delete if any Asset is assigned to a status in the workflow. All assets
	 *             assigned to a workflow must be reassigned to another Workflow before the workflow can be deleted.
	 * @throws WorkflowNotFoundException
	 *             if workflow with given name or id is not available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/workflows/{workflowIdOrName}", params = "op=delete")
	public void deleteWorkFlow(@PathVariable String workflowIdOrName) throws WorkflowNotFoundException, WorkflowInUseException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteWorkflows");
		workflowController.deleteWorkFlow(workflowIdOrName);
	}

	// Api's related to user roles get, create, update & delete.
	
	/**
	 * Get details of all the user roles that exist in the system. Each RoleInfo object consists of details like id, name, application
	 * privileges & content type privileges. All privileges granted for a role are included.
	 * 
	 * @return {@link RoleInfoList} object containing list of {@link RoleInfo} objects with detailed information of each role.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/roles")
	@WebReturnType("xmlView")
	public RoleInfoList getAllRoles() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUserClasses");
		return roleController.getAllRoles();
	}
	
	/**
	 * Get details of a user class, its id, name, content and application based privileges. All privileges granted for the role are
	 * included. 
	 * 
	 * @param userClass
	 *            Id or name of the userclass whose metadata is to be retrieved. The Id will be given priority over name.
	 * @return RoleInfoList object specifying details of the user role containing user role name, application & content privileges granted
	 *         for the role.
	 * @throws UserClassNotFoundException
	 *             If the user class with given name or id doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/roles/{roleIdOrName}")
	@WebReturnType("xmlView")
	public RoleInfoList getRole(@PathVariable String roleIdOrName) throws UserClassNotFoundException, UserPrivilegeException,
			QppServiceException {
		if(!roleController.isLoggedonUserDefaultRole(roleIdOrName)){
			//validate privileges only if it is not the default role of the logged on user
			privilegeValidator.validateApplicationPrivileges("viewUserClasses");
		}
		return roleController.getRole(roleIdOrName);
	}
	
	
	/**
	 * Creates user role(s) with the given roleinfo object(s) that contains role name, content based privileges and application based
	 * privileges information. Minimum fields required to create a role is role name.
	 * 
	 * @param roleInfoList
	 *            list of roleInfo objects specifying details of the user role including privileges to be granted for the role.
	 * @return roleInfoList List of all successfully created user roles.
	 * @throws InvalidUserClassException
	 *             If any detail provided in role info is invalid. Exception code of the exception describes the exact cause of exception.
	 * @throws PrivilegeNotFoundException
	 *             If any of the privileges included in the role info doesn't exist.Additional info will give the privilege id that has
	 *             thrown this exception.
	 * @throws InvalidPrivilegeException
	 *             If any of the privileges specified is invalid. Additional info will return the privilege id that has thrown this
	 *             exception.
	 * @throws InvalidRoleInfoException
	 *             In case of invalid role info. The exception code will describe the exact cause of the exception.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/roles", params = "op=create")
	@WebReturnType("xmlView")
	public RoleInfoList createRoles(@WebSerializedParam("roleinfolist") RoleInfoList roleInfoList) throws InvalidUserClassException, PrivilegeNotFoundException,
			InvalidPrivilegeException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUserClasses");
		return roleController.createRoles(roleInfoList);
	}
	
	/**
	 * Updates the specified user role(s),its name, content type and application based privileges for the specified user role with the given
	 * id/name. This would result in replacing all existing application privileges of the given user role with the one supplied in the user
	 * role and override content privileges of the given content types in contentTypePrivileges array. The content privileges for rest of
	 * the content types remains intact. Allows only a user defined user role to be set with new values.
	 * 
	 * @param roleInfoList
	 *            {@link RoleInfoList} object containing list of all the roles to be updated.
	 * @return Updated {@link RoleInfoList} object of all updated roles.
	 * @throws UserClassNotFoundException
	 *             In case the userclass with the given name or id does not exist in the system.
	 * @throws UserClassNotEditableException
	 *             In case the userclass is not editable
	 * @throws InvalidContentTypeException
	 *             In case the content type is invalid
	 * @throws PrivilegeNotFoundException
	 *             In case the privilege with the given id doesnot exist. Additional info will return the privilege id that has thrown this
	 *             exception.
	 * @throws InvalidPrivilegeException
	 *             In case the privilege is invalid. Additional info will return the privilege id that has thrown this exception.
	 * @throws InvalidRoleInfoException
	 *             In case of invalid role info for updation. The exception code will describe the exact cause of exception.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/roles", params = "op=update")
	@WebReturnType("xmlView")
	public RoleInfoList updateRoles(@WebSerializedParam("roleinfolist") RoleInfoList roleInfoList) throws UserClassNotFoundException,
			UserClassNotEditableException, InvalidContentTypeException, PrivilegeNotFoundException, InvalidPrivilegeException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUserClasses");
		return roleController.updateRoles(roleInfoList);
	}

	/**
	 * Delete a user role with the given id/name, provided it is not assigned to any user.
	 * 
	 * @param roleIdOrName
	 *            Id or name of role to be deleted. Id is given preference over name.
	 * @throws UserClassNotFoundException
	 *             If role with given id or name is not available in system.
	 * @throws UserClassInUseException
	 *             If there is a user still belonging to this role, then it cannot be deleted.
	 * @throws UserClassNotEditableException
	 *             If role is system defined and cannot be deleted.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/roles/{roleIdOrName}", params = "op=delete")
	public void deleteRole(@PathVariable String roleIdOrName) throws UserClassNotFoundException, UserClassInUseException,
			UserClassNotEditableException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteUserClasses");
		roleController.deleteRole(roleIdOrName);
	}
		
	/**
	 * Returns the platform users with the default userclass as given.
	 * 
	 * @param userClass
	 *            id or name of the userclass corresponding to which the users in the platform will be retrieved.Id is given preference over
	 *            name.
	 * @return userInfoList object containing users with given userclass id/name.
	 * @throws UserClassNotFoundException
	 *             In case the userclass with the given id or name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown. 
	 * @throws QppServiceException
	 *             Unhandled server Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/roles/{roleIdOrName}", params = "users=true")
	@WebReturnType("xmlView")
	public UserInfoList getUsersWithGivenUserClass(@PathVariable String roleIdOrName) throws UserClassNotFoundException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return roleController.getUsersWithGivenRole(roleIdOrName);
	}
	
	/**
	 * Returns the platform groups with the default userclass as given.
	 * 
	 * @param userClass
	 *            id or name of the userclass corresponding to which the groups in the platform will be retrieved.Id is given preference over
	 *            name.
	 * @return groupInfoLList object containing groups with given userclass id/name.
	 * @throws UserClassNotFoundException
	 *             In case the userclass with the given id or name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown. 
	 * @throws QppServiceException
	 *             Unhandled server Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/roles/{roleIdOrName}", params = "groups=true")
	@WebReturnType("xmlView")
	public GroupInfoList getGroupsWithGivenUserClass(@PathVariable String roleIdOrName) throws UserClassNotFoundException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return roleController.getGroupsWithGivenRole(roleIdOrName);
	}
	
	// Api's related to Users get, create, update & delete.
	
	
	/**
	 * Returns all the users existing in the system.
	 * 
	 * @return {@link UserInfoList} object encapsulating list of users in the platform server.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/users")
	@WebReturnType("xmlView")
	public UserInfoList getAllUsers() throws UserPrivilegeException, QppServiceException {
			privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
			return trusteeController.getAllUsers();
		}
	
	/**
	 * Gets the user details for a specified user. The UserInfo object consists of details like name, firstName, lastName, phooneNumber,
	 * emailAddress, natveUser, enabled, defaultUsercCassId, nameForAuthentication, ldapProfile id & name etc..
	 * 
	 * @param userIdOrName
	 *            Id or name of the user whose details are to be retrieved.Id is given preference over name.
	 * @return {@link UserInfoList} object containing complete user information.
	 * @throws UserNotFoundException
	 *             if user with given id or name doesnot exist in the system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/users/{userIdOrName}")
	@WebReturnType("xmlView")
	public UserInfoList getUser(@PathVariable String userIdOrName) throws UserNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return trusteeController.getUser(userIdOrName);
	}
	
	/**
	 * Gets all groups of the given user.
	 * 
	 * @param userIdOrName
	 *            Id or name of the user whose groups are to be fetched.
	 * @return List of GroupInfo objects. Returns an empty list if user does not belong to any group.
	 * @throws UserNotFoundException
	 *             If user with the given id or name does not exist
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/users/{userIdOrName}", params = "groups=true")
	@WebReturnType("xmlView")
	public GroupInfoList getUserGroups(@PathVariable String userIdOrName) throws UserNotFoundException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return trusteeController.getUserGroups(userIdOrName);
	}

	/**
	 * Returns enabled applicable application privileges of the logged-in user. Applicable privileges are determined by making union of all
	 * the privileges granted to him as well to the groups user is member of.
	 * 
	 * @param privilegeIdsOrNames
	 *            Ids or Names of privileges required. If not provided then all enabled applicable privileges are returned.
	 * @return enabled application privileges.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/users", params = "op=applicableapplicationprivileges")
	@WebReturnType("xmlView")
	public ApplicationPrivList getApplicableApplicationPrivileges(@WebArrayParam(value = "privileges") String[] privilegeIdsOrNames)
			throws QppServiceException {
		return trusteeController.getApplicableApplicationPrivileges(privilegeIdsOrNames);
	}

	/**
	 * Returns enabled privileges of the given content type applicable for the logged-in user. Applicable privileges are determined by
	 * making union of all the privileges granted to him as well to the groups logged-on user is member of.
	 * 
	 * @param contentTypeIdOrNameOrHierarchy
	 *            Id, hierarchy or name of the content type whose applicable privileges are required
	 * @param privilegeIdsOrNames
	 *            Ids or Names of privileges required. If not provided then all privileges enabled for the given content type are returned.
	 * @return enabled content privileges.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/users", params = "op=applicablecontentprivileges")
	@WebReturnType("xmlView")
	public ContentTypePriv getApplicableContentPrivileges(@RequestParam("contenttype") String contentTypeIdOrNameOrHierarchy,
			@WebArrayParam(value = "privileges") String[] privilegeIdsOrNames) throws QppServiceException {
		return trusteeController.getApplicableContentPrivileges(contentTypeIdOrNameOrHierarchy, privilegeIdsOrNames);
	}
	
	/**
	 * Creates user(s) in the platform server. The minimum field required for a user
	 * creation is user name. In scenario's when userclass id or name is not mentioned, defaultUserClassIdOrName parameter will be considered. 
	 * By default the password for each user is set blank. In order to create an ldap user, it is mandatory to set isNativeUser to false. 
	 * @param userInfoList
	 *            {@link UserInfoList} object containing list of the users to be created.
	 * @param defaultUserClassIdOrName
	 * 			This field is considered in case you don't mention defaultUserClassId or defaultUserClass in any of the userInfo object.
	 * @return {@link UserInfoList} object containing information of the successfully created users.
	 * @throws InvalidUserException
	 *             If there is any wrong information in the UserInfo DTO. The specific reason for the exception can be determined from
	 *             getExceptionCode() of the exception.
	 * @throws InvalidUserClassException
	 *             If the default user class specified for the given user does not exist in the system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/users", params = "op=create")
	@WebReturnType("xmlView")
	public UserInfoList createUsers(@WebSerializedParam("userinfolist") UserInfoList userInfoList, @RequestParam(value = "defaultuserclass", required=false, defaultValue = "Administrator") String defaultUserClassIdOrName) throws InvalidUserException,
			InvalidUserClassException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		return trusteeController.createUsers(userInfoList, defaultUserClassIdOrName);
	}

	/**
	 * Updates details for the existing user(s).Fields like name, firstName, lastName, phoneNumber, emailAddress, nativeUser, enabled and
	 * defaultUserClass are updatable.
	 * 
	 * @param userInfoList
	 *            {@link UserInfoList} object containing list of {@link UserInfo} objects.
	 * @return {@link UserInfoList} Object containing List of all successfully updated Users.
	 * @throws UserNotFoundException
	 *             In case the user with the given id/name does not exist in the system.
	 * @throws InvalidUserException
	 *             If there is any wrong information in the user DTO. The specific reason for the exception can be determined from
	 *             getExceptionCode() of the exception.
	 * @throws UserNotEditableException
	 *             If an attempt is made to update the Admin user.
	 * @throws UserClassNotFoundException
	 *             In case the userclass with given id/name doesn't exist.
	 * @throws InvalidLdapProfileException
	 *             In case of invalid ldap profile. The exception code will describe the exact cause of exception.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/users", params = "op=update")
	@WebReturnType("xmlView")
	public UserInfoList updateUsers(@WebSerializedParam("userinfolist") UserInfoList userInfoList) throws UserNotFoundException, InvalidUserException,
			UserNotEditableException, UserClassNotFoundException, InvalidLdapProfileException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		return trusteeController.updateUsers(userInfoList);
	}

	/**
	 * Enables/disables the platform logon for the given user<br>
	 * Boolean value as true would indicate platform logon for user is to be enabled & a false value would indicate that the platform logon
	 * is to be disabled for the given user.
	 * 
	 * @param userId
	 *            Id of the user for which platform logon is to be enabled/disabled.
	 * @param enabled
	 *            Boolean value indicating whether the platform logon is to be enabled/disabled.
	 * @throws TrusteeNotFoundException
	 *             In case no trustee with the given id exists.
	 * @throws UserNotEditableException
	 *             In case the trustee is Admin user, which is not an editable user.
	 * @throws InvalidUserException
	 *             In case the trustee is not a user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/users/{userIdOrName}", params = "op=setenabled")
	public void updateUserEnabled(@PathVariable String userIdOrName, @RequestParam("enabled") boolean enabled)
			throws TrusteeNotFoundException, UserNotEditableException, InvalidUserException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		trusteeController.updateUserEnabled(userIdOrName, enabled);
	}

	/**
	 * Deletes the user with given id/name. If the user is in use - e.g., if some assets are routed to this trustee - the trustee is marked
	 * for deletion but not permanently deleted. The client should reroute the assets before invoking this API.
	 * 
	 * @param userIdOrName
	 *            Id or name of the user to be deleted. Id is given preference over name.
	 * @throws UserNotFoundException
	 *             In case the user with the given id or name doesnot exist in the system.
	 * @throws UserInUseException
	 *             If an attempt is made to delete a user who is logged on to the server.
	 * @throws UserNotEditableException
	 *             If the user is system defined.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled Exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/users/{userIdOrName}", params = "op=delete")
	public void deleteUser(@PathVariable String userIdOrName) throws UserNotFoundException, UserInUseException, UserNotEditableException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteUsersGroups");
		trusteeController.deleteUser(userIdOrName);
	}
		
	// Api's related to Group get, create, update & delete.
	
	/**
	 * Returns all the groups existing in the system.
	 * 
	 * @return {@link GroupInfoList} object encapsulating list of
	 *         groups available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a
	 *             specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/groups")
	@WebReturnType("xmlView")
	public GroupInfoList getAllGroups() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return trusteeController.getAllGroups();
	}
		
	/**
	 * Gets the group details for a specified group.
	 * 
	 * @param groupIdOrName
	 *            Id or name of the group to be retrieved. Id is given preference over name.
	 * @return GroupInfoList containing details for the specified group.
	 * @throws GroupNotFoundException
	 *             In case the group with the given id/name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server Exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/groups/{groupIdOrName}")
	@WebReturnType("xmlView")
	public GroupInfoList getGroup(@PathVariable String groupIdOrName) throws GroupNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return trusteeController.getGroup(groupIdOrName);
	}
	
	/**
	 * Creates new Group(s). Atleast one object among ( {@link GroupInfo}, {@link GroupInfoList} ) is necessary.
	 * 
	 * @param groupInfoList
	 *            Object containing list of groups to be created.
	 * @return {@link GroupInfoList} List of all successfully created groups.
	 * @throws InvalidGroupException
	 *             if duplicate group name or group name is null.
	 * @throws UserNotFoundException
	 *             In case the user with given id/name doensot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/groups", params = "op=create")
	@WebReturnType("xmlView")
	public GroupInfoList createGroups(@WebSerializedParam("groupinfolist") GroupInfoList groupInfoList) throws InvalidGroupException,
			UserNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		return trusteeController.createGroups(groupInfoList);
	}

	/**
	 * It updates information for provided groups.
	 * 
	 * @param groupInfoList
	 *            {@link GroupInfoList} object containing information for multiple Groups.
	 * @return {@link GroupInfoList} List of all successfully updated groups.
	 * @throws InvalidGroupException
	 *             If duplicate group name or group name is null.
	 * @throws UserNotFoundException
	 *             if user trying to map with group is not available in system.
	 * @throws GroupNotFoundException
	 *             if group with given name or id is not available in system
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/groups", params = "op=update")
	@WebReturnType("xmlView")
	public GroupInfoList updateGroups(@WebSerializedParam("groupinfolist") GroupInfoList groupInfoList) throws UserPrivilegeException,
			GroupNotFoundException, UserNotFoundException, InvalidGroupException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		return trusteeController.updateGroups(groupInfoList);
	}
	
	/**
	 * Deletes the group with the given id/name from the system.
	 * 
	 * @param groupIdOrName
	 *            Id or name of the group to be deleted from the system.Id is given preference over name.
	 * @throws GroupNotFoundException
	 *             In case there is no group with given id/name.
	 * @throws TrusteeNotFoundException
	 *             If there is no trustee (user/group) with the given id or name.
	 * @throws UserInUseException
	 *             If an attempt is made to delete a user who is logged on to the server.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been throw.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/groups/{groupIdOrName}", params = "op=delete")
	public void deleteGroup(@PathVariable String groupIdOrName) throws GroupNotFoundException, TrusteeNotFoundException, UserInUseException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteUsersGroups");
		trusteeController.deleteGroup(groupIdOrName);
	}
	
	/**
	 * Get details of the trustee with the given name.
	 * 
	 * @param trusteeName
	 *            name of the trustee to be fetched
	 * @return {@link TrusteeInfo} object containing details of the required trustee
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/trustees/{trusteeName}")
	@WebReturnType("xmlView")
	public TrusteeInfo getTrustee(@PathVariable String trusteeName) throws QppServiceException{
		privilegeValidator.validateApplicationPrivileges("viewUsersGroups");
		return trusteeController.getTrustee(trusteeName);
	}
	
	/**
	 * Sets default role for the given trustee (User or Group);
	 * 
	 * @param trusteeIdOrName
	 *            id or name of the trustee whose role is to be set
	 * @param roleIdOrName
	 *            id or name of the role to be set.
	 * @param overrideUsersUserclass
	 *            This flag is applicable only if the trusteeId provided is that of group. If true, it will override the userclass of all
	 *            users belonging to the given group. If user belongs to other groups, in addition to this group, then also the userclass of
	 *            user will be overridden.
	 * @throws TrusteeNotFoundException
	 *             If the specified trustees do not exist. To get the additional information about which trustee does not exist, use
	 *             TrusteeNotFoundException.getAdditionalInfo().
	 * @throws UserNotEditableException
	 *             If the Admin user is being updated, then this exception will be thrown.
	 * @throws InvalidUserClassException
	 *             In case no role with the given id exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/trustees/{trusteeIdOrName}", params = "op=setrole")
	@WebReturnType("xmlView")
	public void updateTrusteeRole(@PathVariable String trusteeIdOrName,
			@RequestParam(value = "role", required = true) String roleIdOrName,
			@RequestParam(value = "overrideusersuserclass", required = false) boolean overrideUsersUserclass) throws TrusteeNotFoundException,
			UserNotEditableException, InvalidUserClassException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyUsersGroups");
		trusteeController.updateTrusteeRole(trusteeIdOrName, roleIdOrName, overrideUsersUserclass);
	}
	
	// Api's related to Storage get, create, update & delete.

	/**
	 * It gives information of all the repositories registered with the platform.
	 * 
	 * @return {@link StorageRepositoryInfoList} list of registered repositories.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/repositories")
	@WebReturnType("xmlView")
	public StorageRepositoryInfoList getAllRepositories() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewStorageRepositories");
		return storageController.getAllRepositories();
	}

	/**
	 * Returns a repository with the given Id or name. Id is given preference over name. The returned {@link StorageRepositoryInfo} consists of
	 * information like name, repositoryType id & name, connection properties & status id & name.
	 * 
	 * @param repositoryIdOrName
	 *            Id or name of the repository to be fetched.
	 * @return {@link StorageRepositoryInfo} object containing information about requested repository.
	 * @throws RepositoryNotFoundException
	 *             repository with given name or id is not available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/repositories/{repositoryIdOrName}")
	@WebReturnType("xmlView")
	public StorageRepositoryInfoList getRepository(@PathVariable String repositoryIdOrName) throws RepositoryNotFoundException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewStorageRepositories");
		return storageController.getRepository(repositoryIdOrName);
	}

	/**
	 * Creates new storage repository(s). Minimum fields required to create a storage repository are :
	 * <p>
	 * <li>name : display name of the storage repository.
	 * <li>connectionProperties : represents connection URL of the repository. For instance the connectionProperties can contain cdata
	 * like &lt;property name=&quot;url&quot; required=&quot;true&quot;&gt;C:\sample_ditavals&lt;/property&gt;
	 * <li>repositoryTypeId or repositoryType that refers to respository type name.
	 * </p>
	 * Fields like id & status are set by the platform server.
	 * In case of multiple repositories creation, if few repositories creation fail,then the list of successfully created repositories is retuned and
	 * exceptions are logged for the failed repositories.
	 * 
	 * @param storageRepositoryInfoList
	 *            list of storage repositories to create
	 * @return {@link StorageRepositoryInfo} object containing list of all successfully created repositories.
	 * @throws InvalidRepositoryException
	 *             if the repository with given repositoryName already exist or the connectionProperties supplied is not valid.
	 * @throws InvalidRepositoryTypeException
	 *             if provided repository type is invalid.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/repositories", params = "op=create")
	@WebReturnType("xmlView")
	public StorageRepositoryInfoList createRepositories(@WebSerializedParam("storagerepositoryinfolist") StorageRepositoryInfoList storageRepositoryInfoList)
			throws InvalidRepositoryException, InvalidRepositoryTypeException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyStorageRepositories");
		return storageController.createRepositories(storageRepositoryInfoList);
	}

	/**
	 * It updates information like name, connection properties and status of the storage repository(s).
	 * 
	 * @param storageRepositoryInfoList
	 *            List of the storage repositories to be updated.
	 * @return {@link StorageRepositoryInfoList} object containing list of all successfully updated repositories.
	 * @throws InvalidRepositoryTypeException
	 *             if repository type is invalid.
	 * @throws InvalidRepositoryException
	 *             if its a duplicate repository.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/repositories", params = "op=update")
	@WebReturnType("xmlView")
	public StorageRepositoryInfoList updateRepositories(@WebSerializedParam("storagerepositoryinfolist") StorageRepositoryInfoList storageRepositoryInfoList)
			throws InvalidRepositoryException, InvalidRepositoryTypeException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyStorageRepositories");
		return storageController.updateRepositories(storageRepositoryInfoList);
	}

	/**
	 * Deletes the specified repository.
	 * 
	 * @param repositoryIdOrName
	 *            Id or name of the repository to be deleted.
	 * @throws RepositoryNotFoundException
	 *             if repository with given name or id is not available in system.
	 * @throws RepositoryInUseException
	 *             if repository is currently in use.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/repositories/{repositoryIdOrName}", params = "op=delete")
	public void deleteRepository(@PathVariable String repositoryIdOrName) throws RepositoryNotFoundException, RepositoryInUseException,
			XPathExpressionException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteStorageRepositories");
		storageController.deleteRepository(repositoryIdOrName);
	}
		
	// Api's related to relation types get, create, update & delete.

	/**
	 * Returns definition of all the relation types defined in the system. Each returned relation type contains information like id, name,
	 * systemDefined flag, checkOutMandatory flag and relation-attribute mappings.
	 * 
	 * @return {@link RelationTypeInfoList} object containing information about all relation types.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server Exceptions
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/relationtypes")
	@WebReturnType("xmlView")
	public RelationTypeInfoList getAllRelationTypes() throws UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewRelations");
		return relationController.getAllRelationTypes();
	}
	
	/**
	 * Returns the definition of the relation type with the given id/name that includes its id, name, systemDefined flag, checkOutMandatory
	 * flag and its relation-attribute mappings.
	 * 
	 * @param relationTypeIdOrName
	 *            id or name of the relation type that is to be retrieved.
	 * @return RelationTypeInfoList containing definition of the relation type retrieved.
	 * @throws RelationTypeNotFoundException
	 *             In case the relation type with given id/name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server Exceptions
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/relationtypes/{relationTypeIdOrName}")
	@WebReturnType("xmlView")
	public RelationTypeInfoList getRelationType(@PathVariable String relationTypeIdOrName) throws UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewRelations");
		return relationController.getRelationType(relationTypeIdOrName);
	}

	/**
	 * Creates a new relation type with the defined name, checkOutManadatory boolean flag and list of relationtype-attribute mapping. The
	 * checkOutMandatory flag signifies whether it is mandatory to check out parent asset or not while creating/updating or deleting an
	 * asset relation of this type. Each relationType-attribute mapping contains attributeId/attribute name and valueMandatory flag to
	 * indicate whether the attribute value for this relation type is mandatory or not.The userMapped flag is overridden/set by server.
	 * 
	 * @param relationTypeInfoList
	 *            list of relationTypes to be created.
	 * @return {@link RelationTypeInfoList} list of successfully created relation types.
	 * @throws InvalidRelationTypeException
	 *             If the relation type name is null or there already exists a relation type with the same name then this exception is
	 *             thrown. Exact cause of the exception can be known from the exception code of the exception.
	 * @throws AttributeNotFoundException
	 *             If any of the attribute id's specified is invalid, then this exception is thrown. AdditionalInfo will refer to the
	 *             attribute id for which this exception has been thrown.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/relationtypes", params = "op=create")
	@WebReturnType("xmlView")
	public RelationTypeInfoList createRelationTypes(@WebSerializedParam("relationtypeinfolist") RelationTypeInfoList relationTypeInfoList)
			throws InvalidRelationTypeException, AttributeNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyRelations");
		return relationController.createRelationTypes(relationTypeInfoList);
	}
	
	/**
	 * It updates the name and relation type - attribute mapping. Only user defined relation types can be updated.
	 * 
	 * @param relationTypeInfoList
	 *            list of relation types to be updated.
	 * @return {@link RelationTypeInfoList} list of successfully updated relation types.
	 * @throws RelationTypeNotFoundException
	 *             In case the relation type with given id/name does not exist.
	 * @throws @link InvalidRelationTypeException In case of system defined relation type.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/relationtypes", params = "op=update")
	@WebReturnType("xmlView")
	public RelationTypeInfoList updateRelationTypes(@WebSerializedParam("relationtypeinfolist") RelationTypeInfoList relationTypeInfoList)
			throws RelationTypeNotFoundException, InvalidRelationTypeException, AttributeNotFoundException, UserPrivilegeException,
			QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyRelations");
		return relationController.updateRelationTypes(relationTypeInfoList);
	}

	/**
	 * Deletes a relation type with the given id or name from the system. Only user defined relation types can be deleted.
	 * 
	 * @param relationType
	 *            name or id of the relation type to be deleted.
	 * @throws RelationTypeNotFoundException
	 * 			In case the relation type with given id/name doesnot exist.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/relationtypes/{relationTypeIdOrName}", params = "op=delete")
	@WebReturnType("xmlView")
	public void deleteRelationType(@PathVariable String relationTypeIdOrName) throws RelationTypeNotFoundException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("deleteRelations");
		relationController.deleteRelationType(relationTypeIdOrName);
	}
		
  // Api's related to forms get, create, update & delete.
	
	/**
	 * Returns all forms saved in the system. Specify a valid workflow to get workflow forms. Specify a valid workflow & content type combination to get
	 * content type form. In case the workflow & content type are not mentioned, it will return all the forms saved in the system.
	 * 
	 * @param workflow
	 *            id or name of the workflow to get workflow forms.
	 * @param contentTypeIdOrPathOrName
	 *            id or path or name of the content type to get content type forms. 
	 * @return list of forms retrieved.
	 * @throws WorkflowNotFoundException
	 *             if workflow with given id/name is not available.
	 * @throws InvalidContentTypeException
	 *             if content type with given id/name is not available in system.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/forms")
	@WebReturnType("xmlView")
	public FormInfoList getAllForms(@RequestParam(value = "workflow", required = false) String workflow,
			@RequestParam(value = "contenttype", required = false) String contentTypeIdOrPathOrName) throws WorkflowNotFoundException,
			InvalidContentTypeException, UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("viewForms");
		FormInfoList contentTypeInfoList = new FormInfoList();
		if (workflow != null && contentTypeIdOrPathOrName == null) {
			contentTypeInfoList.getFormInfo().addAll(formController.getForms(workflow));
		} else if (contentTypeIdOrPathOrName != null) {
			FormInfo contentTypeFormInfo = formController.getContentTypeForm(contentTypeIdOrPathOrName, workflow);
			contentTypeInfoList.getFormInfo().add(contentTypeFormInfo);
		} else {
			contentTypeInfoList = formController.getAllForms();
		}
		return contentTypeInfoList;
	}

	/**
	 * Creates new forms with the given details. Minimum fields required to create a form are :<li>contentTypeId or contentTypeName : content type for which the form is to be created.</li> <li>
	 * workflowId or workflowName : optional for collection forms like {@link DefaultContentTypes#BOOK})</li>, <li>defaultView : if true
	 * implies the default view for all fields is to be considered. If false then the {@link FormAttributeList} is saved in the system.</li>
	 * , <li>formAttributeList : List of form attributes with position properties for each attribute. This list is considered in case the
	 * defaultView flag is false.</li>
	 * <p>
	 * The form ID is automatically generated by the server. If an ID is
	 * supplied, it is discarded and a new ID is generated.<br>
	 * </p>
	 * @param formInfoList
	 *            list of forms to be created.
	 * @return list of successfully created forms.
	 * @throws InvalidFormException
	 *             if content type or workflow for given form are not valid.
	 * @throws AttributeNotFoundException
	 *             if attribute with given name/id is not available
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/forms", params = "op=create")
	@WebReturnType("xmlView")
	public FormInfoList createForms(@WebSerializedParam("forminfolist") FormInfoList formInfoList) throws AttributeNotFoundException, InvalidFormException,
			UserPrivilegeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyForms");
		return formController.createForms(formInfoList);
	}

	/**
	 * Updates attributes of the form with given id. In case form id is not specified, workflow & content type combination will be used to
	 * fetch the form to be updated. Minimum fields required to set the form attributes are <li>defaultView : if true implies the default
	 * view for all fields is to be considered. If false then the {@link FormAttributeList} is saved in the system.</li>, <li>
	 * formAttributeList : List of form attributes with position properties for each attribute. This list is considered in case the
	 * defaultView flag is false.</li>
	 * 
	 * @param formInfoList
	 *            list of forms to be updated.
	 * @return list of successfully updated forms.
	 * @throws AttributeNotFoundException
	 *             In case an attribute with given name doesnot exist.
	 * @throws WorkflowNotFoundException
	 *             In case workflow with given name doesnot exist.
	 * @throws InvalidFormException
	 *             if invalid workflow/content type for given form.
	 * @throws InvalidContentTypeException
	 *             In case of an invalid content type.
	 * @throws UserPrivilegeException
	 *             This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will refer to the
	 *             disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/forms", params = "op=update")
	@WebReturnType("xmlView")
	public FormInfoList updateForms(@WebSerializedParam("forminfolist") FormInfoList formInfoList) throws AttributeNotFoundException,
			InvalidFormException, WorkflowNotFoundException, InvalidContentTypeException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyForms");
		return formController.updateForms(formInfoList);
	}
	
	/**
	 * Deletes the form for specified workflow & content type.
	 * 
	 * @param formId
	 * 			Id of the form to be deleted.
	 * @throws InvalidFormException
	 * 			In case of invalid form. The exception code will tell the exact cause of exception.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/forms", params = "op=delete")
	@WebReturnType("xmlView")
	public void deleteForm(@RequestParam(value = "workflow", required = false) String workflow,
			@RequestParam(value = "contenttype", required = false) String contenttype) throws InvalidFormException, QppServiceException {
		privilegeValidator.validateApplicationPrivileges("createModifyForms");
		formController.deleteForm(workflow, contenttype);
	}
	
	/*
	 * API's related to create, get, update & delete of preference definitions.
	 */

	/**
	 * Returns all the existing preference definitions. If the preference has possible values, then the PreferenceInfo object contains a
	 * list of all possible values along with the default value id and default value. If the preference has no possible values, then the
	 * possible values list is null, the default value id is invalid and only the default value should be considered.
	 * 
	 * @return {@link PreferenceInfoList} object containing list of all preferences defined.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/preferences")
	@WebReturnType("xmlView")
	public PreferenceInfoList getAllPreferences() throws QppServiceException {
		return preferenceController.getAllPreferences();
	}

	/**
	 * Gets preference details for the preference with the given id or unique name. The input will be assumed to be an id first, but if it
	 * leads to exception, then the input is assumed to be preference name. If the preference has possible values, then the PreferenceInfo
	 * object contains list of all possible values along with the default value id and default values. If the preference has no possible
	 * values, then the list is null; also, the default value id is invalid and only the default value should be considered.In case there
	 * exists multiple preferences with given name, then only one of the preference will be returned.
	 * 
	 * @param preferenceIdOrName
	 *            id or name of the preference to be fetched
	 * @return {@link PreferenceInfoList} object containing details of the requested preference.
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name doesn't exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/preferences/{preferenceIdOrName}")
	@WebReturnType("xmlView")
	public PreferenceInfoList getPreference(@PathVariable String preferenceIdOrName) throws PreferenceNotFoundException,
			QppServiceException {
		return preferenceController.getPreference(preferenceIdOrName);
	}

	/**
	 * Creates multiple preferences using the name, category, defaultValue & possibleValues fields of the each mentioned PreferenceInfo
	 * object. The possibleValues are considered only when the isPossibleValueExists flag is true & default value if mentioned will be
	 * assumed to be among the possibleValues.In case the defaultValue is not mentioned,then the first possible value is considered as the
	 * default value. If isPossibleValueExists flag is false, then only the defaultValue field is considered.
	 * 
	 * @param {@link PreferenceInfoList} object containing list of preferenceInfo objects to be created.
	 * @return {@link PreferenceInfoList} object containing list of all successfully created preference definitions.
	 * @throws InvalidPreferenceException
	 *             In case of invalid preference name/defaultValue/possibleValues this exception is thrown. The exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferences", params = "op=create")
	@WebReturnType("xmlView")
	public PreferenceInfoList createPreferences(@WebSerializedParam("preferenceinfolist") PreferenceInfoList preferenceInfoList)
			throws InvalidPreferenceException, QppServiceException {
		return preferenceController.createPreferences(preferenceInfoList);
	}

	/**
	 * Updates multiple preferences. A preference can be updated on the basis of id or name. In case the preference id is not mentioned, the
	 * preference will be updated on the basis of name. One can update name, isPossibleValueExists flag, possibleValues & defaultValue. But
	 * one cannot update the category. Only user defined preferences can be updated. It is mandatory to specify the preference id in case,
	 * the preference name is to be updated.
	 * 
	 * @param {@link preferenceInfoList} object containing list of PreferenceInfo's to be updated.
	 * @return {@link PreferenceInfoList} object containing list of all successfully updated preference definitions.
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name does not exist.
	 * @throws InvalidPreferenceException
	 *             In case of system defined preference or invalid preference name or invalid possible values this exception is thrown. The
	 *             exception code will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferences", params = "op=update")
	@WebReturnType("xmlView")
	public PreferenceInfoList updatePreferences(@WebSerializedParam("preferenceinfolist") PreferenceInfoList preferenceInfoList)
			throws PreferenceNotFoundException, InvalidPreferenceException, QppServiceException {
		return preferenceController.updatePreferences(preferenceInfoList);
	}
	
	/**
	 * Sets default values of the preferences. If the preference has possible
	 * values, then the valueId will be considered. Otherwise, only the value
	 * holds meaning and the value id is invalid. If any of the preference Ids
	 * provided are invalid then PreferenceNotFoundException is thrown. The
	 * additional info in the exception contains a comma separated ids of
	 * preferences that were invalid.
	 * 
	 * @param preferenceValueList
	 *            list of default preference values to be set.
	 * @throws PreferenceNotFoundException
	 *             If any or some preferences with the given id don't exist.
	 *             Additional info contains the invalid id(s).
	 * @throws InvalidPreferenceException
	 *             In case of invalid default value, this exception is thrown.
	 *             The exception code specifies the exact cause of the
	 *             exception.
	 * @throws QppServiceException
	 *             Unhandled Server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferences", params = "op=setdefaultvalues")
	@WebReturnType("xmlView")
	public void setDefaultPreferenceValues(@WebSerializedParam("preferencevaluelist") PreferenceValueList preferenceValueList) throws PreferenceNotFoundException,
			InvalidPreferenceException, QppServiceException {
		preferenceController.setDefaultPreferenceValues(preferenceValueList);
	}

	/**
	 * Deletes the preference definition with the given id or name. Only user defined preferences can be deleted.
	 * 
	 * @param preferenceIdOrName
	 *            id or name of the preference definition to be deleted.
	 * @throws PreferenceNotFoundException
	 *             In case the preference with the given id or name doesn't exist.
	 * @throws InvalidPreferenceException
	 *             In case the preference is system defined & can't be deleted.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferences/{preferenceIdOrName}", params = "op=delete")
	public void deletePreference(@PathVariable String preferenceIdOrName) throws PreferenceNotFoundException, InvalidPreferenceException,
			QppServiceException {
		preferenceController.deletePreference(preferenceIdOrName);
	}

	/*
	 * API's related to get & set of preference values for the logged-in user
	 */

	/**
	 * Returns the preference values corresponding to the logged-in user. If the preference has possible values, then both valueId and value
	 * would be present for each preference. Otherwise, only the value will be present and the value id would be invalid. Default value will
	 * be returned for those preferences for which the user has not set any value yet.
	 * 
	 * @param preferenceIdOrNames
	 *            Array of preference ids or names for which values are to be fetched.
	 * @return {@link PreferenceValuelist} object containing list of preference values requested.
	 * @throws PreferenceNotFoundException
	 *             In case preference with the given id or name doesn't exist.
	 * @throws InvalidPreferenceException
	 *             In case there exist multiple preferences with given name, then this exception will be thrown. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/preferencevalues")
	@WebReturnType("xmlView")
	public PreferenceValueList getPreferenceValues(@WebArrayParam("preferences") String[] preferenceIdOrNames)
			throws PreferenceNotFoundException, InvalidPreferenceException, QppServiceException {
		return preferenceController.getPreferenceValues(preferenceIdOrNames);
	}

	/**
	 * Set the preference values corresponding to the logged-in user. One may specify the preference id/name & the valueId or value to be
	 * set. The preferenceId is given first preference over preferenceName. In case the preferenceId is not mentioned, then the
	 * prefernceName is considered. Similarly for values, valueId is given first preference over value.
	 * 
	 * @param preferenceValuelist
	 *            list of preference values that is to be set for the logged-in user.
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name doesnot exist.
	 * @throws PreferenceValueNotFoundException
	 *             If the value that is to be set for the preference does not exist in the possible values for the preference.
	 * @throws InvalidPreferenceValueException
	 *             If null or empty string is sent for preferences that have no possible values.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferencevalues", params = "op=update")
	@WebReturnType("xmlView")
	public PreferenceValueList updatePreferenceValues(@WebSerializedParam("preferencevaluelist") PreferenceValueList preferenceValuelist)
			throws PreferenceNotFoundException, PreferenceValueNotFoundException, InvalidPreferenceValueException, QppServiceException {
		return preferenceController.updatePreferenceValues(preferenceValuelist);
	}
	
	/**
	 * Deletes values of given preferences for all users. This is applicable to
	 * preferences of category type {@link PreferenceConstants.Category#USER}.
	 * 
	 * @param userPreferenceIdsOrNames
	 *            Array of user preference id's or names whose values are to be
	 *            deleted for all users.
	 * @throws PreferenceNotFoundException
	 *             If any or some preferences with the given id don't exist.
	 *             Additional info contains the invalid id(s).
	 * @throws InvalidUserPreferenceException
	 *             If any or some of the preference ids provided are system
	 *             preferences. Additional info contains the ids that are system
	 *             preferences.
	 * @throws QppServiceException
	 *             Unhandled Server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preferencevalues", params = "op=resetallusersprefvalues")
	@WebReturnType("xmlView")
	public void resetAllUsersPreferenceValues(@WebArrayParam("preferences") String[] userPreferenceIdsOrNames) throws PreferenceNotFoundException, InvalidUserPreferenceException,
			QppServiceException {
		preferenceController.resetAllUsersPreferenceValues(userPreferenceIdsOrNames);
	}

	/*
	 * API's related to get & set of favorites
	 */

	/**
	 * Returns all favorite items of the logged-on user.
	 * 
	 * @return List of favorite items.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/favorites")
	@WebReturnType("xmlView")
	public FavoriteItemlist getFavorites() throws QppServiceException {
		return preferenceController.getFavorites();
	}

	/**
	 * Sets favorites items for the logged on users. It will delete all existing favorites and would replace them with the supplied favorite
	 * items. Position of the favorite items are not validated and set without validations. Thus, sending correct favorite items positions
	 * would be responsibility of the caller application.
	 * 
	 * @param favoriteItemlist
	 *            list of of favorite items to be set for logged on user.
	 * @throws InvalidFavoriteItemException
	 *             If favorite type of the favorite item specified is invalid.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/favorites", params = "op=setfavorites")
	@WebReturnType("xmlView")
	public void setFavorites(@WebSerializedParam("favoriteitemlist") FavoriteItemlist favoriteItemlist)
			throws InvalidFavoriteItemException, QppServiceException {
		preferenceController.setFavorites(favoriteItemlist);
	}

	/**
	 * Returns all privilege definitions in the system.
	 * 
	 * @param contenttype
	 *            boolean flag to filter out content type specific privileges. If set false, it will not return contenttype based
	 *            privileges. By default its value is true.
	 * @param application
	 *            boolean flag to filter out application specific privileges. if set false, it will not return application based
	 *            privileges. By default its value is true.
	 * @return PrivilegeDefinitionList containing list of all privilege definitions available in system.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/privileges")
	@WebReturnType("xmlView")
	public PrivilegeDefinitionList getAllPrivileges(
			@RequestParam(value = "contenttype", required = false, defaultValue = "true") boolean getContentTypePrivileges,
			@RequestParam(value = "application", required = false, defaultValue = "true") boolean getApplicationPrivileges)
			throws QppServiceException {
		return privilegeController.getAllPrivileges(getContentTypePrivileges, getApplicationPrivileges);
	}

	/**
	 * Returns specific privilege(s) in system with given id or name. If privilege name is specified and there exists multiple privileges,
	 * in different privilege groups, with the given name, list of all such privileges will be returned.
	 * 
	 * @return PrivilegeDefinitionList containing privilege definition(s) requested.
	 * @throws PrivilegeNotFoundException
	 *             If the privilege with the given privilege id or name doesn't exist. Additional info will refer to the privilege id/name
	 *             that doesn't exist.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/privileges/{privilegeIdOrName}")
	@WebReturnType("xmlView")
	public PrivilegeDefinitionList getPrivilege(@PathVariable String privilegeIdOrName) throws PrivilegeNotFoundException,
			QppServiceException {
		return privilegeController.getPrivilege(privilegeIdOrName);
	}

	/**
	 * Creates the required privilege definitions. Set the {@link PrivilegeDefinition#isContentPrivilege()} flag to true for a content based
	 * privilege definition and for application based privilege, set the flag to false. If the privilege is status based, the statusBased
	 * flag in privilege definition should be set true.
	 * <p>
	 * If the privilege being created is that of content based, there should be at least one contentType supplied.
	 * <p>
	 * Id and SystemDefined flag will be automatically overridden/set by the server.
	 * 
	 * @param privilegeDefinitionList
	 *            {@link PrivilegeDefinitionList} object containing list of all privileges to be created along with information to be set
	 *            for privilege definitions.
	 * @return PrivilegeDefinitionList containing information of all successfully created privileges definition. See server logs for failed
	 *         cases.
	 * @throws PrivilegeGroupNotFoundException
	 *             If the parent privilege group id of the privilege is not valid.
	 * @throws InvalidContentTypeException
	 *             While creating a content based privilege if content types specified in the privilege is null/size zero or if one(or more)
	 *             of the content types specified is not valid then this exception is thrown. Additional info will refer to the content id
	 *             for which this exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privileges", params = "op=create")
	@WebReturnType("xmlView")
	public PrivilegeDefinitionList createPrivileges(
			@WebSerializedParam("privilegedefinitionlist") PrivilegeDefinitionList privilegeDefinitionList)
			throws InvalidContentTypeException, PrivilegeGroupNotFoundException, QppServiceException {
		return privilegeController.createPrivileges(privilegeDefinitionList);
	}

	/**
	 * Updates the given set of privileges based on their id or name specified. Updates the privilege name and mapped content types for the
	 * given privileges definition. In order to rename the privilege, correct privilege Id should be specified in the definition. It will
	 * not change the privilege from application specific to content type specific and vice versa. It will not change the privilege from
	 * status based to non status based and vice versa.
	 * 
	 * @param privilegeDefinitionList
	 *            {@link PrivilegeDefinitionList} object containing list of all privileges to be updated along with information to be set
	 *            for privilege definitions.
	 * @return PrivilegeDefinitionList containing information of all successfully updated privileges definition. See server logs for failed
	 *         cases.
	 * @throws InvalidContentTypeException
	 *             While creating a content based privilege if content types specified in the privilege is null/size zero or if one(or more)
	 *             of the content types specified is not valid then this exception is thrown. Additional info will refer to the content id
	 *             for which this exception has been thrown.
	 * @throws PrivilegeGroupNotFoundException
	 *             If the parent privilege group id of the privilege is not valid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privileges", params = "op=update")
	@WebReturnType("xmlView")
	public PrivilegeDefinitionList updatePrivileges(
			@WebSerializedParam("privilegedefinitionlist") PrivilegeDefinitionList privilegeDefinitionList)
			throws InvalidContentTypeException, PrivilegeGroupNotFoundException, QppServiceException {
		return privilegeController.updatePrivileges(privilegeDefinitionList);
	}

	/**
	 * Deletes the given privilege from the system based on its name or id provided.
	 * 
	 * @param privilegeIdOrName
	 *            id or name of the privilege to be deleted.
	 * @throws PrivilegeNotFoundException
	 *             if the privilege definition id supplied is not valid.
	 * @throws InvalidPrivilegeException
	 *             if the id supplied is that of system defined privilege.
	 * @throws QppServiceException
	 *             Unhandled server exception. *
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privileges/{privilegeIdOrName}", params = "op=delete")
	public void deletePrivilege(@PathVariable String privilegeIdOrName) throws PrivilegeNotFoundException, InvalidPrivilegeException,
			QppServiceException {
		privilegeController.deletePrivilege(privilegeIdOrName);
	}

	/**
	 * Returns all existing privilege group definitions. Each privilege group contains its information along with its privileges and
	 * sub-privilege group definitions.
	 * 
	 * @return PrivilegeGroupDefinitionList containing list of all privilege group definitions available in system.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/privilegegroups")
	@WebReturnType("xmlView")
	public PrivilegeGroupDefinitionList getAllPrivilegeGroups() throws QppServiceException {
		return privilegeController.getAllPrivilegeGroups();
	}

	/**
	 * Returns information for the specified privilege group based on its id or name specified. A Privilege group contains its information
	 * along with its privileges and sub-privilege group definitions.
	 * 
	 * @param privilegeGroupIdOrName
	 *            name or id or privilege group.
	 * @return PrivilegeGroupDefinitionList containing list of privilege group definitions for given name or id.
	 * @throws PrivilegeGroupNotFoundException
	 *             If the specified group id or name does not exist. Additional info will return the privilege group id that doesn't exist
	 *             and has thrown this exception.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/privilegegroups/{privilegeGroupIdOrName}")
	@WebReturnType("xmlView")
	public PrivilegeGroupDefinitionList getPrivilegeGroup(@PathVariable String privilegeGroupIdOrName)
			throws PrivilegeGroupNotFoundException, QppServiceException {
		return privilegeController.getPrivilegeGroup(privilegeGroupIdOrName);
	}

	/**
	 * Creates new privilege group along with its subgroups and privileges in the specified hierarchy. Privilege group at root level can be
	 * created by setting its parent group id to -1.
	 * 
	 * @param privilegeGroupDefinitionList
	 *            Containing information of all successfully created privilege groups along with its sub-groups and privileges created. See
	 *            server logs for failed cases.
	 * @return list of all successfully created privilegeGroups.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privilegegroups", params = "op=create")
	@WebReturnType("xmlView")
	public PrivilegeGroupDefinitionList createPrivilegeGroups(
			@WebSerializedParam("privilegegroupdefinitionlist") PrivilegeGroupDefinitionList privilegeGroupDefinitionList)
			throws QppServiceException {
		return privilegeController.createPrivilegeGroups(privilegeGroupDefinitionList);
	}

	/**
	 * Updates the given privilege group. Privilege group with the given ID or Name(& parent group) will be updated. This will create,
	 * update and delete all provided sub-groups and privileges in the specified hierarchy.
	 * 
	 * 
	 * @param privilegeGroupDefinitionList
	 *            Containing information of the privilege group along with its sub-groups and privileges to be updated.
	 * @return PrivilegeGroupDefinitionList containing updated information of the successfully updated privilege groups along with its sub
	 *         groups and privileges. See server logs for failed cases.
	 * @throws InvalidPrivilegeGroupException
	 *             Thrown when an incorrect id of privilege group is specified.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privilegegroups", params = "op=update")
	@WebReturnType("xmlView")
	public PrivilegeGroupDefinitionList updatePrivilegeGroups(
			@WebSerializedParam("privilegegroupdefinitionlist") PrivilegeGroupDefinitionList privilegeGroupDefinitionList)
			throws InvalidPrivilegeGroupException, QppServiceException {
		return privilegeController.updatePrivilegeGroups(privilegeGroupDefinitionList);
	}

	/**
	 * Deletes privilege group from system with given id or name.
	 * 
	 * @param privilegeGroupIdOrName
	 *            id or name of privilege group to be deleted
	 * @throws PrivilegeGroupNotFoundException
	 *             if privilege group not found in system.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/privilegegroups/{privilegeGroupIdOrName}", params = "op=delete")
	public void deletePrivilegeGroup(@PathVariable String privilegeGroupIdOrName) throws PrivilegeGroupNotFoundException,
			QppServiceException {
		privilegeController.deletePrivilegeGroup(privilegeGroupIdOrName);
	}

	/**
	 * Returns list of all the users along with their redlining colors.
	 * 
	 * @return RedlineInfoList containing list of all redlining definitions for
	 *         all users in system.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/redline")
	@WebReturnType("xmlView")
	public RedlineInfoList getAllUserRedliningColor() throws QppServiceException {
		return workflowController.getAllUserRedliningColor();
	}
	
	/**
	 * Returns the defined redlining color for the given user.
	 * 
	 * @param user
	 *            Id or name of the user for whom redlining color is required.
	 * @return RedlineInfoList containing redlining definitions for requested
	 *         users.
	 * @throws QppServiceException
	 *             Unhandled Server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/redline", params = "user")
	@WebReturnType("xmlView")
	public RedlineInfoList getUserRedliningColor(@RequestParam(value = "user", required = true) String user) throws QppServiceException {
		return workflowController.getUserRedliningColor(user);
	}

	/**
	 * Updates the redlining color for the given user(s).
	 * 
	 * @param redlineInfoList
	 *            list of all redlining color dto having information for the
	 *            user and there redlining color.
	 * @return RedlineInfoList containing successfully updated redlining
	 *         definitions. See logs for failed cases.
	 * @throws InvalidUserColorException
	 *             If the redlining color object is either null or contains
	 *             invalid data.
	 * @throws UserNotFoundException
	 *             If the user does not exist.
	 * @throws InvalidColorException
	 *             If the color value does not lie in the permissible range of 0
	 *             to 255.
	 * @throws QppServiceException
	 *             Unhandled Server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/redline", params = "op=update")
	@WebReturnType("xmlView")
	public RedlineInfoList updateUserRedliningColor(@WebSerializedParam("redlineinfolist") RedlineInfoList redlineInfoList) throws InvalidUserColorException, UserNotFoundException, InvalidColorException, QppServiceException {
		return workflowController.updateUserRedliningColor(redlineInfoList);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods of this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	/**
	 * Moves a set of domain values to some other location in the hierarchy. 
	 * 
	 * <p>
	 * After successful update of domain values, message <code>DOMAIN_CHANGED</code> is published.
	 * </p>
	 * 
	 * @param domainIdOrName
	 *            Id or name of the domain whose values are to be moved.
	 * @param sourcedomainvalues
	 *            Set of Domain value ids, hierarchies or names which are to be moved.
	 *            In case of hierarchical domains, if only domain name is provided and there are multiple domain values with same name,
	 *            then the first domain value encountered with that name will be moved to the target location.
	 * @param targetparentvalue
	 * 			  Id, hierarchy or name of the target-parent domain value under which required values are to be moved.
	 *  		  If source domain values are to be moved at root, then provide either 0 or -1 as target parent domain value.
	 * @param startposition
	 * 			  Position at which source domain values are to be moved.
	 * 			  To move the source domain values at the beginning under the target parent value, specify the startposition as 1. 
	 *			  If start position is specified, the source domain values will be moved at that position in given order.
	 *			  If start position is not specified or is an invalid value, source domain values will be moved at the last position in the given order.
	 * @return Target-parent domain value. If target parent is root, then all domain values present at the root are returned.
	 * @throws DomainNotFoundException
	 *             If no domain with given name or id exists.
	 * @throws InvalidDomainException
	 *             If the given domain is a system-defined domain and not user modifiable.
	 *             If Domain Id or its name is not provided.
	 *             If domain is non-hierarchical and targetparentvalue is specified.
	 * @throws DomainValueNotFoundException
	 *             In case there doesn't exist a domain value with the given target parent value id, name or hierarchy  for hierarchical domains and
	 *             in case there doesn't exist a domain value with the given source domain value ids, names or hierarchies.
	 * @throws InvalidDomainValueException
	 *             If there already exists a domain value with the same name as sourcedomainvalues among children of targetparentvalue.
	 *             If targetparentvalue is one of the sourcedomainvalues or a descendant of any of the sourcedomainvalues.
	 *             If domain values to be moved contain more than one value with same name.
	 *             If set of sourcedomainvalues is null or empty or if targetparentvalue is null for hierarchical domains.
	 *             If the set of sourcedomainvalues contains both a domain value as well as any of its descendants, 
	 *             because a domain value and its descendants can't be moved simultaneously.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/domains/{domainIdOrName}", params = "op=move")
	@WebReturnType("xmlView")
	public DomainValueList moveDomainValues(@PathVariable(value = "domainIdOrName") String domainIdOrName,
		@RequestParam(value = "targetparentvalue", required = false) String targetparentvalue,
		@WebArrayParam(value = "sourcedomainvalues") String[] sourcedomainvalues,
		@RequestParam(value = "startposition", required = false) Integer startposition) throws DomainNotFoundException, 
		InvalidDomainException, DomainValueNotFoundException, InvalidDomainValueException, QppServiceException {			
			return attributeDomainController.moveDomainValues(domainIdOrName,  targetparentvalue, sourcedomainvalues, (startposition == null ? -1 : startposition));
	}
	
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.utility;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.Map.Entry;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.common.utility.Encryptor;

public class CommonUtility {
	/**
	 * Encryptes the plain text password and convert it to a byte array.
	 * 
	 * @param password
	 * @return Encrypted password
	 */
	public static byte[] getEncryptedPassword(String password) {
		byte[] encryptedPassword = null;
		try {
			encryptedPassword = Encryptor.encrypt(password);
		} catch (Exception e) {
			System.out.println("Exception = " + e.getStackTrace());
		}
		return encryptedPassword;
	}

	/**
	 * Gets the timezone of the machine in the format +/-HH:mm
	 */
	public static String getTimeZoneOffset() {
		TimeZone currentTimeZone = TimeZone.getDefault();
		int offset = currentTimeZone.getRawOffset()
				+ TimeZone.getDefault().getDSTSavings();
		String offsetSign = null;
		if (offset > 0) {
			offsetSign = "+";
		} else {
			offsetSign = "-";
		}
		offset = Math.abs(offset);

		// Offset in seconds
		offset /= 60000;
		int offsetInHours = offset / 60;
		int offsetInMinutes = offset % 60;
		StringWriter stringWriter = new StringWriter();
		PrintWriter printWriter = new PrintWriter(stringWriter);
		printWriter.printf(offsetSign + "%02d:%02d", offsetInHours,
				offsetInMinutes);
		return stringWriter.toString();
	}
	
	public static <T, E> T getKeyForValue(Map<T, E> map, E value) throws QppServiceException {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (value.equals(entry.getValue())) {
	            return entry.getKey();
	        }
	    }
		throw new QppServiceException("Invalid value " + value);
	}
	
	/** 
	 * Returns true if given string is completly numeric.
	 * @param value
	 * @return
	 */
	public static boolean isNumeric(String value) {
		try {
			Long.parseLong(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	public static long[] getLongArray(List<Long> arrayList) {
		int size = arrayList == null ? 0 : arrayList.size();
		long[] array = new long[size];
		for (int i = 0; i < size; i++) {
			array[i] = (Long) arrayList.get(i);
		}
		return array;
	}
}

/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidUserClassException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.relation.service.dto.RelationType;
import com.quark.qpp.core.relation.service.local.RelationService;
import com.quark.qpp.core.security.service.dto.Group;
import com.quark.qpp.core.security.service.dto.Trustee;
import com.quark.qpp.core.security.service.dto.User;
import com.quark.qpp.core.security.service.exceptions.GroupNotFoundException;
import com.quark.qpp.core.security.service.exceptions.InvalidGroupException;
import com.quark.qpp.core.security.service.exceptions.InvalidUserException;
import com.quark.qpp.core.security.service.exceptions.SecurityServiceExceptionCodes.InvalidGroupExceptionCodes;
import com.quark.qpp.core.security.service.exceptions.SecurityServiceExceptionCodes.InvalidUserExceptionCodes;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserInUseException;
import com.quark.qpp.core.security.service.exceptions.UserNotEditableException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.userprovisioning.service.dto.LdapSearchCriteria;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapQueryDefinitionException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapSearchCriteriaException;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserSourceAccessException;
import com.quark.qpp.core.userprovisioning.service.local.UserProvisioningService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.CommonUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.ApplicationPrivList;
import com.quark.qpp.service.xmlBinding.ContentTypePriv;
import com.quark.qpp.service.xmlBinding.GroupInfo;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.Privilege;
import com.quark.qpp.service.xmlBinding.RelationTypeInfoList;
import com.quark.qpp.service.xmlBinding.TrusteeInfo;
import com.quark.qpp.service.xmlBinding.UserInfo;
import com.quark.qpp.service.xmlBinding.UserInfoList;

public class TrusteeController {

	@Autowired
	private RelationService relationService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private TrusteeService trusteeService;

	@Autowired
	private UserProvisioningService userProvisioningService;

	@Autowired
	private FacadeUtility facadeUtility;

	private final Logger logger = Logger.getLogger(this.getClass());

	public UserInfoList getAllUsers() throws UserClassNotFoundException, QppServiceException {
		User[] users = trusteeService.getAllUsers();
		return objectTransformer.transform(users);
	}

	public UserInfoList getUser(String userName) throws UserNotFoundException, QppServiceException {
		long userId = facadeUtility.getUserId(userName);
		User user = trusteeService.getUser(userId);
		UserInfo userInfo = objectTransformer.transform(user);
		UserInfoList userInfoList = new UserInfoList();
		userInfoList.getUserInfo().add(userInfo);
		return userInfoList;
	}

	public UserInfoList createUsers(UserInfoList userInfoList, String defaultUserClassIdOrName) throws InvalidUserException, InvalidUserClassException,
			QppServiceException {
		UserInfoList newUserInfoList = new UserInfoList();
		long defaultUserClassId = -1;
		try {
			defaultUserClassId = facadeUtility.getUserClassId(defaultUserClassIdOrName);
		} catch (QppServiceException e) {
			logger.error("Error while fetching the default userclass id for : "+defaultUserClassIdOrName +" in create users operation.", e);
		}
		if (userInfoList != null) {
			Iterator<UserInfo> iterator = userInfoList.getUserInfo().iterator();
			while (iterator.hasNext()) {
				UserInfo usrInfo = iterator.next();
				try {
					UserInfo newUserInfo = createUser(usrInfo, defaultUserClassId);
					if (newUserInfo != null) {
						newUserInfoList.getUserInfo().add(newUserInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while creating user with name " + usrInfo.getName(), e);
					if (userInfoList.getUserInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidUserException(InvalidUserExceptionCodes.USER_NOT_FOUND);
		}
		return newUserInfoList;
	}

	private UserInfo createUser(UserInfo userInfo, long defaultUserClassId) throws InvalidUserException, InvalidUserClassException, QppServiceException {
		User user = objectTransformer.transform(userInfo);
		if(user.getDefaultUserClassId() == 0){
			user.setDefaultUserClassId(defaultUserClassId);
		}
		long newUserId = trusteeService.createUser(user, CommonUtility.getEncryptedPassword(""));
		User newUser = trusteeService.getUser(newUserId);
		return objectTransformer.transform(newUser);
	}

	public UserInfoList updateUsers(UserInfoList userInfoList) throws UserNotFoundException, InvalidUserException,
			UserNotEditableException, QppServiceException {
		UserInfoList updatedUserInfoList = new UserInfoList();
		if (userInfoList != null) {
			Iterator<UserInfo> iterator = userInfoList.getUserInfo().iterator();
			while (iterator.hasNext()) {
				UserInfo usrInfo = iterator.next();
				try {
					UserInfo updatedUserInfo = updateUser(usrInfo);
					if (updatedUserInfo != null) {
						updatedUserInfoList.getUserInfo().add(updatedUserInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while updating user with name " + usrInfo.getName(), e);
					if (userInfoList.getUserInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidUserException(InvalidUserExceptionCodes.USER_NOT_FOUND);
		}
		return updatedUserInfoList;
	}

	private UserInfo updateUser(UserInfo userInfo) throws UserNotFoundException, InvalidUserException, UserNotEditableException,
			UserClassNotFoundException, InvalidLdapProfileException, QppServiceException {
		User user = objectTransformer.transform(userInfo);
		if (user.getId() <= 0) {
			long userId = trusteeService.getUserId(user.getName());
			user.setId(userId);
		}
		trusteeService.updateUser(user);
		User updatedUser = trusteeService.getUser(user.getId());
		return objectTransformer.transform(updatedUser);
	}

	public void deleteUser(String user) throws UserNotFoundException, TrusteeNotFoundException, UserNotEditableException,
			UserInUseException, QppServiceException {
		long id = facadeUtility.getUserId(user);
		trusteeService.deleteTrustee(id);
	}

	public GroupInfoList getGroup(String groupName) throws GroupNotFoundException, TrusteeNotFoundException, QppServiceException {
		/** returns the id of groupname */
		long groupId = facadeUtility.getGroupId(groupName);
		Group grp = trusteeService.getGroup(groupId);
		GroupInfo groupInfo = objectTransformer.transform(grp, true/*getDetailedInfo*/);
		GroupInfoList groupInfoList = new GroupInfoList();
		groupInfoList.getGroupInfo().add(groupInfo);
		return groupInfoList;
	}

	public GroupInfoList getAllGroups() throws TrusteeNotFoundException, QppServiceException {
		com.quark.qpp.core.security.service.dto.GroupInfo[] groups = trusteeService.getAllGroups();
		return objectTransformer.transform(groups, true/*getDetailedInfo*/);
	}

	public GroupInfoList createGroups(GroupInfoList groupInfoList) throws InvalidGroupException,
			UserNotFoundException, TrusteeNotFoundException, QppServiceException {
		GroupInfoList newGroupInfoList = new GroupInfoList();
		if (groupInfoList != null) {
			Iterator<GroupInfo> iterator = groupInfoList.getGroupInfo().iterator();
			while (iterator.hasNext()) {
				GroupInfo grpInfo = iterator.next();
				try {
					GroupInfo newGroupInfo = createGroup(grpInfo);
					if (newGroupInfo != null) {
						newGroupInfoList.getGroupInfo().add(newGroupInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while creating group with name " + grpInfo.getName(), e);
					if (groupInfoList.getGroupInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidGroupException(InvalidGroupExceptionCodes.GROUP_NOT_FOUND);
		}
		return newGroupInfoList;
	}

	private GroupInfo createGroup(GroupInfo groupInfo) throws InvalidGroupException, UserNotFoundException, TrusteeNotFoundException,
			QppServiceException {
		/** Updation of user ids is done in transform method. */
		Group group = objectTransformer.transform(groupInfo);
		long newGroupId = trusteeService.createGroup(group);
		Group newGroup = trusteeService.getGroup(newGroupId);
		return objectTransformer.transform(newGroup, true/*getDetailedInfo*/);
	}

	public GroupInfoList updateGroups(GroupInfoList groupInfoList) throws GroupNotFoundException,
			UserNotFoundException, InvalidGroupException, QppServiceException {
		GroupInfoList updatedGroupInfoList = new GroupInfoList();
		if (groupInfoList != null) {
			Iterator<GroupInfo> iterator = groupInfoList.getGroupInfo().iterator();
			while (iterator.hasNext()) {
				GroupInfo grpInfo = iterator.next();
				try {
					GroupInfo updatedGroupInfo = updateGroup(grpInfo);
					if (updatedGroupInfo != null) {
						updatedGroupInfoList.getGroupInfo().add(updatedGroupInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while updating group with name " + grpInfo.getName(), e);
					if (groupInfoList.getGroupInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidGroupException(InvalidGroupExceptionCodes.GROUP_NOT_FOUND);
		}
		return updatedGroupInfoList;
	}

	private GroupInfo updateGroup(GroupInfo groupInfo) throws GroupNotFoundException, UserNotFoundException, InvalidGroupException,
			QppServiceException {
		Group group = objectTransformer.transform(groupInfo);
		long groupId = -1;
		if (groupInfo.getId() == null || groupInfo.getId() <= 0) {
			groupId = trusteeService.getGroupId(groupInfo.getName());
		} else {
			groupId = groupInfo.getId();
		}
		group.setId(groupId);
		trusteeService.updateGroup(group);

		Group updatedGroup = trusteeService.getGroup(groupId);
		return objectTransformer.transform(updatedGroup, true/*getDetailedInfo*/);
	}

	public void deleteGroup(String group) throws GroupNotFoundException, TrusteeNotFoundException, UserNotEditableException,
			UserInUseException, QppServiceException {
		long groupId = facadeUtility.getGroupId(group);
		trusteeService.deleteTrustee(groupId);
	}

	public TrusteeInfo getTrustee(String trusteeName) throws QppServiceException {
		long trusteeId = trusteeService.getTrusteeId(trusteeName);
		Trustee trustee = trusteeService.getTrustee(trusteeId);
		return objectTransformer.transform(trustee);
	}

	public UserInfoList importUsersFromLdap(String savedLdapQueryNameOrId, String ldapProfileNameOrId, String baseString,
			String searchFilter, String defaultUserClass, int pageSize) throws InvalidLdapProfileException,
			InvalidLdapSearchCriteriaException, InvalidLdapQueryDefinitionException, QppServiceException {
		long usersIteratorId = -1;
		if (savedLdapQueryNameOrId != null && !savedLdapQueryNameOrId.isEmpty()) {
			long ldapQueryDefId = facadeUtility.getLdapQueryDefId(savedLdapQueryNameOrId);
			usersIteratorId = userProvisioningService.openIteratorForQueryId(pageSize, ldapQueryDefId );
		} else if (ldapProfileNameOrId != null && !ldapProfileNameOrId.isEmpty()) {
			long ldapProfileId = facadeUtility.getLdapProfileId(ldapProfileNameOrId);
			LdapSearchCriteria ldapSearchCriteria = new LdapSearchCriteria();
			ldapSearchCriteria.setBaseString(baseString);
			ldapSearchCriteria.setLdapProfileId(ldapProfileId);
			ldapSearchCriteria.setSearchFilter(searchFilter);
			usersIteratorId = userProvisioningService.openIteratorForLdapSearchCriteria(pageSize, ldapSearchCriteria);
		} else {
			throw new InvalidLdapProfileException();
		}
		if (usersIteratorId > 0) {
			try {
				return createUsersFromIterator(usersIteratorId, defaultUserClass);
			} finally {
				userProvisioningService.closeIterator(usersIteratorId);
			}
		}
		return null;
	}

	private UserInfoList createUsersFromIterator(long iteratorId, String defaultUserClass) throws InvalidLdapSearchCriteriaException,
			UserSourceAccessException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(defaultUserClass);
		User[] ldapUsers = null;//userProvisioningService.getNextUsers(iteratorId);
		ArrayList<User> ldapUsersToBeImported = new ArrayList<User>();
		for (int i = 0; ldapUsers != null && i < ldapUsers.length; i++) {
			try {
				trusteeService.getUserId(ldapUsers[i].getName());
				logger.warn("User with given name alreday exist. " + ldapUsers[i].getName());
			} catch (UserNotFoundException e) {
				ldapUsersToBeImported.add(ldapUsers[i]);
			}
		}
		User[] usersImported = new User[ldapUsersToBeImported.size()];
		for (int i = 0; ldapUsersToBeImported != null && i < ldapUsersToBeImported.size(); i++) {
			User userToBeImported = ldapUsersToBeImported.get(i);
			userToBeImported.setDefaultUserClassId(userClassId);
			long userId = trusteeService.createUser(userToBeImported, CommonUtility.getEncryptedPassword(""));
			User userinfo = trusteeService.getUser(userId);
			usersImported[i] = userinfo;
		}
		return objectTransformer.transform(usersImported);
	}

	public RelationTypeInfoList getAllRelationTypes() throws QppServiceException {
		RelationType[] relationTypes = relationService.getAllRelationTypes();
		return objectTransformer.transform(relationTypes);
	}

	public UserInfoList getUsersWithRole(String userClass) throws QppServiceException {
		long userClassId = facadeUtility.getUserClassId(userClass);
		User[] allUsers = trusteeService.getAllUsers();
		List<User> usersList = new ArrayList<User>();
		for (User user : allUsers) {
			if (user.getDefaultUserClassId() == userClassId) {
				usersList.add(user);
			}
		}
		return objectTransformer.transform(usersList.toArray(new User[0]));
	}

	public void updateTrusteeRole(String trusteeIdOrName, String roleIdOrName, boolean overrideUsersUserclass)
			throws TrusteeNotFoundException, InvalidUserClassException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(roleIdOrName);
		long[] trusteeIds = facadeUtility.getTrusteeIds(new String[]{trusteeIdOrName});
		long trusteeID = 0;
		if (trusteeIds != null && trusteeIds.length > 0) {
			trusteeID = trusteeIds[0];
		}
		trusteeService.updateTrusteeUserClass(trusteeID, userClassId, overrideUsersUserclass);
	}

	public void updateUserEnabled(String userIdOrName, boolean enabled) throws UserNotFoundException, QppServiceException {
		long userId = facadeUtility.getUserId(userIdOrName);
		trusteeService.updateUserEnabled(userId, enabled);
	}
	
	public ApplicationPrivList getApplicableApplicationPrivileges(String[] privilegeIds) throws QppServiceException {
		long[] allEnabledPrivIds = null;
		if (privilegeIds != null && privilegeIds.length > 0) {
			long[] givenPrivilegeIds = facadeUtility.getPrivilegeIds(privilegeIds);
			allEnabledPrivIds = trusteeService.getApplicableApplicationPrivileges(givenPrivilegeIds);
		} else {
			allEnabledPrivIds = trusteeService.getAllApplicableApplicationPrivileges();
		}
		ApplicationPrivList applicationPrivList = new ApplicationPrivList();
		Privilege[] enabledPrivileges = objectTransformer.transform(allEnabledPrivIds);
		applicationPrivList.getPrivilege().addAll(Arrays.asList(enabledPrivileges));
		return applicationPrivList;
	}

	public ContentTypePriv getApplicableContentPrivileges(String contentTypeIdOrNameOrHierarchy, String[] privilegeIdsOrNames) throws InvalidContentTypeException, QppServiceException {
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrNameOrHierarchy);
		long[] enabledPrivIds = null;
		if(privilegeIdsOrNames != null && privilegeIdsOrNames.length > 0){
			long[] privIds = facadeUtility.getPrivilegeIds(privilegeIdsOrNames);
			enabledPrivIds = trusteeService.getApplicableContentPrivileges(contentTypeId, privIds);
		}else{
			enabledPrivIds = trusteeService.getAllApplicableContentPrivileges(contentTypeId);
		}
		ContentTypePriv contentTypePriv = new ContentTypePriv();
		Privilege[] enabledPrivileges = objectTransformer.transform(enabledPrivIds);
		contentTypePriv.getPrivilege().addAll(Arrays.asList(enabledPrivileges));
		return contentTypePriv;
	}
	
	public void synchronizeLdapUsersGroupsBasedOnProfile(String profileIdOrName) throws QppServiceException {
		long ldapProfileId = facadeUtility.getLdapProfileId(profileIdOrName);
		trusteeService.synchronizeLdapUsersGroupsBasedOnProfile(ldapProfileId);
	}

	public void synchronizeLdapUsersGroups() throws QppServiceException {
		trusteeService.synchronizeLdapUsersGroups();
	}

	public GroupInfoList getUserGroups(String userIdOrName) throws UserNotFoundException, QppServiceException {
		long userId = facadeUtility.getUserId(userIdOrName);
		com.quark.qpp.core.security.service.dto.GroupInfo[] groupInfos = trusteeService.getUserGroups(userId);
		return objectTransformer.transform(groupInfos, false);
	}
}

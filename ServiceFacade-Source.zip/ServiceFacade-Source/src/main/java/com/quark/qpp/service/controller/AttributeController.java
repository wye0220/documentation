/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.DomainValueListPreferences;
import com.quark.qpp.core.attribute.service.dto.DomainValuePreferences;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidAttributeExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AttributeInfo;
import com.quark.qpp.service.xmlBinding.AttributeInfoList;

public class AttributeController {

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private FacadeUtility facadeUtility;

	private final Logger logger = Logger.getLogger(this.getClass());

	public AttributeInfoList getAllAttributes(String contentTypeIdOrPathOrName, boolean includeSubContentTypes) throws DomainNotFoundException,
			InvalidContentTypeException, QppServiceException {
		Attribute[] attributes = new Attribute[0];
		/** If attributes of specific content type are required. */
		if (contentTypeIdOrPathOrName != null) {
			/** get attributes for specific content type */
			long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrPathOrName);
			attributes = contentStructureService.getContentTypeAttributes(contentTypeId, includeSubContentTypes);
		} else {
			/** get all attributes in system */
			attributes = attributeService.getAllAttributes();
		}
		/** Content types mapping information is added in transform method. */
		return objectTransformer.transform(attributes);
	}

	public AttributeInfoList getAttribute(String attributeName) throws AttributeNotFoundException, DomainNotFoundException,
			QppServiceException {
		long id = facadeUtility.getAttributeIds(new String[] { attributeName })[0];
		Attribute attribute = attributeService.getAttribute(id);
		AttributeInfo attributeInfo = objectTransformer.transform(attribute);
		AttributeInfoList attributeInfoList = new AttributeInfoList();
		attributeInfoList.getAttributeInfo().add(attributeInfo);
		return attributeInfoList;
	}

	public AttributeInfoList createAttributes(AttributeInfoList attributeInfoList)
			throws InvalidAttributeException, InvalidAttributeValueException, RepositoryActionException, QppServiceException {
		if (attributeInfoList != null && attributeInfoList.getAttributeInfo() != null) {
			ArrayList<Attribute> createdAttributes = new ArrayList<Attribute>();
			Iterator<AttributeInfo> it = attributeInfoList.getAttributeInfo().iterator();
			while (it.hasNext()) {
				AttributeInfo attrInfo = it.next();
				try {
					Attribute attributeCreated = createAttribute(attrInfo);
					createdAttributes.add(attributeCreated);
				} catch (QppServiceException e) {
					logger.error("Error while creating attribute with name : " + attrInfo.getName(), e);
					if(attributeInfoList.getAttributeInfo().size() == 1){
						throw e;
					}
				}
			}
			return objectTransformer.transform(createdAttributes.toArray(new Attribute[0]));
		} else {
			throw new InvalidAttributeException(InvalidAttributeExceptionCodes.NO_ATTRIBUTE_SPECIFIED);
		}
	}

	private Attribute createAttribute(AttributeInfo attributeInfo) throws InvalidAttributeException, InvalidAttributeValueException,
			RepositoryActionException, QppServiceException {
		Attribute attribute = objectTransformer.transform(attributeInfo);
		return attributeService.createAttribute(attribute);
	}

	public void deleteAttribute(String attribute) throws InvalidAttributeException, AttributeNotFoundException,
			RepositoryActionException, QppServiceException {
		long attributeId = facadeUtility.getAttributeIds(new String[] { attribute })[0];
		attributeService.deleteAttribute(attributeId);
	}

	public AttributeInfoList updateAttributes(AttributeInfoList attributeInfoList)
			throws AttributeNotFoundException, InvalidAttributeException, DomainNotFoundException,
			RepositoryActionException, QppServiceException {
		if (attributeInfoList != null && attributeInfoList.getAttributeInfo() != null) {
			ArrayList<Attribute> updatedAttributes = new ArrayList<Attribute>();
			Iterator<AttributeInfo> iterator = attributeInfoList.getAttributeInfo().iterator();
			while (iterator.hasNext()) {
				AttributeInfo attrInfo = iterator.next();
				try {
					Attribute updatedAttribute = updateAttribute(attrInfo);
					updatedAttributes.add(updatedAttribute);
				} catch (QppServiceException e) {
					logger.error(
							"Error while updating the attribute with id: " + attrInfo.getId() + " and attribute name : " + attrInfo.getName(), e);
					if(attributeInfoList.getAttributeInfo().size() == 1){
						throw e;
					}
				}
			}
			return objectTransformer.transform(updatedAttributes.toArray(new Attribute[0]));
		} else {
			throw new InvalidAttributeException(InvalidAttributeExceptionCodes.NO_ATTRIBUTE_SPECIFIED);
		}
		
	}

	private Attribute updateAttribute(AttributeInfo attributeInfo) throws AttributeNotFoundException, InvalidAttributeException, DomainNotFoundException,
			RepositoryActionException, QppServiceException {
		long attributeId = -1;
		if (attributeInfo.getId() == null) {
			Attribute attr = attributeService.getAttributeByName(attributeInfo.getName());
			attributeId = attr.getId();
		} else {
			attributeId = attributeInfo.getId();
		}
		attributeInfo.setId(attributeId);
		Attribute attribute = objectTransformer.transform(attributeInfo);
		
		if(attribute.getName()!=null && !attribute.getName().isEmpty()){
			attributeService.updateAttributeName(attribute.getId(), attribute.getName());
		}
		attributeService.updateAttributeLimitedAccess(attribute.getId(), attribute.isLimitedAccess());
		if (attributeInfo.isMultiValued()) {
			attributeService.convertAttributeToMultiValued(attributeId);
		}
		int newAttributeValueType = attribute.getValueType();
		if(newAttributeValueType > 0){
			int domainId = -1;
			if(newAttributeValueType == AttributeValueTypes.DOMAIN){
				if(attribute.getDefaultValuePreference() instanceof DomainValuePreferences){
					domainId = ((DomainValuePreferences)attribute.getDefaultValuePreference()).getDomainId();
				} else if(attribute.getDefaultValuePreference() instanceof DomainValueListPreferences){
					domainId = ((DomainValueListPreferences)attribute.getDefaultValuePreference()).getDomainId();
				}
			}
			attributeService.updateAttributeValueType(attribute.getId(), attribute.getValueType(), domainId <= 0 ? 0 : domainId);
		}
		if (attribute.getDefaultValuePreference() != null) {
			/** Default value preferences is set in transform method */
			attributeService.updateAttributeValuePreferences(attribute.getId(), attribute.getDefaultValuePreference());
		}
		return attributeService.getAttribute(attribute.getId());
	}
}

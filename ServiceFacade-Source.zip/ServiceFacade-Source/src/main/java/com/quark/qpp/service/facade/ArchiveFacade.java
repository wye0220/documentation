/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.facade;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.Value;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.dto.Article;
import com.quark.qpp.core.asset.service.dto.ArticleComponent;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.dto.Layout;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.relation.service.constants.DefaultRelationTypes;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.exception.ArchiveException;
import com.quark.qpp.service.exception.ArchiveExceptionCodes;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.ArchiveRestoreUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.ArchiveRestoreInfo;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * The ArchiveFacade archives assets based on asset id, asset path, collection id, collection path, or query name. In case of collection
 * assets and query name it queries for the corresponding assets, and iterates over every asset of the result, and its related assets (if
 * 'archiverelations' flag is set to true), and archives them. An Archive.xml file will be created per asset version, parallel to the asset
 * high-res file that has been downloaded, containing the metadata for this asset necessary for restoring. An Archive.log file is generated
 * with detailed archive logs inside the QPP server installation path /log folder. An Index.xml is also generated that contains information
 * regarding the asset id, version, and relative download path of each asset downloaded at the destination folder. An ArchiveSummary.log
 * file is generated as well parallel to the Index.xml file, that contains the count of assets archived/ failed.
 */
@Controller(value = "archiveFacade")
@RequestMapping("/archive")
public class ArchiveFacade {

	@Autowired
	private AssetService assetService;

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private StreamingService defaultStreamingService;

	@Autowired
	private ArchiveRestoreUtility archiveRestoreUtility;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private PrivilegeValidator privilegeValidator;

	private Logger logger = Logger.getLogger(ArchiveFacade.class);

	/**
	 * Variable for internal use to switch on/off functionality to download or not all versions of a related asset
	 */
	// Get all revisions for related asset or just the revision which is related. 'false' to download only the revision which is related
	boolean relatedAssetAllVersions = true;

	/**
	 * Archives an asset from the given asset id or asset path.
	 * 
	 * @param assetIdOrPath
	 *            Id or asset name with complete collection path of the asset to be archived. For example, /archive/assets?assets=10,11,12
	 *            OR /archive/assets?assets=Home/C1/C2/Project.qxp,Home/C1/C2/Article.qcd
	 * @param destinationFolder
	 *            Path to archive the assets to.
	 * @param allVersions
	 *            Archive all revisions of an asset, or only the latest one.
	 * @param archiveRelations
	 *            Archive child relations or not.
	 * @param deleteAfterArchive
	 *            Delete asset on successful archive or not.
	 * @return ArchiveRestoreInfo object containing information for all successful or failed archives.
	 * @throws AssetNotFoundException
	 *             If no asset with the given id exists.
	 * @throws InvalidAttributeException
	 *             If the given attribute is invalid or does not exist, then this exception is thrown. Additional info will refer to the
	 *             attribute id that caused this exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@WebReturnType(value = "xmlView")
	@RequestMapping(method = RequestMethod.GET, value = "/assets")
	public ArchiveRestoreInfo archiveAssets(@RequestParam(value = "assets") String assetIdOrPath,
			@RequestParam(value = "destinationfolder", defaultValue = ".") String destinationFolder,
			@RequestParam(value = "allversions", defaultValue = "true") boolean allVersions,
			@RequestParam(value = "archiverelations", defaultValue = "true") boolean archiveRelations,
			@RequestParam(value = "deleteafterarchive", defaultValue = "false") boolean deleteAfterArchive) throws AssetNotFoundException,
			InvalidAttributeException, QppServiceException {

		logger.trace("-- Starting Archive --");
		// Maintain record of archived asset revisions - asset id, version, archive path
		ArrayList<AssetInfo> revisionsSuccessfullyArchived = new ArrayList<AssetInfo>();
		// Maintain record of failed asset revisions - name and revision as key, and exception information as value
		Map<String, String> revisionsFailedToArchive = new HashMap<String, String>();
		// Maintain record of assets successfully archived
		ArrayList<Long> assetsSelectedForArchive = new ArrayList<Long>();
		// Maintain record of assets failed to archive
		ArrayList<String> assetsFailedToArchive = new ArrayList<String>();
		// archive summary text
		String logText = "";

		try {
			// boolean to check if user has directory/file write access.
			// to be maintained in recursive calls to archiveAsset method.
			boolean[] hasAccess = { false };
			// parameter will be a comma separated string in case of multiple asset selection.
			String[] assetIdsOrPaths = assetIdOrPath.split(",");
			for (String assetIdOrPathValue : assetIdsOrPaths) {
				long assetId = facadeUtility.getAssetId(assetIdOrPathValue);
				if (assetId > 0) {
					AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.NAME,
							DefaultAttributes.IS_PLACEHOLDER, DefaultAttributes.CONTENT_TYPE, DefaultAttributes.COLLECTION_PATH });

					try {
						// validate asset archive privilege for the logged in user for this content type.
						privilegeValidator.validateContentTypePrivileges(assetId, attributeValues, "archiveAsset");
					} catch (Exception e) {
						String assetName = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.NAME, attributeValues))
								.getValue();
						String collectionPath = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.COLLECTION_PATH,
								attributeValues)).getValue();
						logger.error("Exception occurred while archiving " + collectionPath + "/" + assetName, e);
						assetsFailedToArchive.add(collectionPath + "/" + assetName);
						revisionsFailedToArchive.put(collectionPath + "/" + assetName + ", All Versions.", e.toString());

						// continue archiving next asset...
						continue;
					}
					archiveAsset(attributeValues, assetId, revisionsSuccessfullyArchived, assetsFailedToArchive, revisionsFailedToArchive,
							allVersions, archiveRelations, destinationFolder, assetsSelectedForArchive, hasAccess);
				}
			}
		} catch (AssetNotFoundException e) {
			logger.error("Unable to archive assets.", e);
			throw e;
		} catch (InvalidAttributeException e) {
			logger.error("Unable to archive assets.", e);
			throw e;
		} catch (QppServiceException e) {
			logger.error("Unable to archive assets.", e);
			throw e;
		} finally {
			logText = logArchive(deleteAfterArchive, destinationFolder, revisionsSuccessfullyArchived, revisionsFailedToArchive,
					assetsSelectedForArchive, assetsFailedToArchive);
			logger.trace("-- Archiving Complete. --");
		}

		// return the info object
		ArchiveRestoreInfo info = new ArchiveRestoreInfo();
		info.setFailureCount(assetsFailedToArchive.size());
		info.setSuccessCount(assetsSelectedForArchive.size());
		info.setSummary(logText);
		return info;
	}

	/**
	 * Archives all assets belonging to a particular collection, from the given collection id or complete collection path.
	 * 
	 * @param collectionIdOrPath
	 *            Id or collection path of the collection whose assets are to be archived. For example,
	 *            /archive/collectionassets?collection=20 OR /archive/collectionassets?collection=Home/C1/C2
	 * @param destinationFolder
	 *            Path to archive the assets to.
	 * @param allVersions
	 *            Archive all revisions of an asset, or only the latest one.
	 * @param archiveRelations
	 *            Archive child relations or not.
	 * @param deleteAfterArchive
	 *            Delete asset on successful archive or not.
	 * @return ArchiveRestoreInfo object containing information for all successful or failed archives.
	 * @throws InvalidQueryDefinitionException
	 *             If no query with the given definition exists.
	 * @throws InvalidQueryDisplayException
	 *             If <code>queryDisplay</code> is null, empty, or contains invalid attributeIds.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@WebReturnType(value = "xmlView")
	@RequestMapping(method = RequestMethod.GET, value = "/collectionassets")
	public ArchiveRestoreInfo archiveCollectionAssets(@RequestParam(value = "collection") String collectionIdOrPath,
			@RequestParam(value = "destinationfolder", defaultValue = ".") String destinationFolder,
			@RequestParam(value = "allversions", defaultValue = "true") boolean allVersions,
			@RequestParam(value = "archiverelations", defaultValue = "true") boolean archiveRelations,
			@RequestParam(value = "deleteafterarchive", defaultValue = "false") boolean deleteAfterArchive)
			throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {

		logger.trace("-- Starting Archive --");
		// Maintain record of archived asset revisions - asset id, version, archive path
		ArrayList<AssetInfo> revisionsSuccessfullyArchived = new ArrayList<AssetInfo>();
		// Maintain record of failed asset revisions - name and revision as key, and exception information as value
		Map<String, String> revisionsFailedToArchive = new HashMap<String, String>();
		// Maintain record of assets successfully archived
		ArrayList<Long> assetsSelectedForArchive = new ArrayList<Long>();
		// Maintain record of assets failed to archive
		ArrayList<String> assetsFailedToArchive = new ArrayList<String>();
		// archive summary text
		String logText = "";

		try {
			long collectionId = facadeUtility.getCollectionId(collectionIdOrPath);
			QueryResultElement[] queryResults = null;
			if (collectionId > 0)
				queryResults = archiveRestoreUtility.getCollectionAssets(collectionId, new long[] { DefaultAttributes.NAME,
						DefaultAttributes.IS_PLACEHOLDER, DefaultAttributes.CONTENT_TYPE, DefaultAttributes.COLLECTION_PATH,
						DefaultAttributes.FILE_EXTENSION });
			if (queryResults != null)
				logText = archiveQueryResults(queryResults, revisionsSuccessfullyArchived, assetsFailedToArchive, revisionsFailedToArchive,
						allVersions, archiveRelations, deleteAfterArchive, destinationFolder, assetsSelectedForArchive);

		} catch (InvalidQueryDefinitionException e) {
			logger.error("Unable to archive collection assets.", e);
			throw e;
		} catch (InvalidQueryDisplayException e) {
			logger.error("Unable to archive collection assets.", e);
			throw e;
		} catch (QppServiceException e) {
			logger.error("Unable to archive collection assets.", e);
			throw e;
		} catch (Exception e) {
			logger.error("Unable to archive collection assets.", e);
		} finally {
			logger.trace("-- Archiving Complete. --");
		}

		// return the info object
		ArchiveRestoreInfo info = new ArchiveRestoreInfo();
		info.setFailureCount(assetsFailedToArchive.size());
		info.setSuccessCount(assetsSelectedForArchive.size());
		info.setSummary(logText);
		return info;
	}

	/**
	 * Archives all assets returned in the query result for the given query name.
	 * 
	 * @param searchName
	 *            Name of the query containing assets to be archived. For example, /archive/searchresults?searchname=allAssets
	 * @param destinationFolder
	 *            Path to archive the assets to.
	 * @param allVersions
	 *            Archive all revisions of an asset, or only the latest one.
	 * @param archiveRelations
	 *            Archive child relations or not.
	 * @param deleteAfterArchive
	 *            Delete asset on successful archive or not.
	 * @return ArchiveRestoreInfo object containing information for all successful or failed archives.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@WebReturnType(value = "xmlView")
	@RequestMapping(method = RequestMethod.GET, value = "/searchresults")
	public ArchiveRestoreInfo archiveQueryAssets(@RequestParam(value = "searchname") String searchName,
			@RequestParam(value = "destinationfolder", defaultValue = ".") String destinationFolder,
			@RequestParam(value = "allversions", defaultValue = "true") boolean allVersions,
			@RequestParam(value = "archiverelations", defaultValue = "true") boolean archiveRelations,
			@RequestParam(value = "deleteafterarchive", defaultValue = "false") boolean deleteAfterArchive) throws QppServiceException {

		logger.trace("-- Starting Archive --");
		// Maintain record of archived asset revisions - asset id, version, archive path
		ArrayList<AssetInfo> revisionsSuccessfullyArchived = new ArrayList<AssetInfo>();
		// Maintain record of failed asset revisions - name and revision as key, and exception information as value
		Map<String, String> revisionsFailedToArchive = new HashMap<String, String>();
		// Maintain record of assets successfully archived
		ArrayList<Long> assetsSelectedForArchive = new ArrayList<Long>();
		// Maintain record of assets failed to archive
		ArrayList<String> assetsFailedToArchive = new ArrayList<String>();
		// archive summary text
		String logText = "";

		try {
			long queryId = facadeUtility.getQueryId(searchName);
			boolean collectionQuery = archiveRestoreUtility.isCollectionQuery(queryId);
			if (!collectionQuery) {
				QueryResultElement[] queryResults = archiveRestoreUtility.executeQuery(queryId, new long[] { DefaultAttributes.NAME,
						DefaultAttributes.IS_PLACEHOLDER, DefaultAttributes.CONTENT_TYPE, DefaultAttributes.COLLECTION_PATH,
						DefaultAttributes.FILE_EXTENSION });
				if (queryResults != null)
					logText = archiveQueryResults(queryResults, revisionsSuccessfullyArchived, assetsFailedToArchive,
							revisionsFailedToArchive, allVersions, archiveRelations, deleteAfterArchive, destinationFolder,
							assetsSelectedForArchive);
			} else {
				logger.error("ArchiveException occured. Cannot archive a collection based search.");
				throw new ArchiveException(ArchiveExceptionCodes.CANNOT_ARCHIVE_COLLECTION_SEARCH);
			}

		} catch (QppServiceException e) {
			logger.error("Unable to archive search results.", e);
			throw e;
		} catch (Exception e) {
			logger.error("Unable to archive search results.", e);
		} finally {
			logger.trace("-- Archiving Complete. --");
		}

		// return the info object
		ArchiveRestoreInfo info = new ArchiveRestoreInfo();
		info.setFailureCount(assetsFailedToArchive.size());
		info.setSuccessCount(assetsSelectedForArchive.size());
		info.setSummary(logText);
		return info;
	}

	/**
	 * This method iterates over the query results for archiving assets.
	 * 
	 * @param queryResults
	 * @param revisionsSuccessfullyArchived
	 * @param assetsFailedToArchive
	 * @param revisionsFailedToArchive
	 * @param allVersions
	 * @param archiveRelations
	 * @param deleteAfterArchive
	 * @param destinationFolder
	 * @param assetsSelectedForArchive
	 * @return The archived assets summary log.
	 * @throws QppServiceException
	 */
	private String archiveQueryResults(QueryResultElement[] queryResults, ArrayList<AssetInfo> revisionsSuccessfullyArchived,
			ArrayList<String> assetsFailedToArchive, Map<String, String> revisionsFailedToArchive, boolean allVersions,
			boolean archiveRelations, boolean deleteAfterArchive, String destinationFolder, ArrayList<Long> assetsSelectedForArchive)
			throws QppServiceException {
		logger.trace("queryResults length is: " + queryResults.length);
		String logText = "";

		try {
			// boolean to check if user has directory/file write access.
			// to be maintained in recursive calls to archiveAsset method.
			boolean[] hasAccess = { false };
			for (int i = 0; i < queryResults.length; i++) {
				AssetElement assetElement = (AssetElement) queryResults[i];
				AttributeValue[] attributeValues = assetElement.getAttributeValues();
				long assetId = assetElement.getAssetId();

				try {
					// validate asset archive privilege for the logged in user for this content type.
					privilegeValidator.validateContentTypePrivileges(assetId, attributeValues, "archiveAsset");
				} catch (Exception e) {
					String assetName = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.NAME, attributeValues))
							.getValue();
					String collectionPath = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.COLLECTION_PATH,
							attributeValues)).getValue();
					logger.error("Exception occured while archiving " + collectionPath + "/" + assetName, e);
					assetsFailedToArchive.add(collectionPath + "/" + assetName);
					revisionsFailedToArchive.put(collectionPath + "/" + assetName + "All Versions.", e.toString());

					// continue archiving next asset...
					continue;
				}
				archiveAsset(attributeValues, assetId, revisionsSuccessfullyArchived, assetsFailedToArchive, revisionsFailedToArchive,
						allVersions, archiveRelations, destinationFolder, assetsSelectedForArchive, hasAccess);
			}
		} finally {
			logText = logArchive(deleteAfterArchive, destinationFolder, revisionsSuccessfullyArchived, revisionsFailedToArchive,
					assetsSelectedForArchive, assetsFailedToArchive);
		}
		return logText;
	}

	/**
	 * This method will begin the process to archive an asset and its revisions.
	 * 
	 * @param attributeValues
	 * @param assetId
	 * @param revisionsSuccessfullyArchived
	 * @param assetsFailedToArchive
	 * @param revisionsFailedToArchive
	 * @param allVersions
	 * @param archiveRelations
	 * @param destinationFolder
	 * @param assetsSelectedForArchive
	 * @throws QppServiceException
	 */
	private void archiveAsset(AttributeValue[] attributeValues, long assetId, ArrayList<AssetInfo> revisionsSuccessfullyArchived,
			ArrayList<String> assetsFailedToArchive, Map<String, String> revisionsFailedToArchive, boolean allVersions,
			boolean archiveRelations, String destinationFolder, ArrayList<Long> assetsSelectedForArchive, boolean[] hasAccess)
			throws QppServiceException {

		// check for directory permissions before beginning archive...
		// check only once, do not check for subsequent assets...
		if (!hasAccess[0]) {
			if (!new File(destinationFolder).exists()) {
				boolean success = new File(destinationFolder).mkdirs();
				if (!success) {
					logger.error("Problem occurred while creating archive directory.");
					throw new ArchiveException(ArchiveExceptionCodes.INVALID_ARCHIVE_PATH, new String[] { destinationFolder });
				}
			}
			// check for file write access
			hasAccess[0] = checkFilePermissions(destinationFolder);
		}

		DomainValue contentType = (DomainValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.CONTENT_TYPE, attributeValues);
		String assetName = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.NAME, attributeValues)).getValue();
		boolean isPlaceHolder = ((BooleanValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.IS_PLACEHOLDER, attributeValues))
				.getValue();
		try {
			if (!isPlaceHolder) {
				logger.trace("");
				logger.trace("Archiving asset with name: " + assetName+" assetId: "+assetId);

				// assetVersion parameter is null when archiving a query result or an asset id
				createAssetVersionNode(attributeValues, assetId, null, contentType.getId(), allVersions, archiveRelations,
						revisionsSuccessfullyArchived, revisionsFailedToArchive, destinationFolder);

				// add asset to selected assets list for deletion in case deleteAfterArchive flag is true
				assetsSelectedForArchive.add(assetId);

			} else
				logger.trace("Skipping placeholder asset " + assetName);

		} catch (ArchiveException e) {
			logger.error("ArchiveException has occured for " + assetName, e);
			String collectionPath = ((TextValue) archiveRestoreUtility
					.getAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValues)).getValue();
			assetsFailedToArchive.add(collectionPath + "/" + assetName);
			throw e;

		} catch (Exception e) {
			logger.error("Exception occured while archiving " + assetName, e);
			String collectionPath = ((TextValue) archiveRestoreUtility
					.getAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValues)).getValue();
			assetsFailedToArchive.add(collectionPath + "/" + assetName);
		}
		if (assetsFailedToArchive.size() > 0)
			logger.trace("Number of assets failed during archive process: " + assetsFailedToArchive.size());
	}

	/**
	 * This method archives every asset version and generates the 'Asset' and 'Version' nodes for the corresponding Archive.xml. It is
	 * invoked recursively for archiving every asset relation for the particular asset version.
	 * 
	 * @param attributeValues
	 * @param assetId
	 * @param assetVersion
	 *            assetVersion is null when archiving a query result or an asset id, and it is not null when archiving related/child assets
	 *            recursively.
	 * @param contentTypeId
	 * @param allVersions
	 * @param archiveRelations
	 * @param revisionsSuccessfullyArchived
	 * @param revisionsFailedToArchive
	 * @param destinationFolder
	 * @throws Exception
	 */
	private void createAssetVersionNode(AttributeValue[] attributeValues, long assetId, AssetVersion assetVersion, long contentTypeId,
			boolean allVersions, boolean archiveRelations, ArrayList<AssetInfo> revisionsSuccessfullyArchived,
			Map<String, String> revisionsFailedToArchive, String destinationFolder) throws Exception {

		if(assetVersion != null){
			logger.trace("Archiving Related/Child Assets..."+assetId +" version "+assetVersion.getMajorVersion()+"."+assetVersion.getMinorVersion());
		}else{
			logger.trace("Archiving Related/Child Assets..."+assetId);
		}
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();

		// maintain a list of asset version relations for all versions of an asset, and download them once the parent asset has
		// completed execution, by downloading the high-res and writing the corresponding Archive.xml file for each.
		List<AssetInfo> assetVersionRelations = new ArrayList<AssetInfo>();

		// fetch the asset version/s based on whether allVersions flag is true or false.
		Asset[] assetVersions = getAssetVersions(assetId, assetVersion, allVersions);
		if (assetVersions != null) {
			// looping to archive asset versions
			for (Asset asset : assetVersions) {
				try {
					Document dom = db.newDocument();
					Element qpsEle = dom.createElement("QPPArchiveData");
					qpsEle.setAttribute("DateCreated", "" + new Date());
					qpsEle.setAttribute("CreatedBy", "QPP");
					dom.appendChild(qpsEle);

					Element assetEle = dom.createElement("Asset");
					assetEle.setAttribute("AssetID", "" + assetId);
					assetEle.setAttribute("ContentType", "" + contentTypeId);
					assetEle.setAttribute("ContentTypeHierarchy", "" + facadeUtility.getContentTypeHierarchy(contentTypeId));
					Element versionElement = dom.createElement("Version");
					assetEle.appendChild(versionElement);

					// write asset metadata in the Attributes node.
					createAttributesElement(assetId, asset.getAttributeValues(), versionElement, false);

					if (contentTypeId == DefaultContentTypes.ARTICLE
							|| contentStructureService.isValidAncestor(DefaultContentTypes.ARTICLE, contentTypeId)) {
						ArticleComponent[] articleComponents = ((Article) asset).getArticleComponents();
						// create the Components node
						createComponentsElement(assetId, articleComponents, versionElement);

					} else if (contentTypeId == DefaultContentTypes.QUARK_XPRESS_PROJECT
							|| contentStructureService.isValidAncestor(DefaultContentTypes.QUARK_XPRESS_PROJECT, contentTypeId)
							|| contentTypeId == DefaultContentTypes.QUARK_XPRESS_TEMPLATE
							|| contentStructureService.isValidAncestor(DefaultContentTypes.QUARK_XPRESS_TEMPLATE, contentTypeId)) {
						Layout[] layouts = ((com.quark.qpp.core.asset.service.dto.Document) asset).getLayouts();
						// create the Layouts node
						createLayoutsElement(assetId, layouts, versionElement);
					}

					if (archiveRelations) {
						// create the Relations node
						createRelationsElement(versionElement, assetId, assetVersionRelations, allVersions);
					}

					// append the Asset node to the root
					qpsEle.appendChild(assetEle);

					// download the asset version
					String assetPath = archiveRestoreUtility.getAssetPath(assetId);
					boolean archivedSucessfully = createDirAndDownload(dom, assetId, versionElement, revisionsSuccessfullyArchived,
							destinationFolder, assetPath);
					if (archivedSucessfully) {
						logger.trace("Total assets downloaded: " + revisionsSuccessfullyArchived.size());
					}

				} catch (Exception e) {
					// log asset versions that failed to archive
					String assetName = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.NAME, attributeValues))
							.getValue();
					String collectionPath = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.COLLECTION_PATH,
							attributeValues)).getValue();
					long majorVersion = asset.getAssetVersion().getMajorVersion();
					long minorVersion = asset.getAssetVersion().getMinorVersion();
					logger.error("Exception occurred while archiving " + collectionPath + "/" + assetName + ", Version: " + majorVersion
							+ minorVersion, e);
					revisionsFailedToArchive.put(collectionPath + "/" + assetName + ", Version: " + majorVersion + "." + minorVersion,
							e.toString());
					// fail the main asset
					throw e;
				}

				// looping to archive asset version relations
				for (AssetInfo assetInfo : assetVersionRelations) {
					if(!revisionsSuccessfullyArchived.contains(assetInfo)){
					// assetVersion parameter is not null when archiving related/child assets recursively
					long contentType = ((DomainValue) assetService.getAttributeValues(assetInfo.getAssetId(),
							new long[] { DefaultAttributes.CONTENT_TYPE })[0].getAttributeValue()).getId();
					attributeValues = assetService.getAsset(assetInfo.getAssetId()).getAttributeValues();
					createAssetVersionNode(attributeValues, assetInfo.getAssetId(),
							new AssetVersion(assetInfo.getMajorVersion(), assetInfo.getMinorVersion()), contentType, allVersions,
							archiveRelations, revisionsSuccessfullyArchived, revisionsFailedToArchive, destinationFolder);
					}
				}
			}
		}
	}

	/**
	 * Return an array of asset objects containing the latest or all revisions of the asset.
	 * 
	 * @param assetId
	 * @param assetVersion
	 * @param allVersions
	 * @return
	 * @throws AssetNotFoundException
	 * @throws QppServiceException
	 */
	private Asset[] getAssetVersions(long assetId, AssetVersion assetVersion, boolean allVersions) throws AssetNotFoundException,
			QppServiceException {
		Asset[] assetObjects = null;
		if (allVersions) {
			if (!relatedAssetAllVersions && assetVersion != null)
				assetObjects = new Asset[] { assetService.getAssetVersion(assetId, assetVersion) };
			else
				assetObjects = assetService.getAssetAllVersions(assetId);
		} else {
			if (assetVersion != null) {
				try {
					assetObjects = new Asset[] { assetService.getAssetVersion(assetId, assetVersion) };
				} catch (Exception e) {
					logger.trace("Error while fetching particular asset with Id: " + assetId + " version: "+ assetVersion.getMajorVersion() + "." + assetVersion.getMinorVersion()+ " Therefore, using latest version.");
					assetObjects = new Asset[] { assetService.getAsset(assetId) };
				}
			} else
				assetObjects = new Asset[] { assetService.getAsset(assetId) };
		}
		return assetObjects;
	}

	/**
	 * This method writes asset relation metadata in the 'Attributes' node.
	 * 
	 * @param attributeValues
	 * @param attributesParentElement
	 * @param isComponentAttr
	 * @throws DomainNotFoundException
	 * @throws QppServiceException
	 */
	@SuppressWarnings("unchecked")
	private void createAttributesElement(long assetId, AttributeValue[] attributeValues, Element attributesParentElement, boolean isComponentAttr)
			throws DomainNotFoundException, QppServiceException {
		
		// validate mandatory attributes for asset
		attributeValues = validateMandatoryAttributeValues(assetId, attributeValues);
		
		Element attributesElement = attributesParentElement.getOwnerDocument().createElement("Attributes");
		attributesParentElement.appendChild(attributesElement);
		for (AttributeValue attributeValue : attributeValues) {
			Attribute attribute = attributeService.getAttribute(attributeValue.getAttributeId());
			long attributeId = attribute.getId();
			// skip all SERVER_MODIFIABLE attributes except for these
			// skip SERVER_MODIFIABLE datadoc attributes since they are to be used to convert asset to datadoc.
			if (!(attributeId == DefaultAttributes.IS_PLACEHOLDER || attributeId == DefaultAttributes.MAJOR_VERSION
					|| attributeId == DefaultAttributes.MINOR_VERSION || attributeId == DefaultAttributes.ID || attributeId == DefaultAttributes.COLLECTION_PATH || 
					attributeId == DefaultAttributes.IS_DATADOC || attributeId == DefaultAttributes.DATADOC_CHANNEL_ID || attributeId == DefaultAttributes.DATADOC_CHANNEL_PARAMETERS))
				if (attribute.getModificationLevel() == AttributeModificationLevels.SERVER_MODIFIABLE)
					continue;

			Value value = attributeValue.getAttributeValue();
			if (value != null) {
				Object attributeTypeValue = archiveRestoreUtility.getValueForAttributeType(attributeValue);
				if (attributeTypeValue != null) {
					// write parent element attributes
					if (!isComponentAttr) {
						if (attributeId == DefaultAttributes.IS_DATADOC) {
							attributesParentElement.setAttribute("isDatadoc", String.valueOf(attributeTypeValue));
						}
						// if article component, don't bother to look for these attributes
						if (attributeId == DefaultAttributes.NAME)
							attributesParentElement.setAttribute("VersionName", "" + attributeTypeValue);
						else if (attributeId == DefaultAttributes.COLLECTION) {
							String collectionName = ((HashMap<String, String>) attributeTypeValue).get("valueText");
							/* Replace all invalid characters in collection name, since it is to be used for creating the archive directory. */
							collectionName = collectionName.replaceAll("[\\\\ / : * ? \" < > |]","_");
							attributesParentElement.setAttribute("CollectionName", "" + collectionName);
							
							/* 
							 * Also add CollectionPath tag attribute here, since there might be a case where this method receives the Collection attribute value 
							 * but not the  Collection Path attribute value. Since unique Collection id can only be fetched using Collection Path attribute value, 
							 * therefore such cases will fail during restore if the value is not given.
							 */
							if (!Arrays.asList(attributeValues).contains(DefaultAttributes.COLLECTION_PATH)) {
								String collectionPath = archiveRestoreUtility.getCollectionPath(Long.parseLong(((HashMap<String, String>) attributeTypeValue).get("valueId")));
								attributesParentElement.setAttribute("CollectionPath", "" + collectionPath);
							}
						}
						else if (attributeId == DefaultAttributes.WORKFLOW) {
							String workflowName = ((HashMap<String, String>) attributeTypeValue).get("valueText");
							/* Replace all invalid characters in workflow name, since it is to be used for creating the archive directory. */
							workflowName = workflowName.replaceAll("[\\\\ / : * ? \" < > |]","_");
							attributesParentElement.setAttribute("WorkflowName", "" + workflowName);
						}
						else if (attributeId == DefaultAttributes.COLLECTION_PATH)
							attributesParentElement.setAttribute("CollectionPath", "" + (String) attributeTypeValue);
						else if (attributeId == DefaultAttributes.MAJOR_VERSION)
							attributesParentElement.setAttribute("MajorVersionID", "" + attributeTypeValue);
						else if (attributeId == DefaultAttributes.MINOR_VERSION)
							attributesParentElement.setAttribute("MinorVersionID", "" + attributeTypeValue);
						else if (attributeId == DefaultAttributes.IS_PLACEHOLDER)
							attributesParentElement.setAttribute("isPlaceHolder", "" + attributeTypeValue);
					} else {
						if (attributeId == DefaultAttributes.ID)
							attributesParentElement.setAttribute("ComponentId", "" + attributeTypeValue);
						else if (attributeId == DefaultAttributes.COMPONENT_NAME)
							attributesParentElement.setAttribute("ComponentName", "" + attributeTypeValue);
					}

					// create the Attribute node
					if (!(attributeId == DefaultAttributes.IS_PLACEHOLDER || attributeId == DefaultAttributes.MAJOR_VERSION || attributeId == DefaultAttributes.MINOR_VERSION)) {
						Element attributeElement = attributesParentElement.getOwnerDocument().createElement("Attribute");
						attributeElement.setAttribute("name", attribute.getName());
						attributeElement.setAttribute("id", "" + attributeId);
						attributeElement.setAttribute("type", "" + attribute.getValueType());
						boolean multiValued = false;

						// for domain type attribute values
						if (attributeTypeValue instanceof HashMap<?, ?>) {
							// for multivalued attribute create the value node as child of attribute
							if (attribute.isMultiValued()) {
								multiValued = true;
								String[] domainValuesName = ((HashMap<String, String[]>) attributeTypeValue).get("valueText");
								String[] domainValuesId = ((HashMap<String, String[]>) attributeTypeValue).get("valueId");						
								String domainValueName = null;
								
								attributeElement.setAttribute("domainName", (((HashMap<String, String[]>) attributeTypeValue).get("domainName"))[0]);
								attributesElement.appendChild(attributeElement);
								
								// for each domain value create the value node
								for (int i = 0; i < domainValuesName.length ; i++) {
									domainValueName = domainValuesName[i];

									if (domainValueName != null) {
										Element valueNode = attributesParentElement.getOwnerDocument().createElement("Value");

										valueNode.setTextContent(archiveRestoreUtility.filterXmlText(domainValueName));
										valueNode.setAttribute("valueId", domainValuesId[i]);
										attributeElement.appendChild(valueNode);
									}
								}
							} else {
								String domainValue = ((HashMap<String, String>) attributeTypeValue).get("valueText");
								if (domainValue != null) {
									// for setting an article component's 'Content Type' attribute
									if (isComponentAttr && attributeId == DefaultAttributes.CONTENT_TYPE) {
										String componentContentTypePrefix = "";
										long componentContentTypeId = ((DomainValue) attributeValue.getAttributeValue()).getId();
										if (contentStructureService.isValidAncestor(DefaultContentTypes.TEXT_COMPONENT, componentContentTypeId))
											componentContentTypePrefix = "Text Component ";
										else if (contentStructureService.isValidAncestor(DefaultContentTypes.PICTURE_COMPONENT, componentContentTypeId))
											componentContentTypePrefix = "Picture Component ";
										attributeElement.setTextContent(componentContentTypePrefix + archiveRestoreUtility.filterXmlText(domainValue));
									}
									// for setting all other domain values
									else
										attributeElement.setTextContent(archiveRestoreUtility.filterXmlText(domainValue));
								}
								
								attributeElement.setAttribute("domainName", ((HashMap<String, String>) attributeTypeValue).get("domainName"));
								attributeElement.setAttribute("valueId", ((HashMap<String, String>) attributeTypeValue).get("valueId"));
							}							
						}
						// for non domain type attribute values
						else
							attributeElement.setTextContent(archiveRestoreUtility.filterXmlText(String.valueOf(attributeTypeValue)));

						// for multivalued domain type attribute have to append the value elements for Attribute. For this
						// we have append the child for multivalued already. 
						if (multiValued == false) {
							attributesElement.appendChild(attributeElement);
						}
					}
				}
			}
		}
	}
	
	/**
	 * This method will add a mandatory attribute if it is found missing in the given attributes array. 
	 * It fetches the attribute value from the current asset version.
	 * @param assetId
	 * @param attributeValues
	 * @return Array with all mandatory attributes.
	 * @throws InvalidContentTypeException
	 * @throws QppServiceException
	 */
	public AttributeValue[] validateMandatoryAttributeValues(long assetId, AttributeValue[] attributeValues)
			throws InvalidContentTypeException, QppServiceException {

		ArrayList<Long> mandatoryAttributeIds = new ArrayList<Long>();
		Value contentTypeValue = archiveRestoreUtility.getAttributeValue(DefaultAttributes.CONTENT_TYPE, attributeValues);
		if (contentTypeValue != null) {
			long contentTypeId = ((DomainValue) contentTypeValue).getId();

			// fetch mandatory attributes for this content type
			ContentTypeAttributeMapping[] attributeMappings = contentStructureService.getContentTypeAttributesMapping(contentTypeId);
			for (ContentTypeAttributeMapping contentTypeAttributeMapping : attributeMappings) {
				if (contentTypeAttributeMapping.isValueMandatory()) {
					Attribute attribute = attributeService.getAttribute(contentTypeAttributeMapping.getAttributeId());
					if (attribute.getModificationLevel() != AttributeModificationLevels.SERVER_MODIFIABLE) {
						mandatoryAttributeIds.add(contentTypeAttributeMapping.getAttributeId());
					}
				}
			}

			ArrayList<AttributeValue> attributeValuesList = new ArrayList<AttributeValue>(Arrays.asList(attributeValues));
			for (long attributeId : mandatoryAttributeIds) {
				boolean attributeFound = false;
				for (AttributeValue attributeValue : attributeValuesList) {
					if (attributeId == attributeValue.getAttributeId()) {
						attributeFound = true;
						break;
					}
				}
				if (!attributeFound) {
					// fetch the attribute value for current asset version and add to the list
					AttributeValue[] currentAssetVersionAttributeValues = assetService.getAsset(assetId).getAttributeValues();
					Value currentAssetVersionValue = archiveRestoreUtility.getAttributeValue(attributeId, currentAssetVersionAttributeValues);
					int attributeType = attributeService.getAttribute(attributeId).getValueType();
					attributeValuesList.add(new AttributeValue(attributeId, currentAssetVersionValue, attributeType));
				}
			}
			return attributeValuesList.toArray(new AttributeValue[0]);
		}
		return attributeValues;
	}
	
	/**
	 * This method creates the 'Components' node and writes components metadata.
	 * @param assetId 
	 * @param articleComponents
	 * @param versionElement
	 * @throws AssetNotFoundException
	 * @throws InvalidAttributeException
	 * @throws QppServiceException
	 */
	private void createComponentsElement(long assetId, ArticleComponent[] articleComponents, Element versionElement) throws AssetNotFoundException,
			InvalidAttributeException, QppServiceException {
		Document dom = versionElement.getOwnerDocument();
		Element componentParentEle = dom.createElement("Components");
		componentParentEle.setAttribute("ComponentCount", "" + articleComponents.length);
		versionElement.appendChild(componentParentEle);
		for (ArticleComponent articleComponent : articleComponents) {
			Element componentEle = dom.createElement("Component");
			componentParentEle.appendChild(componentEle);
			// write component metadata in Attributes node.
			createAttributesElement(assetId, articleComponent.getComponentAttributeValues(), componentEle, true);
		}
	}

	/**
	 * This method creates the 'Layouts' node and writes layouts metadata.
	 * @param assetId 
	 * @param layouts
	 * @param versionElement
	 * @throws DomainNotFoundException
	 * @throws QppServiceException
	 */
	private void createLayoutsElement(long assetId, Layout[] layouts, Element versionElement) throws DomainNotFoundException, QppServiceException {
		Document dom = versionElement.getOwnerDocument();
		Element layoutParentEle = dom.createElement("Layouts");
		layoutParentEle.setAttribute("LayoutCount", "" + layouts.length);
		versionElement.appendChild(layoutParentEle);
		for (Layout layout : layouts) {
			Element layoutEle = dom.createElement("Layout");
			layoutEle.setAttribute("layoutID", "" + layout.getLayoutId());
			layoutParentEle.appendChild(layoutEle);
			createAttributesElement(assetId, layout.getAttributeValues(), layoutEle, false);
		}
	}

	/**
	 * This method creates the 'Relations' node and writes asset relations metadata. It also updates the relations list for this asset
	 * version. These relations will be archived once the parent asset has been archived.
	 * 
	 * @param versionElement
	 * @param assetId
	 * @param assetVersionRelations
	 * @param allVersions 
	 * @param archiveRelations
	 * @throws AssetNotFoundException
	 * @throws QppServiceException
	 */
	private void createRelationsElement(Element versionElement, long assetId, List<AssetInfo> assetVersionRelations, boolean allVersions)
			throws AssetNotFoundException, QppServiceException {

		AssetRelation[] assetRelations = assetService.getChildAssetRelationsVersion(
				assetId,
				new AssetVersion(Long.valueOf(versionElement.getAttribute("MajorVersionID")), Long.valueOf(versionElement
						.getAttribute("MinorVersionID"))));
		Document dom = versionElement.getOwnerDocument();
		Element relationsElement = dom.createElement("Relations");
		versionElement.appendChild(relationsElement);
		relationsElement.setAttribute("RelationsCount", String.valueOf(assetRelations.length));
		for (AssetRelation assetRelation : assetRelations) {
			long childAssetId = assetRelation.getChildAssetId();
			long childMajorVersion = assetRelation.getChildAssetVersion().getMajorVersion();
			long childMinorVersion = assetRelation.getChildAssetVersion().getMinorVersion();
			
			
			
			Element assetRelationElement = dom.createElement("AssetRelation");
			relationsElement.appendChild(assetRelationElement);
			assetRelationElement.setAttribute("RelationId", String.valueOf(assetRelation.getId()));
			assetRelationElement.setAttribute("RelationType", String.valueOf(assetRelation.getRelationTypeId()));
			assetRelationElement.setAttribute("RelationTypeName", facadeUtility.getRelationTypeName(assetRelation.getRelationTypeId()));
			assetRelationElement.setAttribute("RelationState", String.valueOf(assetRelation.getRelationState()));
			assetRelationElement.setAttribute("ParentAssetId", String.valueOf(assetRelation.getParentAssetId()));
			assetRelationElement.setAttribute("ChildAssetID", String.valueOf(childAssetId));

			//the version setting in relationInfo needs to be kept intact so that restore flow runs smoothly
			assetRelationElement.setAttribute("ChildMajorVersion", String.valueOf(childMajorVersion));
			assetRelationElement.setAttribute("ChildMinorVersion", String.valueOf(childMinorVersion));

			//but for child file download use another parameter   
			long childDownloadMajorVersion = -1;
			long childDownloadMinorVersion = -1;
			
			if (assetRelation.isLockedToChildVersion() || allVersions) {
				childDownloadMajorVersion = childMajorVersion;
				childDownloadMinorVersion = childMinorVersion;
			} else {
				// pick latest version of child
				AssetVersion assetVersion = assetService.getAsset(childAssetId).getAssetVersion();
				
				childDownloadMajorVersion = assetVersion.getMajorVersion();
				childDownloadMinorVersion = assetVersion.getMinorVersion();

			}
			
			long childAssetContentType = ((DomainValue) assetService.getAttributeValues(childAssetId,
					new long[] { DefaultAttributes.CONTENT_TYPE })[0].getAttributeValue()).getId();
			assetRelationElement.setAttribute("ChildAssetType", String.valueOf(childAssetContentType));
			assetRelationElement.setAttribute("ChildAssetTypeHierarchy", facadeUtility.getContentTypeHierarchy(childAssetContentType));
			assetRelationElement.setAttribute("LockedToChildVersion", String.valueOf(assetRelation.isLockedToChildVersion()));

			/**
			 * For primary, secondary and article comp ref relation types (which (may) involve article components), write the attached
			 * component name and id as well in the archive xml AssetRelation node so that while restoring the assets, we know with which
			 * component out of all the article components, the particular asset relation has to be created, since the archived component id
			 * will change once the article is restored/checked-in again if it was deleted after archive.
			 */
			long attachedComponentId = 0;
			Value componentId = archiveRestoreUtility.getAttributeValue(DefaultAttributes.ATTACHED_COMPONENT_ID,
					assetRelation.getRelationAttributes());
			if (componentId != null)
				attachedComponentId = ((NumericValue) componentId).getValue();
			AttributeValue[] attributeValues = null;
			if (assetRelation.getRelationTypeId() == DefaultRelationTypes.PRIMARY_ATTACHMENT
					|| assetRelation.getRelationTypeId() == DefaultRelationTypes.SECONDARY_ATTACHMENT
					|| assetRelation.getRelationTypeId() == DefaultRelationTypes.ARTICLE_COMP_REFERENCE) {
				Article attachedArticle = null;
				if (assetRelation.getRelationTypeId() == DefaultRelationTypes.PRIMARY_ATTACHMENT
						|| assetRelation.getRelationTypeId() == DefaultRelationTypes.SECONDARY_ATTACHMENT) {
					Asset attachedAsset = assetService.getAssetVersion(childAssetId, assetRelation.getChildAssetVersion());
					if (attachedAsset instanceof Article)
						attachedArticle = (Article) assetService.getAssetVersion(childAssetId, assetRelation.getChildAssetVersion());
				} else if (assetRelation.getRelationTypeId() == DefaultRelationTypes.ARTICLE_COMP_REFERENCE)
					attachedArticle = (Article) assetService.getAssetVersion(assetRelation.getParentAssetId(),
							assetService.getAsset(assetRelation.getParentAssetId()).getAssetVersion());

				if (attachedArticle != null) {
					ArticleComponent[] articleComponents = attachedArticle.getArticleComponents();
					for (ArticleComponent articleComponent : articleComponents) {
						if (articleComponent.getComponentId() == ((NumericValue) componentId).getValue()) {
							attributeValues = articleComponent.getComponentAttributeValues();
							break;
						}
					}
				}
			}
			String attachedComponentName = "";
			Value componentName = archiveRestoreUtility.getAttributeValue(DefaultAttributes.COMPONENT_NAME, attributeValues);
			if (componentName != null)
				attachedComponentName = ((TextValue) componentName).getValue();
			assetRelationElement.setAttribute("ComponentName", attachedComponentName);
			assetRelationElement.setAttribute("ComponentId", String.valueOf(attachedComponentId));

			// write asset relation metadata in the Attributes node
			createAttributesElement(assetId, assetRelation.getRelationAttributes(), assetRelationElement, false);

			AssetInfo assetInfo = new AssetInfo(childAssetId, childDownloadMajorVersion/*refers to the version to be downloaded*/, childDownloadMinorVersion);
			if (!assetVersionRelations.contains(assetInfo)) {
				logger.trace("Adding Related Asset with id: " + childAssetId + " and Version: " + childDownloadMajorVersion + "."
						+ childDownloadMinorVersion + " to assetVersionRelations list " + " for assetId "+assetId +" version "+Long.valueOf(versionElement.getAttribute("MajorVersionID")) +"."+ Long.valueOf(versionElement
								.getAttribute("MinorVersionID")));
				assetVersionRelations.add(assetInfo);
			}
		}
	}

	/**
	 * This method creates the download directory in archive destination folder, and downloads the asset. On successful download it writes
	 * the asset version dom object to Arcive.xml file.
	 * 
	 * @param dom
	 * @param assetId
	 * @param versionEle
	 * @param revisionsSuccessfullyArchived
	 * @param destinationFolder
	 * @param assetPath
	 * @return
	 * @throws QppServiceException
	 */
	private boolean createDirAndDownload(Document dom, long assetId, Element versionEle,
			ArrayList<AssetInfo> revisionsSuccessfullyArchived, String destinationFolder, String assetPath) throws QppServiceException,
			Exception {
		String majorVersionId = versionEle.getAttribute("MajorVersionID");
		String minorVersionId = versionEle.getAttribute("MinorVersionID");
		String archivePath = "Data" + File.separator + versionEle.getAttribute("CollectionName") + File.separator
				+ versionEle.getAttribute("WorkflowName") + File.separator + assetId + File.separator + majorVersionId + "."
				+ minorVersionId;
		boolean archivedSuccessfully = false;
		try {
			if (!revisionsSuccessfullyArchived.contains(new AssetInfo(assetId, Long.valueOf(majorVersionId), Long.valueOf(minorVersionId),
					archivePath))) {
				logger.trace("Downloading asset with id: " + assetId + " and version: " + majorVersionId + "." + minorVersionId);

				String directoryName = destinationFolder + File.separator + archivePath;
				File downloadDir = new File(directoryName);
				if (downloadDir.exists())
					downloadFile(assetId, new AssetVersion(Long.valueOf(majorVersionId), Long.valueOf(minorVersionId)),
							versionEle.getAttribute("VersionName"), directoryName, archivePath, revisionsSuccessfullyArchived, assetPath);
				else {
					boolean success = downloadDir.mkdirs();
					if (!success) {
						logger.error("Problem occured while creating the directory.");
						throw new ArchiveException(ArchiveExceptionCodes.INVALID_ARCHIVE_PATH, new String[] { directoryName });
					} else {
						logger.trace("Directory created with name : " + directoryName);
						downloadFile(assetId, new AssetVersion(Long.valueOf(majorVersionId), Long.valueOf(minorVersionId)),
								versionEle.getAttribute("VersionName"), directoryName, archivePath, revisionsSuccessfullyArchived,
								assetPath);
					}
				}
				// write the asset version Archive.xml file
				File archiveXmlFile = new File(directoryName + File.separator + "Archive.xml");
				writeDocumentToXmlFile(dom, archiveXmlFile);
				archivedSuccessfully = true;
			} else {
				logger.trace("Asset id: " + assetId + " and version: " + majorVersionId + "." + minorVersionId
						+ ", already downloaded. Skipping download.");
				archivedSuccessfully = false;
			}

		} catch (NumberFormatException e) {
			logger.error("Exception occured while downloading asset id: " + assetId + " and version: " + majorVersionId + "."
					+ minorVersionId, e);
		}
		return archivedSuccessfully;
	}

	/**
	 * Download the QPP asset version, and update the successful archives record with relevant asset info.
	 * 
	 * @param assetId
	 * @param assetVersion
	 * @param assetVersionName
	 * @param directoryName
	 * @param archivePath
	 * @param revisionsSuccessfullyArchived
	 * @throws Exception
	 */
	private void downloadFile(long assetId, AssetVersion assetVersion, String assetVersionName, String directoryName, String archivePath,
			ArrayList<AssetInfo> revisionsSuccessfullyArchived, String assetPath) throws Exception {
		boolean contextCreated = false;
		long contextId = -1;
		FileOutputStream fileOutputStream = null;
		try {
			assetVersionName = assetVersionName.replaceAll("<|>|:|\"|/|\\\\|\\||\\?|\\*", "_");
			fileOutputStream = new FileOutputStream(new File(directoryName + File.separator + assetVersionName));
			contextId = assetService.createReadContext(assetId, assetVersion, DefaultRenditionTypes.HIGH_RES);
			contextCreated = true;
			defaultStreamingService.download(fileOutputStream, contextId);

			// update revisionsSuccessfullyArchived record with assetInfo data for writing to Index.xml file
			AssetInfo assetInfo = new AssetInfo(assetId, assetVersion.getMajorVersion(), assetVersion.getMinorVersion(), archivePath,
					assetPath);
			revisionsSuccessfullyArchived.add(assetInfo);
			logger.trace("Downloaded asset with id: " + assetId + " and version: " + assetVersion.getMajorVersion() + "."
					+ assetVersion.getMinorVersion());

		} finally {
			if (fileOutputStream != null)
				fileOutputStream.close();
			if (contextCreated)
				assetService.closeContext(contextId);
		}
	}

	/**
	 * Finally delete successfully archived assets, and print the summary log file and index xml file upon archive completion.
	 * 
	 * @param deleteAfterArchive
	 * @param destinationFolder
	 * @param revisionsSuccessfullyArchived
	 * @param revisionsFailedToArchive
	 * @throws QppServiceException
	 * @throws Exception
	 */
	private String logArchive(boolean deleteAfterArchive, String destinationFolder, ArrayList<AssetInfo> revisionsSuccessfullyArchived,
			Map<String, String> revisionsFailedToArchive, ArrayList<Long> assetsSelectedForArchive, ArrayList<String> assetsFailedToArchive)
			throws QppServiceException {
		// if delete after archive is true, delete all the assets
		if (deleteAfterArchive)
			deleteAssetsAfterArchiving(assetsSelectedForArchive);

		// print the log file with details of the archive operation
		String logText = printLogFile(destinationFolder, assetsSelectedForArchive.size(), assetsFailedToArchive.size(),
				revisionsFailedToArchive, revisionsSuccessfullyArchived);

		// print index.xml with assets archived information
		printIndexXml(destinationFolder, revisionsSuccessfullyArchived);

		return logText;
	}

	private void deleteAssetsAfterArchiving(ArrayList<Long> assetsSelectedForArchive) {
		logger.trace("-- Archived assets deletion process started. --");
		ArrayList<Long> assetsToDelete = new ArrayList<Long>();
		for (Long selectedAssetId : assetsSelectedForArchive) {
			try {
				if (!assetsToDelete.contains(selectedAssetId)) {
					logger.trace("Deleting asset with id: " + selectedAssetId);
					assetService.lockAsset(selectedAssetId);
					assetService.deleteAsset(selectedAssetId);
					assetsToDelete.add(selectedAssetId);
				}
			} catch (Exception e) {
				logger.error("Unable to delete asset: " + selectedAssetId, e);
			}
		}
		logger.trace("-- Deletion process completed. --");

	}

	private void writeDocumentToXmlFile(Document document, File file) throws TransformerException, IOException, QppServiceException {
		FileOutputStream xmlOutputStream = null;
		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");
			DOMSource source = new DOMSource(document);
			try {
				xmlOutputStream = new FileOutputStream(file);

			} catch (FileNotFoundException e) {
				logger.error("Unable to write index xml file.", e);
				throw new ArchiveException(ArchiveExceptionCodes.FILE_IO_ERROR_OCCURED);
			}
			StreamResult result = new StreamResult(xmlOutputStream);
			transformer.transform(source, result);
			xmlOutputStream.close();
		} finally {
			if (xmlOutputStream != null) {
				xmlOutputStream.close();
			}
		}
	}

	private String printLogFile(String destinationFolder, int assetsSuccessfullyArchivedCount, int assetsFailedToArchiveCount,
			Map<String, String> revisionsFailedToArchive, ArrayList<AssetInfo> revisionsSuccessfullyArchived) throws QppServiceException {
		FileOutputStream fileOutputStream = null;
		try {
			File folder = new File(destinationFolder);

			boolean success = false;
			// folder will not be created earlier if there were no assets to be archived
			// create it now to write the log files
			if (!folder.exists()) {
				success = folder.mkdirs();
				if (!success) {
					logger.error("Unable to write summary log file. Archive folder does not exist.");
					throw new ArchiveException(ArchiveExceptionCodes.INVALID_ARCHIVE_PATH, new String[] { destinationFolder });
				}
			}

			File file = null;
			try {
				file = new File(destinationFolder + File.separator + "ArchiveSummary.log");
				fileOutputStream = new FileOutputStream(file);

			} catch (FileNotFoundException e) {
				logger.error("Unable to write summary log file.", e);
				throw new ArchiveException(ArchiveExceptionCodes.FILE_IO_ERROR_OCCURED, new String[] { destinationFolder });
			}

			StringBuilder sb = new StringBuilder();
			sb.append("\n\n" + "Archive Summary Log" + "\n\n");

			// format current date to the desired format
			SimpleDateFormat formatter = new SimpleDateFormat("M/dd/yy HH:mm a");
			String outputText = formatter.format(new Date());
			Date date = formatter.parse(outputText);
			sb.append("Date: " + formatter.format(date) + "\n");

			sb.append("Archive location: " + destinationFolder + "\n\n");

			sb.append("Total assets to be archived: " + (assetsSuccessfullyArchivedCount + assetsFailedToArchiveCount) + "\n");
			sb.append("Number of assets successfully archived: " + assetsSuccessfullyArchivedCount + "\n");
			sb.append("Number of assets failed to archive: " + assetsFailedToArchiveCount + "\n\n");
			sb.append("Per Version Listing of Assets\n");
			if (revisionsSuccessfullyArchived.size() != 0) {
				sb.append("-----------------------------------------------------------" + "\n");
				sb.append("Asset Versions Successfully Archived: " + "\n");
				sb.append("-----------------------------------------------------------" + "\n");
				for (AssetInfo assetInfo : revisionsSuccessfullyArchived) {
					sb.append("&nbsp; &nbsp;" + assetInfo.getAssetPath() + ", Version: " + assetInfo.getMajorVersion() + "."
							+ assetInfo.getMinorVersion() + "\n");
				}
				sb.append("\n");
			}
			if (revisionsFailedToArchive.size() != 0) {
				sb.append("-----------------------------------------------------------" + "\n");
				sb.append("Asset Versions Failed to Archive: " + "\n");
				sb.append("-----------------------------------------------------------" + "\n");
				for (Map.Entry<String, String> entry : revisionsFailedToArchive.entrySet()) {
					sb.append("&nbsp; &nbsp;" + entry.getKey() + "\n &nbsp; &nbsp;Reason: " + entry.getValue() + "\n");
				}
			}
			sb.append("\n");

			String logText = sb.toString();
			fileOutputStream.write(logText.getBytes());
			return logText;

		} catch (IOException e) {
			logger.error("Unable to write summary log file.", e);
			return null;
		} catch (ParseException e) {
			logger.error("Unable to write summary log file.", e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					logger.error("Exception occured in writing ArchiveSummary.log file: ", e);
				}
			}
		}
	}

	private void printIndexXml(String destinationFolder, ArrayList<AssetInfo> revisionsSuccessfullyArchived) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = null;
			db = dbf.newDocumentBuilder();

			Document document = db.newDocument();
			Element root = document.createElement("AssetsArchivedRoot");
			document.appendChild(root);

			Element asset = null;
			for (AssetInfo assetInfo : revisionsSuccessfullyArchived) {
				asset = document.createElement("AssetArchived");
				asset.setAttribute("assetId", assetInfo.getAssetId() + "");
				asset.setAttribute("majorVersion", assetInfo.getMajorVersion() + "");
				asset.setAttribute("minorVersion", assetInfo.getMinorVersion() + "");
				asset.setAttribute("path", assetInfo.getPath());
				root.appendChild(asset);
			}

			File indexFile = new File(destinationFolder + File.separator + "Index.xml");
			writeDocumentToXmlFile(document, indexFile);

		} catch (Exception e) {
			logger.error("Unable to write index xml file: ", e);

		}
	}

	private boolean checkFilePermissions(String destinationFolder) throws ArchiveException {
		File file = new File(destinationFolder);
		boolean hasAccess = false;
		try {
			File.createTempFile("check", null, file).delete();
			hasAccess = true;
		} catch (IOException e) {
			throw new ArchiveException(ArchiveExceptionCodes.FILE_IO_ERROR_OCCURED, new String[] { destinationFolder });
		}
		return hasAccess;
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceExceptionInfo.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

	/**
	 * This class contains information regarding a particular asset id, version and the corresponding archive path to its high-res file.
	 * 
	 */
	private class AssetInfo {
		private long assetId;
		private long majorVersion;
		private long minorVersion;
		private String path;
		private String assetPath;

		public AssetInfo(long assetId, long majorVersion, long minorVersion) {
			this.assetId = assetId;
			this.majorVersion = majorVersion;
			this.minorVersion = minorVersion;
		}

		public AssetInfo(long assetId, long majorVersion, long minorVersion, String path) {
			this.assetId = assetId;
			this.majorVersion = majorVersion;
			this.minorVersion = minorVersion;
			this.path = path;
		}

		public AssetInfo(long assetId, long majorVersion, long minorVersion, String path, String assetPath) {
			this.assetId = assetId;
			this.majorVersion = majorVersion;
			this.minorVersion = minorVersion;
			this.path = path;
			this.assetPath = assetPath;
		}

		public long getAssetId() {
			return assetId;
		}

		public long getMajorVersion() {
			return majorVersion;
		}

		public long getMinorVersion() {
			return minorVersion;
		}

		public String getPath() {
			return path;
		}

		public String getAssetPath() {
			return assetPath;
		}

		@Override
		public boolean equals(Object assetInfo2) {
			if (!(assetInfo2 instanceof AssetInfo))
				return false;
			AssetInfo assetInfoObj = (AssetInfo) assetInfo2;
			return (assetId == assetInfoObj.assetId) && (majorVersion == assetInfoObj.majorVersion)
					&& (minorVersion == assetInfoObj.minorVersion) && (path != null ? path.equals(assetInfoObj.path) : true);
		}
	}
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.InvalidTimeZoneFormatException;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.security.service.dto.Session;
import com.quark.qpp.core.security.service.exceptions.AuthenticationFailedException;
import com.quark.qpp.core.security.service.exceptions.InvalidSessionException;
import com.quark.qpp.core.security.service.exceptions.SessionNotFoundException;
import com.quark.qpp.core.security.service.local.SessionService;
import com.quark.qpp.licensing.service.exceptions.LicenseNotAvailableException;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.CommonUtility;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.SessionInfo;
import com.quark.qpp.service.xmlBinding.SessionInfoList;

/**
 * Logs users on and off the system. It also provides other related operations that can be performed on the session.
 * 
 */

@Controller(value = "sessionFacade")
@RequestMapping("/sessions")
public class SessionFacade {

	@Autowired
	private SessionService sessionService;

	@Autowired
	private ObjectTransformer objectTransformer;

	/**
	 * LogOn / LogOnAs a user on the server.Incase the asUserName request parameter in not null , the user will logOn to
	 * QPP impersonating another user.
	 * 
	 * @param userName
	 *            Name of the impersonating user.
	 * @param password
	 *            Encrypted password of the impersonating user.
	 * @param asUserName
	 *            The user being impersonated
	 * @param machineName
	 *            Name of the machine from which client has logged on
	 * @param applicationName
	 *            Name of the application from which client has logged on
	 * @return SessionInfo created for the user.
	 * @throws AuthenticationFailedException
	 *             If there is any authentication-related problem - e.g., username not valid, password not valid.
	 * @throws InvalidTimeZoneFormatException
	 *             If the time-zone offset format provided is invalid.
	 * @throws LicenseNotAvailableException
	 *             If no license is available with the System.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{username}", params = "op=logon")
	@WebReturnType("xmlView")
	public SessionInfo logOn(@PathVariable("username") String userName, @RequestParam(value="password", required=false) String password,
			@RequestParam(value = "asusername", defaultValue = "") String asUserName,
			@RequestParam(value = "machinename", defaultValue = "localhost") String machineName,
			@RequestParam(value = "appname", defaultValue = "Rest Client") String applicationName) throws AuthenticationFailedException,
			InvalidTimeZoneFormatException, LicenseNotAvailableException, QppServiceException {
		String dateOffset = CommonUtility.getTimeZoneOffset();
		Session session = logon(userName, password, asUserName, applicationName, machineName, dateOffset);
		return objectTransformer.transform(session);
	}

	/**
	 * Validates the given username, password combination.
	 * 
	 * @param userName
	 *            Name of the user
	 * @param password
	 *            Password of the user
	 * @return true if the username password combination is valid, false otherwise
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{username}", params = "op=validate")
	@WebReturnType("textView")
	public Boolean validatePassword(@PathVariable("username") String userName, @RequestParam("password") String password) throws QppServiceException {
		Boolean validPassword = sessionService.validatePassword(userName, CommonUtility.getEncryptedPassword(password));
		return validPassword;
	}

	/**
	 * Logs off the user from the system.
	 * 
	 * @throws SessionNotFoundException
	 *             If the session from which this API is called is invalid or not active.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=logoff")
	public void logOff() throws SessionNotFoundException, QppServiceException {
		sessionService.logOff();
	}

	/**
	 * Terminates a session with the given sessionId.
	 * 
	 * @param sessionId
	 *            Id of the session to be terminated.
	 * @throws SessionNotFoundException
	 *             If the session with the given id does not exist in the server.
	 * @throws InvalidSessionException
	 *             If the user is trying to terminate its own session.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{sessionId}", params = "op=delete")
	public void terminateSession(@PathVariable("sessionId") String sessionId) throws SessionNotFoundException, InvalidSessionException,
			QppServiceException {
		sessionService.terminateSession(sessionId);
	}

	/**
	 * Gets the maximum time in seconds for which the session can remain active without calling the server or calling
	 * keepSessionAlive().
	 * 
	 * @return Maximum idle time in seconds.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=maxidletime")
	@WebReturnType("textView")
	public long getMaxIdleTime() throws QppServiceException {
		long sessionMaxIdleTime = sessionService.getMaxIdleTime();
		return sessionMaxIdleTime;
	}

	/**
	 * In case clients do not want to time-out (even in case of no activity), they can call this API at regular
	 * intervals to prevent time-out.
	 * 
	 * @throws QppServiceException
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=keepalive")
	public void keepSessionAlive() throws QppServiceException {
		sessionService.keepSessionAlive();
	}

	/**
	 * Returns the session info for a given session id.
	 * 
	 * @param sessionId
	 *            Id of the required session.
	 * @return Required SessionInfo object.
	 * @throws SessionNotFoundException
	 *             If the session with the given id does not exist in the server.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{sessionId}")
	@WebReturnType("xmlView")
	public SessionInfo getSession(@PathVariable(value = "sessionId") String sessionId) throws SessionNotFoundException, QppServiceException {
		Session session = sessionService.getSession(sessionId);
		return objectTransformer.transform(session);
	}

	/**
	 * Returns all sessions that are currently active.
	 * 
	 * @return Array of all active sessions.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType("xmlView")
	public SessionInfoList getAllSessions() throws QppServiceException {
		Session[] sessions = sessionService.getAllSessions();
		return objectTransformer.transform(sessions);
	}

	private Session logon(String userName, String password, String asUserName, String applicationName, String machineName, String dateOffSet)
			throws AuthenticationFailedException, InvalidTimeZoneFormatException, LicenseNotAvailableException, QppServiceException {
		Session session = null;
		if (asUserName == null || asUserName.length() <= 0) {
			session = sessionService.logOn(userName, CommonUtility.getEncryptedPassword(password), machineName, applicationName, dateOffSet);
		} else {
			session = sessionService.logOnAs(userName, CommonUtility.getEncryptedPassword(password), asUserName, machineName, applicationName,
					dateOffSet);
		}
		return session;
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

}

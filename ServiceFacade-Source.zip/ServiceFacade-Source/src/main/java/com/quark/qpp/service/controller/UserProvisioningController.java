/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.security.service.dto.Group;
import com.quark.qpp.core.security.service.dto.ImportedGroupInfo;
import com.quark.qpp.core.security.service.dto.Trustee;
import com.quark.qpp.core.security.service.dto.User;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.userprovisioning.service.constants.LdapSearchTypes;
import com.quark.qpp.core.userprovisioning.service.dto.LdapAttributeValue;
import com.quark.qpp.core.userprovisioning.service.dto.LdapProfile;
import com.quark.qpp.core.userprovisioning.service.dto.LdapQueryDefinition;
import com.quark.qpp.core.userprovisioning.service.dto.LdapSearchCriteria;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapAttributesException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapQueryDefinitionException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapSearchCriteriaException;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapAttributesExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapProfileExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserSourceAccessException;
import com.quark.qpp.core.userprovisioning.service.local.UserProvisioningService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.CommonUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.ImportedGroupInfoList;
import com.quark.qpp.service.xmlBinding.LdapAttributeInfoList;
import com.quark.qpp.service.xmlBinding.LdapProfileInfo;
import com.quark.qpp.service.xmlBinding.LdapProfileInfoList;
import com.quark.qpp.service.xmlBinding.LdapSearchInfo;
import com.quark.qpp.service.xmlBinding.LdapSearchInfoList;
import com.quark.qpp.service.xmlBinding.UserInfoList;

public class UserProvisioningController {

	@Autowired
	private UserProvisioningService userProvisioningService;

	@Autowired
	private ObjectTransformer objectTransformer;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private TrusteeService trusteeService;

	private final Logger logger = Logger.getLogger(this.getClass());

	public LdapProfileInfoList getAllLdapProfiles() throws QppServiceException {
		LdapProfile[] ldapProfiles = userProvisioningService.getAllLdapProfiles();
		LdapProfileInfoList ldapProfileInfoList = objectTransformer.transform(ldapProfiles);
		return ldapProfileInfoList;
	}

	public LdapProfileInfoList getLdapProfile(String ldapProfileIdOrName) throws InvalidLdapProfileException, QppServiceException {
		long ldapProfileId = getLdapProfileId(ldapProfileIdOrName);
		LdapProfile ldapProfile = userProvisioningService.getLdapProfile(ldapProfileId);
		LdapProfileInfo ldapProfileInfo = objectTransformer.transform(ldapProfile);
		LdapProfileInfoList ldapProfileInfoList = new LdapProfileInfoList();
		ldapProfileInfoList.getLdapProfileInfo().add(ldapProfileInfo);
		return ldapProfileInfoList;
	}

	public LdapProfileInfoList createLdapProfiles(LdapProfileInfoList ldapProfileInfoList)
			throws InvalidLdapProfileException, QppServiceException {
		LdapProfileInfoList createdLdapProfilesList = new LdapProfileInfoList();
		if (ldapProfileInfoList != null) {
			Iterator<LdapProfileInfo> iterator = ldapProfileInfoList.getLdapProfileInfo().iterator();
			while (iterator.hasNext()) {
				LdapProfileInfo profileInfo = iterator.next();
				try {
					LdapProfileInfo newProfileInfo = createLdapProfile(profileInfo);
					createdLdapProfilesList.getLdapProfileInfo().add(newProfileInfo);
				} catch (QppServiceException e) {
					logger.error("Error while creating Ldap profile with name " + profileInfo.getName(), e);
					if (ldapProfileInfoList.getLdapProfileInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidLdapProfileException(InvalidLdapProfileExceptionCodes.INVALID_PROFILE);
		}
		return createdLdapProfilesList;
	}

	private LdapProfileInfo createLdapProfile(LdapProfileInfo ldapProfileInfo) throws InvalidLdapProfileException, QppServiceException {
		LdapProfile ldapProfile = objectTransformer.transform(ldapProfileInfo);
		long newLdapProfileId = userProvisioningService.createLdapProfile(ldapProfile);
		LdapProfile newLdapProfile = userProvisioningService.getLdapProfile(newLdapProfileId);
		return objectTransformer.transform(newLdapProfile);
	}

	public LdapProfileInfoList updateLdapProfiles(LdapProfileInfoList ldapProfileInfoList)
			throws InvalidLdapProfileException, QppServiceException {
		LdapProfileInfoList updatedLdapProfileInfoList = new LdapProfileInfoList();
		if (ldapProfileInfoList != null) {
			Iterator<LdapProfileInfo> it = ldapProfileInfoList.getLdapProfileInfo().iterator();
			while (it.hasNext()) {
				LdapProfileInfo profileInfo = it.next();
				try {
					LdapProfileInfo updatedProfileInfo = updateLdapProfile(profileInfo);
					updatedLdapProfileInfoList.getLdapProfileInfo().add(updatedProfileInfo);
				} catch (QppServiceException e) {
					logger.error("Error while updating ldap profile with id " + profileInfo.getId() + " and LDAP profile name "
							+ profileInfo.getName(), e);
					if (ldapProfileInfoList.getLdapProfileInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidLdapProfileException(InvalidLdapProfileExceptionCodes.INVALID_PROFILE);
		}
		return updatedLdapProfileInfoList;
	}

	public void deleteLdapProfile(String profile) throws InvalidLdapProfileException, QppServiceException {
		long ldapProfileId = getLdapProfileId(profile);
		userProvisioningService.deleteLdapProfile(ldapProfileId);
	}

	private LdapProfileInfo updateLdapProfile(LdapProfileInfo ldapProfileInfo) throws InvalidLdapProfileException, QppServiceException {
		LdapProfile ldapProfile = objectTransformer.transform(ldapProfileInfo);
		long profileId = -1;
		if (ldapProfileInfo.getId() == null) {
			profileId = getLdapProfileId(ldapProfile.getName());
		} else {
			profileId = ldapProfileInfo.getId();
		}
		ldapProfile.setId(profileId);
		LdapProfile updatedLdapProfile = userProvisioningService.updateLdapProfile(ldapProfile);
		return objectTransformer.transform(updatedLdapProfile);
	}

	private long getLdapProfileId(String profileIdOrName) throws InvalidLdapProfileException, QppServiceException {
		long id = 0;
		try {
			id = Long.parseLong(profileIdOrName);
		} catch (NumberFormatException e) {
			id = getProfileIdByName(profileIdOrName);
		}
		return id;
	}

	private long getProfileIdByName(String profileName) throws InvalidLdapProfileException, QppServiceException {
		LdapProfile[] profiles = userProvisioningService.getAllLdapProfiles();
		for (LdapProfile ldapProfile : profiles) {
			if (ldapProfile.getName().equalsIgnoreCase(profileName)) {
				return ldapProfile.getId();
			}
		}
		throw new InvalidLdapProfileException(InvalidLdapProfileExceptionCodes.INVALID_PROFILE);
	}

	public LdapAttributeInfoList getAllLdapAttributesValue() throws QppServiceException {
		LdapAttributeValue[] ldapAttributeValues = null;//userProvisioningService.getAllLdapAttributesValue();
		return objectTransformer.transform(ldapAttributeValues);
	}

	public LdapAttributeInfoList setLdapAttributeValues(LdapAttributeInfoList ldapAttributeInfoList)
			throws InvalidLdapAttributesException, QppServiceException {
		LdapAttributeValue[] updatedLdapAttributeValues = null;
		if(ldapAttributeInfoList!=null && ldapAttributeInfoList.getLdapAttributeInfo()!=null && ldapAttributeInfoList.getLdapAttributeInfo().size()>0){
			LdapAttributeValue[] ldapAttributeValues = objectTransformer.transform(ldapAttributeInfoList);
			updatedLdapAttributeValues = null;//userProvisioningService.updateLdapAttributesValue(ldapAttributeValues);
		}else{
			throw new InvalidLdapAttributesException(InvalidLdapAttributesExceptionCodes.INVALID_LDAP_ATTRIBUTES);
		}
		return objectTransformer.transform(updatedLdapAttributeValues);
	}
	
	public UserInfoList importUsersFromLdap(String savedLdapQueryNameOrId, String ldapProfileNameOrId, String baseString, String searchFilter,
			String defaultUserClassIdOrName, int pageSize) throws InvalidLdapProfileException,
			InvalidLdapSearchCriteriaException, InvalidLdapQueryDefinitionException, UserSourceAccessException, QppServiceException {
		if ((savedLdapQueryNameOrId != null && !savedLdapQueryNameOrId.isEmpty()) || (ldapProfileNameOrId != null && !ldapProfileNameOrId.isEmpty())) {
			Trustee[] ldapTrustees = fetchLdapTrustees(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize, LdapSearchTypes.USERS_SEARCH);
			User[] ldapUsers = Arrays.asList(ldapTrustees).toArray(new User[0]);
			return importUsers(ldapUsers, defaultUserClassIdOrName);
		}else{
			throw new InvalidLdapProfileException();
		}
	}
	
	public UserInfoList getLdapUsers(String savedLdapQueryNameOrId, String ldapProfileNameOrId, String baseString, String searchFilter,
			int pageSize) throws InvalidLdapQueryDefinitionException, InvalidLdapProfileException, InvalidLdapSearchCriteriaException,
			UserSourceAccessException, QppServiceException {
		Trustee[] ldapTrustees = fetchLdapTrustees(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize, LdapSearchTypes.USERS_SEARCH);
		User[] ldapUsers = Arrays.asList(ldapTrustees).toArray(new User[0]);
		return objectTransformer.transform(ldapUsers);
	}
	
	public GroupInfoList getLdapGroups(String savedLdapQueryNameOrId,
			String ldapProfileNameOrId, String baseString, String searchFilter,
			int pageSize) throws InvalidLdapQueryDefinitionException, InvalidLdapProfileException, InvalidLdapSearchCriteriaException,
			UserSourceAccessException, QppServiceException {
		Trustee[] ldapTrustees = fetchLdapTrustees(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize, LdapSearchTypes.GROUPS_SEARCH);
		Group[] ldapGroups = Arrays.asList(ldapTrustees).toArray(new Group[0]);
		return objectTransformer.transform(ldapGroups, true);
	}
	
	
	private Trustee[] fetchLdapTrustees(String savedLdapQueryNameOrId, String ldapProfileNameOrId, String baseString, String searchFilter,
			int pageSize, int searchType) throws InvalidLdapQueryDefinitionException, InvalidLdapProfileException, InvalidLdapSearchCriteriaException,
			UserSourceAccessException, QppServiceException {
		long usersIteratorId = -1;
		if (savedLdapQueryNameOrId != null && !savedLdapQueryNameOrId.isEmpty()) {
			long ldapQueryDefId = facadeUtility.getLdapQueryDefId(savedLdapQueryNameOrId);
			usersIteratorId = userProvisioningService.openIteratorForQueryId(pageSize, ldapQueryDefId);
		} else {
			long ldapProfileId = facadeUtility.getLdapProfileId(ldapProfileNameOrId);
			LdapSearchCriteria ldapSearchCriteria = new LdapSearchCriteria();
			ldapSearchCriteria.setBaseString(baseString);
			ldapSearchCriteria.setLdapProfileId(ldapProfileId);
			ldapSearchCriteria.setSearchFilter(searchFilter);
			ldapSearchCriteria.setSearchType(searchType);
			usersIteratorId = userProvisioningService.openIteratorForLdapSearchCriteria(pageSize, ldapSearchCriteria);
		}
		try {
			Trustee[] ldapUsers = userProvisioningService.getNextResults(usersIteratorId);
			return ldapUsers;			
		} finally {
			userProvisioningService.closeIterator(usersIteratorId);
		}
	}
	
	private UserInfoList importUsers(User[] ldapUsers, String defaultUserClassIdOrName) throws InvalidLdapSearchCriteriaException, UserSourceAccessException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(defaultUserClassIdOrName);
		ArrayList<User> ldapUsersToBeImported = new ArrayList<User>();
		for (int i = 0; ldapUsers !=null && i < ldapUsers.length; i++) {
			try {
				trusteeService.getUserId(ldapUsers[i].getName());
				logger.warn("User with given name alreday exist. " + ldapUsers[i].getName());
			} catch(UserNotFoundException e){
				ldapUsersToBeImported.add(ldapUsers[i]);
			}
		}
		User[] usersImported = new User[ldapUsersToBeImported.size()];
		for (int i = 0; ldapUsersToBeImported != null && i < ldapUsersToBeImported.size(); i++) {
			User userToBeImported = ldapUsersToBeImported.get(i);
			userToBeImported.setDefaultUserClassId(userClassId);
			long userId = trusteeService.createUser(userToBeImported, CommonUtility.getEncryptedPassword(""));
			User userinfo = trusteeService.getUser(userId);
			usersImported[i] = userinfo;
		}
		return objectTransformer.transform(usersImported);
	}

	public ImportedGroupInfoList importGroupsFromLdap(String savedLdapQueryNameOrId, String ldapProfileNameOrId, String baseString, String searchFilter,String defaultUserClassIdOrName, int pageSize) throws InvalidLdapQueryDefinitionException, InvalidLdapProfileException, InvalidLdapSearchCriteriaException, UserSourceAccessException, QppServiceException {
		if ((savedLdapQueryNameOrId != null && !savedLdapQueryNameOrId.isEmpty()) || (ldapProfileNameOrId != null && !ldapProfileNameOrId.isEmpty())) {
			Trustee[] ldapTrustees = fetchLdapTrustees(savedLdapQueryNameOrId, ldapProfileNameOrId, baseString, searchFilter, pageSize, LdapSearchTypes.GROUPS_SEARCH);
			Group[] ldapGroups = Arrays.asList(ldapTrustees).toArray(new Group[0]);
			return importGroups(ldapGroups, defaultUserClassIdOrName);
		} else {
			throw new InvalidLdapProfileException();
		}
	}

	private ImportedGroupInfoList importGroups(Group[] ldapGroups,
			String defaultUserClassIdOrName) throws UserClassNotFoundException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(defaultUserClassIdOrName);
		for (int i = 0; ldapGroups!=null && i < ldapGroups.length; i++) {
			ldapGroups[i].setDefaultUserClassId(userClassId);
		}
		ImportedGroupInfo[] groupInfos = trusteeService.importGroupFromLdap(ldapGroups);
		
		ImportedGroupInfoList importedGroupInfoList = objectTransformer.transform(groupInfos);
		
		return importedGroupInfoList;		
	}
	
	public void addAllToList (ArrayList<Long> idsList, long[] idsArray) {
	    for (int x = 0; x < idsArray.length; x++) {
	    	idsList.add(idsArray[x]);
	    }	  
	}

	public LdapSearchInfoList getAllLdapQueryDefinitions() throws QppServiceException {
		LdapQueryDefinition[] ldapQueryDefinitions = userProvisioningService.getAllLdapQueryDefinitions();
		return objectTransformer.transform(ldapQueryDefinitions);
	}

	public LdapSearchInfoList getLdapQueryDefinition(String queryIdOrName) throws InvalidLdapQueryDefinitionException, QppServiceException {
		long queryId = facadeUtility.getLdapQueryDefId(queryIdOrName);
		LdapQueryDefinition ldapQueryDefinition = userProvisioningService.getLdapQueryDefinition(queryId);
		return objectTransformer.transform(new LdapQueryDefinition[] { ldapQueryDefinition });
	}

	public LdapSearchInfoList createLdapQueryDefinitions(LdapSearchInfoList ldapSearchInfoList) throws InvalidLdapProfileException,
			InvalidLdapQueryDefinitionException, InvalidLdapSearchCriteriaException, QppServiceException {
		if (ldapSearchInfoList == null || ldapSearchInfoList.getLdapSearchInfo() == null
				|| ldapSearchInfoList.getLdapSearchInfo().size() == 0) {
			return new LdapSearchInfoList();
		}
		ArrayList<LdapSearchInfo> searchList = (ArrayList<LdapSearchInfo>) ldapSearchInfoList.getLdapSearchInfo();
		LdapSearchInfoList successfullyCreatedList = new LdapSearchInfoList();
		for (int i = 0; searchList != null && i < searchList.size(); i++) {
			LdapSearchInfo ldapSearchInfo = searchList.get(i);
			if (ldapSearchInfo != null) {
				try {
					LdapQueryDefinition ldapQueryDefinition = objectTransformer.transform(ldapSearchInfo);
					long queryId = userProvisioningService.createLdapQueryDefinition(ldapQueryDefinition);
					LdapQueryDefinition ldapQueryDefinitionCreated = userProvisioningService.getLdapQueryDefinition(queryId);
					LdapSearchInfo ldapSearchInfoCreated = objectTransformer.transform(ldapQueryDefinitionCreated);
					successfullyCreatedList.getLdapSearchInfo().add(ldapSearchInfoCreated);
				} catch (QppServiceException e) {
					if (searchList.size() == 1) {
						throw e;
					} else {
						logger.error("Error occurred while creating LDAP query definition with name : " + ldapSearchInfo.getName(), e);
					}
				}
			}
		}
		return successfullyCreatedList;
	}

	public LdapSearchInfoList updateLdapQueryDefinitions(LdapSearchInfoList ldapSearchInfoList) throws QppServiceException {
		if (ldapSearchInfoList == null || ldapSearchInfoList.getLdapSearchInfo() == null
				|| ldapSearchInfoList.getLdapSearchInfo().size() == 0) {
			return new LdapSearchInfoList();
		}
		ArrayList<LdapSearchInfo> searchList = (ArrayList<LdapSearchInfo>) ldapSearchInfoList.getLdapSearchInfo();
		LdapSearchInfoList successfullyCreatedList = new LdapSearchInfoList();
		for (int i = 0; searchList != null && i < searchList.size(); i++) {
			LdapSearchInfo ldapSearchInfo = searchList.get(i);
			if (ldapSearchInfo != null) {
				try {
					Long id = ldapSearchInfo.getId();
					if (id == null || id <= 0) {
						id = facadeUtility.getLdapQueryDefId(ldapSearchInfo.getName());
						ldapSearchInfo.setId(id);
					}
					LdapQueryDefinition ldapQueryDefinition = objectTransformer.transform(ldapSearchInfo);
					LdapQueryDefinition updatedLdapQueryDefinition = userProvisioningService.updateLdapQueryDefinition(ldapQueryDefinition);
					LdapSearchInfo ldapSearchInfoCreated = objectTransformer.transform(updatedLdapQueryDefinition);
					successfullyCreatedList.getLdapSearchInfo().add(ldapSearchInfoCreated);
				} catch (QppServiceException e) {
					if (searchList.size() == 1) {
						throw e;
					} else {
						logger.error("Error occurred while updating LDAP query definition with name : " + ldapSearchInfo.getName(), e);
					}
				}
			}
		}
		return successfullyCreatedList;
	}

	public void deleteLdapQueryDefinition(String queryIdOrName) throws InvalidLdapQueryDefinitionException, QppServiceException {
		long queryId = facadeUtility.getLdapQueryDefId(queryIdOrName);
		userProvisioningService.deleteLdapQueryDefinition(queryId);
	}

}

/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.preference.service.constants.PreferenceConstants.Category;
import com.quark.qpp.core.preference.service.dto.FavoriteItem;
import com.quark.qpp.core.preference.service.dto.Preference;
import com.quark.qpp.core.preference.service.dto.PreferenceValue;
import com.quark.qpp.core.preference.service.exceptions.InvalidFavoriteItemException;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceException;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceValueException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceNotFoundException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceValueNotFoundException;
import com.quark.qpp.core.preference.service.local.PreferenceService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.FavoriteItemlist;
import com.quark.qpp.service.xmlBinding.PreferenceInfoList;
import com.quark.qpp.service.xmlBinding.PreferenceValueList;


public class PreferenceController {

	@Autowired
	private PreferenceService preferenceService;

	@Autowired
	private ObjectTransformer objectTranformer;

	@Autowired
	private FacadeUtility facadeUtility;

	private Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * Returns all the existing preference definitions. If the preference has possible values, then the PreferenceInfo object contains a
	 * list of all possible values along with the default value id and default value. If the preference has no possible values, then the
	 * list is null. Also, the default value id is invalid and only the default value should be considered.
	 * 
	 * @return {@link PreferenceInfoList} object containing list of all preferences.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public PreferenceInfoList getAllPreferences() throws QppServiceException {
		Preference[] preferences = preferenceService.getAllPreferences();
		return objectTranformer.transform(preferences);
	}

	/**
	 * Gets preference details for preference with the given id or unique name. In case there exists multiple preferences with given name,
	 * then one of the preference's will only be returned.. The input will be assumed to be an id first, but if it leads to exception, then the
	 * input is assumed to be preference name. If the preference has possible values, then the PreferenceInfo object contains list of all
	 * possible values along with the default value id and default values. If the preference has no possible values, then the list is null;
	 * also, the default value id is invalid and only the default value should be considered.
	 * 
	 * @param preferenceIdOrName
	 *            id or name of the preference to be fetched
	 * @return {@link PreferenceInfoList} object containing details of the requested preference.
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name doesn't exist.
	 * @throws InvalidPreferenceException
	 *             In case there exist multiple preferences with given name, then this exception will be thrown. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	public PreferenceInfoList getPreference(String preferenceIdOrName) throws PreferenceNotFoundException,
			QppServiceException {
		Preference preference = null;
		try {
			preference = preferenceService.getPreference(Long.parseLong(preferenceIdOrName));
		} catch (NumberFormatException e) {
			preference = preferenceService.getPreferenceByName(preferenceIdOrName);
		}
		return objectTranformer.transform(new Preference[] { preference });
	}

	/**
	 * Creates multiple preferences using the name, category, defaultValue & possibleValues fields of the each mentioned PreferenceInfo
	 * object. The possibleValues are considered only when the isPossibleValueExists flag is true & default value if mentioned will be
	 * assumed to be among the possibleValues else the first possible value is considered as the default value. But if isPossibleValueExists
	 * flag is false,then only the defaultValue field is considered.
	 * 
	 * @param {@link PreferenceInfoList} object containing list of preferenceInfo objects to be created.
	 * @return {@link PreferenceInfoList} object containing list of all successfully created preferences.
	 * @throws InvalidPreferenceException
	 *             In case of invalid preference name/defaultValue/possibleValues this exception is thrown. The exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public PreferenceInfoList createPreferences(PreferenceInfoList preferenceInfoList)
			throws InvalidPreferenceException, QppServiceException {
		List<Preference> listOfCreatedPreferences = new ArrayList<Preference>();
		Preference[] preferences = objectTranformer.transform(preferenceInfoList);
		for (Preference preference : preferences) {
			try {
				long prefId = preferenceService.createPreference(preference);
				listOfCreatedPreferences.add(preferenceService.getPreference(prefId));
			} catch (QppServiceException e) {
				logger.error("Error while creating preference with the name " + preference.getName(), e);
				if (preferences.length == 1) {
					throw e;
				}
			}
		}
		return objectTranformer.transform(listOfCreatedPreferences.toArray(new Preference[0]));
	}

	/**
	 * Updates the preferences with the given id or name. Id is given preference over name. One can update name, isPossibleValueExists flag,
	 * possibleValues & defaultValue. But one cannot update the category. Only user defined preferences can be updated. It is mandatory to
	 * specify the preference id in case, the preference name is to be updated.
	 * 
	 * @param {@link preferenceInfoList} object containing list of PreferenceInfo's to be updated.
	 * @return {@link PreferenceInfoList} object containing list of all successfully updated preferences.
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name does not exist.
	 * @throws InvalidPreferenceException
	 *             In case of system defined preference or invalid preference name or invalid possible values this exception is thrown. The
	 *             exception code will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public PreferenceInfoList updatePreferences(PreferenceInfoList preferenceInfoList)
			throws PreferenceNotFoundException, InvalidPreferenceException, QppServiceException {
		Preference[] preferences = objectTranformer.transform(preferenceInfoList);
		List<Preference> listOfUpdatedPreferences = new ArrayList<Preference>();
		for (Preference preference : preferences) {
			try {
				if (preference.getId() == 0 && preference.getName() != null) {
					long preferenceId = facadeUtility.getPreferenceId(preference.getName());
					preference.setId(preferenceId);
				}
				preferenceService.updatePreference(preference);
				listOfUpdatedPreferences.add(preferenceService.getPreference(preference.getId()));
			} catch (QppServiceException e) {
				logger.error("Error while updating preference " + preference.getName(), e);
				if (preferences.length == 1) {
					throw e;
				}
			}
		}
		return objectTranformer.transform(listOfUpdatedPreferences.toArray(new Preference[0]));
	}

	/**
	 * Deletes the preference definition with the given id or name. Only user defined preferences can be deleted.
	 * 
	 * @param preferenceIdOrName
	 *            id or name of the preference to be deleted.
	 * @throws PreferenceNotFoundException
	 *             In case the preference with the given id or name doesn't exist.
	 * @throws InvalidPreferenceException
	 *             In case the preference is system defined & can't be deleted.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public void deletePreference(String preferenceIdOrName) throws PreferenceNotFoundException, InvalidPreferenceException,
			QppServiceException {
		long preferenceId = facadeUtility.getPreferenceId(preferenceIdOrName);
		preferenceService.deletePreference(preferenceId);
	}

	/**
	 * Returns the preference values corresponding to the logged-in user. If the preference has possible values, then both valueId and value
	 * would be present for each preference. Otherwise, only the value will be present and the value id would be invalid. Default value will
	 * be returned for those preferences for which the user has not set any value yet.
	 * 
	 * @param preferenceIdOrNames
	 *            Array of preference ids or names for which values are to be fetched.
	 * @return {@link PreferenceValuelist} object containing list of preference values requested.
	 * @throws PreferenceNotFoundException
	 *             In case preference with the given id or name doesn't exist.
	 * @throws InvalidPreferenceException
	 *             In case there exist multiple preferences with given name, then this exception will be thrown. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public PreferenceValueList getPreferenceValues(String[] preferenceIdOrNames)
			throws PreferenceNotFoundException, InvalidPreferenceException, QppServiceException {
		if (preferenceIdOrNames != null) {
			long[] preferenceIds = facadeUtility.getPreferenceIds(preferenceIdOrNames);
			ArrayList<Long> systemPreferences = new ArrayList<Long>();
			ArrayList<Long> userPreferences = new ArrayList<Long>();
			for (int i = 0; i < preferenceIds.length; i++) {
				long preferenceId = preferenceIds[i];
				int category = preferenceService.getPreference(preferenceId).getCategory();
				if (category == Category.SYSTEM) {
					systemPreferences.add(preferenceId);
				} else {
					userPreferences.add(preferenceId);
				}
			}
			PreferenceValue[] systemPreferenceValues = new PreferenceValue[0];
			if(systemPreferences.size()>0){
				systemPreferenceValues = preferenceService.getDefaultPreferenceValues(facadeUtility
						.getLongArray(systemPreferences));
			}
			PreferenceValue[] userPreferenceValues = new PreferenceValue[0];
			if(userPreferences.size() > 0){
				userPreferenceValues = preferenceService.getUserPreferenceValues(facadeUtility.getLongArray(userPreferences));
			}
			
			PreferenceValue[] preferenceValues = new PreferenceValue[systemPreferenceValues.length + userPreferenceValues.length];
			System.arraycopy(systemPreferenceValues, 0, preferenceValues, 0, systemPreferenceValues.length);
			System.arraycopy(userPreferenceValues, 0, preferenceValues, systemPreferenceValues.length, userPreferenceValues.length);
			return objectTranformer.transform(preferenceValues);
		} else {
			throw new InvalidPreferenceException();
		}
	}

	/**
	 * Sets the Preference Values provided, values corresponding to preference ids for a user or system. If the preference value for a user
	 * has to be set, then the user id is implicitly considered as the current logged-in user.
	 * 
	 * 
	 * @param preferenceValuelist
	 *            list of peference values that is to be set for the logged-in user.
	 * @return 
	 * @throws PreferenceNotFoundException
	 *             In case preference with given id or name doesnot exist.
	 * @throws PreferenceValueNotFoundException
	 *             If the value that is to be set for the preference does not exist in the possible values for the preference.
	 * @throws InvalidPreferenceValueException
	 *             If null or empty string is sent for preferences that have no possible values.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public PreferenceValueList updatePreferenceValues(PreferenceValueList preferenceValuelist)
			throws PreferenceNotFoundException, PreferenceValueNotFoundException, InvalidPreferenceValueException, QppServiceException {
		if (preferenceValuelist != null) {
			List<com.quark.qpp.service.xmlBinding.PreferenceValue> list = preferenceValuelist.getPreferenceValue();
			ArrayList<String> preferenceIds = new ArrayList<String>();
			for (int i = 0; list != null && i < list.size(); i++) {
				com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValue = list.get(i);
				Long prefId = preferenceValue.getPreferenceId();
				if (prefId == null && preferenceValue.getPreferenceName() != null) {
					prefId = facadeUtility.getPreferenceId(preferenceValue.getPreferenceName());
					preferenceValue.setPreferenceId(prefId);
				}
				preferenceIds.add(prefId+"");
				if (preferenceValue.getValueId() == null && preferenceValue.getValue() != null) {
					Preference preference = preferenceService.getPreference(prefId);
					if (preference.isPossibleValuesExist()) {
						PreferenceValue[] possibleValues = preference.getPossibleValues();
						for (int j = 0; j < possibleValues.length; j++) {
							if (possibleValues[j].getValue().equals(preferenceValue.getValue())) {
								preferenceValue.setValueId(possibleValues[j].getValueId());
								break;
							}
						}
					}
				}
			}
			PreferenceValue[] preferenceValues = objectTranformer.transform(preferenceValuelist);
			preferenceService.setPreferenceValues(preferenceValues);
			return getPreferenceValues(preferenceIds.toArray(new String[]{}));
		} else {
			throw new InvalidPreferenceException();
		}
	}
	
	/**
	 * Returns all favorite items of the logged-on user.
	 * 
	 * @return List of favorite items.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	public FavoriteItemlist getFavorites() throws QppServiceException {
		FavoriteItem[] favoriteItems = preferenceService.getFavorites();
		return objectTranformer.transform(favoriteItems);
	}
	
	/**
	 * Sets favorites items for the logged on users. It will delete all existing favorites and would replace them with the supplied favorite
	 * items. Position of the favorite items are not validated and set without validations. Thus, sending correct favorite items positions
	 * would be responsibility of the caller application.
	 * 
	 * @param favoriteItemlist
	 *            list of of favorite items to be set for logged on user.
	 * @throws InvalidFavoriteItemException
	 *             If favorite type or id of the favorite item specified is invalid.
	 * @throws QppServiceException
	 *             Unhandled Server exception.
	 */
	public void setFavorites(FavoriteItemlist favoriteItemlist) throws InvalidFavoriteItemException, QppServiceException {
		FavoriteItem[] favoriteItems = objectTranformer.transform(favoriteItemlist);
		preferenceService.setFavorites(favoriteItems);
	}

	public void resetAllUsersPreferenceValues(String[] userPreferenceIdsOrNames) throws PreferenceNotFoundException, QppServiceException {
		long[] userPreferenceIds = null;
		if(userPreferenceIdsOrNames != null){
			userPreferenceIds = facadeUtility.getPreferenceIds(userPreferenceIdsOrNames);
		}
		preferenceService.resetAllUsersPreferenceValues(userPreferenceIds);
	}

	public void setDefaultPreferenceValues(PreferenceValueList preferenceValueList) throws PreferenceNotFoundException, InvalidPreferenceException, QppServiceException {
		PreferenceValue[] preferenceValues = null;
		if (preferenceValueList != null) {
			List<com.quark.qpp.service.xmlBinding.PreferenceValue> list = preferenceValueList.getPreferenceValue();
			for (int i = 0; list != null && i < list.size(); i++) {
				com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValue = list.get(i);
				Long prefId = preferenceValue.getPreferenceId();
				if (prefId == null && preferenceValue.getPreferenceName() != null) {
					prefId = facadeUtility.getPreferenceId(preferenceValue.getPreferenceName());
					preferenceValue.setPreferenceId(prefId);
				}
				if (preferenceValue.getValueId() == null && preferenceValue.getValue() != null) {
					Preference preference = preferenceService.getPreference(prefId);
					if (preference.isPossibleValuesExist()) {
						PreferenceValue[] possibleValues = preference.getPossibleValues();
						for (int j = 0; j < possibleValues.length; j++) {
							if (possibleValues[j].getValue().equals(preferenceValue.getValue())) {
								preferenceValue.setValueId(possibleValues[j].getValueId());
								break;
							}
						}
					}
				}
			}
			preferenceValues = objectTranformer.transform(preferenceValueList);
		} 
		preferenceService.setDefaultPreferenceValues(preferenceValues);
	}

}

/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.exception;

import com.quark.qpp.common.exceptions.QppServiceException;

/**
 * This exception is thrown when user tries to archive a collection search.
 * 
 */
public class ArchiveException extends QppServiceException {

	private static final long serialVersionUID = 1L;

	/**
	 * Parameterized constructor that creates a new ArchiveException object with the given exceptionCode.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 */
	public ArchiveException(String exceptionCode) {
		super(exceptionCode);
	}

	/**
	 * Parameterized constructor that creates a new ArchiveException object with the given exceptionCode and additional information.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 * @param additionalInfo
	 *            additionalInfo that is to be set for this exception.
	 */
	public ArchiveException(String exceptionCode, String[] additionalInfo) {
		super(exceptionCode, additionalInfo);
	}

}

/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.exception;

/**
 * Defines exception codes for archive failure scenarios.
 * 
 */
public abstract class ArchiveExceptionCodes {

	/**
	 * Exception code when a query cannot be archived.
	 */
	public static final String CANNOT_ARCHIVE_COLLECTION_SEARCH = "CANNOT_ARCHIVE_COLLECTION_SEARCH";

	/**
	 * Exception code when archive path is invalid.
	 */
	public static final String INVALID_ARCHIVE_PATH = "INVALID_ARCHIVE_PATH";
	
	/**
	 * Exception code when an IO exception occurs.
	 */
	public static final String FILE_IO_ERROR_OCCURED = "FILE_IO_ERROR_OCCURED";

}

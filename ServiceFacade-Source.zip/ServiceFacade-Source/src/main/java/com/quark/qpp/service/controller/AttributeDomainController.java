/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.dto.AttributeDomain;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidDomainExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainValueNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidDomainException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidDomainValueException;
import com.quark.qpp.core.attribute.service.local.AttributeDomainService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AttributeDomainInfo;
import com.quark.qpp.service.xmlBinding.AttributeDomainInfoList;
import com.quark.qpp.service.xmlBinding.DomainValueList;

public class AttributeDomainController {

	@Autowired
	private AttributeDomainService attributeDomainService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;

	private final Logger logger = Logger.getLogger(this.getClass());

	public AttributeDomainInfoList getAllDomains() throws QppServiceException {
		AttributeDomain[] attributeDomains = attributeDomainService.getAllDomains();
		return objectTransformer.transform(attributeDomains);
	}

	public AttributeDomainInfoList getDomain(String domain) throws DomainNotFoundException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domain);
		AttributeDomain attributeDomain = attributeDomainService.getDomain(domainId);
		AttributeDomainInfo attributeDomainInfo = objectTransformer.transform(attributeDomain);
		AttributeDomainInfoList attributeDomainInfoList = new AttributeDomainInfoList();
		attributeDomainInfoList.getAttributeDomainInfo().add(attributeDomainInfo);
		return attributeDomainInfoList;
	}

	public AttributeDomainInfoList createDomains(AttributeDomainInfoList attributeDomainInfoList) throws InvalidDomainException,
			QppServiceException {
		if (attributeDomainInfoList != null) {
			List<AttributeDomainInfo> domainsToBeCreated = attributeDomainInfoList.getAttributeDomainInfo();
			AttributeDomainInfoList createdDomains = new AttributeDomainInfoList();
			for (int i = 0; domainsToBeCreated != null && i < domainsToBeCreated.size(); i++) {
				try {
					AttributeDomainInfo newDomain = createDomain(domainsToBeCreated.get(i));
					createdDomains.getAttributeDomainInfo().add(newDomain);
				} catch (QppServiceException e) {
					logger.error("Error while creating domain with name " + domainsToBeCreated.get(i).getName(), e);
					if (attributeDomainInfoList.getAttributeDomainInfo().size() == 1) {
						throw e;
					}
				}
			}
			return createdDomains;
		} else {
			throw new InvalidDomainException(InvalidDomainExceptionCodes.INVALID_DOMAIN);
		}
	}

	public AttributeDomainInfoList updateDomains(AttributeDomainInfoList attributeDomainInfoList) throws DomainNotFoundException,
			QppServiceException {
		AttributeDomainInfoList updatedDomains = new AttributeDomainInfoList();
		if (attributeDomainInfoList != null) {
			List<AttributeDomainInfo> domainsToBeCreated = attributeDomainInfoList.getAttributeDomainInfo();
			for (int i = 0; domainsToBeCreated != null && i < domainsToBeCreated.size(); i++) {
				try {
					AttributeDomainInfo newDomain = updateDomain(domainsToBeCreated.get(i));
					updatedDomains.getAttributeDomainInfo().add(newDomain);
				} catch (QppServiceException e) {
					logger.error("Error while updating attribute domain with name " + domainsToBeCreated.get(i).getName(), e);
					if (attributeDomainInfoList.getAttributeDomainInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidDomainException(InvalidDomainExceptionCodes.INVALID_DOMAIN);
		}
		return updatedDomains;
	}

	public void deleteDomain(String domainIdOrName) throws DomainNotFoundException, InvalidDomainException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		attributeDomainService.deleteDomain(domainId);
	}

	private AttributeDomainInfo createDomain(AttributeDomainInfo attributeDomainInfo) throws InvalidDomainException, QppServiceException {
		AttributeDomain attributeDomain = objectTransformer.transform(attributeDomainInfo);
		DomainValue[] domainValues = objectTransformer.transform(attributeDomainInfo.getDomainValueList());
		int newDomainId = attributeDomainService.createDomain(attributeDomain, domainValues);
		return objectTransformer.transform(attributeDomainService.getDomain(newDomainId));
	}

	private AttributeDomainInfo updateDomain(AttributeDomainInfo attributeDomainInfo) throws DomainNotFoundException,
			InvalidDomainException, QppServiceException {
		AttributeDomain attributeDomain = objectTransformer.transform(attributeDomainInfo);
		if (attributeDomain.getId() == 0) {
			int domainId = facadeUtility.getDomainId(attributeDomain.getName());
			attributeDomain.setId(domainId);
		}
		if (attributeDomain.getName() == null || attributeDomain.getName().isEmpty()) {
			String domainName = attributeDomainService.getDomain(attributeDomain.getId()).getName();
			attributeDomain.setName(domainName);
		}
		DomainValue[] domainValues = objectTransformer.transform(attributeDomainInfo.getDomainValueList());
		attributeDomainService.setDomain(attributeDomain);
		if (attributeDomainInfo.getDomainValueList() != null) {
			attributeDomainService.setDomainValues(attributeDomain.getId(), domainValues);
		}
		return objectTransformer.transform(attributeDomainService.getDomain(attributeDomain.getId()));
	}

	public String getDomainValueXml(String domainIdOrName, long valueId) throws DomainNotFoundException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		return attributeDomainService.getDomainValueXml(domainId, valueId);
	}

	public void setDomainValueXml(String domainIdOrName, long valueId, String xmlValue) throws DomainNotFoundException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		attributeDomainService.setDomainValueXml(domainId, valueId, xmlValue);
	}

	public DomainValueList searchDomainValues(String domainIdOrName, String xpath) throws DomainNotFoundException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		DomainValue[] domainValues = attributeDomainService.searchDomainValues(domainId, xpath);
		boolean isHierarchicalDomain = attributeDomainService.getDomain(domainId).isHierarchical();
		return objectTransformer.transform(domainValues, isHierarchicalDomain);
	}

	public com.quark.qpp.service.xmlBinding.DomainValue getDomainValue(String domainIdOrName, long valueId) throws DomainNotFoundException,
			DomainValueNotFoundException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		DomainValue domainValue = attributeDomainService.getDomainValue(domainId, valueId);
		boolean isHierarchicalDomain = attributeDomainService.getDomain(domainId).isHierarchical();
		return objectTransformer.transform(domainValue, isHierarchicalDomain);
	}
	
	public com.quark.qpp.service.xmlBinding.DomainValue addDomainValue(String domainIdOrName, Long parentDomainValueId, String name,
			String sourceReference, Integer position) throws DomainNotFoundException, InvalidDomainException, DomainValueNotFoundException,
			InvalidDomainValueException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		long newValueId = attributeDomainService.addDomainValue(domainId, parentDomainValueId != null ? parentDomainValueId : -1, name,
				sourceReference, position == null ? -1 : position);
		boolean isHierarchicalDomain = attributeDomainService.getDomain(domainId).isHierarchical();
		return objectTransformer.transform(attributeDomainService.getDomainValue(domainId, newValueId), isHierarchicalDomain);
	}

	public com.quark.qpp.service.xmlBinding.DomainValue updateDomainValueName(String domainIdOrName, long valueId, String name,
			String sourceReference) throws DomainNotFoundException, InvalidDomainException, DomainValueNotFoundException,
			InvalidDomainValueException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		attributeDomainService.updateDomainValue(domainId, valueId, name, sourceReference);
		DomainValue domainValue = attributeDomainService.getDomainValue(domainId, valueId);
		boolean isHierarchicalDomain = attributeDomainService.getDomain(domainId).isHierarchical();
		return objectTransformer.transform(domainValue, isHierarchicalDomain);
	}

	public void deleteDomainValue(String domainIdOrName, long valueId) throws DomainNotFoundException, DomainValueNotFoundException,
			InvalidDomainException, QppServiceException {
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		attributeDomainService.deleteDomainValue(domainId, valueId);
	}
	
	public com.quark.qpp.service.xmlBinding.DomainValueList moveDomainValues(String domainIdOrName, String targetParentvalue, 
			String[] sourceDomainValues, int startPosition) throws DomainNotFoundException, InvalidDomainException, 
			DomainValueNotFoundException, InvalidDomainValueException, QppServiceException {			
		int domainId = facadeUtility.getDomainId(domainIdOrName);
		AttributeDomain attributeDomain = attributeDomainService.getDomain(domainId);
		boolean isHierarchicalDomain = attributeDomain.isHierarchical();
		long targetParentValueId;
		if(targetParentvalue == null && !isHierarchicalDomain) {
			targetParentValueId = 0;
		} else {
			targetParentValueId = facadeUtility.getDomainValueIds(domainId, new String[] { targetParentvalue })[0];
		}
		long[] sourceDomainValueIds = facadeUtility.getDomainValueIds(domainId, sourceDomainValues);
		attributeDomainService.moveDomainValues(domainId, targetParentValueId, sourceDomainValueIds, startPosition);
		if (targetParentValueId <= 0) {
			DomainValue[] domainValues = attributeDomainService.getDomainValues(domainId);
			return objectTransformer.transform(domainValues, isHierarchicalDomain);
		} else {
			DomainValue domainValue = attributeDomainService.getDomainValue(domainId, targetParentValueId);
			return objectTransformer.transform(new DomainValue[] { domainValue }, isHierarchicalDomain);
		}
	}	
}

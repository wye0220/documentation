/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.office.service.constants.ExcelDataObjectTypes;
import com.quark.qpp.office.service.constants.ExcelDataOutputFormats;
import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.constants.PowerPointDataOutputFormats;
import com.quark.qpp.office.service.constants.TableOutputProperties;
import com.quark.qpp.office.service.constants.VisioDataOutputFormats;
import com.quark.qpp.office.service.dto.PowerPointSlide;
import com.quark.qpp.office.service.dto.VisioPage;
import com.quark.qpp.office.service.dto.Worksheet;
import com.quark.qpp.office.service.exceptions.ExcelDataException;
import com.quark.qpp.office.service.exceptions.ExcelOutputException;
import com.quark.qpp.office.service.exceptions.InvalidOfficeContextException;
import com.quark.qpp.office.service.exceptions.OfficeServiceExceptionCodes.ExcelOutputExceptionCodes;
import com.quark.qpp.office.service.exceptions.PowerPointDataException;
import com.quark.qpp.office.service.exceptions.PowerPointOutputException;
import com.quark.qpp.office.service.exceptions.VisioDataException;
import com.quark.qpp.office.service.exceptions.VisioOutputException;
import com.quark.qpp.office.service.local.OfficeService;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AssetRenditionInfoList;
import com.quark.qpp.service.xmlBinding.PowerPointSlideInfo;
import com.quark.qpp.service.xmlBinding.PowerPointSlideInfoList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.VisioPageInfo;
import com.quark.qpp.service.xmlBinding.VisioPageInfoList;
import com.quark.qpp.service.xmlBinding.WorksheetInfo;
import com.quark.qpp.service.xmlBinding.WorksheetInfoList;

/**
 * Facade to burst an Excel document into worksheets & data objects.
 * 
 */
@Controller(value = "officeFacade")
@RequestMapping("/office")
public class OfficeFacade {

	@Autowired
	private OfficeService officeService;
	
	@Autowired
	private AssetFacade assetFacade;

	@Autowired
	private StreamingService officeStreamingService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ContentStructureService contentStructureService;
	
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	private String officeTempDirectory = System.getProperty("java.io.tmpdir") + "/QppServer/Office";

	public OfficeFacade() {
		File systemDir = new File(officeTempDirectory);
		if (!systemDir.exists()) {
			systemDir.mkdirs();
		}
	}
	

	/**
	 * Returns all worksheets defined in an Excel document. Each worksheet object encapsulates its metadata like worksheet index & name. In
	 * addition, a worksheet will also provide information about its data objects like tables, named ranges & charts.<br/>
	 * In order to retrieve specific worksheets, specify valid worksheet names in worksheetNames parameter.
	 * 
	 * @param assetId
	 *            asset id of the Excel document whose worksheets are to be retrieved.
	 * @param majorVersion
	 *            major version of the Excel asset. 
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetNames
	 *            string array of worksheet names to be retrieved. In case this parameter is not defined, then all the Excel worksheets will
	 *            be returned.
	 * @return List of worksheets in the Excel document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel/{assetId}")
	@WebReturnType("xmlView")
	public WorksheetInfoList getExcelWorksheets(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, @WebArrayParam("worksheets") String[] worksheetNames)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
		
 		File tempFile = null;
		WorksheetInfoList worksheetInfoList = null;		
		try {			
			tempFile = getMetadataFile(assetId, majorVersion, minorVersion);
			if(tempFile != null) {
				JAXBContext jaxbContext = JAXBContext.newInstance(WorksheetInfoList.class);  	   
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
				worksheetInfoList = (WorksheetInfoList) jaxbUnmarshaller.unmarshal(tempFile);
				if (worksheetInfoList != null && worksheetInfoList.getWorksheetInfo() != null && worksheetInfoList.getWorksheetInfo().size() > 0) {
					if (worksheetNames != null && worksheetNames.length > 0) {
						WorksheetInfoList newWorksheetInfoList = new WorksheetInfoList();
						for (int i = 0; i < worksheetNames.length; i++) {
							String worksheetName = worksheetNames[i];
							for (int j = 0; j < worksheetInfoList.getWorksheetInfo().size(); j++) {
								WorksheetInfo WorksheetInfo = worksheetInfoList.getWorksheetInfo().get(j);
								if (WorksheetInfo.getName().equalsIgnoreCase(worksheetName)) {
									newWorksheetInfoList.getWorksheetInfo().add(WorksheetInfo);
									break;
								}
							}
						}
						return newWorksheetInfoList;
					}
					return worksheetInfoList;
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching DECONSTRUCTED_XML rendition.", e);
		} finally {
			try {
				if (tempFile != null) {
					tempFile.delete();
				}
			} catch (Exception e) {
				logger.error("Error while deleting file.", e);
			} 
		} 		

		AssetVersion assetVersion = null;
		if (majorVersion != null && minorVersion != null) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}
		Worksheet[] allWorksheets = officeService.getExcelWorksheets(assetId, assetVersion);
		ArrayList<Worksheet> list = new ArrayList<Worksheet>();
		for (int i = 0; worksheetNames != null && i < worksheetNames.length; i++) {
			for (int j = 0; j < allWorksheets.length; j++) {
				if (allWorksheets[j].getName().equalsIgnoreCase(worksheetNames[i])) {
					list.add(allWorksheets[j]);
					break;
				}
			}
		}
		if (worksheetNames != null && worksheetNames.length > 0) {
			return objectTransformer.transform(list.toArray(new Worksheet[0]));
		} else {
			return objectTransformer.transform(allWorksheets);
		}
	}
	
	/**
	 * Returns all worksheets defined in an Excel document. Each worksheet object encapsulates its metadata like worksheet index & name. In
	 * addition, a worksheet will also provide information about its data objects like tables, named ranges & charts.<br/>
	 * In order to retrieve specific worksheets, specify valid worksheet names in worksheetNames parameter.
	 * 
	 * @param uri uri of the excel file whose worksheets are required. 
	 * @param worksheetNames
	 *            string array of worksheet names to be retrieved. In case this parameter is not defined, then all the Excel worksheets will
	 *            be returned.
	 * @return List of worksheets in the Excel document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel", params={"uri","!chart","!table","!namedrange","!dynamicrange"})
	@WebReturnType("xmlView")
	public WorksheetInfoList getExcelWorksheetsBasedOnURI(@RequestParam("uri") String uri, @WebArrayParam("worksheets") String[] worksheetNames)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
		Worksheet[] allWorksheets = officeService.getExcelWorksheetsBasedOnURI(uri);
		ArrayList<Worksheet> list = new ArrayList<Worksheet>();
		for (int i = 0; worksheetNames != null && i < worksheetNames.length; i++) {
			for (int j = 0; j < allWorksheets.length; j++) {
				if (allWorksheets[j].getName().equalsIgnoreCase(worksheetNames[i])) {
					list.add(allWorksheets[j]);
					break;
				}
			}
		}
		if (worksheetNames != null && worksheetNames.length > 0) {
			return objectTransformer.transform(list.toArray(new Worksheet[0]));
		} else {
			return objectTransformer.transform(allWorksheets);
		}
	}
	
	/**
	 * Returns all worksheets defined in an Excel document. Each worksheet object encapsulates its metadata like worksheet index & name. In
	 * addition, a worksheet will also provide information about its data objects like tables, named ranges & charts.<br/>
	 * In order to retrieve specific worksheets, specify valid worksheet names in worksheetNames parameter.
	 * 
	 * @param inputStream inputStream of the excel file whose worksheets are required. 
	 * @param worksheetNames
	 *            string array of worksheet names to be retrieved. In case this parameter is not defined, then all the Excel worksheets will
	 *            be returned.
	 * @return List of worksheets in the Excel document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excel")
	@WebReturnType("xmlView")
	public WorksheetInfoList getExcelWorksheetsBasedOnStreamContext(@WebInputStream InputStream inputStream, @WebArrayParam("worksheets") String[] worksheetNames)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException, StreamingException {
		long contextId = officeService.createExcelReadWriteContext();
		officeStreamingService.upload(inputStream, contextId);
		Worksheet[] allWorksheets = null;
		try {
			allWorksheets = officeService.getExcelWorksheetsBasedOnStreamContext(contextId);
		} finally {
			officeService.closeContext(contextId);
		}
		ArrayList<Worksheet> list = new ArrayList<Worksheet>();
		for (int i = 0; worksheetNames != null && i < worksheetNames.length; i++) {
			for (int j = 0; j < allWorksheets.length; j++) {
				if (allWorksheets[j].getName().equalsIgnoreCase(worksheetNames[i])) {
					list.add(allWorksheets[j]);
					break;
				}
			}
		}
		if (worksheetNames != null && worksheetNames.length > 0) {
			return objectTransformer.transform(list.toArray(new Worksheet[0]));
		} else {
			return objectTransformer.transform(allWorksheets);
		}
	
	}

	/**
	 * Returns an Excel chart in the image format. The source Excel document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Excel document whose chart is to be retrieved in image format.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the chart is defined. In case the worksheet name is not defined, then the first chart in the
	 *            Excel with the given name is considered.
	 * @param chartName
	 *            name of the Excel chart to be retrieved.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name  or chart name supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel/{assetId}", params = "chart")
	public void getChart(@PathVariable("assetId") long assetId, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "chart", required = true) String chartName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponent(assetId, majorVersion, minorVersion, worksheetName, ExcelDataObjectTypes.CHART, chartName,  ExcelDataOutputFormats.IMAGE,
				outputFormatProperties, httpServletResponse, contentDisposition, os);
	}

	/**
	 * Returns an Excel chart in the image format. The source Excel document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            uri of the Excel document
	 * @param worksheetName
	 *            name of the worksheet where the chart is defined. In case the worksheet name is not defined, then the first chart in the
	 *            Excel with the given name is considered.
	 * @param chartName
	 *            name of the Excel chart to be retrieved.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or chart name supplied is not valid. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel", params = {"chart", "uri"})
	public void getChartBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "chart", required = true) String chartName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnURI(uri, worksheetName, ExcelDataObjectTypes.CHART, chartName,  ExcelDataOutputFormats.IMAGE,
				outputFormatProperties, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel chart in the image format. The source Excel document should be supplied in the form of input stream. 
	 * 
	 * @param inputStream
	 *            inputStream from where the Excel document can be read
	 * @param worksheetName
	 *            name of the worksheet where the chart is defined. In case the worksheet name is not defined, then the first chart in the
	 *            Excel with the given name is considered.
	 * @param chartName
	 *            name of the Excel chart to be retrieved.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or chart name supplied is not valid. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excel", params = "chart")
	public void getChartBasedOnStream(@WebInputStream InputStream inputStream,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "chart", required = true) String chartName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {

		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnStream(inputStream, worksheetName, ExcelDataObjectTypes.CHART, chartName, ExcelDataOutputFormats.IMAGE,	outputFormatProperties, httpServletResponse, contentDisposition, os);
	}

	/**
	 * Returns an Excel table in the desired output format. The source Excel document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Excel document whose table is to be retrieved in desired output format.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the table is defined. In case the worksheet name is not defined, then the first table in the
	 *            Excel with the given name is considered.
	 * @param tableName
	 *            name of the Excel table to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the table is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of table is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or table name supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel/{assetId}", params = "table")
	public void getTable(@PathVariable("assetId") long assetId, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "table", required = true) String tableName,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponent(assetId, majorVersion, minorVersion, worksheetName, ExcelDataObjectTypes.TABLE, tableName, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel table in the desired output format. The source Excel document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *           URI of the Excel document whose table is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the table is defined. In case the worksheet name is not defined, then the first table in the
	 *            Excel with the given name is considered.
	 * @param tableName
	 *            name of the Excel table to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the table is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of table is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or table name supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel", params = "table")
	public void getTableBasedOnURI(@RequestParam(value = "uri", required = true) String uri, @RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "table", required = true) String tableName,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters,  HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnURI(uri, worksheetName, ExcelDataObjectTypes.TABLE, tableName, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel table in the desired output format. The source Excel document should be supplied in the form of URI.
	 * 
	 * @param inputStream
	 *           InputStream of the Excel document whose table is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the table is defined. In case the worksheet name is not defined, then the first table in the
	 *            Excel with the given name is considered.
	 * @param tableName
	 *            name of the Excel table to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the table is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of table is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or table name supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excel", params = "table")
	public void getTableBasedOnStreamContext(@WebInputStream InputStream inputStream,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "table", required = true) String tableName,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException,
			StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnStream(inputStream, worksheetName, ExcelDataObjectTypes.TABLE, tableName, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);

	}
	
	/**
	 * Returns an Excel named range in the desired output format. The source Excel document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Excel document whose named range is to be retrieved in desired output format.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the named range is defined. In case the worksheet name is not defined, then the first named range in the
	 *            Excel with the given name is considered.
	 * @param namedRange
	 *            name of the Excel named range to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel/{assetId}", params = "namedrange")
	public void getNamedRange(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "namedrange", required = true) String namedRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponent(assetId, majorVersion, minorVersion, worksheetName, ExcelDataObjectTypes.NAMED_RANGE, namedRange, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	
	/**
	 * Returns an Excel named range in the desired output format. The source Excel document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            URI of the Excel document whose named range is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the named range is defined. In case the worksheet name is not defined, then the first named range in the
	 *            Excel with the given name is considered.
	 * @param namedRange
	 *            name of the Excel named range to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML//CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel", params = { "namedrange", "uri" })
	public void getNamedRangeBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "namedrange", required = true) String namedRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException,
			StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnURI(uri, worksheetName, ExcelDataObjectTypes.NAMED_RANGE, namedRange, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel named range in the desired output format. The source Excel document should be supplied in the form of InputStream.
	 * 
	 * @param inputStream
	 *            InputStream of the Excel document whose named range is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the named range is defined. In case the worksheet name is not defined, then the first named range in the
	 *            Excel with the given name is considered.
	 * @param namedRange
	 *            name of the Excel named range to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excel", params = "namedrange")
	public void getNamedRangeBasedOnStream(@WebInputStream InputStream inputStream,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "namedrange", required = true) String namedRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnStream(inputStream, worksheetName, ExcelDataObjectTypes.NAMED_RANGE, namedRange, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel dynamic range in the desired output format. The source Excel document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Excel document whose dynamic range is to be retrieved in desired output format.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the dynamic range is to fetched. In case the worksheet name is not defined, then the first
	 *            worksheet of the Excel will be considered.
	 * @param dynamicRange
	 *            specify a valid dynamic range.<br/>
	 *            Dynamic range can be defined in formats like :<li>Cell reference : A1:C20</li><li>Sheet & cell reference together :
	 *            'Sheet1'!A1:C20</li><li>RC patten : 'Sheet1'!R1C2:R2C3 or R1C2:R2C3(without sheet reference in pattern)</li>
	 *            <li>Formula based : =offset('Sheet1'!A1:C12,2,2,20,10)</li>
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of dynamic range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param outputStream
	 *            output stream onto which named range is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel/{assetId}", params = "dynamicrange")
	public void getDynamicRange(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "dynamicrange", required = true) String dynamicRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponent(assetId, majorVersion, minorVersion, worksheetName, ExcelDataObjectTypes.DYNAMIC_RANGE, dynamicRange,
				outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}

	
	/**
	 * Returns an Excel dynamic range in the desired output format. The source Excel document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            URI of the Excel document whose dynamic range is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the dynamic range is to fetched. In case the worksheet name is not defined, then the first
	 *            worksheet of the Excel will be considered.
	 * @param dynamicRange
	 *            specify a valid dynamic range.<br/>
	 *            Dynamic range can be defined in formats like :<li>Cell reference : A1:C20</li><li>Sheet & cell reference together :
	 *            'Sheet1'!A1:C20</li><li>RC patten : 'Sheet1'!R1C2:R2C3 or R1C2:R2C3(without sheet reference in pattern)</li>
	 *            <li>Formula based : =offset('Sheet1'!A1:C12,2,2,20,10)</li>
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of dynamic range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param outputStream
	 *            output stream onto which named range is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excel", params = {"dynamicrange", "uri"})
	public void getDynamicRangeBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "dynamicrange", required = true) String dynamicRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnURI(uri, worksheetName, ExcelDataObjectTypes.DYNAMIC_RANGE, dynamicRange,
				outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns an Excel dynamic range in the desired output format. The source Excel document should be supplied in the form of InputStream.
	 * 
	 * @param inputStream
	 *            InputStream of the Excel document whose dynamic range is to be retrieved in desired output format.
	 * @param worksheetName
	 *            name of the worksheet where the dynamic range is to fetched. In case the worksheet name is not defined, then the first
	 *            worksheet of the Excel will be considered.
	 * @param dynamicRange
	 *            specify a valid dynamic range.<br/>
	 *            Dynamic range can be defined in formats like :<li>Cell reference : A1:C20</li><li>Sheet & cell reference together :
	 *            'Sheet1'!A1:C20</li><li>RC patten : 'Sheet1'!R1C2:R2C3 or R1C2:R2C3(without sheet reference in pattern)</li>
	 *            <li>Formula based : =offset(Sheet1!A1:C12,2,2,20,10)</li>
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of dynamic range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param outputStream
	 *            output stream onto which named range is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excel", params = "dynamicrange")
	public void getDynamicRangeBasedOnStream(@WebInputStream InputStream inputStream,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "dynamicrange", required = true) String dynamicRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		
		getSpecificComponentBasedOnStream(inputStream, worksheetName, ExcelDataObjectTypes.DYNAMIC_RANGE, dynamicRange,
				outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            QppServiceException that is to be handled
	 * @return QppServiceExceptionInfo object containing details of the exception thrown
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

	private long downloadSpecificDataObject(long assetId, Long majorVersion, Long minorVersion, String worksheetName,
			String dataObjectType, String dataObjectName, String outputFormat, HashMap<String, String> outputFormatProperties,
			OutputStream outputStream) throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException,
			QppServiceException, StreamingException, InvalidOfficeContextException {
		if (outputFormat == null || outputFormat.trim().isEmpty()) {
			if (dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.CHART)) {
				outputFormat = ExcelDataOutputFormats.IMAGE;
			} else if (dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.TABLE)
					|| dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.NAMED_RANGE)
					|| dataObjectType.equalsIgnoreCase(ExcelDataObjectTypes.DYNAMIC_RANGE)) {
				outputFormat = ExcelDataOutputFormats.SMARTTABLE;
			}
		}
		AssetVersion assetVersion = facadeUtility.getAssetVersion(majorVersion, minorVersion);
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		long contextId = officeService.createExcelDataReadContext(assetId, assetVersion, worksheetName, dataObjectType, dataObjectName,
				outputFormat, nameValues);
		try {
			return officeStreamingService.download(outputStream, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}

	private void getSpecificComponent(long assetId, Long majorVersion, Long minorVersion, String worksheetName, String dataObjectType,
			String dataObjectName, String outputFormat, HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse, String contentDisposition, OutputStream outputStream) throws AssetNotFoundException, InvalidAssetException,
			ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		setContentHttpHeaders(dataObjectName, outputFormat, outputFormatProperties, httpServletResponse, contentDisposition);
		downloadSpecificDataObject(assetId, majorVersion, minorVersion, worksheetName, dataObjectType, dataObjectName, outputFormat,
				outputFormatProperties, outputStream);
	}
	
	private void getSpecificComponentBasedOnStream(InputStream inputStream, String worksheetName, String dataObjectType,  String dataObjectName, String outputFormat,
			HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse, String contentDisposition, OutputStream outputStream) throws QppServiceException, StreamingException,
			AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, InvalidOfficeContextException, IOException {
		long contextId = officeService.createExcelReadWriteContext();
		try {
			officeStreamingService.upload(inputStream, contextId);
			officeService.readExcelDataBasedOnStreamContext(contextId, worksheetName, dataObjectType, dataObjectName, outputFormat,
					createNameValueArray(outputFormatParameters));
			setContentHttpHeaders(dataObjectName, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition);
			officeStreamingService.download(outputStream, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}

	private void getSpecificComponentBasedOnURI(String uri, String worksheetName, String dataObjectType, String dataObjectName, String outputFormat,
			HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse, String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException,
			InvalidOfficeContextException, IOException {
		long contextId = officeService.createExcelDataReadContextBasedOnURI(uri, worksheetName, dataObjectType, dataObjectName,
				outputFormat, createNameValueArray(outputFormatProperties));
		setContentHttpHeaders(dataObjectName, outputFormat, outputFormatProperties, httpServletResponse, contentDisposition);
		try {
			officeStreamingService.download(outputStream, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}

	private void setContentHttpHeaders(String dataObjectName, String outputFormat, HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse, String contentDisposition) throws QppServiceException {
		if (httpServletResponse == null) {
			// This will be null for local (non-REST) invocation.
			return;
		}
		String fileXtension = getFileExtension(outputFormat, outputFormatProperties);
		String mimeType = contentStructureService.getContentIdentifier(fileXtension, null, null).getMimeType();
		httpServletResponse.setContentType(mimeType);

		if (contentDisposition == null) {
			// default disposition is inline
			contentDisposition = "inline";
		}
		if(dataObjectName == null || dataObjectName.isEmpty()) {
			dataObjectName = "response";
		}
		httpServletResponse.setHeader("Content-Disposition", contentDisposition + "; filename=\"" + dataObjectName + "." + fileXtension + "\"");		
	}

	private String getFileExtension(String outputFormat, HashMap<String, String> outputFormatProperties) {
		if (outputFormat == null || outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.IMAGE)) {
			String fileXtension = "png";//TODO how to keep this is sync with OFFICE SERVICE defaultImageFormat value.
			if(outputFormatProperties != null){
				String value = outputFormatProperties.get(ImageOutputProperties.IMAGE_FORMAT);
				if (value != null && value.trim().length() > 0) {
					fileXtension = value;
					if (value.equalsIgnoreCase("pdfnotes")) {
						fileXtension = "pdf"; 
					}
				}			
			}
			return fileXtension;
		} else if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.HTML)
				|| outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XHTML)) {
			return "htm";
		} else if (outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.CALS) || outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.XML) || outputFormat.equalsIgnoreCase(ExcelDataOutputFormats.SMARTTABLE)) {
			return "xml";
		} else if (outputFormat.equalsIgnoreCase("zip")) {
			return "zip"; 
		} else if (outputFormat.equalsIgnoreCase("xps")) {
			return "xps"; 
		} 
	
		return null;
	}

	private NameValue[] createNameValueArray(Map<String, String> outputParameters) {
		NameValue[] nameValues = null;
		if (outputParameters != null) {
			outputParameters.remove("majorversion");
			outputParameters.remove("minorversion");
			outputParameters.remove("worksheet");
			outputParameters.remove("chart");
			outputParameters.remove("table");
			outputParameters.remove("namedrange");
			outputParameters.remove("dynamicrange");
			outputParameters.remove("outputformat");
			outputParameters.remove("loginname");
			outputParameters.remove("loginpassword");
			outputParameters.remove("qppsessionid");
			outputParameters.remove("pagename");
			outputParameters.remove("slideid");
			outputParameters.remove("sliderange");
			
			nameValues = new NameValue[outputParameters.size()];
			Iterator<String> itr = outputParameters.keySet().iterator();
			int i = 0;
			while (itr.hasNext()) {
				String name = itr.next();
				String value = outputParameters.get(name);
				nameValues[i] = new NameValue(name, value);
				i = i + 1;
			}
		}
		return nameValues;
	}
	
	/**
	 * Out of the http response and normal stream, returns the one which is not null. In local invocation Outputstream will be provided
	 * whereas in REST invocations outputstream need to be httresponse outputstream
	 * 
	 * @param httpServletResponse
	 * @param outputStream
	 * @return
	 * @throws ExcelOutputException
	 * @throws IOException
	 */
	private OutputStream getDesiredOutputStream(HttpServletResponse httpServletResponse, OutputStream outputStream) throws ExcelOutputException, IOException {
		OutputStream os = null;
		if (httpServletResponse != null && httpServletResponse.getOutputStream() != null) {
			os = httpServletResponse.getOutputStream();
		} else if (outputStream != null) {
			os = outputStream;
		} else {
			throw new ExcelOutputException(ExcelOutputExceptionCodes.NO_OUTPUT_STREAM_FOR_WRITING_OUTPUT);
		}
		return os;
	}

	
	/**Returns PowerPoint Slide-Range output in the desired output format. The source
	 * Powerpoint document should be supplied in the form of Platform Asset.
	 * @param assetId 
	 * 				asset id of the PowerPoint document whose slides are to be retrieved.
	 * @param majorVersion
	 * 			  major version of the PowerPoint asset.
	 * @param minorVersion
	 * 			   minor version of the PowerPoint asset.
	 * @param slideRange
	 * 			Range of indexes of slides to be retrieved. 
	 *            <ol>Values in following formats can be specified:
	 *            <li>Continuous slide range. For Example: "4-6" or "4-end"</li>
	 *            <li>Discrete slide range. For example: "2,5,7"</li>	 
	 *            </ol>   
	 * @param outputFormat
	 * 			Format in which slide output is to be retrieved @see {@link PowerPointDataOutputFormats}
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 * 		   FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *         to set content type and content-disposition header values. The
	 *         value of this argument is set by the QPP REST framework.
	 * @param contentDisposition 
	 * 			 Optional value used to set content-disposition header value in
	 *           response. Set to "attachment" if downloading of slides is required.
	 * @param outputStream  
	 * 			  output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 			 In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 * 			 In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointDataException
	 * 			If the slide range supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 * 			 If the output format provided is invalid or error occurs
	 *           during the given output generation. Exception code will
	 *           specify the exact cause of exception.
	 * @throws QppServiceException
	 * 			  Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint/{assetId}", params = {"sliderange"})
	public void getPowerPointSlideRangeOutput(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "sliderange", required = true) String slideRange,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) 
			throws AssetNotFoundException, InvalidAssetException, PowerPointDataException, PowerPointOutputException, 
			QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		String dataObjectName = "Slide" + slideRange;
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		AssetVersion assetversion = facadeUtility.getAssetVersion(majorVersion, minorVersion);
		long contextId = officeService.createPowerPointDataReadContext(assetId, assetversion, 0, slideRange, outputFormat, nameValues);		
		if(outputFormat.equalsIgnoreCase(PowerPointDataOutputFormats.IMAGE)) {
			String imageFormat = null;		
			for (int i = 0; nameValues != null && i < nameValues.length; i++) {
				if(nameValues[i].getName().equalsIgnoreCase(ImageOutputProperties.IMAGE_FORMAT)){
					imageFormat = nameValues[i].getValue();	
				}
			}
			if((imageFormat == null) || ((!imageFormat.equalsIgnoreCase("pdf") && !imageFormat.equalsIgnoreCase("pdfnotes")))){
				outputFormat = "zip";
			}
		}
		setContentHttpHeaders(dataObjectName, outputFormat, outputFormatProperties, httpServletResponse, contentDisposition);
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}		
	}
	/**Returns PowerPoint Slide-Range output in the desired output format. The source
	 * PowerPoint document should be supplied in the form of URI.
	 * @param uri  
	 * 		  URI of the PowerPoint document.
	 * @param slideRange  
	 * 		  Range of indexes of slides to be retrieved. 
	 *            <ol>Values in following formats can be specified:
	 *            <li>Continuous slide range. For Example: "4-6" or "4-end"</li>
	 *            <li>Discrete slide range. For example: "2,5,7"</li>	 
	 *            </ol>   	
	 * @param outputFormat
	 * 		  Format in which slide output is to be retrieved @see {@link PowerPointDataOutputFormats}.
	 * @param outputFormatProperties
	 * 		  Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/>  
				  <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 * 		   FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *         to set content type and content-disposition header values. The
	 *         value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 * 		   Optional value used to set content-disposition header value in
	 *         response. Set to "attachment" if downloading of slides is required.
	 * @param outputStream
	 * 		    output stream onto which output is to be written in the
	 *          desired output format. This parameter is applicable only for
	 *          the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 		    In case the asset with the given id (or version) does not exist
	 * @throws InvalidAssetException
	 * 			In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointOutputException
	 * 			If the slide range supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	 * @throws PowerPointDataException
	 * 		    If the output format provided is invalid or error occurs
	 *           during the given output generation. Exception code will
	 *           specify the exact cause of exception.
	 * @throws QppServiceException
	 * 		     Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint" ,params={"uri","sliderange"})
	public void getPowerPointSlideRangeOutputBasedOnURI(
			@RequestParam(value = "sliderange", required = true) String slideRange,
			@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException, InvalidAssetException, PowerPointOutputException, PowerPointDataException,
			QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		String dataObjectName = "Slide" + slideRange;
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		long contextId = officeService.createPowerPointDataReadContextBasedOnURI(uri, 0, slideRange, outputFormat, nameValues);
		if(outputFormat.equalsIgnoreCase(PowerPointDataOutputFormats.IMAGE)) {
			String imageFormat = null;		
			for (int i = 0; nameValues != null && i < nameValues.length; i++) {
				if(nameValues[i].getName().equalsIgnoreCase(ImageOutputProperties.IMAGE_FORMAT)){
					imageFormat = nameValues[i].getValue();	
				}
			}
			if((imageFormat == null) || ((!imageFormat.equalsIgnoreCase("pdf") && !imageFormat.equalsIgnoreCase("pdfnotes")))){
				outputFormat = "zip";
			}
		}
		setContentHttpHeaders(dataObjectName, outputFormat,outputFormatProperties, httpServletResponse, contentDisposition);	
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	
}	
	/***
	 * Returns PowerPoint Slide-Range output in the desired output format. The source
	 * PowerPoint document should be supplied in the form of Stream.
	 * 
	 * @param inputStream
	 *            inputStream from where the PowerPoint document can be read.
	 * @param slideRange 
	 * 		  Range of indexes of slides to be retrieved. 
	 *            <ol>Values in following formats can be specified:
	 *            <li>Continuous slide range. For Example: "4-6" or "4-end"</li>
	 *            <li>Discrete slide range. For example: "2,5,7"</li>	 
	 *            </ol>   
	 * @param outputFormat
	 *            Format in which slide output is to be retrieved @see
	 *            {@link PowerPointDataOutputFormats}
	 * @param outputFormatProperties
	 *            Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of slide is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointDataException
	 *             If the slide range supplied is not valid. The exception code
	 *             will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 *             If the output format provided is invalid or error occurs
	 *             during the given output generation. Exception code will
	 *             specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/powerpoint",params={"sliderange"})
	public void getPowerPointSlideRangeOutputBasedOnStreamContext(
			@WebInputStream InputStream inputStream,
			@RequestParam(value = "sliderange", required = true) String slideRange,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, PowerPointDataException, PowerPointOutputException,
			QppServiceException, StreamingException, IOException {

		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		long contextId = officeService.createPowerPointReadWriteContext();
		String dataObjectName = "Slide" + slideRange;
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		try {	
			officeStreamingService.upload(inputStream, contextId);
			officeService.readPowerPointDataBasedOnStreamContext(contextId, 0, slideRange, outputFormat, nameValues);
			if(outputFormat.equalsIgnoreCase(PowerPointDataOutputFormats.IMAGE)) {
				String imageFormat = null;		
				for (int i = 0; nameValues != null && i < nameValues.length; i++) {
					if(nameValues[i].getName().equalsIgnoreCase(ImageOutputProperties.IMAGE_FORMAT)){
						imageFormat = nameValues[i].getValue();	
					}
				}
				if((imageFormat == null) || ((!imageFormat.equalsIgnoreCase("pdf") && !imageFormat.equalsIgnoreCase("pdfnotes")))){
					outputFormat = "zip";
				}
			}
			setContentHttpHeaders(dataObjectName, outputFormat,outputFormatProperties, httpServletResponse, contentDisposition);
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/**Returns PowerPoint Slide output in the desired output format. The source
	 * PowerPoint document should be supplied in the form of Platform Asset.
	 * @param assetId 
	 * 				asset id of the PowerPoint document whose slide is to be
	 *              retrieved.
	 * @param majorVersion
	 * 			  Major version of the PowerPoint asset.
	 * @param minorVersion
	 * 			   Minor version of the PowerPoint asset.
	 * @param slideId
	 * 			Id of PowerPoint slide to be retrieved.
	 * @param outputFormat
	 * 			Format in which slide output is to be retrieved @see {@link PowerPointDataOutputFormats}
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 * 		      FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition 
	 * 			 Optional value used to set content-disposition header value in
	 *           response. Set to "attachment" if downloading of slide is
	 *           required.
	 * @param outputStream  
	 * 			  output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 			 In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 * 			 In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointDataException
	 * 			If the slide id supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 * 			 If the output format provided is invalid or error occurs
	 *           during the given output generation. Exception code will
	 *           specify the exact cause of exception.
	 * @throws QppServiceException
	 * 			  Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint/{assetId}", params = {"slideid"})
	public void getPowerPointSlideOutput(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "slideid", required = true) Long slideId,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, PowerPointDataException, PowerPointOutputException,
			QppServiceException, StreamingException, IOException {
		
		String dataObjectName = "Slide" + slideId;
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		AssetVersion assetversion = facadeUtility.getAssetVersion(majorVersion, minorVersion);
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		long contextId = officeService.createPowerPointDataReadContext(assetId, assetversion, slideId, null, outputFormat, nameValues);
		setContentHttpHeaders(dataObjectName, outputFormat,outputFormatProperties, httpServletResponse, contentDisposition);
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/***
	 * Returns PowerPoint Slide output in the desired output format. The source
	 * PowerPoint document should be supplied in the form of URI.
	 * 
	 * @param slideId
	 *            Id of slide within PowerPoint to be retrieved.
	 * @param uri
	 *            URI of the PowerPoint document.
	 * @param outputFormat
	 *            Format in which slide output is to be retrieved @see
	 *            {@link PowerPointDataOutputFormats}.
	 * @param outputFormatProperties
	 *            Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of slide is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not
	 *             exist
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointOutputException
	 *             If the slide id supplied is not valid. The exception code
	 *             will specify the exact cause of exception.
	 * @throws PowerPointDataException
	 *             If the output format provided is invalid or error occurs
	 *             during the given output generation. Exception code will
	 *             specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint", params = { "uri", "slideid" })
	public void getPowerPointSlideOutputBasedOnURI (
			@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "slideid", required = true) Long slideId,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, PowerPointOutputException, PowerPointDataException,
			QppServiceException, StreamingException, IOException {
		String dataObjectName = "Slide" + slideId;
		long contextId = 0;
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		OutputStream os = getDesiredOutputStream(httpServletResponse,outputStream);
		contextId = officeService.createPowerPointDataReadContextBasedOnURI(uri, slideId, null, outputFormat, nameValues);
		setContentHttpHeaders(dataObjectName, outputFormat,outputFormatProperties, httpServletResponse, contentDisposition);
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}

	}

	/***
	 * Returns PowerPoint Slide output in the desired output format. The source
	 * PowerPoint document should be supplied in the form of Stream.
	 * 
	 * @param inputStream
	 *            inputStream from where the PowerPoint document can be read.
	 * @param slideId
	 *            Id of slide within PowerPoint to be retrieved.
	 * @param outputFormat
	 *            Format in which slide output is to be retrieved @see
	 *            {@link PowerPointDataOutputFormats}.
	 * @param outputFormatProperties
	 *            Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of slide is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws PowerPointDataException
	 *             If the slide id supplied is not valid. The exception code
	 *             will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 *             If the output format provided is invalid or error occurs
	 *             during the given output generation. Exception code will
	 *             specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/powerpoint",params={"slideid"})
	public void getPowerPointSlideOutputBasedOnStreamContext(
			@WebInputStream InputStream inputStream,
			@RequestParam(value = "slideid", required = true) Long slideId,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException,
			QppServiceException, StreamingException, IOException {
		
		NameValue[] nameValues = createNameValueArray(outputFormatProperties);
		OutputStream os = getDesiredOutputStream(httpServletResponse,outputStream);
		long contextId = officeService.createPowerPointReadWriteContext();
		String dataObjectName = "Slide" + slideId;
		try {
			officeStreamingService.upload(inputStream, contextId);
			officeService.readPowerPointDataBasedOnStreamContext(contextId, slideId, null, outputFormat, nameValues);
			setContentHttpHeaders(dataObjectName, outputFormat,outputFormatProperties, httpServletResponse, contentDisposition);
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/***
	 * Returns a Visio Document Page output in the desired output format. The source
	 * Visio document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            Assetid of the Visio document whose page's output is to be retrieved.
	 * @param outputFormat
	 *            Format in which Page within Visio Document is to be retrieved @see
	 *            {@link VisioDataOutputFormats}.
	 * @param pageName
	 *            Name of page within Visio Document whose output is to be generated.      
	 * @param outputFormatProperties
	 *            Properties applicable for a given Visio document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf rendering, all native properties of com.aspose.diagram.PdfSaveOptions can be set.</li>
	 *            <li>In case of svg rendering, all native properties of com.aspose.diagram.SVGSaveOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.diagram.HTMLSaveOptions can be set.</li>
	 *            <li>In case of png, jpeg and gif rendering, all native properties of com.aspose.diagram.ImageSaveOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: 
	 * 				<li>{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#RESOLUTION}</li> <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set 
	 *            content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. 
	 *            Set to "attachment" if downloading of page is required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. 
	 *            This parameter is applicable only for the local invocations and not for REST APIs.   
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO}
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws VisioDataException
	 *             If Page name specified is not valid.
	 * @throws VisioOutputException
	 *             If the outputformat supplied is not valid. The exception 
	 *             code will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/visio/{assetId}", params = { "pagename" })
	public void getVisioPageOutput(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@RequestParam(value = "pagename", required = true) String pageName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, VisioDataException, VisioOutputException,
			QppServiceException, StreamingException, IOException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		if (outputFormat == null || outputFormat.trim().isEmpty()) {
			outputFormat = VisioDataOutputFormats.IMAGE;			
		}			
		AssetVersion assetVersion = facadeUtility.getAssetVersion(majorVersion, minorVersion);
		long contextId = officeService.createVisioDataReadContext(assetId, assetVersion, pageName, outputFormat, createNameValueArray(outputFormatProperties));	
		setContentHttpHeaders(pageName, outputFormat.equalsIgnoreCase(VisioDataOutputFormats.HTML) ? "zip" : outputFormat, 
				outputFormatProperties, httpServletResponse, contentDisposition);
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/***
	 * Returns an Visio Document Page output in the desired output format. The source
	 * Visio document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            Uri of the Visio document whose page's output is to be retrieved.
	 * @param outputFormat
	 *            Format in which Visio Page output is to be retrieved @see {@link VisioDataOutputFormats}.
	 * @param pageName 
	 * 			  Name of page within Visio Document whose output is to be generated.
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given Visio document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf rendering, all native properties of com.aspose.diagram.PdfSaveOptions can be set.</li>
	 *            <li>In case of svg rendering, all native properties of com.aspose.diagram.SVGSaveOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.diagram.HTMLSaveOptions can be set.</li>
	 *            <li>In case of png, jpeg and gif rendering, all native properties of com.aspose.diagram.ImageSaveOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: 
	 * 				<li>{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#RESOLUTION}</li> <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of page is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO}
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws VisioDataException
	 *             if page name specified is not valid
	 * @throws VisioOutputException
	 *             If the outputformat supplied is not valid. The exception code
	 *             will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/visio",params={ "uri", "pagename" })
	public void getVisioPageOutputBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@RequestParam(value = "pagename", required = true) String pageName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, VisioDataException, VisioOutputException,
			QppServiceException, StreamingException, IOException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);	
		if (outputFormat == null || outputFormat.trim().isEmpty()) {
			outputFormat = VisioDataOutputFormats.IMAGE;			
		}		
		long contextId = officeService.createVisioDataReadContextBasedOnURI(uri, pageName, outputFormat, createNameValueArray(outputFormatProperties));			
		setContentHttpHeaders(pageName, outputFormat.equalsIgnoreCase(VisioDataOutputFormats.HTML) ? "zip" : outputFormat, 
			outputFormatProperties, httpServletResponse, contentDisposition);			
		try {
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/***
	 * Returns a Visio Document Page output in the desired output format. The
	 * source Visio document should be supplied in the form of Stream.
	 * 
	 * @param inputStream
	 *            stream of the Visio document whose page's output is to be retrieved.
	 * @param outputFormat
	 *            Format in which Visio Document Page output is to be retrieved @see
	 *            {@link VisioDataOutputFormats}
	 * @param pageName
	 *            Name of page within Visio Document whose output is to be generated.
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given Visio document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf rendering, all native properties of com.aspose.diagram.PdfSaveOptions can be set.</li>
	 *            <li>In case of svg rendering, all native properties of com.aspose.diagram.SVGSaveOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.diagram.HTMLSaveOptions can be set.</li>
	 *            <li>In case of png, jpeg and gif rendering, all native properties of com.aspose.diagram.ImageSaveOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: 
	 * 				<li>{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#RESOLUTION}</li> <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of page is required.
	 * @param outputStream
	 *            Output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type 
	 *             		{@link DefaultContentTypes#MICROSOFT_VISIO}
	 *            	 	{@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws VisioDataException
	 *             If page name specified is not valid.
	 * @throws VisioOutputException
	 *             If the outputformat supplied is not valid. The exception code
	 *             will specify the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/visio", params = {"pagename"})
	public void getVisioPageOutputBasedOnStreamContext(@WebInputStream InputStream inputStream,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@RequestParam(value = "pagename", required = true) String pageName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition,
			OutputStream outputStream) throws AssetNotFoundException,InvalidAssetException, VisioDataException, VisioOutputException,
			QppServiceException, StreamingException, IOException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);		
		if (outputFormat == null || outputFormat.trim().isEmpty()) {
			outputFormat = VisioDataOutputFormats.IMAGE;			
		}
		long contextId = officeService.createVisioReadWriteContext();
		try {
			officeStreamingService.upload(inputStream, contextId);
			officeService.readVisioDataBasedOnStreamContext(contextId, pageName, outputFormat, createNameValueArray(outputFormatProperties));
			setContentHttpHeaders(pageName, outputFormat.equalsIgnoreCase(VisioDataOutputFormats.HTML) ? "zip" : outputFormat, 
				outputFormatProperties, httpServletResponse,contentDisposition);
			officeStreamingService.download(os, contextId);
		} finally {
			officeService.closeContext(contextId);
		}
	}
	
	/**
	 * Returns all Pages defined within Visio document. Each page
	 * object encapsulates its metadata like Page index & Page Name. <br/>
	 * In order to retrieve specific pages, specify valid name of page
	 * in pages parameter.
	 * 
	 * @param assetId
	 *            Asset id of the Visio document whose metadata is to be
	 *            retrieved.
	 * @param majorVersion
	 *            Major version of the Visio asset.
	 * @param minorVersion
	 *            Minor version of the Visio asset.
	 * @param pageNames
	 *            String array of Page names to be retrieved. In case this
	 *            parameter is not defined, then all the Visio Pages will
	 *            be returned.
	 * @return List of pages in the Visio document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO}
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/visio/{assetId}")
	@WebReturnType("xmlView")
	public VisioPageInfoList getVisioPagesInfo(
			@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@WebArrayParam("pages") String[] pageNames) 	
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {		
		
		File tempFile = null;
		VisioPageInfoList visioPageInfoList = null;		
		try {			
			tempFile = getMetadataFile(assetId, majorVersion, minorVersion);
			if(tempFile != null) {
				JAXBContext jaxbContext = JAXBContext.newInstance(VisioPageInfoList.class);  	   
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
				visioPageInfoList = (VisioPageInfoList) jaxbUnmarshaller.unmarshal(tempFile);			
				if (visioPageInfoList != null && visioPageInfoList.getVisioPageInfo() != null && visioPageInfoList.getVisioPageInfo().size() > 0) {
					if (pageNames != null && pageNames.length > 0) {
						VisioPageInfoList newVisioPageInfoList = new VisioPageInfoList();
						for (int i = 0; i < pageNames.length; i++) {
							String pageName = pageNames[i];
							for (int j = 0; j < visioPageInfoList.getVisioPageInfo().size(); j++) {
								VisioPageInfo visioPageInfo = visioPageInfoList.getVisioPageInfo().get(j);
								if (visioPageInfo.getPageName().equalsIgnoreCase(pageName)) {
									newVisioPageInfoList.getVisioPageInfo().add(visioPageInfo);
									break;
								}
							}
						}
						return newVisioPageInfoList;
			        }
					return visioPageInfoList;
				} 
			}
		} catch (Exception e) {
			logger.error("Error while fetching DECONSTRUCTED_XML rendition.", e);
		} finally {
			try {
				if (tempFile != null) {
					tempFile.delete();
				}
			} catch (Exception e) {
				logger.error("Error while deleting file.", e);
			} 
		}
		
		AssetVersion assetVersion = null;
		if (majorVersion != null && minorVersion != null) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}
		VisioPage[] allPages = officeService.getVisioPages(assetId, assetVersion);
		
		ArrayList<VisioPage> list = new ArrayList<VisioPage>();
		for (int i = 0; pageNames != null && i < pageNames.length; i++) {
			for (int j = 0; j < allPages.length; j++) {
				if (allPages[j].getPageName().equalsIgnoreCase(pageNames[i])) {
					list.add(allPages[j]);
				}
			}
		}
		if (pageNames != null && pageNames.length > 0) {
			return objectTransformer.transform(list.toArray(new VisioPage[] {}));
		} else {
			return objectTransformer.transform(allPages);
		}
				
	}
	
	/**
	 * Returns all pages defined in the Visio document. Each page
	 * object encapsulates its metadata like Page index & Name.<br/>
	 * In order to retrieve specific page, specify valid page names
	 * in pages parameter.
	 * 
	 * @param uri
	 *           Uri of the Visio file whose pages are required.
	 * @param pageNames
	 *            String array of page-names to be retrieved. In case this
	 *            parameter is not defined, then metadata of all the Visio pages will
	 *            be returned.
	 * @return List of Pages within Visio document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO}
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	
	@RequestMapping(method = RequestMethod.GET, value = "/visio", params = {"uri"})
	@WebReturnType("xmlView")
	public VisioPageInfoList getVisioPagesInfoBasedOnURI(
			@RequestParam(value = "uri", required = true) String uri,
			@WebArrayParam("pages") String[] pageNames)
			throws AssetNotFoundException, InvalidAssetException,QppServiceException {
		
		VisioPage[] allPages = officeService.getVisioPagesBasedOnURI(uri);
		
		ArrayList<VisioPage> list = new ArrayList<VisioPage>();
		for (int i = 0; pageNames != null && i < pageNames.length; i++) {
			for (int j = 0; j < allPages.length; j++) {
				if (allPages[j].getPageName().equalsIgnoreCase(pageNames[i])) {
					list.add(allPages[j]);
				}
			}
		}
		if (pageNames != null && pageNames.length > 0) {
			return objectTransformer.transform(list.toArray(new VisioPage[] {}));
		} else {
			return objectTransformer.transform(allPages);
		}
	}
	
	/**
	 * Returns all pages defined in the Visio document. Each page
	 * object encapsulates its metadata like Page index & Name.<br/>
	 * In order to retrieve specific page, specify valid page names
	 * in pages parameter.
	 * @param inputStream
	 *           InputStream of the Visio document whose pages are required.
	 * @param pageNames
	 *            String array of page-names to be retrieved. In case this
	 *            parameter is not defined, then metadata of all the Visio pages will
	 *            be returned.
	 * @return List of Pages in the Visio document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO}
	 *             {@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 *  @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 * 		   
	 */
	
	@RequestMapping(method = RequestMethod.POST, value = "/visio")
	@WebReturnType("xmlView")
	public VisioPageInfoList getVisioPagesInfoBasedOnStreamContext(
			@WebInputStream InputStream inputStream,
			@WebArrayParam("pages") String[] pageNames)
			throws AssetNotFoundException, InvalidAssetException,
			QppServiceException,StreamingException {
		
		long contextId = officeService.createVisioReadWriteContext();
		officeStreamingService.upload(inputStream, contextId);
		
		VisioPage[] allPages = null;
		
		try {
			allPages = officeService.getVisioPagesBasedOnStreamContext(contextId);
		} finally {
			officeService.closeContext(contextId);
		}
		
		ArrayList<VisioPage> list = new ArrayList<VisioPage>();
		for (int i = 0; pageNames != null && i < pageNames.length; i++) {
			for (int j = 0; j < allPages.length; j++) {
				if (allPages[j].getPageName().equalsIgnoreCase(pageNames[i])) {
					list.add(allPages[j]);
				}
			}
		}
		if (pageNames != null && pageNames.length > 0) {
			return objectTransformer.transform(list.toArray(new VisioPage[] {}));
		} else {
			return objectTransformer.transform(allPages);
		}
	}
	
	/**
	 * Returns all Slides defined in the PowerPoint document. Each page
	 * object encapsulates its metadata like Slide index and Slide id.<br/>
	 * In order to retrieve specific Slide, specify valid index of slide
	 * in slideIndexes parameter.
	 * 
	 * @param assetId
	 *            Asset id of the PowerPoint document whose slides information are to be
	 *            retrieved.
	 * @param majorVersion
	 *            Major version of the PowerPoint asset.
	 * @param minorVersion
	 *            Minor version of the PowerPoint asset.
	 * @param slideIndexes
	 *            Array of Slide Indexes to be retrieved. In case this
	 *            parameter is not defined, then all the PowerPoint Slides will
	 *            be returned.
	 * @return List of Slides in the PowerPoint document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */	
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint/{assetId}")
	@WebReturnType("xmlView")
	public PowerPointSlideInfoList getPowerPointSlidesInfo(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@WebArrayParam("slideindexes") int[] slideIndexes)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {		
		
		File tempFile = null;
		PowerPointSlideInfoList powerPointSlideInfoList = null;		
		try {			
			tempFile = getMetadataFile(assetId, majorVersion, minorVersion);
			if(tempFile != null) {
				JAXBContext jaxbContext = JAXBContext.newInstance(PowerPointSlideInfoList.class);  	   
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
				powerPointSlideInfoList = (PowerPointSlideInfoList) jaxbUnmarshaller.unmarshal(tempFile);
				if (powerPointSlideInfoList != null && powerPointSlideInfoList.getPowerPointSlideInfo() != null && powerPointSlideInfoList.getPowerPointSlideInfo().size() > 0) {
					if (slideIndexes != null && slideIndexes.length > 0) {
						PowerPointSlideInfoList newPowerPointSlideInfoList = new PowerPointSlideInfoList();
						for (int i = 0; i < slideIndexes.length; i++) {
							int slideIndex = slideIndexes[i];
							for (int j = 0; j < powerPointSlideInfoList.getPowerPointSlideInfo().size(); j++) {
								PowerPointSlideInfo powerPointSlideInfo = powerPointSlideInfoList.getPowerPointSlideInfo().get(j);
								if (powerPointSlideInfo.getIndex() == slideIndex) {
									newPowerPointSlideInfoList.getPowerPointSlideInfo().add(powerPointSlideInfo);
									break;
								}
							}
						}
						return newPowerPointSlideInfoList;
					}
					return powerPointSlideInfoList;
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching DECONSTRUCTED_XML rendition.", e);
		} finally {
			try {
				if (tempFile != null) {
					tempFile.delete();
				}
			} catch (Exception e) {
				logger.error("Error while deleting file.", e);
			} 
		}
		
		AssetVersion assetVersion = null;
		if (majorVersion != null && minorVersion != null) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}
			
		PowerPointSlide[] allSlides = officeService.getPowerPointSlides(assetId,assetVersion);
		
		ArrayList<PowerPointSlide> list = new ArrayList<PowerPointSlide>();
		for (int i = 0; slideIndexes != null && i < slideIndexes.length; i++) {
			for (int j = 0; j < allSlides.length;j++) {
				if (allSlides[j].getSlideIndex() == slideIndexes[i]) {
					list.add(allSlides[j]); 
				}
			}
		}
		
		if (list != null && list.size() > 0) {
			return objectTransformer.transform(list.toArray(new PowerPointSlide[0]));
		} else {
			return objectTransformer.transform(allSlides);
		}
	
	}
	
	/**
	 *  Returns all Slides defined in the PowerPoint document. Each Slide
	 * object encapsulates its metadata like Slide index and Slide id.<br/>
	 * In order to retrieve specific slide, specify valid slideIndex
	 * in slideIndexes parameter.
	 * @param uri
	 *           Uri of the PowerPoint document whose slide metadata is required.
	 * @param slideIndexes
	 *            Array of Slide Indexes to be retrieved. In case this
	 *            parameter is not defined, then all the PowerPoint Slides will
	 *            be returned.
	 * @return List of Slides in the PowerPoint document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpoint", params={ "uri" })
	@WebReturnType("xmlView")
	public PowerPointSlideInfoList getPowerPointSlidesInfoBasedOnURI(
			@RequestParam("uri") String uri,
			@WebArrayParam("slideindexes") int[] slideIndexes)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
			
		PowerPointSlide[] allSlides = officeService.getPowerPointSlidesBasedOnURI(uri);
		ArrayList<PowerPointSlide> list = new ArrayList<PowerPointSlide>();
		for (int i = 0; slideIndexes != null && i < slideIndexes.length; i++) {
			for (int j = 0; j < allSlides.length; j++) {
				if (allSlides[j].getSlideIndex() == slideIndexes[i]) {
					list.add(allSlides[j]);
				}
			}
		}
		if (list != null && list.size() > 0) {
			return objectTransformer.transform(list.toArray(new PowerPointSlide[0]));
		} else {
			return objectTransformer.transform(allSlides);
		}
	}
	
	/**
	 *  Returns all Slides defined in the PowerPoint document. Each Slide
	 * object encapsulates its metadata like Slide index and Slide id.<br/>
	 * In order to retrieve specific slide, specify valid slideIndex
	 * in slideIndexes parameter.
	 * 
	 *@param inputStream
	 *            InputStream of the PowerPoint document whose slide metadata is required.
	 * @param slideIndexes
	 *            Array of Slide Indexes to be retrieved. In case this
	 *            parameter is not defined, then all the PowerPoint Slides will
	 *            be returned.
	 * @return List of Slides in the PowerPoint document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 *  @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 * 		   
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/powerpoint")
	@WebReturnType("xmlView")
	public PowerPointSlideInfoList getPowerPointSlidesInfoBasedOnStreamContext(
			@WebInputStream InputStream inputStream,
			@WebArrayParam("slideindexes") int[] slideIndexes)
			throws AssetNotFoundException, InvalidAssetException,
			QppServiceException,StreamingException {
			
		long contextId = officeService.createPowerPointReadWriteContext();
		officeStreamingService.upload(inputStream, contextId);
		
		PowerPointSlide[] allSlides = null;
		
		try {
			allSlides = officeService.getPowerPointSlidesBasedOnStreamContext(contextId);
		} finally {
			officeService.closeContext(contextId);
		}
		
		ArrayList<PowerPointSlide> list = new ArrayList<PowerPointSlide>();
		for (int i = 0; slideIndexes != null && i < slideIndexes.length; i++) {
			for (int j = 0; j < allSlides.length; j++) {
				if (allSlides[j].getSlideIndex() == slideIndexes[i]) {
					list.add(allSlides[j]);	    
				}
			}
		}
		
		if (list != null && list.size() > 0) {
			return objectTransformer.transform(list.toArray(new PowerPointSlide[0]));
		} else {
			return objectTransformer.transform(allSlides);
		}
	}
	
	private File getMetadataFile(long assetId, Long majorVersion, Long minorVersion) throws Exception {		
		File tempFile = null;
		OutputStream tempOutputStream = null;
		try {
			String renditionType = String.valueOf(DefaultRenditionTypes.DECONSTRUCTED_XML);		
			AssetRenditionInfoList assetRenditionInfoList = assetFacade.getAssetRenditionsInfo(assetId, majorVersion, minorVersion, renditionType);
		
			if (assetRenditionInfoList != null && assetRenditionInfoList.getAssetRenditionInfo() != null && assetRenditionInfoList.getAssetRenditionInfo().size() > 0) {			
				tempFile = File.createTempFile("temp", "xml", new File (officeTempDirectory));
				tempOutputStream = new FileOutputStream(tempFile);
				assetFacade.getAsset(assetId, majorVersion, minorVersion, null, false, false, null, renditionType, tempOutputStream, null, null);					        
			}
			return tempFile;
		} finally {
			if (tempOutputStream != null) {
				tempOutputStream.close();
			}
		}
	}
	
	/**
	 * Returns the chart from a Microsoft Excel Chart document in the desired image format. A Microsoft Excel Chart is an Excel document that contains only one worksheet and one chart. 
	 * The source document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Microsoft Excel Chart asset.
	 * @param majorVersion
	 *            major version of the Microsoft Excel Chart asset.
	 * @param minorVersion
	 *            minor version of the Microsoft Excel Chart asset.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_CHART}
	 * @throws ExcelDataException
	 *             If no chart is found in the first worksheet of the Microsoft Excel Chart. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelchart/{assetId}")
	public void getExcelChart(@PathVariable("assetId") long assetId, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		getSpecificComponent(assetId, majorVersion, minorVersion, null, ExcelDataObjectTypes.CHART, null,  ExcelDataOutputFormats.IMAGE,
				outputFormatProperties, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns the chart from a Microsoft Excel Chart document in the desired image format. A Microsoft Excel Chart is an Excel document that contains only one worksheet and one chart.
	 * The source Excel document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            uri of the Microsoft Excel Chart document
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_CHART}
	 * @throws ExcelDataException
	 *             If no chart is found in the first worksheet of the Microsoft Excel Chart. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelchart", params = {"uri"})
	public void getExcelChartBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {	
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);	
		getSpecificComponentBasedOnURI(uri, null, ExcelDataObjectTypes.CHART, null, ExcelDataOutputFormats.IMAGE,
				outputFormatProperties, httpServletResponse, contentDisposition, os);
	}

	/**
	 * Returns the chart from a Microsoft Excel Chart document in the desired image format. A Microsoft Excel Chart is an Excel document that contains only one worksheet and one chart. 
	 * The source Excel document should be supplied in the form of input stream. 
	 * 
	 * @param inputStream
	 *            inputStream from where the Microsoft Excel Chart document can be read
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_CHART}
	 * @throws ExcelDataException
	 *             If no chart is found in the first worksheet of the Microsoft Excel Chart. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/excelchart")
	public void getExcelChartBasedOnStream(@WebInputStream InputStream inputStream,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		getSpecificComponentBasedOnStream(inputStream, null, ExcelDataObjectTypes.CHART, null, ExcelDataOutputFormats.IMAGE,	outputFormatProperties, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns the named range from a Microsoft Excel Table document in the desired output format. A Microsoft Excel Table is an Excel document that contains only one worksheet and one named range. 
	 * The source document should be supplied in the form of Platform Asset.
	 * 
	 * @param assetId
	 *            asset id of the Microsoft Excel Table document whose named range is to be retrieved in desired output format.
	 * @param majorVersion
	 *            major version of the Microsoft Excel Table asset.
	 * @param minorVersion
	 *            minor version of the Microsoft Excel Table asset.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_TABLE}
	 * @throws ExcelDataException
	 *             If no named range is found in the first worksheet of the Microsoft Excel Table. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/exceltable/{assetId}")
	public void getExcelTable(@PathVariable("assetId") long assetId,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		getSpecificComponent(assetId, majorVersion, minorVersion, null, ExcelDataObjectTypes.NAMED_RANGE, null, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns the named range from a Microsoft Excel Table document in the desired output format. A Microsoft Excel Table is an Excel document that contains only one worksheet and one named range. 
	 * The source document should be supplied in the form of URI.
	 * 
	 * @param uri
	 *            URI of the Microsoft Excel Table document whose named range is to be retrieved in desired output format.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML//CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_TABLE}
	 * @throws ExcelDataException
	 *             If no named range is found in the first worksheet of the Microsoft Excel Table. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/exceltable", params = { "uri" })
	public void getExcelTableBasedOnURI(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws AssetNotFoundException, InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException,
			StreamingException, IOException {	
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);	
		getSpecificComponentBasedOnURI(uri, null, ExcelDataObjectTypes.NAMED_RANGE, null, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, os);
	}
	
	/**
	 * Returns the named range from a Microsoft Excel Table document in the desired output format. A Microsoft Excel Table is an Excel document that contains only one worksheet and one named range. 
	 * The source document should be supplied in the form of InputStream.
	 * 
	 * @param inputStream
	 *            InputStream of the Microsoft Excel Table document whose named range is to be retrieved in desired output format.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMARTTABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_TABLE}
	 * @throws ExcelDataException
	 *             If no named range is found in the first worksheet of the Microsoft Excel Table. The exception code will specify the
	 *             exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/exceltable")
	public void getExcelTableBasedOnStream(@WebInputStream InputStream inputStream,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {		
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		getSpecificComponentBasedOnStream(inputStream, null, ExcelDataObjectTypes.NAMED_RANGE, null, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, os);
	}

}

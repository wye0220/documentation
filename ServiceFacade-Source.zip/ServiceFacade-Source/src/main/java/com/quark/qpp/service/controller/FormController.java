package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentType;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.form.service.dto.Form;
import com.quark.qpp.core.form.service.exceptions.FormServiceExceptionCodes.InvalidFormExceptionCodes;
import com.quark.qpp.core.form.service.exceptions.InvalidFormException;
import com.quark.qpp.core.form.service.local.FormService;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.local.WorkflowService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.FormAttribute;
import com.quark.qpp.service.xmlBinding.FormAttributeList;
import com.quark.qpp.service.xmlBinding.FormInfo;
import com.quark.qpp.service.xmlBinding.FormInfoList;

public class FormController {

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private FormService formService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ContentStructureService contentStructureService;

	private final Logger logger = Logger.getLogger(this.getClass());

	public FormInfoList getAllForms() throws WorkflowNotFoundException, InvalidContentTypeException, QppServiceException {
		FormInfoList formInfoList = new FormInfoList();
		List<FormInfo> list = formInfoList.getFormInfo();
		Workflow[] workflows = workflowService.getAllWorkflows();
		// fetch workflow forms
		for (Workflow workflow : workflows) {
			List<FormInfo> workflowForms = getForms(String.valueOf(workflow.getId()));
			list.addAll(workflowForms);
		}
		// fetch collection forms
		FormInfo formInfo = getContentTypeForm(String.valueOf(DefaultContentTypes.COLLECTION), null);
		if (formInfo != null) {
			list.add(formInfo);
		}
		fetchDescendentConentTypeForms(contentStructureService.getContentType(DefaultContentTypes.COLLECTION), list);
		return formInfoList;
	}

	/*
	 * Fetch the forms for all the descendent content types.
	 */
	private void fetchDescendentConentTypeForms(ContentType contentType, List<FormInfo> list) throws InvalidContentTypeException,
			QppServiceException {
		for (ContentType childContentType : contentType.getSubContentTypes()) {
			long childContentTypeId = childContentType.getId();
			FormInfo childFormInfo = getContentTypeForm(String.valueOf(childContentTypeId), null);
			if(childFormInfo!=null){
				list.add(childFormInfo);
			}
			fetchDescendentConentTypeForms(childContentType, list);
		}
	}

	public List<FormInfo> getForms(String workflow) throws WorkflowNotFoundException, InvalidContentTypeException, QppServiceException {
		long workflowId = facadeUtility.getWorkflowIds(new String[] { workflow })[0];
		List<FormInfo> formList = new ArrayList<FormInfo>();
		Form[] workflowForms = formService.getWorkflowForms(workflowId);
		for (int i = 0; workflowForms != null && i < workflowForms.length; i++) {
			FormInfo FormInfo = objectTransformer.transform(workflowForms[i], workflowId);
			formList.add(FormInfo);
		}
		return formList;
	}

	public FormInfo getContentTypeForm(String contentTypeIdOrPathOrName, String workflow) throws WorkflowNotFoundException, InvalidContentTypeException,
			QppServiceException {
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrPathOrName);
		long workflowId = -1;
		if (workflow != null) {
			workflowId = facadeUtility.getWorkflowIds(new String[] { workflow })[0];
		}
		Form form = formService.getContentTypeForm(contentTypeId, workflowId);
		if (form == null) {
			return null;
		}
		FormInfo FormInfo = objectTransformer.transform(form, workflowId);
		return FormInfo;
	}

	public FormInfoList createForms(FormInfoList formInfoList) throws AttributeNotFoundException, InvalidFormException, QppServiceException {
		FormInfoList createdFormsList = new FormInfoList();
		if (formInfoList != null) {
			Iterator<FormInfo> it = formInfoList.getFormInfo().iterator();
			while (it.hasNext()) {
				FormInfo form = it.next();
				/** skip if content type form is default */
				// if (!form.isDefaultForm()) {
				try {
					FormInfo newFormInfo = createForm(form);
					if (newFormInfo != null) {
						createdFormsList.getFormInfo().add(newFormInfo);
					}
				} catch (QppServiceException e) {
					logger.error(
							"Error while creating form for content type " + form.getContentTypeName() + " and workflow "
									+ form.getWorkflowName(), e);
					if (formInfoList.getFormInfo().size() == 1) {
						throw e;
					}
				}
				// }
			}
		} else {
			throw new InvalidFormException(InvalidFormExceptionCodes.FORM_NOT_FOUND);
		}
		return createdFormsList;
	}

	private FormInfo createForm(FormInfo formInfo) throws AttributeNotFoundException, InvalidFormException, InvalidContentTypeException,
			QppServiceException {
		long contentTypeId = -1;
		if (formInfo.getContentTypeName() != null) {
			contentTypeId = facadeUtility.getContentTypeIdForText(formInfo.getContentTypeName());
		} else if (formInfo.getContentTypeId() > 0) {
			contentTypeId = formInfo.getContentTypeId();
		}
		long workflowId = -1;
		if (formInfo.getWorkflowName() != null) {
			workflowId = facadeUtility.getWorkflowIds(new String[] { formInfo.getWorkflowName() })[0];
		} else if (formInfo.getWorkflowId() > 0) {
			workflowId = formInfo.getWorkflowId();
		}
		String strFormContent = null;
		if (!formInfo.isDefaultView()) {
			strFormContent = getFormDesignerXml(formInfo.getFormAttributeList());
		}
		Form savedForm = formService.getContentTypeForm(contentTypeId, workflowId);
		long formId = -1;
		if (savedForm != null) {
			formId = savedForm.getId();
			formInfo.setId(formId);
			updateContentTypeForm(formInfo);
		} else {
			formId = formService.createForm(contentTypeId, workflowId, strFormContent);
		}
		Form newForm = formService.getForm(formId);
		FormInfo newFormInfo = objectTransformer.transform(newForm, workflowId);
		return newFormInfo;
	}

	private String getFormDesignerXml(FormAttributeList formAttributeList) throws AttributeNotFoundException, QppServiceException {
		StringBuffer formContent = new StringBuffer("<qpsFormDesigner>");
		formContent
				.append("<formSettings><defaultForm>false</defaultForm><useUpperLevel>false</useUpperLevel><snapHorizontal>true</snapHorizontal><snapVerticle>true</snapVerticle></formSettings>");
		if(formAttributeList != null){
			List<FormAttribute> attributeInfoList = formAttributeList.getFormAttribute(); 
			formContent.append("<attributeList>");
			if (attributeInfoList != null && attributeInfoList.size() > 0) {
				Iterator<FormAttribute> iterator = attributeInfoList.iterator();
				while (iterator.hasNext()) {
					FormAttribute attributeInfo = iterator.next();
					if (attributeInfo.getName() != null && !attributeInfo.getName().isEmpty()) {
						formContent.append("<attribute id=\"" + attributeService.getAttributeByName(attributeInfo.getName()).getId() + "\">");
					} else {
						formContent.append("<attribute id=\"" + attributeInfo.getId() + "\">");
					}
					formContent.append("<size x=\"" + attributeInfo.getXPos() + "\" y=\"" + attributeInfo.getYPos() + "\" width=\""
							+ attributeInfo.getTotalWidth() + "\" labelWidth=\"" + attributeInfo.getLabelWidth() + "\" controlWidth=\""
							+ attributeInfo.getControlWidth() + "\"/>");
					formContent.append("</attribute>");
				}
			}
			formContent.append("</attributeList>");
		}
		formContent.append("</qpsFormDesigner>");
		return formContent.toString();
	}

	public FormInfoList updateForms(FormInfoList formInfoList) throws AttributeNotFoundException, InvalidFormException,
			WorkflowNotFoundException, InvalidContentTypeException, QppServiceException {
		FormInfoList updatedFormInfoList = new FormInfoList();
		if (formInfoList != null) {
			Iterator<FormInfo> it = formInfoList.getFormInfo().iterator();
			while (it.hasNext()) {
				FormInfo form = it.next();
				try {
					FormInfo updatedFormInfo = updateContentTypeForm(form);
					updatedFormInfoList.getFormInfo().add(updatedFormInfo);
				} catch (QppServiceException e) {
					logger.error(
							"Error while updating form for content type " + form.getContentTypeName() + " and workflow "
									+ form.getWorkflowName(), e);
					if (formInfoList.getFormInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidFormException(InvalidFormExceptionCodes.FORM_NOT_FOUND);
		}
		return updatedFormInfoList;
	}

	private FormInfo updateContentTypeForm(FormInfo formInfo) throws AttributeNotFoundException, InvalidFormException,
			WorkflowNotFoundException, InvalidContentTypeException, QppServiceException {
		long formId = -1;
		long workflowId = -1;
		
		if (formInfo.getWorkflowId() > 0) {
			// workflowId = facadeUtility.getWorkflowIds(new String[] { formInfo.getWorkflowName() })[0];
			workflowId = formInfo.getWorkflowId();
		} else if (formInfo.getWorkflowName() != null) {
			workflowId = facadeUtility.getWorkflowIds(new String[] { formInfo.getWorkflowName() })[0];
		}
		
		if (formInfo.getId() == null || formInfo.getId() <= 0) {
			long contentTypeId = -1;
			if(formInfo.getContentTypeName() != null && !formInfo.getContentTypeName().isEmpty()){
				contentTypeId = facadeUtility.getContentTypeIdForText(formInfo.getContentTypeName());
			}else{
				contentTypeId = formInfo.getContentTypeId();
			}
			Form existingForm = formService.getContentTypeForm(contentTypeId, workflowId);
			// There may be a scenario where we are trying to update a form on the basis of content type & workflow given, but there does not
			// exist a form. Hence following null check required.
			if (existingForm != null) {
				formId = existingForm.getId();
			}
		} else {
			formId = formInfo.getId();
		}
		/** convert form attribute info to form designer xml. */
		String strFormContent = null;
		if (!formInfo.isDefaultView()) {
			strFormContent = getFormDesignerXml(formInfo.getFormAttributeList());
		}
		formService.updateFormContent(formId, strFormContent);
		Form updatedForm = formService.getForm(formId);
		FormInfo updatedFormInfo = objectTransformer.transform(updatedForm, workflowId);
		return updatedFormInfo;
	}

	public void deleteForm(String workflow, String contenttype) throws QppServiceException {
		long workflowId = -1;
		if (workflow != null) {
			workflowId = facadeUtility.getWorkflowIds(new String[] { workflow })[0];
		}
		long contentTypeId = -1;
		if (contenttype != null) {
			contentTypeId = facadeUtility.getContentTypeId(contenttype);
		}
		if (workflowId > 0 && contentTypeId > 0) {
			Form form = formService.getContentTypeForm(contentTypeId, workflowId);
			if(form != null)
				formService.deleteForm(form.getId());
			else 
				throw new InvalidFormException(InvalidFormExceptionCodes.FORM_NOT_FOUND);
			return;
		}
		Form[] forms = formService.getWorkflowForms(workflowId);
		for (int i = 0; forms != null && i < forms.length; i++) {
			formService.deleteForm(forms[i].getId());
		}
	}
}

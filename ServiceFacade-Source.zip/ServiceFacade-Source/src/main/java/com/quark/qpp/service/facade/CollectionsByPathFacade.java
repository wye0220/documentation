/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.collection.service.exceptions.CollectionInUseException;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.exceptions.InvalidJobJacketException;
import com.quark.qpp.core.collection.service.exceptions.InvalidRevisionControlException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.query.service.dto.CollectionDisplay;
import com.quark.qpp.core.security.service.exceptions.InvalidGroupException;
import com.quark.qpp.core.security.service.exceptions.InvalidUserException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.workflow.service.constants.ConstraintTypes;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowInUseException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;
import com.quark.qpp.rest.framework.annotations.WebResourcePathParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.ApplicablePrivilegesInfo;
import com.quark.qpp.service.xmlBinding.AttributeConstraintsInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.JobJacketInfo;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.RevisionControlInfoList;
import com.quark.qpp.service.xmlBinding.RoutingInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.UserInfoList;


/**
 * A facade to create,update,fetch and delete collections on the basis of collection path.
 */
@Controller(value = "collectionsByPathFacade")
@RequestMapping("/collectionsbypath/**")
public class CollectionsByPathFacade {

	private static final String PATH_IDENTIFIER = "collectionsbypath";
	
	@Autowired
	private CollectionFacade collectionFacade;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private ObjectTransformer objectTransformer;
	
	

	/**
	 * Returns default jobjacket of the collection. Returns null if no jobjacket is specified as default for this
	 * collection or content of the jobjacket is not found.
	 * 
	 * @param collectionPath
	 *            path of the collection whose default jobjacket is required.
	 * @return {@link JobJacketInfo} object containing detail about the job jacket.
	 * @throws InvalidCollectionException
	 *             if the collection to which the given jobjacket belongs is inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=defaultjobjacket")
	@WebReturnType("xmlView")
	public JobJacketInfo getCollectionDefaultJobJacket(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath) throws InvalidCollectionException,
			QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getCollectionDefaultJobJacket(collectionId);
	}

	
	/**
	 * Returns default ticket of the collection.
	 * 
	 * @param collectionPath
	 *            path of the collection whose default job ticket is required.
	 * @return Name of the default ticket specified for this collection.
	 * @throws InvalidCollectionException
	 *              if the collection with the given path supplied is invalid or inaccessible to the logged-on user
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=defaultticket")
	@WebReturnType("textView")
	public String getCollectionDefaultTicket(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath) throws InvalidCollectionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getCollectionDefaultTicket(collectionId);
	}

	

	/**
	 * Writes the content of job jacket in an output stream for the job jacket with the given id and mapped to the collection with given id.
	 * 
	 * @param outputStream
	 *            output stream onto which the jobjacket content is to be written
	 * @param collectionPath
	 *            path of the collection whose jobajcket XML content is required
	 * @param jobJacketId
	 *            Id of the jobjacket whose XML content is required.
	 * @throws InvalidCollectionException
	 *             if the collection to which the given jobjacket belongs is inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 *             In case of failed or interrupted I/O operations.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=jobjacketcontent")
	public void getJobJacketContent(@WebOutputStream OutputStream outputStream, @WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value = "jobjacket") long jobJacketId) throws InvalidCollectionException, QppServiceException, IOException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		collectionFacade.getJobJacketContent(outputStream, collectionId, jobJacketId);
	}

	/**
	 * Returns applicable role of the logged-in user for the given collection. This would return the default userclass of the user if there
	 * is no userclass overridden for the given collection.
	 * 
	 * @param collectionPath
	 *            path of the collection for which applicable role is to be retrieved.
	 * @return {@link RoleInfo} object containing privilege details
	 * @throws InvalidCollectionException
	 *             if the collection path supplied is invalid or inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
//	@RequestMapping(method = RequestMethod.GET, params = "op=applicablerole")
//	@WebReturnType("xmlView")
//	public RoleInfo getApplicableRole(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath) throws InvalidCollectionException,
//			QppServiceException {
//		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
//		return collectionFacade.getApplicableRole(collectionId);
//	}
	
	/**
	 * Returns privileges applicable to the logged-in user for the given collection. These privileges are union of privileges of following
	 * userclasses:
	 * <ul>
	 * <li>Userclass of the logged in user in the given collection, only if the user is mapped to the given collection.</li>
	 * <li>Userclasses of collection mapped groups of which the logged in user is member of.</li>
	 * </ul>
	 * Depending upon the input parameters, appropriate applicable privileges will be returned.<br>
	 * Supported input combinations to retrieve applicable privileges are :<br>
	 * <br>
	 * <ul>
	 * <li>Default case : Get all applicable privileges for this collection:<br>
	 * Example:....collectionsbypath/Home?op=applicableprivileges</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled status privileges:<br>
	 * Example:....collectionsbypath/Home?op=applicableprivileges&status=10</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled status privileges for a content type:<br>
	 * Example:....collectionsbypath/Home?op=applicableprivileges&status=10&contenttype=asset</li>
	 * <br>
	 * <br>
	 * <li>Get enabled status privileges for a content type from the mentioned privileges list:<br>
	 * Example:....collectionsbypath/Home?op=applicableprivileges&status=10&contenttype=Picture&privileges=11000,20000,...,...</li>
	 * <br>
	 * <br>
	 * <li>Get all enabled content type privileges:<br>
	 * Example:...collectionsbypath/Home?op=applicableprivileges&contenttype=asset</li><br>
	 * <br>
	 * <li>Get enabled content type privileges from the mentioned privileges list<br>
	 * Example:...collectionsbypath/Home?op=applicableprivileges&contenttype=Picture&privileges=110000,20000,...,...</li><br>
	 * <br>
	 * 
	 * @param collectionPath
	 *            Path of the collection for which applicable privileges are to be evaluated.
	 * @param statusIdOrNameOrStatusWorkflowCombination
	 *            Id, name or status workflow combination of the status.For example, status=10 or status=ReadyForPublish or status=EditorialWorkflow/ReadyForPublish
	 * @param contentTypeIdOrPathOrName
	 *            Id, name or hierarchy of the content type.
	 * @param privilegeIdsOrNames
	 *            Id or name of the privileges to be retrieved.
	 * @return ApplicablePrivilegesInfo object containing enabled privilege ids depending upon the input parameters.
	 * @throws InvalidCollectionException
	 *             In case of invalid collection id or the collection is inaccessible to the logged on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "applicableprivileges=true")
	@WebReturnType("xmlView")
	public ApplicablePrivilegesInfo getApplicablePrivileges(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value="status", required=false) String statusIdOrNameOrStatusWorkflowCombination, @RequestParam(value="contenttype", required=false) String contentTypeIdOrPathOrName,
			@RequestParam(value="privileges",required=false) String[] privilegeIdsOrNames) throws InvalidCollectionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicablePrivileges(collectionId, statusIdOrNameOrStatusWorkflowCombination, contentTypeIdOrPathOrName, privilegeIdsOrNames);
	}

	/**
	 * Returns complete collection hierarchy of the given collection. By default the below mentioned flags are false and thus this method
	 * will return metadata of each collection in the hierarchy. The parameters like getAssets/getUsers/,,,/attributes will be considered for
	 * every collection in the hierarchy. For example if getUsers flag is true, it will retrieve users for all the collections down the
	 * hierarchy. Thus the behaviour of parameters like getAssets/attributes/getUsers/... will be replicated to every collection in the
	 * hierarchy.
	 * 
	 * @param collectionPath
	 * 			path of the collection for which complete collection hierarchy is to be retrieved.
	 * @param attributes
	 *            array of collection attributes to be retrieved. An attribute can be specified by id or name. Example : 2,created, Is
	 *            Template, 57,Content Type Hierarchy,.......These attribute values will be retrieved for each collection in the hierarchy.
	 * @param getAssets
	 *            boolean flag to retrieve each collection's assets.
	 * @param getWorkflows
	 *            get all applicable worklfow's for each collection in the hierarchy. Specify contenttypes parameter in order to get
	 *            workflow's associated with these content types only.
	 * @param getUsers
	 *            get users mapped to each collection
	 * @param getGroups
	 *            get groups mapped to each collection
	 * @param getRoutings
	 *            get status routings for each collection for mentioned workflow.
	 * @param getRevisionControls
	 *            get revision controls for each collection.
	 * @param getJobJackets
	 *            get jobjacket's mapped to each collection
	 * @param contentTypes
	 *            array of content types (id, path (e.g. System;Asset;Document) or name(e.g. Document)) corresponding to which workflow's will be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required. If workflow is not given but workflows=true, then status
	 *            routing preferences of all applicable workflow in the collection is being provided.It is mandatory to specify either the
	 *            workflow parameter or enable the getWorkflows flag to fetch status routings.
	 * @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return CollectionInfoList encapsulating the complete collection hierarchy of the collection with the given id.
	 * @throw UserPrivilegeException This exception is thrown if the loggedOn user doesn't have a specific privilege. Additional Info will
	 *        refer to the disabled privilege for which exception has been thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, params="hierarchy=true")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfoList getCollectionHierarchy(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@WebArrayParam(value = "attributes") String[] attributes, @RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets, @WebArrayParam("contenttypes") String[] contentTypes,
			@RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes) throws InvalidCollectionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getCollectionHierarchy(collectionId, attributes, getAssets, getWorkflows, getUsers, getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
	}

	/**
	 * Returns collection metadata. Depending upon the flag value, the collection metadata is returned. For instance if
	 * only collection mapped workflows are to be retrieved, then set workflows flag as true.If only collection assets
	 * are to be retrieved then set assets flag as true and so on.
	 * 
	 * @param collectionPath
	 *            Path of the collection whose details are required.
	 * @param attributes
	 *            list of attribute ids or names to be fetched. Attribute name is given preference over id.
	 * @param getAssets
	 *            boolean flag to indicate if collection assets are also to be retrieved.
	 * @param getChildCollections
	 *            boolean flag if true, will return immediate child collections accessible to the logged On user.
	 * @param getParentCollections
	 *            Returns collection info of ancestor collections up the hierarchy based on access control. While going
	 *            up the hierarchy if there exists any inaccessible collection (on which the logged on user does not
	 *            have access to), collection path array would contain CollectionInfo objects of only those collections
	 *            which are lying below that collection.
	 * @param getWorkflows
	 *            returns workflows mapped for given collection
	 * @param getUsers
	 *            Returns users mapped for given collection
	 * @param getGroups
	 *            Returns groups mapped for given collection.
	 * @param getRoutings
	 *            Returns status routings of the workflow defined in workflow request parameter for given collection.
	 * @param getRevisionControls
	 *            Get revision control settings of the Collection for all content types or for the specified content
	 *            types defined in contentTypes request parameter.
	 * @param getJobJackets
	 *            Returns jobajackets mapped to the given collection.
	 * @param contentTypes
	 *            list of content types for which revision control settings are to be fetched.
	 * @param workflow
	 *            name/id of the workflow whose whose status routings are required.
	 *  @param assetAttributes
	 *  		  array of display attributes ids or names to be used while querying for Assets within a Collection.For example, assetattributes=2, workflow, 55, status,...
	 *  		  If not specified, then the {@link CollectionDisplay#getAssetView()} of the context collection will be used for querying the collection assets.
	 * @return {@link com.quark.qpp.service.xmlBinding.CollectionInfo} object containing collection details.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 * 
	 */
	@RequestMapping(method = RequestMethod.GET)
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfoList getCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@WebArrayParam(value = "attributes") String[] attributes, @RequestParam(value = "assets", defaultValue = "false") boolean getAssets,
			@RequestParam(value = "childcollections", defaultValue = "false") boolean getChildCollections,
			@RequestParam(value = "parentcollections", defaultValue = "false") boolean getParentCollections,
			@RequestParam(value = "workflows", defaultValue = "false") boolean getWorkflows,
			@RequestParam(value = "users", defaultValue = "false") boolean getUsers,
			@RequestParam(value = "groups", defaultValue = "false") boolean getGroups,
			@RequestParam(value = "routings", defaultValue = "false") boolean getRoutings,
			@RequestParam(value = "revisioncontrols", defaultValue = "false") boolean getRevisionControls,
			@RequestParam(value = "jobjackets", defaultValue = "false") boolean getJobJackets,
			@WebArrayParam("contenttypes") String[] contentTypes,  @RequestParam(value = "workflow", required = false) String workflow, @WebArrayParam(value = "assetattributes") String[] assetAttributes) throws InvalidCollectionException,
			QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getCollection(collectionId, attributes, getAssets, getChildCollections, getParentCollections, getWorkflows, getUsers, getGroups, getRoutings, getRevisionControls, getJobJackets, contentTypes, workflow, assetAttributes);
	}
	
	/**
	 * Returns list of applicable routings users for the given collection for specified workflow and status. This will return those
	 * collection mapped users that have their userclass same as one of the status mapped userclasses.
	 * 
	 * @param collectionPath
	 *            Path of the collection whose for which applicable routings users are to be fetched
	 * @param workflowIdOrName
	 *            Id or name of the workflow for which collection applicable users are to be fetched. This is an optional field.If not
	 *            mentioned, the workflow will be evaluated on the basis of status input.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or workflow-status combination for the status to be considered.For example : status=10 or status=New Status 001
	 *            or status=Default Workflow/New Status 001.
	 * @param considerRoutingGroups
	 *            If true, applicable routing groups will also be considered and all users of these groups will be included in the list of users being returned. 
	 * @return List of collection applicable routing users.
	 * @throws WorkflowNotFoundException
	 *             In case the workflow with the given id/name does not exist.
	 * @throws InvalidStatusException
	 *             In case of an invalid status id or the status is not applicable to the mentioned workflow.Exception code will specify the
	 *             exact cause of exception.
	 * @throws StatusNotFoundException
	 *             In case status with the given id/name does not exist.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user does not have access to this collection.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, params = "routingusers=true")
	@WebReturnType("xmlView")
	public UserInfoList getApplicableRoutingUsers(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value = "workflow", required = false) String workflowIdOrName,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination,
			@RequestParam(value = "considerroutinggroups", defaultValue = "false") boolean considerRoutingGroups) throws WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, InvalidCollectionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicableRoutingUsers(collectionId, workflowIdOrName, statusIdOrNameOrWorkflowStatusCombination, considerRoutingGroups);
	}

	/**
	 * Returns array of applicable routings groups for the given collection for specified workflow and status. This will return those
	 * collection mapped groups that have their userclass same as one of the status mapped userclasses.
	 * 
	 * @param collectionPath
	 *            Path of the collection for which applicable routings groups are to be fetched
	 * @param workflowIdOrName
	 *            Id/name of the workflow against which applicable routings groups are to be fetched for a collection.This is an optional
	 *            parameter.If not mentioned, then the workflow will be evaluated on the basis of input status.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or workflow-status combination of the status to be considered. For example : status=10 or status=New Status 001
	 *            or status=Default Workflow/New Status 001.
	 * @return List of collection groups applicable for the given collection, workflow & status combination.
	 * @throws WorkflowNotFoundException
	 *             If the workflow with the given id/name doesn't exist.
	 * @throws StatusNotFoundException
	 *             If the status with the specified id/name does not exist
	 * @throws InvalidStatusException
	 *             If the status does not belong to the specified workflow.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "routinggroups=true")
	@WebReturnType("xmlView")
	public GroupInfoList getApplicableRoutingGroups(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value = "workflow", required = false) String workflowIdOrName,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination) throws WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, InvalidCollectionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicableRoutingGroups(collectionId, workflowIdOrName, statusIdOrNameOrWorkflowStatusCombination);
	}
	
	/**
	 * Returns attribute constraints applicable for the given status and collection for logged-in user.<BR>
	 * User may have multiple userclasses, due to its membership in multiple groups which are mapped to the collection with different
	 * userclasses. <b>Since attribute constraints are defined per userclass, multiple constraints in such cases are evaluated and the most
	 * permissive set of attribute constraints are returned.</b> <br/>
	 * Following is the order of constraints permissiveness:
	 * <ol>
	 * <li>No constrained applied</li>
	 * <li>{@link ConstraintTypes#REQUIRE_VALUE}</li>
	 * <li>{@link ConstraintTypes#REQUIRE_CHANGE}</li>
	 * <li>{@link ConstraintTypes#PREVENT_CHANGE}</li>
	 * </ol>
	 * 
	 * For example: If the collection is mapped to 3 Groups - G1, G2 and G3 with userclasses U1, U2 and U3 respectively and logged-on user
	 * is a member of all of these groups.
	 * <ul>
	 * <li>For U1 there is no constraint applied, for U2 {@link ConstraintTypes#REQUIRE_CHANGE} and for U3
	 * {@link ConstraintTypes#PREVENT_CHANGE} - then applicable constraint would be no constraint.</li>
	 * <li>For U1 there is {@link ConstraintTypes#REQUIRE_CHANGE} applied, for U2 {@link ConstraintTypes#REQUIRE_VALUE} and for U3
	 * {@link ConstraintTypes#PREVENT_CHANGE} - then applicable constraint would be {@link ConstraintTypes#REQUIRE_VALUE}.</li>
	 * </ul
	 * 
	 * @param collectionPath
	 *            Path of the collection whose applicable constraints are required.
	 * @param statusIdOrNameOrWorkflowStatusCombination
	 *            Id, name or status workflow combination of the status.For example, status=10 or status=ReadyForPublish or
	 *            status=EditorialWorkflow/ReadyForPublish
	 * @param attributeIdsOrNames
	 *            Array of attribute ids or names whose constraints are required.For example, attributes=2,510,resource id,...
	 * @return List of <code>AttributeConstraintsInfo</code> objects for the given set of attributes applicable for the logged-in user for
	 *         the given status and collection.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws StatusNotFoundException
	 *             If the status with the given id or name or workflow status combination does not exists.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "applicableconstraints=true")
	@WebReturnType("xmlView")
	public AttributeConstraintsInfoList getApplicableAttributeConstraints(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam("status") String statusIdOrNameOrWorkflowStatusCombination,
			@WebArrayParam("attributes") String[] attributeIdsOrNames) throws InvalidCollectionException, StatusNotFoundException,
			QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicableAttributeConstraints(collectionId, statusIdOrNameOrWorkflowStatusCombination, attributeIdsOrNames);
	}
	
	/**
	 * Returns applicable status transition for the given workflow, status and collection for the logged-in user.<br>
	 * If the status transition is overridden for the given userclass, then overridden will be considered.But, if there are no userclass
	 * overridden status transitions then the default status transition is returned.And if the
	 * {@link Workflow#isConstrainedStatusTransition()} flag of workflow is false,then all the statuses of the workflow(expect for the given
	 * status)will be returned in next possible array of statuses.<br>
	 * User may have multiple userclasses, due to its membership in multiple groups which are mapped to the collection with different
	 * userclasses. Thus the overridden status transitions are evaluated in the following manner:
	 * <ul>
	 * <li>Userclasses of the collection mapped logged-in-user and groups (of which logged-in-user is member of) are determined.</li>
	 * <li>For all the applicable userclasses, applicable (default if not overridden for the userclass) status transitions are retrieved.</li>
	 * <li>The set of {@link StatusTransition#getNextPossibleStatusIds()} is union of {@link StatusTransition#getNextPossibleStatusIds()}
	 * from all the status transitions corresponding to the applicable userclasses.</li> </br>
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable status transition is to be evaluated for given status.
	 * @param workflowIdOrName
	 *            Id of the workflow for which applicable status transitions are to be evaluated.
	 * @param statusIdOrName
	 *            Id or name of the status for which status transition is to be retrieved.For example status=10 or
	 *            status=ReadyForPublish.This is an optional parameter if not mentioned then the complete workflow status transitions will
	 *            be returned.
	 * @return List of applicable status transitions for the entire workflow or a particular status and collection.
	 * @throws InvalidCollectionException
	 *             In case collection with the given id doesn't exist or the collection is inaccessible to the logged-in user.
	 * @throws StatusNotFoundException
	 *             In case status with the given id or name doesn't exist.
	 * @throws InvalidStatusException
	 *             In case status doesn't belong to the given workflow.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "statustransitions=true")
	@WebReturnType("xmlView")
	public StatusTransitionInfoList getApplicableStatusTransition(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value = "workflow", required = true) String workflowIdOrName,
			@RequestParam(value = "status", required = false) String statusIdOrName)
			throws InvalidCollectionException, StatusNotFoundException, InvalidStatusException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicableStatusTransition(collectionId, workflowIdOrName, statusIdOrName);
	}

	/**
	 * Returns initial applicable statuses for the given workflow and collection. In case the given workflow has constrained status
	 * transitions and the collection has multiple applicable userclasses due to its membership, then "Workflow Initiating Statuses" from
	 * all the user classes are merged & returned. However, if workflow does not have constrained status transitions then all statues of the
	 * workflow are returned.
	 * 
	 * @param collectionId
	 *            Id of the collection for which applicable "Workflow Initiating Statuses" are to be fetched in context of the given
	 *            workflow.
	 * @param workflowIdOrName
	 *            Id or name of the workflow whose "Workflow Initiating Statuses" are to be fetched.
	 * @return List of applicable "Workflow Initiating Statuses" for the given collection and workflow.
	 * @throws InvalidCollectionException
	 *             In case collection with the given id doesn't exist or the collection is inaccessible to the logged-in user.
	 * @throws WorkflowNotFoundException
	 *             If workflow with the given id does not exist.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "workflowinitiatingstatuses=true")
	@WebReturnType("xmlView")
	public StatusInfoList getApplicableWorkflowInitialStatuses(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam("workflow") String workflowIdOrName) throws InvalidCollectionException, WorkflowNotFoundException,
			QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.getApplicableWorkflowInitialStatuses(collectionId, workflowIdOrName);
	}
	

	/**
	 * Move collection along with child collections and assets under new parent collection
	 * 
	 * @param collectionPath
	 *            Path of the collection to be moved.
	 * @param targetParentCollection
	 *            Id or collection path of the collection in which collection is to be moved.
	 * @return CollectionInfo object of the moved collection.
	 * @throws InvalidCollectionException
	 *             If specified collection is invalid or inaccessible to the logged-on user.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during pre or post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=move")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo moveCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam("targetparent") String targetParentCollection) throws InvalidCollectionException, RepositoryActionException,
			QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.moveCollection(collectionId, targetParentCollection);
	}

	/**
	 * Duplicates a collection. By default the metadata of the original collection like workflows, users, routings, revisioncontrols etc..will be mapped to the new collection being created.
	 * In order to prevent the original collection metadata being mapped to new collection, set the boolean flags like duplicateWorkflows, duplicateMembers,..as false.
	 * If assets flag is true, then assets are also duplicated along with the collection. In case the assets are also to be duplicated then metadata flags like
	 * duplicateHierarchy, duplicateWorkflows, duplicateMembers, etc will be overridden as true.
	 * 
	 * @param collectionPath
	 *            refers to the collection with given path, that needs to be duplicated.
	 * @param collectionName
	 *            Name to be used for duplicated collection.
	 * @param targetParentCollection
	 *            Id or collection path of the collection under which the given collection would be duplicated. If
	 *            specified 0, collection would be duplicated parallel to the source collection.
	 * @param duplicateHierarchy
	 *            A boolean flag indicating whether to duplicate only given collection or collection with complete
	 *            hierarchy. While duplicating the collection hierarchy, only collections would be duplicated and
	 *            collection templates would be ignored.
	 * @param duplicateWorkflows
	 *            A boolean flag indicating whether to duplicate collection workflows.
	 * @param duplicateMembers
	 *            A boolean flag indicating whether to duplicate collection users and groups.
	 * @param duplicateStatusRoutings
	 *            A boolean flag indicating whether to duplicate collection status routings. This argument has
	 *            dependency on duplicateWorkflows and duplicateMembers. So if it is true but one of duplicateWorkflows
	 *            and duplicateMembers is false then it would be considered as false.
	 * @param duplicateJobjackets
	 *            A boolean flag indicating whether to duplicate collection jobjackets.
	 * @param duplicateRevisionControls
	 *            A boolean flag indicating whether to duplicate collection revision control settings.
	 * @param duplicateWithAssets
	 *            boolean flag to indicate whether the assets are also to be duplicated along with collection.
	 * @param createAssetsMinorVersion
	 *            boolean flag specifying whether to duplicate collection assets as a minor version or as a major
	 *            version.
	 * @return {@link com.quark.qpp.service.xmlBinding.CollectionInfo} object of the new duplicated collection.
	 * @throws InvalidCollectionException
	 *             This exception is thrown in case of following cases: <li>If collectionId is invalid. <li>If you don't
	 *             have access to parent collection of the collection that is being duplicated. <li>If the name being
	 *             supplied is not unique.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=duplicate")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo duplicateCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam("name") String collectionName, @RequestParam("targetparent") String targetParentCollection,
			@RequestParam(value = "duphierarachy", defaultValue = "true") boolean duplicateHierarchy,
			@RequestParam(value = "dupworkflows", defaultValue = "true") boolean duplicateWorkflows,
			@RequestParam(value = "dupmembers", defaultValue = "true") boolean duplicateMembers,
			@RequestParam(value = "duproutings", defaultValue = "true") boolean duplicateStatusRoutings,
			@RequestParam(value = "dupjobjackets", defaultValue = "true") boolean duplicateJobjackets,
			@RequestParam(value = "duprevisioncontrols", defaultValue = "true") boolean duplicateRevisionControls,
			@RequestParam(value = "assets", defaultValue = "false") boolean duplicateWithAssets,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createAssetsMinorVersion) throws InvalidCollectionException,
			RepositoryActionException, QppServiceException {
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.duplicateCollection(collectionId, collectionName, targetParentCollection, duplicateHierarchy, duplicateWorkflows,
				duplicateMembers, duplicateStatusRoutings, duplicateJobjackets, duplicateRevisionControls, duplicateWithAssets,
				createAssetsMinorVersion);
	}

	/**
	 * Creates new collection in the given parent collection and with the given metadata. Only users having access to the parent collection
	 * (in which collection is being created) would be allowed to create the collection.The metadata like worklfows, users,
	 * revisioncontrols, etc are mapped from the parent collection to the new collection being created. Admin user and logged-in user are
	 * implicitly mapped to the newly created collection.But when you instantiate a collection from template the parent collection's
	 * users/workflows/groups/.. will not be copied to newly instantiated collection instead the collection template's users/groups,... will
	 * be implicitly mapped to the new collection.
	 * 
	 * @param collectionPath
	 *            collection path of the new collection to be created. For instance, to create collection with name B in collection Home/A/
	 *            specify collection path as Home/A/B
	 * @param isTemplate
	 *            boolean flag if true indicates create a collection template else will create a new collection.
	 * @param contentType
	 *            type of the collection to be created. Default value is {@link DefaultContentTypes#GENERAL}
	 * @param attributeValueList
	 *            Metadata to be associated with the collection.
	 * @return collectionInfo object of the newly created collection
	 * @throws InvalidCollectionException
	 *             If the collection, having id or collection path specified in parentCollection parameter, either does not exist or the
	 *             logged on user has not access to this collection.
	 * @throws InvalidAttributeValueException
	 *             If any of the attribute values in supplied in the attributeValueList array is not valid.
	 * @throws RepositoryActionException
	 *             Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=create")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo createCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@RequestParam(value = "istemplate", defaultValue = "false") boolean isTemplate,
			@RequestParam(value = "contenttype", required = false) String contentType,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList) throws InvalidCollectionException,
			InvalidAttributeValueException, RepositoryActionException, QppServiceException {
		int index = collectionPath.lastIndexOf("/");
		String newCollectionName = collectionPath.substring(index+1);
		String parentcollectionPath = collectionPath.substring(0, index);
		return collectionFacade.createCollection(newCollectionName, parentcollectionPath, isTemplate, contentType, attributeValueList);
	}

	/**
	 * Updates the collection metadata depending upon the supplied data.
	 * 
	 * @param collectionPath
	 *            collection path of the new collection to be created. For
	 *            instance, to create collection with name B in collection
	 *            Home/A/ specify collection path as Home/A/B
	 * @param attributeValueList
	 *            attributeValueList object containing the attributes to be
	 *            updated.
	 * @param groupInfoList
	 *            List of groups to be mapped to the given collection. In groupInfo, either the group id or name must be specified to
	 *            identify the group.
	 * @param jobjacketIds
	 *            Ids of the jobjackets to be mapped for given collection.
	 * @param userInfoList
	 *            {@link UserInfoList} object containing info of users to be
	 *            mapped for given collection.
	 * @param workflows
	 *            Names or Ids of the workflows to be mapped for given
	 *            collection.
	 * @param revisionControlInfoList
	 *            {@link RevisionControlInfoList} object containing list of
	 *            revision controls to be set.
	 * @param routingInfoList
	 *            {@link RoutingInfoList} object containing routing info to be
	 *            set.
	 * @param defaultTicketName
	 *            name of the ticket template to be set as default for the
	 *            collection.
	 * @param applyToChildren
	 *            true if the updations(like groups/workflows/..) need to be
	 *            applied to all of the sub-collections as well. In this case
	 *            existing mapped(groups/workflows/..) of all the
	 *            sub-collections would be overridden.
	 * @param appendToChildren
	 *            true if the updations(like groups/workflows/..) need to be
	 *            merged to all sub-collections. In this case existing
	 *            mapped(workflows/groups/...) of sub-collections would remain
	 *            intact whereas any additional would be added to the
	 *            sub-collections.
	 * @return CollectionInfo containing updated details of the collection
	 * @throws InvalidCollectionException
	 *             If the collection, having id or collection path specified in
	 *             parentCollection parameter, either does not exist or the
	 *             logged on user has not access to this collection.
	 * @throws InvalidJobJacketException
	 *             In case the jobjacket with given id is invalid.
	 * @throws WorkflowInUseException
	 *             If any Asset in specified Collection is assigned a Workflow
	 *             which is not in the specified list of workflowIds. The
	 *             Workflow cannot be dissociated from the collection until any
	 *             Asset in the collection is assigned to that Workflow.
	 *             AdditionalInfo of exception would contain the workflowId and
	 *             collectionId for which exception has occured.
	 * @throws WorkflowNotFoundException
	 * 				If the workflow with given id or name doesnot exist.
	 * @throws StatusNotFoundException
	 * 				If the status with given id doesnot exist.
	 * @throws TrusteeNotFoundException
	 * 				If the trustee with given id doesnot exist.
	 * @throws AttributeNotFoundException
	 *             In case attribute with given id/name doesn't exist.
	 * @throws InvalidRevisionControlException
	 * 				 If revision control details are invalid. The exception code specifies exact reason.
	 * @throws InvalidUserException
	 * 				If the user id specified in invalid.
	 * @throws InvalidGroupException
	 * 				If the group id/name specified is invalid.
	 * @throws RepositoryActionException
	 * 				 Exception thrown by underlying RepositoryAdapter during post callback.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST,  params = "op=update")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.CollectionInfo updateCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @WebSerializedParam("groups") GroupInfoList groupInfoList,
			@WebArrayParam("jobjackets") long[] jobjacketIds, @WebSerializedParam("users") UserInfoList userInfoList,
			@WebArrayParam("workflows") String[] workflows, @WebSerializedParam("revisioncontrols") RevisionControlInfoList revisionControlInfoList,
			@WebSerializedParam("routings") RoutingInfoList routingInfoList,
			@RequestParam(value = "ticketname", required = false) String defaultTicketName,
			@RequestParam(value = "applytochildren", defaultValue = "false") boolean applyToChildren,
			@RequestParam(value = "appendtochildren", defaultValue = "false") boolean appendToChildren) throws InvalidCollectionException,
			 WorkflowInUseException, WorkflowNotFoundException, StatusNotFoundException, TrusteeNotFoundException,
			InvalidRevisionControlException, InvalidUserException, AttributeNotFoundException, InvalidJobJacketException, InvalidGroupException,
			RepositoryActionException, QppServiceException {
		
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		return collectionFacade.updateCollection(collectionId, attributeValueList, groupInfoList, jobjacketIds, userInfoList, workflows,
				revisionControlInfoList, routingInfoList, defaultTicketName, applyToChildren, appendToChildren);
	}
	
	/**
	 * Deletes the given collection from the system. Only empty collections are allowed for deletion. This means
	 * collection can only be deleted if the collection and all its child collection do not have any assets in them.
	 * Moreover, only users who have access to the given collection are allowed to delete the collection.
	 * 
	 * @param collectionPath
	 *            path of the collection to be deleted.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 *             Exact reason of the exception can be known by calling getExceptionCode() of the exception.
	 * @throws CollectionInUseException
	 *             If collection being deleted is not empty i.e. either collection or some of its child collection
	 *             contains assets in them.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method=RequestMethod.POST, params="op=delete")
	public void deleteCollection(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath) throws InvalidCollectionException, CollectionInUseException, QppServiceException{
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		collectionFacade.deleteCollection(collectionId);
	}
	

	/**
	 * Deletes the given collection from the system along with its sub-collections and assets. 
	 * Only users who have access to the given collection are allowed to delete the collection.
	 * 
	 * @param collectionPath
	 *            path of the collection to be deleted.
	 * @throws InvalidCollectionException
	 *             If the given collection either does not exist or the logged on user has no access to this collection.
	 *             Exact reason of the exception can be known by calling getExceptionCode() of the exception.
	 * @throws QppServiceException
	 *             Unexpected exception while processing request.
	 */
	@RequestMapping(method=RequestMethod.POST, params="op=deletewithassets")
	public void deleteCollectionWithAssets(@WebResourcePathParam(PATH_IDENTIFIER) String collectionPath) throws InvalidCollectionException, QppServiceException{
		long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
		collectionFacade.deleteCollectionWithAssets(collectionId);
	}
	

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * @param qppServiceException
	 *            QppServiceException that is to be handled
	 * @return QppServiceExceptionInfo object containing details of the exception thrown
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	
}

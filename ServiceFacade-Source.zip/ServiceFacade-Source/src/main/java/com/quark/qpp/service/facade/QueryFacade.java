/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.exceptions.ContentServiceExceptionCodes.InvalidContentTypeExceptionCodes;
import com.quark.qpp.core.query.service.constants.DefaultDisplayModes;
import com.quark.qpp.core.query.service.constants.ExploreModeTypes;
import com.quark.qpp.core.query.service.constants.QueryConstants;
import com.quark.qpp.core.query.service.constants.SystemQueries;
import com.quark.qpp.core.query.service.constants.QueryConstants.DateOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.LogicalOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.MeasurementOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.NumericOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.StatusOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.StringOperators;
import com.quark.qpp.core.query.service.dto.AssignmentCondition;
import com.quark.qpp.core.query.service.dto.AttachmentCondition;
import com.quark.qpp.core.query.service.dto.AttributeCondition;
import com.quark.qpp.core.query.service.dto.AttributeTextSearchCondition;
import com.quark.qpp.core.query.service.dto.BooleanAttributeCondition;
import com.quark.qpp.core.query.service.dto.ContentTypeCondition;
import com.quark.qpp.core.query.service.dto.DateAttributeCondition;
import com.quark.qpp.core.query.service.dto.DateTimeAttributeCondition;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.MeasureAttributeCondition;
import com.quark.qpp.core.query.service.dto.NumericAttributeCondition;
import com.quark.qpp.core.query.service.dto.PopupAttributeCondition;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.SortInfo;
import com.quark.qpp.core.query.service.dto.StatusCondition;
import com.quark.qpp.core.query.service.dto.StringAttributeCondition;
import com.quark.qpp.core.query.service.dto.SubQueryCondition;
import com.quark.qpp.core.query.service.dto.TextSearchCondition;
import com.quark.qpp.core.query.service.dto.TimeAttributeCondition;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.query.service.exceptions.QueryServiceExceptionCodes;
import com.quark.qpp.core.query.service.exceptions.QueryServiceExceptionCodes.InvalidQueryDefinitionExceptionCodes;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowServiceExceptionCodes.InvalidStatusExceptionCodes;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.CollectionInfoList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.QueryResultInfo;
import com.quark.qpp.service.xmlBinding.SearchInfo;
import com.quark.qpp.service.xmlBinding.SortInfoList;


/**
 * Facade that defines APIs performing various query related operations. This interface will be helpful for operations
 * like: querying the assets based on any customized set of conditions etc., querying collections, get all existing
 * saved queries, get query results of a saved query.
 */

@Controller("queryFacade")
@RequestMapping("/search")
public class QueryFacade {
	
	@Autowired 
	private QueryService queryService;
	
	@Autowired
	private AttributeService attributeService;
	
	@Autowired 
	private ObjectTransformer objectTransformer;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	private static long[] defaultDisplayColumns = new long[] { DefaultAttributes.NAME, DefaultAttributes.WORKFLOW,
			DefaultAttributes.COLLECTION, DefaultAttributes.ROUTED_TO, DefaultAttributes.STATUS, DefaultAttributes.CONTENT_TYPE };

	private static int defaultDisplayMode = DefaultDisplayModes.PLAIN;
	
	private static int defaultExploreMode = ExploreModeTypes.PLAIN;
	
	private final Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * Executes a search on assets (or collections) by using the query conditions, query context & query display information in the searchInfo
	 * object.
	 * <p>
	 * In case query context is not mentioned, by default ASSET content type & all collections will be considered.</br> In case query
	 * display is not mentioned, by default attribute columns : NAME, WORKLFOW, STATUS, COLLECTION, ROUTED TO & CONTENT TYPE are considered
	 * as display columns with default column width as 150. By default the display mode is set as {@link DefaultDisplayModes#PLAIN} &
	 * explore mode as {@link ExploreModeTypes#PLAIN}
	 * </p>
	 * 
	 * @param serachinfo
	 *            object containing details like query conditions, query context & query display of the search to be executed.
	 * @return {@link QueryResultInfo} object containing search result after executing the given search details.
	 * @throws InvalidQueryDefinitionException
	 *             In case of invalid query definition. Or in case the searchInfo object has not been given.
	 * @throws QppServiceException
	 *             In case of unhandled server exception.
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, params = "searchinfo")
	@WebReturnType("xmlView")
	public QueryResultInfo search(@WebSerializedParam("searchinfo") SearchInfo searchInfo) throws InvalidQueryDefinitionException,
			QppServiceException {
		QueryDefinition queryDefinition = objectTransformer.transform(searchInfo);
		if (queryDefinition.getQueryDisplay() == null) {
			QueryDisplay queryDisplay = getQueryDisplay(null/* display columns*/, null/* sorting*/, /*descending*/false);
			queryDefinition.setQueryDisplay(queryDisplay);
		}else{
			queryDefinition.getQueryDisplay().setGroupingAttributes(null);
		}
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryDefinition.getQueryConditions(),
				queryDefinition.getQueryContext(), queryDefinition.getQueryDisplay());
		QueryContext queryContext = queryDefinition.getQueryContext();
		long contextContentTypeId = -1;
		if(queryContext != null){
			contextContentTypeId = queryContext.getContentType();
		}else{
			contextContentTypeId = DefaultContentTypes.ASSET;
		}
		QueryResultInfo queryResultInfo = objectTransformer.transform(queryResultElements, contextContentTypeId);
		return queryResultInfo;
	}
	
	/**
	 * Returns the number of assets/collections satisfying the query conditions & query context mentioned in the {@link SearchInfo} object.
	 * 
	 * @param searchInfo
	 *            object containing query conditions & query context to be considered for executing the search. In case the query context is
	 *            not mentioned, bydefault ASSETS are considered & all collections will be considered recursively.
	 * @return Number of assets/collections matching the query conditions & query context.
	 * @throws InvalidQueryDefinitionException
	 *             If the searchInfo specified is invalid.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, params = { "searchinfo", "op=count" })
	@WebReturnType("textView")
	public int count(@WebSerializedParam("searchinfo") SearchInfo searchInfo) throws InvalidQueryDefinitionException, QppServiceException {
		QueryDefinition queryDefinition = objectTransformer.transform(searchInfo);
		return queryService.countQueryResultForConditions(queryDefinition.getQueryConditions(), queryDefinition.getQueryContext());
	}
	
	
	/**
	 * Executes a query on assets based on the parameters specified. The parametersMap helps in forming the query conditions.
	 * <p>
	 * The parameterMap can contain any of the following combinations :
	 * <li>To text search the assets with given text, use text=sometext
	 * <li>To text search an attribute use, textsearchattribute=nameOfTheTextSearchAttribute&text=sometext
	 * <li>To search attachments for a document, use document=assetIdOrAssetPath e.g. document=23 or document=Home/ColA/ColB/abc.qxp
	 * <li>To search for assets of a saved query, use query=savedQueryIdOrName e.g. query=230 or query=MySavedQuery
	 * <li>To search assets based on recursive content type, use includechildcontenttypes=true in addition to content type parameter.  
	 * <li>To search assets based on multiple domain values use comma separated values. For example:  creator=user1,user2,user3
	 * <li>To search for assets in given status, you can use any one of the following option :
	 * 	1. status=statusId e.g. status=10
	 * 	2. status=StatusName e.g. status=New Status 001. This will consider the first status with the given name.
	 * 	3. status=statusname&workflow=workflowIdOrName e.g. status=New Status 001&workflow=DefaultWorkflow
	 * 	4. status=WorklfowName/status e.g. status=DefaultWorklfow/Edit
	 * <li>To search for assets with the attribute value as given. Example to search for assets with some specific attributes values like
	 * name=abc.jpg&status=101&workflow=11&routed to=2&...&...
	 * And in order to search for assets where an attribute is NOT_DEFINED, specify attribute value as empty. For example : country=
	 * But when using QueryFacade as Spring bean, the attribute value can be specified as null or empty in parametersMap.
	 * </p>
	 * </br>
	 * 
	 * @param collectionsIdOrPathOrName
	 *            array of collections. A collection can be specified by id or path(Home/myColA/myColB/../) or name(MyColA). This specifies
	 *            the collections to be considered for search.If null then all the collections will be searched.
	 * @param recursive
	 *            boolean flag to indicate whether all the hierarchy below and including collections are to be searched
	 * @param displayColumns
	 *            array of attribute names (or ids), in order to specify attributes for display columns.
	 * @param sortBy
	 *            array of attributes (Ids or names) used for determining the sequence of asset elements in query results.
	 * @param descending
	 *            boolean flag to indicate whether descending order should be used for sorting query results.
	 * @param parametersMap
	 *            a map of attribute name as key and expected value.
	 * @return {@link AssetInfoList} object, that is abstract implementation of {@link QueryResultInfo}.This object encapsulates list of
	 *         {@link AssetInfo}.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/assets")
	@WebReturnType("xmlView")
	public QueryResultInfo searchAssets(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive,
			@WebArrayParam("attributes") String[] displayColumns,
			@WebArrayParam(value = "sortby") String[] sortBy,
			@RequestParam(value = "descending", defaultValue = "false") boolean descending, @WebParameterMap Map<String, String> parametersMap)
			throws QppServiceException {
		return queryForConditions(collectionsIdOrPathOrName, recursive, DefaultContentTypes.ASSET,
				displayColumns, sortBy, descending, parametersMap);
		
	}
	
	/**
	 * Returns the number of assets satisfying condition parameters specified.
	 * <p>
	 * The parameterMap can contain any of the following combinations :
	 * <li>To text search the assets with given text, use text=sometext
	 * <li>To text search an attribute use, textsearchattribute=nameOfTheTextSearchAttribute&text=sometext
	 * <li>To search attachments for a document, use document=assetIdOrAssetPath e.g. document=23 or document=Home/ColA/ColB/abc.qxp
	 * <li>To search for assets of a saved query, use query=savedQueryIdOrName e.g. query=230 or query=MySavedQuery
	 * <li>To search for assets in given status, you can use any one of the following option :
	 * 	1. status=statusId e.g. status=10
	 * 	2. status=StatusName e.g. status=New Status 001. This will consider the first status with the given name.
	 * 	3. status=statusname&workflow=workflowIdOrName e.g. status=New Status 001&workflow=DefaultWorkflow
	 * 	4. status=WorklfowName/status e.g. status=DefaultWorklfow/Edit
	 * <li>To search for assets with the attribute value as given. Example to search for assets with some specific attributes values like
	 * name=abc.jpg&status=101&workflow=11&routed to=2&...
	 * And in order to search for assets where an attribute is NOT_DEFINED, specify attribute value as empty. For example : country=
	 * But when using QueryFacade as Spring bean, the attribute value can be specified as null or empty in parametersMap.
	 * </p>
	 * 
	 * @param collectionsIdOrPathOrName
	 *            array of collections. A collection can be specified by id or path(Home/myColA/myColB/../) or name(MyColA). This specifies
	 *            the collections to be considered for search.If null then all the collections will be searched.
	 * @param recursive
	 *            boolean flag to indicate whether all the hierarchy below and including collections are to be searched
	 * @param parametersMap
	 *            a map of attribute name as key and value to search for.
	 * @return Number of assets satisfying condition parameters specified.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/assets", params = "op=count")
	@WebReturnType("textView")
	public int countAssets(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive, @WebParameterMap Map<String, String> parametersMap)
			throws QppServiceException {
		return getCountForConditions(collectionsIdOrPathOrName, recursive, DefaultContentTypes.ASSET, parametersMap);

	}
	

	/**
	 * Executes a query on collections based on the parameters specified. The parametersMap helps in forming the query conditions.
	 * 
	 * @param collectionsIdOrPathOrName
	 *            array of collections. A collection can be specified by id or path(Home/myColA/myColB/../) or name(MyColA).If null then all
	 *            the collections will be searched.
	 * @param recursive
	 *            boolean flag to indicate whether all the hierarchy below and including collections are to be searched
	 * @param displayColumns
	 *            array of attribute names (or ids), in order to specify attributes for display columns.
	 * @param sortBy
	 *            array of attributeIds used for determining the sequence of asset elements in query results.
	 * @param descending
	 *            boolean flag to indicate whether descending order should be used for sorting query results.
	 * @param parametersMap
	 *            map of attribute name as key and expected value
	 * @return {@link CollectionInfoList} object, an implementation of abstract class {@link QueryResultInfo}.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/collections")
	@WebReturnType("xmlView")
	public QueryResultInfo searchCollections(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive,
			@WebArrayParam("attributes") String[] displayColumns,
			@WebArrayParam(value = "sortby") String[] sortBy,
			@RequestParam(value = "descending", defaultValue = "false") boolean descending, @WebParameterMap Map<String, String> parametersMap)
			throws QppServiceException {
		return queryForConditions(collectionsIdOrPathOrName, recursive, DefaultContentTypes.COLLECTION,
				displayColumns, sortBy, descending, parametersMap);
	}
	
	/**
	 * Retruns the number of collections satisfying condition parameters specified.
	 * 
	 * @param collectionsIdOrPathOrName
	 *            Array of collections to be considered for search. A collection can be specified either by id or
	 *            path(Home/myColA/myColB/../) or name(MyColA).If null then all the collections will be searched.
	 * @param recursive
	 *            boolean flag to indicate whether all the collection hierarchy below and including collections are to be searched
	 * @param parametersMap
	 *            a map of attribute name as key and value to search for.
	 * @return number of collections satisfying the condtion parameters specified.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/collections", params = { "op=count" })
	@WebReturnType("textView")
	public int countCollections(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive, @WebParameterMap Map<String, String> parametersMap)
			throws QppServiceException {
		return getCountForConditions(collectionsIdOrPathOrName, recursive, DefaultContentTypes.COLLECTION, parametersMap);
	}

	/**
	 * Executes a quick search for assets based on their name. Both simple and wildcard based comparison is performed for name.
	 * 
	 * @param collectionsIdOrPathOrName
	 *            array of collections. A collection can be specified by id or path(Home/myColA/myColB/../) or name(MyColA). If null then
	 *            all the collections will be searched
	 * @param recursive
	 *            boolean flag to indicate whether the hierarchy below and including collections are to be searched. false implies assets
	 *            are searched in only specified collections.
	 * @param displayColumns
	 *            array of attribute names (or ids), in order to specify attributes for display columns
	 * @param sortBy
	 *            attributeIds used for determining the sequence of asset elements in query results.
	 * @param descending
	 *            boolean flag to indicate whether descending order should be used for sorting query results.
	 * @param parametersMap
	 *            A map with 'text' and 'contentType' as key and their values to be used for searching. 'contentType' condition is optional.
	 * @return {@link AssetInfoList} object, an implementation of abstract class {@link QueryResultInfo}, describing searched assets and
	 *         their attributes.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/quicksearch")
	@WebReturnType("xmlView")
	public QueryResultInfo getTextSearchResults(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive,
			@WebArrayParam("attributes") String[] displayColumns, @WebArrayParam("sortby") String[] sortBy,
			@RequestParam(value = "descending", defaultValue = "false") boolean descending,
			@WebParameterMap Map<String, String> parametersMap) throws QppServiceException {
		QueryCondition[] queryConditions = createQuickSearchConditions(parametersMap);
		long[] collectionIds = facadeUtility.getCollectionIds(collectionsIdOrPathOrName);
		QueryContext queryContext = new QueryContext(DefaultContentTypes.ASSET, collectionIds, recursive);
		QueryDisplay queryDisplay = getQueryDisplay(displayColumns, sortBy, descending);
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions, queryContext, queryDisplay);
		return objectTransformer.transform(queryResultElements, DefaultContentTypes.ASSET);
	}
	
	/**
	 * Returns number of assets satisfying the text search on asset name. Both simple and wildcard based comparison is performed for name.
	 * 
	 * @param collectionsIdOrPathOrName
	 *            array of collections to be considered for search. A collection can be specified by id or path(Home/myColA/myColB/../) or
	 *            name(MyColA). If null then all accessible collections will be searched
	 * @param recursive
	 *            boolean flag to indicate whether the hierarchy below and including collections are to be searched. false implies assets
	 *            are searched in only specified collections.
	 * @param parametersMap
	 *            A map with 'text' and 'contentType' as key and their values to be used for searching. 'contentType' condition is optional.
	 * @return number of assets satisfying the quick search
	 * @throws InvalidCollectionException
	 *             In case of invalid collection
	 * @throws InvalidQueryDefinitionException
	 *             In case of invalid query definition
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/quicksearch", params = { "op=count" })
	@WebReturnType("textView")
	public int countTextSearchResults(@WebArrayParam("collections") String[] collectionsIdOrPathOrName,
			@RequestParam(value = "recursive", defaultValue = "true") boolean recursive, @WebParameterMap Map<String, String> parametersMap)
			throws InvalidCollectionException, QppServiceException {
		QueryCondition[] queryConditions = createQuickSearchConditions(parametersMap);
		long[] collectionIds = facadeUtility.getCollectionIds(collectionsIdOrPathOrName);
		QueryContext queryContext = new QueryContext(DefaultContentTypes.ASSET, collectionIds, recursive);
		return queryService.countQueryResultForConditions(queryConditions, queryContext);
	}
	
	/**
	 * Executes an advanced search based on the given query conditions.
	 * 
	 * @deprecated Use {@link #search(SearchInfo)} for new developments
	 * 
	 * @param queryConditions
	 * @param queryContext
	 * @param displayColumns
	 * @param sortBy
	 *            attributeIds used for determining the sequence of selected results.
	 * @param descending
	 *            boolean flag to indicate whether descending order should be used for sorting query results.
	 * @return {@link AssetInfoList} or {@link CollectionInfoList} object, an implementation of abstract class {@link QueryResultInfo},
	 *         describing searched assets/collections and their attributes.
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	public QueryResultInfo searchAssetsForConditions(QueryCondition[] queryConditions, QueryContext queryContext, String[] displayColumns, String[] sortBy, boolean descending) throws AttributeNotFoundException, QppServiceException {
		QueryDisplay queryDisplay = getQueryDisplay(displayColumns, sortBy, descending);
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions, queryContext, queryDisplay);
		long contextEntity = queryContext.getContentType();
		if (contextEntity != DefaultContentTypes.ASSET && contextEntity != DefaultContentTypes.COLLECTION) {
			contextEntity = DefaultContentTypes.ASSET;
		}
		return objectTransformer.transform(queryResultElements, contextEntity);
	}
	
	/**
	 * Executes a query (with the given id or name) already stored at the server and returns all the results. The query results
	 * returned are NOT WATCHED for changes and no notifications are generated corresponding to changes in the result.
	 * 
	 * @param queryNameOrId
	 *            query name or id. Name will be given preference over Id.
	 * @param displayAttributes
	 *            array of attribute names (or id's), in order to specify attributes for display columns. Example : 2,Collection,54,Status,..,..,..
	 * @param parametersMap
	 *            map of attribute name as key and expected value
	 * @return In case the query result is in context of assets, it will return {@link AssetInfoList} , else for collections, it will return
	 *         {@link CollectionInfoList}.AssetInfoList and CollectionInfoList are implementations of abstract class {@link QueryResultInfo}
	 * @throws QueryNotFoundException
	 *             In case there is no saved query with the given id or name.
	 * @throws InvalidQueryDefinitionException
	 *             In case of invalid query defnition exception
	 * @throws InvalidQueryDisplayException
	 *             In case of invalid query display exception
	 * @throws AttributeNotFoundException
	 *             In case the attribute with the given id or name doesnot exist.
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{queryIdOrName}")
	@WebReturnType("xmlView")
	public QueryResultInfo getSearchResultsForQuery(@PathVariable String queryIdOrName, @WebArrayParam("attributes") String[] displayAttributes, 
			@WebParameterMap Map<String, String> parametersMap) throws QueryNotFoundException,
			InvalidQueryDefinitionException, InvalidQueryDisplayException, AttributeNotFoundException, QppServiceException {
		long queryId = facadeUtility.getQueryId(queryIdOrName);
		QueryDefinition queryDefinition = queryService.getQueryDefinition(queryId);
		QueryDisplay queryDisplay = queryDefinition.getQueryDisplay();
		if (displayAttributes != null && displayAttributes.length > 0) {
			DisplayColumn[] displayColumns = getDisplayColumns(displayAttributes);
			queryDisplay.setDisplayColumns(displayColumns);
		}
		// override the saved query's display mode, explore mode, and grouping, as the xml supports only list view
		queryDisplay.setDisplayMode(defaultDisplayMode);
		queryDisplay.setExploreMode(defaultExploreMode);
		queryDisplay.setGroupingAttributes(null);

		Map<String, String> paramsMap = getMapWithAllkeysInUppercase(parametersMap);
		QueryResultElement[] queryResultElements = null;
		/*
		 * System defined MY_CHECKED_OUT_ASSETS query, by default is not
		 * parameterized and gives results in context of the logged in user.<BR>
		 * But in order to fetch assets checked out by other user, using this query,
		 * parameterized flag of query condition is explicitly being set to true,
		 * so that MY_CHECKED_OUT_ASSETS query can be executed along with
		 * input parameter 'Checked out by'. In this case default value of this condition will be overwritten 
		 * with the user mentioned in 'Checked out by' parameter.
		 */
		if (queryDefinition.isParameterized() || queryId == SystemQueries.MY_CHECKED_OUT_ASSETS) {
			if(queryId == SystemQueries.MY_CHECKED_OUT_ASSETS && paramsMap.containsKey("CHECKED OUT BY")){
				queryDefinition.getQueryConditions()[0].setParameterized(true);
			}
			populateQueryConditions(paramsMap, queryDefinition);
			queryResultElements = queryService.getQueryResultForConditions(queryDefinition.getQueryConditions(),
					queryDefinition.getQueryContext(), queryDisplay);
		} else {
			queryResultElements = queryService.getQueryResult(queryId, queryDisplay);
		}
		return objectTransformer.transform(queryResultElements, queryDefinition.getQueryContext().getContentType());
	}
	
	/**
	 * Returns the number of assets/collections satisfying conditions of a saved query.
	 * 
	 * @param queryIdOrName
	 *            Id or name of the query whose result count is to be returned.
	 * @param parametersMap
	 *            map to specify the values for parameterized conditions.disec futher
	 * @return the number of assets/collections satisfing the saved query.
	 * @throws QueryNotFoundException
	 * 			In case there doesn't exist a query with given name or id.
	 * @throws InvalidQueryDefinitionException
	 * 			In case of invalid query definition. 
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{queryIdOrName}", params = { "op=count" })
	@WebReturnType("textView")
	public int countSearchResultsForQuery(@PathVariable String queryIdOrName, @WebParameterMap Map<String, String> parametersMap)
			throws QueryNotFoundException, InvalidQueryDefinitionException, QppServiceException {
		long queryId = facadeUtility.getQueryId(queryIdOrName);
		QueryDefinition queryDefinition = queryService.getQueryDefinition(queryId);
		/*
		 * System defined MY_CHECKED_OUT_ASSETS query, by default is not
		 * parameterized and gives results in context of the logged in user.<BR>
		 * But in order to fetch assets checked out by other user, using this query,
		 * parameterized flag of query condition is explicitly being set to true,
		 * so that MY_CHECKED_OUT_ASSETS query can be executed along with
		 * input parameter 'Checked out by'. In this case default value of this condition will be overwritten 
		 * with the user mentioned in 'Checked out by' parameter.
		 */
		if (queryDefinition.isParameterized() || queryId == SystemQueries.MY_CHECKED_OUT_ASSETS) {
			Map<String, String> paramsMap = getMapWithAllkeysInUppercase(parametersMap);
			if(queryId == SystemQueries.MY_CHECKED_OUT_ASSETS && paramsMap.containsKey("CHECKED OUT BY")){
				queryDefinition.getQueryConditions()[0].setParameterized(true);
			}
			populateQueryConditions(paramsMap, queryDefinition);
			return queryService.countQueryResultForConditions(queryDefinition.getQueryConditions(), queryDefinition.getQueryContext());
		} else {
			return queryService.countQueryResult(queryId);
		}
	}
	
	/**
	 * Executes a search on assets by using the query conditions, query context & query display information in the searchInfo object. Query 
	 * display can be used to specify display columns and sorting. Display columns specify which attribute values will be queried for assets 
	 * matching the query conditions. Sort info specifies attributes/client defined columns, which will be used to sort assets in a query result. 
	 * If display columns or sort info are not specified, then their default values, as specified in Query.properties, will be used.
	 * This API is limited to following:
	 * <ul>
	 * <li>Supports only querying of Assets (not Collections).</li>
	 * <li>Only {@link com.quark.qpp.core.query.service.constants.DefaultDisplayModes#PLAIN} display mode is supported in {@link QueryDisplay#getDisplayMode()}.</li>
	 * <li>Only {@link com.quark.qpp.core.query.service.constants.ExploreModeTypes#PLAIN explore mode is supported in {@link QueryDisplay#getExploreMode()}.</li>
	 * <li>Text search conditions are not supported.</li>
	 * <li>Grouping of assets is not supported - {@link QueryDisplay#getGroupingAttributes()}</li>
	 * <li>The query results are NOT WATCHED for changes and and no notifications are generated corresponding to changes in the result</li>
	 * <li>During each iteration, data is fetched as per current data state. If assets are added or deleted while iterating, then during 
	 * next iteration, offset and limit will be applicable for new data state. It may cause assets from the previous iteration to be either
	 * repeated or missed in further iterations.</li>
	 * </ul>
	 * 
	 * @param searchInfo
	 * 				object containing details like query conditions, query context & query display of the search to be executed.
	 * @param numberOfRows
	 * 				Maximum number of results to be fetched.
	 * @param offset
	 * 				The position from which to fetch the query results.
	 * @return {@link QueryResultInfo} object containing search result after executing the given search details.
	 * @throws InvalidQueryDefinitionException
	 * 				In case of invalid query definition.
	 * @throws InvalidQueryDisplayException
	 * 				If display columns or sort columns in query display contain invalid attributeIds.
	 * @throws QppServiceException
	 * 				Unhandled server exception.
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/paginated", params = { "searchinfo", "offset", "numberofrows" } )
	@WebReturnType("jsonView")
	public QueryResultInfo search(@WebSerializedParam("searchinfo") SearchInfo searchInfo, @RequestParam(value = "numberofrows") int numberOfRows, 
			@RequestParam(value = "offset") int offset) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		QueryDefinition queryDefinition = objectTransformer.transform(searchInfo);
		long resultId = 0;
		
		QueryDisplay queryDisplay = queryDefinition.getQueryDisplay();
		DisplayColumn[] displayColumns = null;
		SortInfo[] sortInfos = null;
		if(queryDisplay != null){
			displayColumns = queryDisplay.getDisplayColumns();
			sortInfos = queryDisplay.getSorting();
		}
		
		
		try {
			resultId = queryService.openBulkQueryResultsForConditions(queryDefinition.getQueryConditions(),
					queryDefinition.getQueryContext(), displayColumns, sortInfos);
			QueryResultElement[] queryResultElements = queryService.getNextQueryResult(resultId, -1, numberOfRows, offset);
			
			return objectTransformer.transform(queryResultElements, DefaultContentTypes.ASSET);
		} finally {
			if(resultId > 0) {
				queryService.closeQueryResults(resultId);
			}
		}
	}
	
	/**
	 * Executes a query (with the given id or name) already stored at the server and returns all the results.
	 * This API is limited to following:
	 * <ul>
	 * <li>Supports only querying of Assets (not Collections).</li>
	 * <li>Only {@link com.quark.qpp.core.query.service.constants.DefaultDisplayModes#PLAIN} display mode is supported in {@link QueryDisplay#getDisplayMode()}.</li>
	 * <li>Only {@link com.quark.qpp.core.query.service.constants.ExploreModeTypes#PLAIN explore mode is supported in {@link QueryDisplay#getExploreMode()}.</li>
	 * <li>Text search conditions are not supported.</li>
	 * <li>Grouping of assets is not supported - {@link QueryDisplay#getGroupingAttributes()}</li>
	 * <li>The query results are NOT WATCHED for changes and and no notifications are generated corresponding to changes in the result</li>
	 * <li>During each iteration, data is fetched as per current data state. If assets are added or deleted while iterating, then during 
	 * next iteration, offset and limit will be applicable for new data state. It may cause assets from the previous iteration to be either
	 * repeated or missed in further iterations.</li>
	 * </ul>
	 * 
	 * @param queryIdOrName
	 * 				query name or id.
	 * @param displayAttributes
	 * 				array of attribute names (or id's), in order to specify attributes for display columns. Example : 2,Collection,54,Status,..
	 * 				If not specified, then display columns will be fetched from the query definition, and if not specified in query definition,
	 * 				then default display columns, as specified in Query.properties, will be used.
	 * @param sortInfoList
	 * 				to specify the attributes/client defined columns, which will be used to sort assets in a query result.
	 * 				If not specified, then sortInfo will be fetched from the query definition, and if not specified in query definition,
	 * 				then default sortInfo, as specified in Query.properties, will be used.
	 * @param parametersMap
	 * 				map of attribute name as key and expected value, to be specified in case of parameterized queries.
	 * @param numberOfRows
	 * 				Maximum number of results to be fetched.
	 * @param offset
	 * 				The position from which to fetch the query results.
	 * @return {@link QueryResultInfo} object containing search result after executing the given query.
	 * @throws QueryNotFoundException
	 * 				In case there is no saved query with the given id or name.
	 * @throws InvalidQueryDefinitionException
	 * 				In case of invalid query definition.
	 * @throws InvalidQueryDisplayException
	 * 				In case of invalid query display.
	 * @throws AttributeNotFoundException
	 * 				In case the attribute with the given id or name does not exist.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/paginated/{queryIdOrName}", params = { "offset", "numberofrows" } )
	@WebReturnType("jsonView")
	public QueryResultInfo getSearchResultsForQuery(@PathVariable("queryIdOrName") String queryIdOrName, 
			@WebArrayParam(value = "attributes") String[] displayAttributes, 
			@WebSerializedParam(value = "sortinfolist") SortInfoList sortInfoList, 
			@WebParameterMap Map<String, String> parametersMap,
			@RequestParam("numberofrows") int numberOfRows, @RequestParam("offset") int offset) throws QueryNotFoundException,
	InvalidQueryDefinitionException, InvalidQueryDisplayException, AttributeNotFoundException, QppServiceException {
		
		long queryId = facadeUtility.getQueryId(queryIdOrName);
		DisplayColumn[] displayColumns = getDisplayColumns(displayAttributes);
		SortInfo[] sortInfo = null;
		if(sortInfoList != null) {
			sortInfo = objectTransformer.transform(sortInfoList);
		}
		
		long resultId = 0;
		try {
			if(parametersMap != null) {
				parametersMap.remove("loginname");
				parametersMap.remove("loginpassword");
				parametersMap.remove("qppsessionid");
				parametersMap.remove("offset");
				parametersMap.remove("numberofrows");
				parametersMap.remove("view");
				
				if(parametersMap.size() > 0) {
					Map<String, String> paramsMap = getMapWithAllkeysInUppercase(parametersMap);	
					QueryDefinition queryDefinition = queryService.getQueryDefinition(queryId);
					
					if (queryDefinition.isParameterized() || queryId == SystemQueries.MY_CHECKED_OUT_ASSETS) {
						if(queryId == SystemQueries.MY_CHECKED_OUT_ASSETS && paramsMap.containsKey("CHECKED OUT BY")){
							queryDefinition.getQueryConditions()[0].setParameterized(true);
						}
						populateQueryConditions(paramsMap, queryDefinition);
						resultId = queryService.openBulkQueryResultsForConditions(queryDefinition.getQueryConditions(),
								queryDefinition.getQueryContext(), displayColumns, sortInfo);
					}
					else {
						resultId = queryService.openBulkQueryResults(queryId, displayColumns, sortInfo);
					}
				} else {
					resultId = queryService.openBulkQueryResults(queryId, displayColumns, sortInfo);
				}
			}
			QueryResultElement[] queryResultElements = queryService.getNextQueryResult(resultId, -1, numberOfRows, offset);		
			return objectTransformer.transform(queryResultElements, DefaultContentTypes.ASSET);
		} finally {
			if(resultId > 0) {
				queryService.closeQueryResults(resultId);
			}
		}
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	/**
	 * Creates query condtions for text search on name. 
	 * @param parametersMap map containing values for text & contentType keys
	 * @return array of query conditions
	 * @throws InvalidQueryDefinitionException
	 */
	private QueryCondition[] createQuickSearchConditions(Map<String, String> parametersMap) throws InvalidQueryDefinitionException, QppServiceException{
		parametersMap.remove("loginpassword");
		parametersMap.remove("loginname");
		parametersMap.remove("qppsessionid");

		ArrayList<QueryCondition> queryConditionsList = new ArrayList<QueryCondition>();

		String searchString = parametersMap.get("text");
		if (searchString != null) {
			String contentType = parametersMap.get("Content Type");

			if (contentType != null && contentType.length() > 0) {
				String[] values = contentType.split(",");
				long[] valueIds = new long[values.length];
				for (int i = 0; i < values.length; i++) {
					valueIds[i] = facadeUtility.getContentTypeId(values[i]);											
				}
				ContentTypeCondition contentTypeCondition = new ContentTypeCondition();
				boolean includeChild = false;
				if (parametersMap.containsKey("includechildcontenttypes")) {
					String includeChildContentType = parametersMap.get("includechildcontenttypes");
					includeChild = Boolean.valueOf(includeChildContentType);
				}
				contentTypeCondition.setRecursive(includeChild);
				contentTypeCondition.setContentTypeIds(valueIds);
				contentTypeCondition.setLogicalOperator(LogicalOperators.AND);
				contentTypeCondition.setNestingLevel(1);
				queryConditionsList.add(contentTypeCondition);
			}

			StringAttributeCondition stringAttributeCondition = new StringAttributeCondition();
			stringAttributeCondition.setAttributeId(DefaultAttributes.NAME);
			stringAttributeCondition.setComparisonOperator(QueryConstants.StringOperators.CONTAINS);
			stringAttributeCondition.setValue(searchString);
			stringAttributeCondition.setLogicalOperator(QueryConstants.LogicalOperators.AND);
			stringAttributeCondition.setNestingLevel(1);
			queryConditionsList.add(stringAttributeCondition);

			AttributeTextSearchCondition attributeTextSearchCondition = new AttributeTextSearchCondition();
			attributeTextSearchCondition.setAttributeId(DefaultAttributes.NAME);
			attributeTextSearchCondition.setSearchString(searchString);
			attributeTextSearchCondition.setLogicalOperator(QueryConstants.LogicalOperators.OR);
			attributeTextSearchCondition.setNestingLevel(2);
			queryConditionsList.add(attributeTextSearchCondition);
		}else{
			throw new InvalidQueryDefinitionException(InvalidQueryDefinitionExceptionCodes.INVALID_QUERY_DEFINITION, new String[]{"Text parameter value is invalid."});
		}
		return queryConditionsList.toArray(new QueryCondition[0]);
	}
	
	
	private DisplayColumn[] getDisplayColumns(String[] displayColumns) throws AttributeNotFoundException, QppServiceException {
		long[] displayColumnIds = facadeUtility.getAttributeIds(displayColumns);
		DisplayColumn[] columns = new DisplayColumn[displayColumnIds.length];
		for (int i = 0; i < displayColumnIds.length; i++) {
			columns[i] = new DisplayColumn(displayColumnIds[i], 100, true);
		}
		return columns;
	}

	private QueryResultInfo queryForConditions(String[] collections, boolean recursive,
			long contentTypeId, String[] displayColumns, String[] sortBy, boolean descending, Map<String, String> parametersMap)
			throws AttributeNotFoundException, QppServiceException {
		QueryDisplay queryDisplay = getQueryDisplay(displayColumns, sortBy, descending);
		long[] collectionIds = null;
		if (collections != null && collections.length > 0) {
			collectionIds = facadeUtility.getCollectionIds(collections);
		}
		QueryContext queryContext = new QueryContext(contentTypeId, collectionIds, recursive);
		QueryCondition[] queryConditions = createQueryConditions(parametersMap);
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions, queryContext, queryDisplay);
		return objectTransformer.transform(queryResultElements, contentTypeId);
	}
	
	private int getCountForConditions(String[] collections, boolean recursive,
			long contentTypeId, Map<String, String> parametersMap)
			throws AttributeNotFoundException, QppServiceException {
		long[] collectionIds = facadeUtility.getCollectionIds(collections);
		QueryContext queryContext = new QueryContext(contentTypeId, collectionIds, recursive);
		QueryCondition[] queryConditions = createQueryConditions(parametersMap);
		return queryService.countQueryResultForConditions(queryConditions, queryContext);
	}
	
	private QueryDisplay getQueryDisplay(String[] displayColumns, String[] sortBy, boolean descending)
			throws QppServiceException {
		QueryDisplay queryDisplay = new QueryDisplay();
		queryDisplay.setDisplayMode(defaultDisplayMode);
		queryDisplay.setExploreMode(defaultExploreMode);

		long[] displayColumnIds = new long[0];
		if(displayColumns != null){
			displayColumnIds = facadeUtility.getAttributeIds(displayColumns);
		}else{
			displayColumnIds = defaultDisplayColumns;
		}

		DisplayColumn[] columns = new DisplayColumn[displayColumnIds.length];
		for (int i = 0; i < displayColumnIds.length; i++) {
			boolean isAttribute = true;
			//Client specific attribute columns like thumbnail are in negative
			if(displayColumnIds[i] < 0) {
				isAttribute = false;
			}
			columns[i] = new DisplayColumn(displayColumnIds[i], 100, isAttribute);
		}
		queryDisplay.setDisplayColumns(columns);

		/* Apply given descending true/false value to all sort by attributes */
		long[] sortByIds = facadeUtility.getAttributeIds(sortBy);
		SortInfo[] sortInfo = new SortInfo[sortByIds.length];
		for (int i = 0; i < sortByIds.length; i++) {
			sortInfo[i] = new SortInfo(sortByIds[i]);
			sortInfo[i].setDescending(descending);
			sortInfo[i].setAttributeColumn(true);
		}
		if (sortInfo.length > 0) {
			queryDisplay.setSorting(sortInfo);
		} else {
			sortInfo = new SortInfo[1];
			sortInfo[0] = new SortInfo(DefaultAttributes.NAME);
			sortInfo[0].setAttributeColumn(true);
			queryDisplay.setSorting(sortInfo);
		}
		return queryDisplay;
	}
	
	private QueryCondition[] createQueryConditions(
			Map<String, String> parameterMap) throws AttributeNotFoundException,  QppServiceException {
		
		// Since this method creates query conditions assuming request parameters to be platform attributes. Thus we need to remove non
		// platform attributes like view, loginpassword, loginname and qppsessionid.
		// In case we don't remove these request parameters, they will
		// be processed as attributes,that will eventually lead to ATTRIBUTE_NOT_FOUND_EXCEPTION
		
		// The request parameters like loginname,loginpassword were added by user to logOn to the platform .Thus should be removed to prevent
		// exception by assuming them as parameters for searching assets.
		parameterMap.remove("view");
		parameterMap.remove("attributes");
		parameterMap.remove("collections");
		parameterMap.remove("recursive");
		/** Check for includechildcontenttypes **/
		boolean includeChild = false;
		if (parameterMap.containsKey("includechildcontenttypes")) {
			String includeChildContentType = parameterMap.get("includechildcontenttypes");
			includeChild = Boolean.valueOf(includeChildContentType);
			parameterMap.remove("includechildcontenttypes");
		}
		parameterMap.remove("sortby");
		parameterMap.remove("descending");
		parameterMap.remove("displaymode");
		parameterMap.remove("exploremode");
		parameterMap.remove("op");
		
		parameterMap.remove("loginpassword");
		parameterMap.remove("loginname");
		parameterMap.remove("qppsessionid");
		
		
		ArrayList<QueryCondition> queryConditionsList = new ArrayList<QueryCondition>(); 
		Set<String> parameterNames = parameterMap.keySet();
		Iterator< String> iterator = parameterNames.iterator();
		boolean statusExists = doesParameterExist(parameterMap, "status");
		boolean textConditionExists = doesParameterExist(parameterMap, "text");
		while(iterator.hasNext()){
			String parameterName = "";
			try{
				parameterName = iterator.next();
			}catch (ConcurrentModificationException e) {
				logger.error("Error while creating query conditions from parameters map.", e);
				break;
			}
			String parameterValue = parameterMap.get(parameterName);
			if(parameterName.equalsIgnoreCase("text") || parameterName.equalsIgnoreCase("textsearchattribute")){
					String attributeName = parameterMap.get("textsearchattribute");
					String searchString = parameterMap.get("text");
					if(attributeName != null && searchString != null){
						long attributeIdToBeSearched = facadeUtility.getAttributeIds(new String[]{attributeName})[0];
						
						AttributeTextSearchCondition attributeTextSearchCondition = new AttributeTextSearchCondition();
						attributeTextSearchCondition.setAttributeId(attributeIdToBeSearched);
						attributeTextSearchCondition.setComparisonOperator(StringOperators.IS);
						attributeTextSearchCondition.setLogicalOperator(LogicalOperators.AND);
						attributeTextSearchCondition.setNegated(false);
						attributeTextSearchCondition.setNestingLevel(1);
						attributeTextSearchCondition.setParameterized(false);
						attributeTextSearchCondition.setSearchString(searchString);
						queryConditionsList.add(attributeTextSearchCondition);
					} else if(textConditionExists){
						TextSearchCondition textSearchCondition = new TextSearchCondition();
						textSearchCondition.setLogicalOperator(LogicalOperators.AND);
						textSearchCondition.setNegated(false);
						textSearchCondition.setNestingLevel(1);
						textSearchCondition.setParameterized(false);
						textSearchCondition.setSearchString(searchString);
						queryConditionsList.add(textSearchCondition);
				}
			} else if(parameterName.equalsIgnoreCase("assigned to")){ 
					//attachments search
					AssignmentCondition assignmentCondition = new AssignmentCondition();
					long userId = facadeUtility.getUserId(parameterValue);
					assignmentCondition.setTrusteeId(userId);
					assignmentCondition.setComparisonOperator(NumericOperators.IS);
					assignmentCondition.setLogicalOperator(LogicalOperators.AND);
					assignmentCondition.setNegated(false);
					assignmentCondition.setNestingLevel(1);
					assignmentCondition.setParameterized(false);
					queryConditionsList.add(assignmentCondition);
			}
			else if(parameterName.equalsIgnoreCase("document")){ 
				//attachments search
				AttachmentCondition attachmentCondition = new AttachmentCondition();
				attachmentCondition.setComparisonOperator(NumericOperators.IS);
				long projectAssetId = facadeUtility.getAssetId(parameterValue);
				attachmentCondition.setProjectAssetId(projectAssetId);
				attachmentCondition.setLogicalOperator(LogicalOperators.AND);
				attachmentCondition.setNegated(false);
				attachmentCondition.setNestingLevel(1);
				attachmentCondition.setParameterized(false);
				queryConditionsList.add(attachmentCondition);
			} else if(parameterName.equalsIgnoreCase("query")){ 
				//subquery search
				SubQueryCondition subQueryCondition = new SubQueryCondition();
				subQueryCondition.setComparisonOperator(NumericOperators.IS);
				subQueryCondition.setLogicalOperator(LogicalOperators.AND);
				subQueryCondition.setNegated(false);
				subQueryCondition.setNestingLevel(1);
				subQueryCondition.setParameterized(false);
				long queryId = facadeUtility.getQueryId(parameterValue);
				subQueryCondition.setQueryId(queryId);
				queryConditionsList.add(subQueryCondition);
			} else if ((parameterName.equalsIgnoreCase("status")
					|| parameterName.equalsIgnoreCase("workflow")) & statusExists){
				/*
				 * Minimum requirement to form Status Condition is presence of either status alone or 'status & workflow' combination.
				 */
				String statusIdOrNameOrWorkflowStatusCombination =  getCaseInsensitiveValue(parameterMap, "status");
				String workflowIdOrName =  getCaseInsensitiveValue(parameterMap, "workflow");
				long workflowId = -1;
				long statusId = -1;
				if (workflowIdOrName != null && workflowIdOrName.trim().length() > 0) {
					workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
					statusId = facadeUtility.getStatusId(workflowId, statusIdOrNameOrWorkflowStatusCombination);
				} else if (statusIdOrNameOrWorkflowStatusCombination != null && statusIdOrNameOrWorkflowStatusCombination.trim().length() > 0) {
					long[] workflowAndStatusId = facadeUtility.getWorkflowAndStatusId(statusIdOrNameOrWorkflowStatusCombination);
					workflowId = workflowAndStatusId[0];
					statusId = workflowAndStatusId[1];
				} else {
					throw new InvalidStatusException(InvalidStatusExceptionCodes.INVALID_STATUS);
				}
				StatusCondition statusCondition = new StatusCondition();
				statusCondition.setComparisonOperator(StatusOperators.IS);
				statusCondition.setLogicalOperator(LogicalOperators.AND);
				statusCondition.setNegated(false);
				statusCondition.setNestingLevel(1);
				statusCondition.setParameterized(false);
				
				statusCondition.setStatusId(statusId);
				statusCondition.setWorkflowId(workflowId);
				queryConditionsList.add(statusCondition);
			} else {
				
				Attribute attribute = attributeService.getAttributeByName(parameterName);
							
							//check whether the attribute is Queryable ? If the attribute is queryable , then on the basis of the attribute value type, create attribute conditions accordingly.
							if(attribute.isQueryable()){
							
								if(attribute.getValueType() == AttributeValueTypes.TEXT){
									StringAttributeCondition stringAttributeCondition = new StringAttributeCondition();
									stringAttributeCondition.setAttributeId(attribute.getId());
									stringAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									stringAttributeCondition.setNestingLevel(1);
									stringAttributeCondition.setParameterized(false);
									if(parameterValue == null || parameterValue.trim().length() == 0){
										stringAttributeCondition.setComparisonOperator(StringOperators.IS_DEFINED);
										stringAttributeCondition.setNegated(true);
									}else{
										stringAttributeCondition.setComparisonOperator(StringOperators.IS);
										stringAttributeCondition.setNegated(false);
										stringAttributeCondition.setValue(parameterValue);
									}
									queryConditionsList.add(stringAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.BOOLEAN){
									BooleanAttributeCondition booleanAttributeCondition = new BooleanAttributeCondition();
									booleanAttributeCondition.setAttributeId(attribute.getId());
									booleanAttributeCondition.setComparisonOperator(StringOperators.IS);
									booleanAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									booleanAttributeCondition.setNestingLevel(1);
									booleanAttributeCondition.setNegated(false);
									booleanAttributeCondition.setParameterized(false);
									booleanAttributeCondition.setValue(Boolean.valueOf(parameterValue));
									queryConditionsList.add(booleanAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.DATE){
									DateAttributeCondition dateAttributeCondition = new DateAttributeCondition();
									dateAttributeCondition.setAttributeId(attribute.getId());
									dateAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									dateAttributeCondition.setNestingLevel(1);
									dateAttributeCondition.setParameterized(false);
									if (parameterValue == null || parameterValue.trim().length() == 0) {
										dateAttributeCondition.setComparisonOperator(DateOperators.IS_DEFINED);
										dateAttributeCondition.setNegated(true);
									} else {
										dateAttributeCondition.setComparisonOperator(DateOperators.IS);
										dateAttributeCondition.setNegated(false);
										dateAttributeCondition.setValue(parameterValue);
									}
									queryConditionsList.add(dateAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.DATETIME){
									DateTimeAttributeCondition dateTimeAttributeCondition = new DateTimeAttributeCondition();
									dateTimeAttributeCondition.setAttributeId(attribute.getId());
									dateTimeAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									dateTimeAttributeCondition.setNestingLevel(1);
									dateTimeAttributeCondition.setParameterized(false);
									if(parameterValue == null || parameterValue.trim().length() == 0){
										dateTimeAttributeCondition.setComparisonOperator(DateOperators.IS_DEFINED);
										dateTimeAttributeCondition.setNegated(true);
									}else{
										dateTimeAttributeCondition.setComparisonOperator(DateOperators.IS);
										dateTimeAttributeCondition.setNegated(false);
										dateTimeAttributeCondition.setValue(parameterValue);
									}
									queryConditionsList.add(dateTimeAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.DOMAIN){
									String[] values = new String[0];
									if (parameterValue != null && parameterValue.trim().length() > 0){
										values = parameterValue.split(",");
									}
									// For content-types attribute , using cont net type condition with recursive flag
									if(DefaultAttributes.CONTENT_TYPE == attribute.getId()) {
										if(values.length == 0){
											InvalidContentTypeException invalidContentTypeException = new InvalidContentTypeException(
													InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
											throw invalidContentTypeException;
										}
										// Set is used to avoid duplicate content type names (as there are content type with same name 
										// in different hierarchies). Here we are considering only first content type . 
										long[] valueIds = new long[values.length];
										for (int i = 0; i < values.length; i++) {
											valueIds[i] = facadeUtility.getContentTypeId(values[i]);											
										}
										ContentTypeCondition contentTypeCondition = new ContentTypeCondition();
										contentTypeCondition.setContentTypeIds(valueIds);
										contentTypeCondition.setRecursive(includeChild);
										contentTypeCondition.setLogicalOperator(LogicalOperators.AND);
										contentTypeCondition.setNestingLevel(1);
										queryConditionsList.add(contentTypeCondition);
									}
									else{
										if (values.length > 0) {
											for (int i = 0; i < values.length; i++) {
												PopupAttributeCondition popUpAttributeCondition = new PopupAttributeCondition();
												popUpAttributeCondition.setAttributeId(attribute.getId());
												popUpAttributeCondition.setComparisonOperator(StringOperators.IS);
												popUpAttributeCondition.setStrValue(parameterValue);
												if (i == 0) { // Anding with previous
																// condition
													popUpAttributeCondition.setLogicalOperator(LogicalOperators.AND);
													popUpAttributeCondition.setNestingLevel(1);
												} else {
													popUpAttributeCondition.setLogicalOperator(LogicalOperators.OR);
													popUpAttributeCondition.setNestingLevel(2);
												}
			
												popUpAttributeCondition.setNegated(false);
												popUpAttributeCondition.setParameterized(false);
												// popUpAttributeCondition.setValue(null);
												// numeric
												// value will not be specified by client.its
												// mandatory for client to specify String
												// value for
												// domain
												popUpAttributeCondition.setStrValue(values[i]);
												queryConditionsList.add(popUpAttributeCondition);
											}
			
										} else {
											PopupAttributeCondition popUpAttributeCondition = new PopupAttributeCondition();
											popUpAttributeCondition.setAttributeId(attribute.getId());
											popUpAttributeCondition.setStrValue(parameterValue);
											popUpAttributeCondition.setLogicalOperator(LogicalOperators.AND);
											popUpAttributeCondition.setNestingLevel(1);
											popUpAttributeCondition.setComparisonOperator(StringOperators.IS_DEFINED);
											popUpAttributeCondition.setNegated(true);
											popUpAttributeCondition.setParameterized(false);
											queryConditionsList.add(popUpAttributeCondition);
										}
									}
								} else if(attribute.getValueType() == AttributeValueTypes.MEASUREMENT){
									MeasureAttributeCondition measureAttributeCondition = new MeasureAttributeCondition();
									measureAttributeCondition.setAttributeId(attribute.getId());
									measureAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									measureAttributeCondition.setNestingLevel(1);
									measureAttributeCondition.setParameterized(false);
									if(parameterValue == null || parameterValue.trim().length() == 0){
										measureAttributeCondition.setComparisonOperator(MeasurementOperators.IS_DEFINED);
										measureAttributeCondition.setNegated(true);
									}else{
										measureAttributeCondition.setComparisonOperator(MeasurementOperators.IS);
										measureAttributeCondition.setNegated(false);
										measureAttributeCondition.setValue(Double.parseDouble(parameterValue));
									}
									queryConditionsList.add(measureAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.NUMERIC){
									NumericAttributeCondition numericAttributeCondition = new NumericAttributeCondition();
									numericAttributeCondition.setAttributeId(attribute.getId());
									numericAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									numericAttributeCondition.setNestingLevel(1);
									numericAttributeCondition.setParameterized(false);
									if(parameterValue == null || parameterValue.trim().length() == 0){
										numericAttributeCondition.setComparisonOperator(MeasurementOperators.IS_DEFINED);
										numericAttributeCondition.setNegated(true);
									}else{
										numericAttributeCondition.setComparisonOperator(MeasurementOperators.IS);
										numericAttributeCondition.setNegated(false);
										numericAttributeCondition.setValue(Long.valueOf(parameterValue));
									}
									queryConditionsList.add(numericAttributeCondition);
								} else if(attribute.getValueType() == AttributeValueTypes.TIME){
									TimeAttributeCondition timeAttributeCondition = new TimeAttributeCondition();
									timeAttributeCondition.setAttributeId(attribute.getId());
									timeAttributeCondition.setLogicalOperator(LogicalOperators.AND);
									timeAttributeCondition.setNestingLevel(1);
									timeAttributeCondition.setParameterized(false);
									timeAttributeCondition.setValue(parameterValue);
									if(parameterValue == null || parameterValue.trim().length() == 0){
										timeAttributeCondition.setComparisonOperator(MeasurementOperators.IS_DEFINED);
										timeAttributeCondition.setNegated(true);
									}else{
										timeAttributeCondition.setComparisonOperator(MeasurementOperators.IS);
										timeAttributeCondition.setNegated(false);
										timeAttributeCondition.setValue(parameterValue);
									}
									queryConditionsList.add(timeAttributeCondition);
								}
				} else {
					throw new InvalidQueryDefinitionException(
							QueryServiceExceptionCodes.InvalidQueryDefinitionExceptionCodes.CANNOT_QUERY_ATTRIBUTE,
							new String[] { attribute.getId() + "", attribute.getName() });
				}
						}
			}
		return queryConditionsList.toArray(new QueryCondition[0]);
	}
	
	
	private String getCaseInsensitiveValue(Map<String, String> map, String key){
		for (String akey : map.keySet()) {
			if(akey.equalsIgnoreCase(key)){
				return map.get(akey);
			}
		}
		return null;
	}
	
	private boolean doesParameterExist(Map<String, String> map, String key){
		for (String akey : map.keySet()) {
			if(akey.equalsIgnoreCase(key)){
				return true;
			}
		}
		return false;
	}
	/**
	 * Populate parametrized query conditions.
	 * @param parametersMap
	 * @param queryDefinition
	 * @throws AssetNotFoundException
	 * @throws AttributeNotFoundException
	 * @throws InvalidContentTypeException
	 * @throws TrusteeNotFoundException
	 * @throws QueryNotFoundException
	 * @throws QppServiceException
	 */
	private void populateQueryConditions(final Map<String, String> parametersMap, final QueryDefinition queryDefinition)
			throws AssetNotFoundException, AttributeNotFoundException, InvalidContentTypeException, TrusteeNotFoundException,
			QueryNotFoundException, QppServiceException {
		QueryCondition[] conditions = queryDefinition.getQueryConditions();
		for(QueryCondition condition : conditions) {
			if (condition.isParameterized()) {
				if (condition instanceof AttributeCondition) {
					AttributeCondition attributeCondition = (AttributeCondition) condition;
					Attribute attribute = attributeService.getAttribute(attributeCondition.getAttributeId());
					String attributeValue = parametersMap.get(attribute.getName().toUpperCase());
					setAttributeConditionValue(attributeCondition, attributeValue);
				} else if (condition instanceof StatusCondition) {
					StatusCondition statusCondition = (StatusCondition) condition;
					String value = parametersMap.get("Status".toUpperCase());
					if(value!=null && !value.isEmpty()){
						long[] workflowAndStatusId = facadeUtility.getWorkflowAndStatusId(value);
						statusCondition.setParameterized(false);
						statusCondition.setWorkflowId(workflowAndStatusId[0]);
						statusCondition.setStatusId(workflowAndStatusId[1]);	
					}
				} else if(condition instanceof AssignmentCondition) {
					String trusteeIdOrName = parametersMap.get("trustee".toUpperCase());
					if(trusteeIdOrName != null && trusteeIdOrName.trim().length()>0){
						((AssignmentCondition) condition).setTrusteeId(facadeUtility.getTrusteeIds(new String[]{trusteeIdOrName})[0]);
					}
					condition.setParameterized(false);
				}else if(condition instanceof AttachmentCondition){
					String assetIdOrPath = parametersMap.get("asset".toUpperCase());
					if(assetIdOrPath!=null){
						long projectAssetId = facadeUtility.getAssetId(assetIdOrPath);
						((AttachmentCondition)condition).setProjectAssetId(projectAssetId);
						condition.setParameterized(false);
					}
				}else if(condition instanceof SubQueryCondition){
					String queryIdOrName = parametersMap.get("query".toUpperCase());
					if(queryIdOrName!=null){
						long queryId = facadeUtility.getQueryId(queryIdOrName);
						((SubQueryCondition)condition).setQueryId(queryId);
					}
					condition.setParameterized(false);
				}else if(condition instanceof AttributeTextSearchCondition){
					String text = parametersMap.get("text".toUpperCase());
					String textSearchAttribute = parametersMap.get("textSearchAttribute".toUpperCase());
					long attributeId = facadeUtility.getAttributeIds(new String[]{textSearchAttribute})[0];
					((AttributeTextSearchCondition) condition).setAttributeId(attributeId);
					((AttributeTextSearchCondition) condition).setSearchString(text);
					condition.setParameterized(false);
				}else if(condition instanceof TextSearchCondition){
					String text = parametersMap.get("text".toUpperCase());
					((TextSearchCondition) condition).setSearchString(text);
					condition.setParameterized(false);
				}else if(condition instanceof ContentTypeCondition){
					String contenttype = parametersMap.get("content type".toUpperCase());
					long contentTypeId = facadeUtility.getContentTypeId(contenttype);
					((ContentTypeCondition) condition).setContentTypeIds(new long[]{contentTypeId});
					condition.setParameterized(false);
				}
			}
		}
	}

	private void setAttributeConditionValue(final AttributeCondition attributeCondition, final String attributeValue) {
		if(attributeValue != null) {
			attributeCondition.setParameterized(false);
			if(attributeCondition instanceof BooleanAttributeCondition) {
				((BooleanAttributeCondition) attributeCondition).setValue(Boolean.valueOf(attributeValue));
			} else if(attributeCondition instanceof DateAttributeCondition) {
				((DateAttributeCondition) attributeCondition).setValue(attributeValue);
			} else if(attributeCondition instanceof DateTimeAttributeCondition) {
				((DateTimeAttributeCondition) attributeCondition).setValue(attributeValue);
			} else if(attributeCondition instanceof MeasureAttributeCondition) {
				((MeasureAttributeCondition) attributeCondition).setValue(Double.valueOf(attributeValue));
			} else if(attributeCondition instanceof NumericAttributeCondition) {
				((NumericAttributeCondition) attributeCondition).setValue(Long.valueOf(attributeValue));
			} else if(attributeCondition instanceof PopupAttributeCondition) {
				((PopupAttributeCondition) attributeCondition).setStrValue(attributeValue);
			} else if(attributeCondition instanceof StringAttributeCondition) {
				((StringAttributeCondition) attributeCondition).setValue(attributeValue);
			} else if(attributeCondition instanceof TimeAttributeCondition) {
				((TimeAttributeCondition) attributeCondition).setValue(attributeValue);
			}
		}
	}
	
	/**
	 * @param parametersMap
	 * @return
	 */
	private Map<String, String> getMapWithAllkeysInUppercase(Map<String, String> parametersMap) {
		Map<String, String> paramsMap = new HashMap<String, String>();
		if(parametersMap != null && !parametersMap.isEmpty()) {
			for(Entry<String, String> entry : parametersMap.entrySet()) {
				paramsMap.put(entry.getKey().toUpperCase(), entry.getValue());
			}
		}
		return paramsMap;
	}
}
/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.context.SessionContextHolder;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.dto.UserClass;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidUserClassException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassInUseException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotEditableException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.UserClassNotFoundExceptionCodes;
import com.quark.qpp.core.privilege.service.local.UserClassService;
import com.quark.qpp.core.security.service.dto.Group;
import com.quark.qpp.core.security.service.dto.SessionContext;
import com.quark.qpp.core.security.service.dto.Trustee;
import com.quark.qpp.core.security.service.dto.User;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.GroupInfoList;
import com.quark.qpp.service.xmlBinding.RoleInfo;
import com.quark.qpp.service.xmlBinding.RoleInfoList;
import com.quark.qpp.service.xmlBinding.UserInfo;
import com.quark.qpp.service.xmlBinding.UserInfoList;

public class RoleController {

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private TrusteeService trusteeService;

	@Autowired
	private UserClassService userClassService;

	@Autowired
	private FacadeUtility facadeUtility;

	private final Logger logger = Logger.getLogger(this.getClass());

	public RoleInfoList getAllRoles() throws UserClassNotFoundException, InvalidContentTypeException, QppServiceException {
		/** Get name and id of all roles */
		UserClass[] userClasses = userClassService.getAllUserClasses();
		UserClass[] detailedUserClasses = new UserClass[userClasses.length];
		for (int i = 0; i < userClasses.length; i++) {
			/**
			 * Get details of a user class, its name, content and application based privilege id's . All privileges granted for the role are
			 * included.
			 */
			detailedUserClasses[i] = userClassService.getUserClass(userClasses[i].getId());
		}
		return objectTransformer.transform(detailedUserClasses);
	}

	public RoleInfoList createRoles(RoleInfoList roleInfoList) throws InvalidUserClassException,
			PrivilegeNotFoundException, InvalidPrivilegeException, QppServiceException {
		RoleInfoList newRoleInfoList = new RoleInfoList();
		if (roleInfoList != null) {
			Iterator<RoleInfo> iterator = roleInfoList.getRoleInfo().iterator();
			while (iterator.hasNext()) {
				RoleInfo userClassInfo = iterator.next();
				try {
					RoleInfo newRoleInfo = createRole(userClassInfo);
					if (newRoleInfo != null) {
						newRoleInfoList.getRoleInfo().add(newRoleInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while creating Role with name " + userClassInfo.getName(), e);
					if (roleInfoList.getRoleInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new UserClassNotFoundException(UserClassNotFoundExceptionCodes.USERCLASS_NOT_FOUND);
		}
		return newRoleInfoList;
	}

	private RoleInfo createRole(RoleInfo roleInfo) throws InvalidUserClassException, PrivilegeNotFoundException, InvalidPrivilegeException, InvalidContentTypeException,
			QppServiceException {
		UserClass userClass = objectTransformer.transform(roleInfo);
		long userClassId = userClassService.createUserClass(userClass);
		UserClass createdUserClassDetail = userClassService.getUserClass(userClassId);
		return objectTransformer.transform(createdUserClassDetail);
	}

	public RoleInfoList updateRoles(RoleInfoList roleInfoList)throws UserClassNotFoundException, UserClassNotEditableException,
	InvalidContentTypeException, PrivilegeNotFoundException, InvalidPrivilegeException, QppServiceException {
		RoleInfoList updatedRoleInfoList = new RoleInfoList();
		if (roleInfoList != null) {
			Iterator<RoleInfo> iterator = roleInfoList.getRoleInfo().iterator();
			while (iterator.hasNext()) {
				RoleInfo userClassInfo = iterator.next();
				try {
					RoleInfo updatedRoleInfo = updateRole(userClassInfo);
					if (updatedRoleInfo != null) {
						updatedRoleInfoList.getRoleInfo().add(updatedRoleInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while updating role with name " + userClassInfo.getName(), e);
					if (roleInfoList.getRoleInfo().size() == 1) {
						throw e;
					}
				}
			}
		}else {
			throw new UserClassNotFoundException(UserClassNotFoundExceptionCodes.USERCLASS_NOT_FOUND);
		}
		return updatedRoleInfoList;
	}

	private RoleInfo updateRole(RoleInfo roleInfo) throws UserClassNotFoundException, UserClassNotEditableException,
			InvalidContentTypeException, PrivilegeNotFoundException, InvalidPrivilegeException, QppServiceException {
		long userClassId = -1;
		UserClass userClass = objectTransformer.transform(roleInfo);
		if (roleInfo.getId() == null || roleInfo.getId() <= 0) {
			userClassId = facadeUtility.getRoleId(roleInfo.getName());
		} else {
			userClassId = roleInfo.getId();
		}
		if (userClass.getContentTypePrivileges() != null) {
			userClassService.setContentPrivileges(userClassId, userClass.getContentTypePrivileges());
		}
		if (userClass.getApplicationPrivileges() != null) {
			userClassService.setApplicationPrivileges(userClassId, userClass.getApplicationPrivileges());
		}
		if(userClass.getName()!= null && !userClass.getName().isEmpty()){
			userClassService.setUserClassName(userClassId, userClass.getName());
		}
		UserClass updatedUserClassDetail = userClassService.getUserClass(userClassId);
		return objectTransformer.transform(updatedUserClassDetail);
	}

	public void deleteRole(String role) throws UserClassNotFoundException, UserClassInUseException, UserClassNotEditableException,
			QppServiceException {
		long roleId = facadeUtility.getRoleId(role);
		userClassService.deleteUserClass(roleId);
	}

	public boolean isLoggedonUserDefaultRole(String roleIdOrName) throws UserClassNotFoundException, QppServiceException{
		SessionContext sessionContext = SessionContextHolder.getSessionContext();
		long loggedInUserId = sessionContext.getUserId();
		User user = trusteeService.getUser(loggedInUserId);
		long defaultUserClassId = user.getDefaultUserClassId();
		long roleId = facadeUtility.getRoleId(roleIdOrName);
		if(roleId > 0 && roleId == defaultUserClassId){
			return true;
		}
		return false;
	}
	
	public RoleInfoList getRole(String role) throws UserClassNotFoundException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(role);
		UserClass userClassDetail = userClassService.getUserClass(userClassId);
		RoleInfo roleInfo = objectTransformer.transform(userClassDetail);
		RoleInfoList roleInfoList = new RoleInfoList();
		roleInfoList.getRoleInfo().add(roleInfo);
		return roleInfoList;
	}
	
	public UserInfoList getUsersWithGivenRole(String roleIdOrName) throws UserClassNotFoundException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(roleIdOrName);
		Trustee[] allTrustees = trusteeService.getTrusteesWithGivenUserClass(userClassId);
		List<User> usersList = new ArrayList<User>();
		for (int i = 0; allTrustees != null && i < allTrustees.length; i++) {
			if (allTrustees[i].isUser()) {
				usersList.add((User) allTrustees[i]);
			}
		}
		return objectTransformer.transform(usersList.toArray(new User[0]));
	}
	
	public GroupInfoList getGroupsWithGivenRole(String roleIdOrName) throws UserClassNotFoundException, QppServiceException {
		long userClassId = facadeUtility.getUserClassId(roleIdOrName);
		Trustee[] allTrustees = trusteeService.getTrusteesWithGivenUserClass(userClassId);
		List<Group> groupsList = new ArrayList<Group>();
		for (int i = 0; allTrustees != null && i < allTrustees.length; i++) {
			if (!allTrustees[i].isUser()) {
				groupsList.add((Group) allTrustees[i]);
			}
		}
		return objectTransformer.transform(groupsList.toArray(new Group[0]), true);
	}
}

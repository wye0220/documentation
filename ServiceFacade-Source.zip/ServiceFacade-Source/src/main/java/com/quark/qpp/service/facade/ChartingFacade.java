/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.charting.service.constants.ChartingOutputFormats;
import com.quark.qpp.charting.service.constants.ChartingOutputProperties;
import com.quark.qpp.charting.service.constants.ChartingSourceTypes;
import com.quark.qpp.charting.service.exceptions.ChartingException;
import com.quark.qpp.charting.service.exceptions.ChartingServiceExceptionCodes.ChartingExceptionCodes;
import com.quark.qpp.charting.service.local.ChartingService;
import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.office.service.exceptions.ExcelOutputException;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * A facade that defines methods to get the chart for a given Smart Table Source using the chart template specified.
 */
@Controller(value = "chartingFacade")
@RequestMapping("/charts")
public class ChartingFacade {

	@Autowired
	private ChartingService chartingService;

	@Autowired
	private StreamingService chartingStreamingService;

	@Autowired
	private ContentStructureService contentStructureService;
	
	@Autowired
	private ObjectTransformer objectTransformer;

	/**
	 * Draws chart for the given asset using the specified template.
	 * 
	 * @param assetId
	 *            asset id of the source data whose chart has to be drawn.
	 * @param majorVersion
	 *            major version of the source data asset.
	 * @param minorVersion
	 *            minor version of the source data asset.
	 * @param sourceDataType
	 *            type of the source data using which the chart will be drawn. Current supported types can be found in
	 *            {@link ChartingSourceTypes}.
	 * @param templateUri
	 *            URI of the template to be used for instantiating the json file required for drawing the desired chart.
	 * @param outputformat
	 *            output format in which the chart is to be rendered. All Possible chart output formats can be found in constants file
	 *            {@link ChartingOutputFormats}
	 * @param outputFormatProperties
	 *            name value array of the output properties applicable for given output format. All possible output properties can be found
	 *            in constant file {@link ChartingOutputProperties}.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            output format in which the chart is to be rendered. All Possible chart output formats can be found in constants file
	 *            {@link ChartingOutputFormats}
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id/version does not exist. The exception code will specify the exact cause of exception.
	 * @throws ChartingException
	 *             In case of any exception occurs during generation of the desired chart. The exception code and stack trace will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 * @throws StreamingException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{assetId}", params = { "templateuri" })
	public void getChart(@PathVariable("assetId") long assetId, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "sourcedatatype", defaultValue = "smarttable") String sourceDataType,
			@RequestParam(value = "templateuri", required = true) String templateUri,
			@RequestParam(value = "outputformat", required = false) String outputformat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws AssetNotFoundException, ChartingException, QppServiceException, IOException, StreamingException {

		AssetVersion assetVersion = null;
		if (majorVersion != null && minorVersion != null) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}

		if (sourceDataType == null) {
			// Consider default source data type as SMART_TABLE
			sourceDataType = ChartingSourceTypes.SMART_TABLE;
		}

		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		long contextId = 0;
		try {
			NameValue[] nameValues = createNameValueArray(outputFormatProperties);
			contextId = chartingService.createChartingReadContext(assetId, assetVersion, sourceDataType, templateUri, outputformat,
					nameValues);

			setContentHttpHeaders(outputformat, outputFormatProperties, httpServletResponse, contentDisposition);

			chartingStreamingService.download(os, contextId);
		} finally {
			if (contextId > 0) {
				chartingService.closeContext(contextId);
			}
		}
	}

	/**
	 * Draws chart for the given data specified in the uri using the specified template.
	 * 
	 * @param uri
	 *            URI of the source data whose chart has to be drawn.
	 * @param sourceDataType
	 *            type of the source data using which the chart will be drawn. Current supported types can be found in
	 *            {@link ChartingSourceTypes}.
	 * @param templateUri
	 *            URI of the template to be used for instantiating the json file required for drawing the desired chart.
	 * @param outputformat
	 *            output format in which the chart is to be rendered. All Possible chart output formats can be found in constants file
	 *            {@link ChartingOutputFormats}
	 * @param outputFormatProperties
	 *            name value array of the output properties applicable for given output format. All possible output properties can be found
	 *            in constant file {@link ChartingOutputProperties}.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            OutputStream to which the resultant chart will be written.
	 * @throws ChartingException
	 *             In case of any exception occurs during generation of the desired chart. The exception code and stack trace will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 * @throws StreamingException
	 */
	@RequestMapping(method = RequestMethod.GET, params = { "uri" })
	public void getChartBasedOnUri(@RequestParam(value = "uri", required = true) String uri,
			@RequestParam(value = "sourcedatatype", defaultValue = "smarttable") String sourceDataType,
			@RequestParam(value = "templateuri", required = true) String templateUri,
			@RequestParam(value = "outputformat", required = false) String outputformat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws ChartingException, QppServiceException, IOException, StreamingException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		long contextId = 0;
		try {
			if (sourceDataType == null) {
				// Consider default source data type as SMART_TABLE
				sourceDataType = ChartingSourceTypes.SMART_TABLE;
			}

			NameValue[] nameValues = createNameValueArray(outputFormatProperties);

			contextId = chartingService.createChartingReadContextBasedOnURI(uri, sourceDataType, templateUri, outputformat, nameValues);

			setContentHttpHeaders(outputformat, outputFormatProperties, httpServletResponse, contentDisposition);

			chartingStreamingService.download(os, contextId);
		} finally {
			if (contextId > 0) {
				chartingService.closeContext(contextId);
			}
		}
	}

	/**
	 * Draws chart for the given data input stream using the specified template.
	 * 
	 * @param inputStream
	 *            of the source data whose chart has to be drawn.
	 * @param sourceDataType
	 *            type of the source data using which the chart will be drawn. Current supported types can be found in
	 *            {@link ChartingSourceTypes}.
	 * @param templateUri
	 *            URI of the template to be used for instantiating the json file required for drawing the desired chart.
	 * @param outputformat
	 *            output format in which the chart is to be rendered. All Possible chart output formats can be found in constants file
	 *            {@link ChartingOutputFormats}
	 * @param outputFormatProperties
	 *            name value array of the output properties applicable for given output format. All possible output properties can be found
	 *            in constant file {@link ChartingOutputProperties}.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream
	 *            OutputStream to which the resultant chart will be written.
	 * @throws ChartingException
	 *             In case of any exception occurs during generation of the desired chart. The exception code and stack trace will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws IOException
	 * @throws StreamingException
	 */
	@RequestMapping(method = RequestMethod.POST)
	public void getChartBasedOnStream(@WebInputStream InputStream inputStream,
			@RequestParam(value = "sourcedatatype", defaultValue = "smarttable") String sourceDataType,
			@RequestParam(value = "templateuri", required = true) String templateUri,
			@RequestParam(value = "outputformat", required = false) String outputformat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream)
			throws ChartingException, QppServiceException, IOException, StreamingException {
		OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
		long contextId = 0;
		try {

			if (sourceDataType == null) {
				// Consider default source data type as SMART_TABLE
				sourceDataType = ChartingSourceTypes.SMART_TABLE;
			}

			contextId = chartingService.createChartingReadWriteContext();
			NameValue[] nameValuesOutputProperties = createNameValueArray(outputFormatProperties);
			chartingStreamingService.upload(inputStream, contextId);

			chartingService.readChartBasedOnStreamContext(contextId, sourceDataType, templateUri, outputformat, nameValuesOutputProperties);

			setContentHttpHeaders(outputformat, outputFormatProperties, httpServletResponse, contentDisposition);
			chartingStreamingService.download(os, contextId);

		} finally {
			if (contextId > 0) {
				chartingService.closeContext(contextId);
			}
		}
	}

	/**
	 * Out of the http response and normal stream, returns the one which is not null. In local invocation Outputstream will be provided
	 * whereas in REST invocations outputstream need to be httresponse outputstream
	 * 
	 * @param httpServletResponse
	 * @param outputStream
	 * @return
	 * @throws ExcelOutputException
	 * @throws IOException
	 */
	private OutputStream getDesiredOutputStream(HttpServletResponse httpServletResponse, OutputStream outputStream)
			throws ChartingException, IOException {
		OutputStream os = null;
		if (httpServletResponse != null && httpServletResponse.getOutputStream() != null) {
			os = httpServletResponse.getOutputStream();
		} else if (outputStream != null) {
			os = outputStream;
		} else {
			throw new ChartingException(ChartingExceptionCodes.NO_OUTPUT_STEAM_FOR_WRITING_OUTPUT);
		}
		return os;
	}

	private NameValue[] createNameValueArray(Map<String, String> outputParameters) {
		NameValue[] nameValues = null;
		if (outputParameters != null) {
			nameValues = new NameValue[outputParameters.size()];
			Iterator<String> itr = outputParameters.keySet().iterator();
			int i = 0;
			while (itr.hasNext()) {
				String name = itr.next();
				String value = outputParameters.get(name);
				nameValues[i] = new NameValue(name, value);
				i = i + 1;
			}
		}
		return nameValues;
	}

	private void setContentHttpHeaders(String outputFormat, HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse, String contentDisposition) throws QppServiceException {
		if (httpServletResponse == null) {
			// This will be null for local (non-REST) invocation.
			return;
		}
		
		String fileXtension = getFileExtension(outputFormat, outputFormatProperties);
		// mimetype can be fetched only on the basis of file extension. Because the output stream on which the output is written is direct
		// httpServletResponse not any temp file using which the initial bytes can be read and mimetype can be determined. Output needs to
		// be written to some temp file if based on initial bytes mime type is to be determined
		String mimeType = contentStructureService.getContentIdentifier(fileXtension, null, null).getMimeType();
		httpServletResponse.setContentType(mimeType);

		if (contentDisposition == null) {
			// default disposition is inline
			contentDisposition = "inline";
		}
		httpServletResponse.setHeader("Content-Disposition", contentDisposition + "; filename=\"" + "Chart" + "." + fileXtension + "\"");
	}

	private String getFileExtension(String outputFormat, HashMap<String, String> outputFormatProperties) {
		String fileXtension = "png";//default file extension. TODO: should be in synch with what is defined in the ChartingServiceConfig.properties
		if (outputFormat == null || outputFormat.equalsIgnoreCase(ChartingOutputFormats.IMAGE)) {
			if (outputFormatProperties != null) {
				String value = outputFormatProperties.get(ChartingOutputProperties.IMAGE_FORMAT);
				if (value != null && value.trim().length() > 0)
					fileXtension = value;
			}
			return fileXtension;
		} else if (outputFormat.equalsIgnoreCase(ChartingOutputFormats.HTML)) {
			fileXtension = "htm";
		} else if (outputFormat.equalsIgnoreCase(ChartingOutputFormats.JSON)) {
			fileXtension = "txt";
		}
		return fileXtension;
	}
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 *
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

}

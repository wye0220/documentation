/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.dto.StatusPrivileges;
import com.quark.qpp.core.privilege.service.dto.UserClass;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidStatusPrivilegesException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotEditableException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.privilege.service.local.UserClassService;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.workflow.service.dto.AttributeConstraint;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.StatusRoutingUserClasses;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.UserRedliningColor;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.InvalidColorException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidUserColorException;
import com.quark.qpp.core.workflow.service.exceptions.InvalidWorkflowDefinitionException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowInUseException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.local.WorkflowService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AttributeConstraintsInfo;
import com.quark.qpp.service.xmlBinding.AttributeConstraintsInfoList;
import com.quark.qpp.service.xmlBinding.ContentTypeInfo;
import com.quark.qpp.service.xmlBinding.ContentTypeInfoList;
import com.quark.qpp.service.xmlBinding.PrivilegeInfo;
import com.quark.qpp.service.xmlBinding.PrivilegeInfoList;
import com.quark.qpp.service.xmlBinding.RedlineInfo;
import com.quark.qpp.service.xmlBinding.RedlineInfoList;
import com.quark.qpp.service.xmlBinding.RoleBasedStatusTransitionInfo;
import com.quark.qpp.service.xmlBinding.RoleBasedStatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.StatusInfo;
import com.quark.qpp.service.xmlBinding.StatusInfoList;
import com.quark.qpp.service.xmlBinding.StatusTransitionInfoList;
import com.quark.qpp.service.xmlBinding.WorkflowInfo;
import com.quark.qpp.service.xmlBinding.WorkflowInfoList;

public class WorkflowController {

	@Autowired
	private WorkflowService workflowService;
	
	@Autowired
	private CollectionService collectionService;

	@Autowired
	private UserClassService userClassService;
	
	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;
	
	private final Logger logger = Logger.getLogger(this.getClass());
	
	private static long ADMINISTRATOR_USERCLASS_ID = 1;

	public WorkflowInfoList getAllWorkflows() throws QppServiceException {
		Workflow[] workflows = workflowService.getAllWorkflows();
		/** status, content type informaion is loaded in transform method */
		return objectTransformer.transform(workflows, true/*getDetailedInfo*/);
	}

	/** Get workflow by name or Id */
	public WorkflowInfoList getWorkflow(String workflow) throws WorkflowNotFoundException, QppServiceException {
		long id = facadeUtility.getWorkflowIds(new String[]{workflow})[0];
		Workflow workFlow = workflowService.getWorkflow(id);
		WorkflowInfo workflowInfo = objectTransformer.transform(workFlow, true/*getDetailedInfo*/);
		WorkflowInfoList workflowInfoList = new WorkflowInfoList();
		workflowInfoList.getWorkflowInfo().add(workflowInfo);
		return workflowInfoList;
	}

	public WorkflowInfoList createWorkFlows(WorkflowInfoList workflowInfoList) throws WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, InvalidWorkflowDefinitionException, InvalidContentTypeException,
			QppServiceException {
		if (workflowInfoList != null && workflowInfoList.getWorkflowInfo() != null) {
			Iterator<WorkflowInfo> it = workflowInfoList.getWorkflowInfo().iterator();
			WorkflowInfoList createdWorkflows = new WorkflowInfoList();
			/** Create workflows one by one. */
			while (it.hasNext()) {
				WorkflowInfo workFlowInfo = it.next();
				try {
					WorkflowInfo newWorkflowInfo = createWorkFlow(workFlowInfo);
					createdWorkflows.getWorkflowInfo().add(newWorkflowInfo);
				} catch (QppServiceException e) {
					logger.error("Error while creating workflow with name: " + workFlowInfo.getName(), e);
					if (workflowInfoList.getWorkflowInfo().size() == 1) {
						throw e;
					}
				}
			}
			return createdWorkflows;
		} else {
			throw new InvalidWorkflowDefinitionException();
		}
	}

	private WorkflowInfo createWorkFlow(WorkflowInfo workflowInfo) throws WorkflowNotFoundException, InvalidStatusException,
			StatusNotFoundException, InvalidWorkflowDefinitionException, InvalidContentTypeException, QppServiceException {
		/** get workflow name */
		String workflowName = workflowInfo.getName();

		/** get content type id array */
		ContentTypeInfoList contentTypeInfoList = workflowInfo.getContentTypeInfoList();
		long[] contentTypesIds = getContentTypeIdsArray(contentTypeInfoList);

		/** get status array . Status dto do not contains info about redlining, rule eval,privlages etc. */
		StatusInfoList statusInfoList = workflowInfo.getStatusInfoList();
		Status[] statuses = objectTransformer.transform(statusInfoList, null/*Specify workflow name as null as we don't want to populate status ids, since this is workflow creation call.*/);

		/** create new workflow */
		Boolean constrainedStatusTransistions = workflowInfo.isConstrainedStatusTransition();
		if (constrainedStatusTransistions == null) {
			constrainedStatusTransistions = false;
		}
		Boolean roleBasedRouting = workflowInfo.isRoleBasedRouting();
		if (roleBasedRouting == null) {
			roleBasedRouting = false;
		}
		
		Workflow workflow = workflowService.createWorkflow(workflowName, statuses, contentTypesIds, constrainedStatusTransistions, roleBasedRouting);

		if (workflow.getStatuses() != null && workflow.getStatuses().length > 0) {
			/** Update Status related information */
			updateStatusRelatedEntities(workflow.getId(), statusInfoList);
		}
		
		// Update status transitions only if they are mentioned otherwise they remain unchanged.
		if (workflowInfo.getStatusTransitionInfoList() != null) {
			StatusTransition[] statusTransitions = objectTransformer.transform(workflowInfo.getStatusTransitionInfoList(), workflow.getId());
			workflowService.setStatusTransitions(workflow.getId(), statusTransitions);
		}

		if(workflowInfo.getRoleBasedStatusTransitionInfoList() != null){
			/** update role based status transition */
			updateRoleBasedStatusTransitions(workflow.getId(), workflowInfo.getRoleBasedStatusTransitionInfoList());
		}
		
		// Update role based status routing only if they are mentioned otherwise they remain unchanged.
		if (workflowInfo.getStatusRoutingRolesInfoList() != null) {
			StatusRoutingUserClasses[] statusRoutingUserClasses = objectTransformer.transform(workflowInfo.getStatusRoutingRolesInfoList(), workflow.getId());
			workflowService.setStatusRoutingUserclasses(workflow.getId(), statusRoutingUserClasses);
		}

		//workflow object which e got from the createWorkflow(..) is now stale because status transition and routing roles are updated after creation of the workflow
		return objectTransformer.transform(workflowService.getWorkflow(workflow.getId()), true/*getDetailedInfo*/);
	}

	public void deleteWorkFlow(String workflow) throws WorkflowNotFoundException, WorkflowInUseException, QppServiceException {
		long id = facadeUtility.getWorkflowIds(new String[]{workflow})[0];
		workflowService.deleteWorkflow(id);
	}

	public WorkflowInfoList updateWorkflows(WorkflowInfoList workflowInfoList)
			throws InvalidWorkflowDefinitionException, WorkflowNotFoundException, InvalidStatusException, StatusNotFoundException,
			QppServiceException {
		WorkflowInfoList updatedWorkflows = new WorkflowInfoList();
		if (workflowInfoList != null) {
			List<WorkflowInfo> workFlowInfoList = workflowInfoList.getWorkflowInfo();
			Iterator<WorkflowInfo> it = workFlowInfoList.iterator();
			while (it.hasNext()) {
				WorkflowInfo workFlowInfo = it.next();
				try {
					WorkflowInfo updatedWorkflow = updateWorkFlow(workFlowInfo);
					updatedWorkflows.getWorkflowInfo().add(updatedWorkflow);
				} catch (QppServiceException e) {
					logger.error("Error while updating workflow with name " + workFlowInfo.getName(), e);
					if (workflowInfoList.getWorkflowInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidWorkflowDefinitionException();
		}
		return updatedWorkflows;
	}

	private WorkflowInfo updateWorkFlow(WorkflowInfo workflowInfo) throws InvalidWorkflowDefinitionException, WorkflowNotFoundException,
			InvalidStatusException, StatusNotFoundException, WorkflowNotFoundException, QppServiceException {
		Long workflowId = workflowInfo.getId();
		String workflowName = workflowInfo.getName();
		if (workflowId == null || workflowId <= 0) {
			workflowId = workflowService.getWorkflowByName(workflowName).getId();
		}
		String currWorkflowName = workflowService.getWorkflow(workflowId).getName();
		if (workflowName != null && !workflowName.isEmpty() && !currWorkflowName.equalsIgnoreCase(workflowName)) {
			workflowService.renameWorkflow(workflowId, workflowName);
		}else{
			workflowName = currWorkflowName;
		}

		/* Update statuses. If statusinfolist is null then no changes are made in statuses for this workflow. Specify an empty StatusInoList in order to delete all statuses. */
		StatusInfoList statusInfoList = workflowInfo.getStatusInfoList();
		if (statusInfoList != null) {
			Status[] statuses = objectTransformer.transform(statusInfoList, workflowName);
			workflowService.setWorkflowStatuses(workflowId, statuses);
			//update status for redlining, tracking, check rule evaluations, constraints etc..
			updateStatusRelatedEntities(workflowId, statusInfoList);
		}

		/* Update workflow content type mapping information. In order to remove all the workflow mapped content types specify empty ContentTypeInfoList. */
		ContentTypeInfoList contentTypeInfoList = workflowInfo.getContentTypeInfoList();
		if (contentTypeInfoList != null && contentTypeInfoList.getContentTypeInfo() != null) {
			long[] ids = getContentTypeIdsArray(contentTypeInfoList);
			workflowService.setWorkflowContentTypes(workflowId, ids);
		}
		
		//Update ConstrainedStatusTransition flag only when it is mentioned, otherwise let it remain unchanged.
		Boolean constrainedStatusTransistions = workflowInfo.isConstrainedStatusTransition();
		if (constrainedStatusTransistions != null) {
			workflowService.updateConstrainedStatusTransition(workflowId, Boolean.valueOf(constrainedStatusTransistions));
		}
		
		//Update status transitions only if they are mentioned otherwise they remain unchanged. 
		if(workflowInfo.getStatusTransitionInfoList()!=null){
			StatusTransition[] statusTransitions = objectTransformer.transform(workflowInfo.getStatusTransitionInfoList(), workflowId);
			workflowService.setStatusTransitions(workflowId, statusTransitions);
		}
		
		/** update role based status transition */
		updateRoleBasedStatusTransitions(workflowId, workflowInfo.getRoleBasedStatusTransitionInfoList());
		
		
		//Update roleBasedRouting flag only when it is mentioned, otherwise let it remain unchanged.
		Boolean roleBasedRouting = workflowInfo.isRoleBasedRouting();
		if (roleBasedRouting != null) {
			workflowService.updateUserclassBasedRouting(workflowId, Boolean.valueOf(roleBasedRouting));
		}
		
		// Update role based status routing only if they are mentioned otherwise they remain unchanged.
		if (workflowInfo.getStatusRoutingRolesInfoList() != null) {
			StatusRoutingUserClasses[] statusRoutingUserClasses = objectTransformer.transform(workflowInfo.getStatusRoutingRolesInfoList(), workflowId);
			workflowService.setStatusRoutingUserclasses(workflowId, statusRoutingUserClasses);
		}

		
		return objectTransformer.transform(workflowService.getWorkflow(workflowId), true/*getDetailedInfo*/);

	}
	
	private void updateStatusRelatedEntities(long workflowId, StatusInfoList statusInfoList) throws WorkflowNotFoundException,
			StatusNotFoundException, InvalidStatusPrivilegesException, UserClassNotFoundException, UserClassNotEditableException,
			InvalidPrivilegeException, PrivilegeNotFoundException, QppServiceException {
		Iterator<StatusInfo> iterator = statusInfoList.getStatusInfo().iterator();
		HashMap<Long, ArrayList<AttributeConstraint>> attributeConstraintsMap = new HashMap<Long, ArrayList<AttributeConstraint>>();
		Status[] existingStatuses = workflowService.getWorkflow(workflowId).getStatuses();
		while (iterator.hasNext()) {
			StatusInfo statusInfo = iterator.next();
			long newStatusId = -1;
			for (int i = 0; i < existingStatuses.length; i++) {
				if (statusInfo.getId()!=null && statusInfo.getId() == existingStatuses[i].getId()) {
					newStatusId = existingStatuses[i].getId();
					break;
				}else if(statusInfo.getName()!=null && statusInfo.getName().equalsIgnoreCase(existingStatuses[i].getName())){
					newStatusId = existingStatuses[i].getId();
					break;
				}
			}
			/** update redlining for status */
			workflowService.updateStatusRedlining(workflowId, newStatusId, statusInfo.isRedlineTracking());
			/** update check in rule evaluation */
			workflowService.updateCheckInRuleEvaluation(workflowId, newStatusId, statusInfo.isCheckInLayoutEvaluation());
			/** update print rule evaluation */
			workflowService.updatePrintRuleEvaluation(workflowId, newStatusId, statusInfo.isOutputLayoutEvaluation());
			/** update status privlages */
			updateStatusPrivileges(workflowId, newStatusId, statusInfo.getPrivilegeInfoList());
			/** update attribute constraints */
			updateMapForAttributeConstraints(newStatusId, statusInfo.getAttributeConstraintsInfoList(), attributeConstraintsMap);			
		}
		/** create attribute constraints for new workflow */
		for (Map.Entry<Long, ArrayList<AttributeConstraint>> entry : attributeConstraintsMap.entrySet()) {
			workflowService.setAttributeConstraints(entry.getKey(), workflowId, entry.getValue().toArray(new AttributeConstraint[0]));
		}
	}

	private void updateRoleBasedStatusTransitions(long workflowId, RoleBasedStatusTransitionInfoList roleBasedStatusTransitionInfoList)
			throws UserClassNotFoundException, InvalidStatusException, StatusNotFoundException, QppServiceException {
		// Update role based transitions only if they are provided
		if (roleBasedStatusTransitionInfoList != null) {
				UserClass[] userclasses = userClassService.getAllUserClasses();
				for (int i = 0; i < userclasses.length; i++) {
					long userclassId = userclasses[i].getId();
					StatusTransition[] existingStatusTransitions = userClassService.getOverriddenWorkflowStatusTransitions(
							userclasses[i].getId(), workflowId);
					RoleBasedStatusTransitionInfo statusTransitionInfo = fetchRoleBasedTransition(userclassId,
							roleBasedStatusTransitionInfoList);
					StatusTransition[] newStatusTransitions = null;
					if (statusTransitionInfo != null) {
						newStatusTransitions = objectTransformer.transform(statusTransitionInfo.getStatusTransitionInfoList(), workflowId);
					}
				
					if (newStatusTransitions != null && newStatusTransitions.length > 0) {
						userClassService.setOverriddenWorkflowStatusTransitions(userclassId, workflowId, newStatusTransitions);
					} else if (existingStatusTransitions != null && existingStatusTransitions.length > 0) {
					// Delete overridden status transition if it exist as status transitions are not provided
						userClassService.setOverriddenWorkflowStatusTransitions(userclassId, workflowId, null);
					}
				}
			}
		}

	private RoleBasedStatusTransitionInfo fetchRoleBasedTransition(long userclassId,
			RoleBasedStatusTransitionInfoList roleBasedStatusTransitionInfoList) throws UserClassNotFoundException, QppServiceException {
		if (roleBasedStatusTransitionInfoList == null) {
			return null;
		}
		List<RoleBasedStatusTransitionInfo> roleBasedStatusTransitionInfos = roleBasedStatusTransitionInfoList
				.getRoleBasedStatusTransitionInfo();
		for (int i = 0; roleBasedStatusTransitionInfos != null && i < roleBasedStatusTransitionInfos.size(); i++) {
			String roleName = roleBasedStatusTransitionInfos.get(i).getName();
			Long roleId = null;
			if (roleName != null && roleName.trim().length() > 0) {
				roleId = facadeUtility.getUserClassId(roleName);
			} else {
				roleId = roleBasedStatusTransitionInfos.get(i).getId();
			}

			if (roleId != null && roleId == userclassId) {
				return roleBasedStatusTransitionInfos.get(i);
			}
		}
		return null;
	}

	private void updateMapForAttributeConstraints(long statusId, AttributeConstraintsInfoList attributeConstraintsInfoList,
			HashMap<Long, ArrayList<AttributeConstraint>> map) throws QppServiceException {
		if (attributeConstraintsInfoList == null || attributeConstraintsInfoList.getAttributeConstraintsInfo() == null) {
			return;
		}
		Iterator<AttributeConstraintsInfo> iterator = attributeConstraintsInfoList.getAttributeConstraintsInfo().iterator();
		while (iterator.hasNext()) {
			AttributeConstraintsInfo attributeConstraintsInfo = iterator.next();
			AttributeConstraint attributeConstraint = new AttributeConstraint();
			/** set attribute constraints properties */
			if(attributeConstraintsInfo.getAttributeName()!=null){
				attributeConstraint
				.setAttributeId(facadeUtility.getAttributeIds(new String[] { attributeConstraintsInfo.getAttributeName() })[0]);
			}else{
				attributeConstraint.setAttributeId(attributeConstraintsInfo.getAttributeId());
			}
			int constraintId = attributeConstraintsInfo.getConstraintId();
			if (constraintId <= 0) {
				constraintId = facadeUtility.getAttributeConstraintId(attributeConstraintsInfo.getConstraintName());
			}
			attributeConstraint.setConstraintType(constraintId);
			attributeConstraint.setStatusId(statusId);
			if(attributeConstraintsInfo.getRoleName()!=null){
				attributeConstraint.setUserclassId(facadeUtility.getRoleId(attributeConstraintsInfo.getRoleName()));
			}else{
				attributeConstraint.setUserclassId(attributeConstraintsInfo.getRoleId());
			}
			
			/** put attribute id and respective constraints to map */
			addAttributeConstraintToMap(attributeConstraint.getAttributeId(), attributeConstraint, map);
		}
	}

	private void updateStatusPrivileges(long workFlowId, long statusId, PrivilegeInfoList privilegeInfoList)
			throws InvalidStatusPrivilegesException, StatusNotFoundException, UserClassNotFoundException, UserClassNotEditableException,
			InvalidPrivilegeException, PrivilegeNotFoundException, QppServiceException {
		/** skip if no privileges provided . */
		if (privilegeInfoList == null || privilegeInfoList.getPrivilegeInfo() == null || privilegeInfoList.getPrivilegeInfo().size() <= 0) {
			return;
		}
		Iterator<PrivilegeInfo> iterator = privilegeInfoList.getPrivilegeInfo().iterator();
		while (iterator.hasNext()) {
			PrivilegeInfo privilegeInfo = iterator.next();
			StatusPrivileges statusPrivileges = new StatusPrivileges();
			statusPrivileges.setStatusId(statusId);
			if (privilegeInfo.getRoleName() != null && !privilegeInfo.getRoleName().isEmpty()) {
				statusPrivileges.setUserClassId(facadeUtility.getRoleId(privilegeInfo.getRoleName()));
			} else {
				statusPrivileges.setUserClassId(privilegeInfo.getRoleId());
			}
			/*
			 * If there no check for administrator userclass id,then there will be unnecessary UserClassNotEditableException even while
			 * creating workflow through an xml exported from source server.
			 */
			if (statusPrivileges.getUserClassId() != ADMINISTRATOR_USERCLASS_ID) {
				statusPrivileges.setOverridden(privilegeInfo.isOverridden());
				if (privilegeInfo.isOverridden() && privilegeInfo.getContentTypePrivList() != null
						&& privilegeInfo.getContentTypePrivList().getContentTypePriv() != null
						&& privilegeInfo.getContentTypePrivList().getContentTypePriv().size() > 0) {
					statusPrivileges.setContentTypePrivileges(objectTransformer.transform(privilegeInfo.getContentTypePrivList()));
				}
				userClassService.setStatusPrivileges(statusPrivileges);
			} else if (statusPrivileges.getUserClassId() == ADMINISTRATOR_USERCLASS_ID && privilegeInfo.isOverridden()) {
				logger.debug("Status privileges can't be overridden for Administrator userclass.");
			}
		}
	}

	private void addAttributeConstraintToMap(long attributeId, AttributeConstraint attributeConstraint,
			HashMap<Long, ArrayList<AttributeConstraint>> attributeConstraintsMap) {
		if (attributeConstraintsMap.containsKey(attributeId)) {
			attributeConstraintsMap.get(attributeId).add(attributeConstraint);
		} else {
			ArrayList<AttributeConstraint> arrList = new ArrayList<AttributeConstraint>();
			arrList.add(attributeConstraint);
			attributeConstraintsMap.put(attributeId, arrList);
		}
	}

	private long[] getContentTypeIdsArray(ContentTypeInfoList contentTypeInfoList) throws QppServiceException {
		Set<Long> contentTypeIds = new HashSet<Long>();
		if (contentTypeInfoList != null && contentTypeInfoList.getContentTypeInfo() != null) {
			Iterator<ContentTypeInfo> iterator = contentTypeInfoList.getContentTypeInfo().iterator();
			while (iterator.hasNext()) {
				ContentTypeInfo contentTypeInfo = iterator.next();
				if (contentTypeInfo.getContentTypeHierarchy() != null && !contentTypeInfo.getContentTypeHierarchy().isEmpty()) {
					long contentTypeId = facadeUtility.getContentTypeIdForHierarchy(contentTypeInfo.getContentTypeHierarchy());
					contentTypeIds.add(contentTypeId);
				} else if (contentTypeInfo.getId() != null) {
					contentTypeIds.add(contentTypeInfo.getId());
				} else if (contentTypeInfo.getName() != null) {
					long contentTypeId = facadeUtility.getContentTypeIdForName(contentTypeInfo.getName());
					contentTypeIds.add(contentTypeId);
				}
			}
		}
		return getLongArray(contentTypeIds);
	}

	public RedlineInfoList getAllUserRedliningColor() throws QppServiceException {
		UserRedliningColor[] userRedliningColors = workflowService.getAllUserRedliningColors();
		return objectTransformer.transform(userRedliningColors);
	}

	public RedlineInfoList getUserRedliningColor(String user) throws UserNotFoundException, QppServiceException {
		long userId = facadeUtility.getUserId(user);
		UserRedliningColor userRedliningColor = workflowService.getUserRedliningColor(userId);
		return objectTransformer.transform(new UserRedliningColor[] { userRedliningColor });
	}

	public RedlineInfoList updateUserRedliningColor(RedlineInfoList redlineInfoList) throws InvalidUserColorException, UserNotFoundException, InvalidColorException, QppServiceException {
		if (redlineInfoList != null && redlineInfoList.getRedlineInfo() != null) {
			Iterator<RedlineInfo> it = redlineInfoList.getRedlineInfo().iterator();
			RedlineInfoList updatedRedlineInfoList = new RedlineInfoList();
			while (it.hasNext()) {
				RedlineInfo redlineInfo = it.next();
				try {
					RedlineInfo updatedRedlineInfo = updateRedline(redlineInfo);
					updatedRedlineInfoList.getRedlineInfo().add(updatedRedlineInfo);
				} catch (QppServiceException e) {
					logger.error("Error while updating redline info", e);
					if (redlineInfoList.getRedlineInfo().size() == 1) {
						throw e;
					}
				}
			}
			return updatedRedlineInfoList;
		} else {
			throw new QppServiceException("NO_REDLINE_INFO_FOUND");
		}
	}
	
	private RedlineInfo updateRedline(RedlineInfo redlineInfo) throws InvalidUserColorException, UserNotFoundException, InvalidColorException, QppServiceException {
		UserRedliningColor userRedliningColor = objectTransformer.transform(redlineInfo);
		workflowService.setUserRedliningColor(userRedliningColor);
		return objectTransformer.transform(workflowService.getUserRedliningColor(userRedliningColor.getUserId()));
	}

	public StatusInfoList getWorkflowInitiatingStatuses(String workflowIdOrName, String roleIdOrName) throws WorkflowNotFoundException,
			UserClassNotFoundException, QppServiceException {
		long workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
		long roleId = 0;
		if (roleIdOrName != null && roleIdOrName.trim().length() > 0) {
			roleId = facadeUtility.getUserClassId(roleIdOrName);
		}
		Status[] workflowInitiatingStatuses = null;
		if (roleId > 0) {
			StatusTransition[] statusTransitions = userClassService.getOverriddenWorkflowStatusTransitions(roleId, workflowId);
			ArrayList<Long> workflowInitiatingStatusIds = new ArrayList<Long>();
			for (int i = 0; statusTransitions != null && i < statusTransitions.length; i++) {
				StatusTransition statusTransition = statusTransitions[i];
				if (statusTransition.isWorkflowInitiatingStatus()) {
					workflowInitiatingStatusIds.add(statusTransition.getStatusId());
				}
			}
			workflowInitiatingStatuses = new Status[workflowInitiatingStatusIds.size()];
			for (int i = 0; i < workflowInitiatingStatusIds.size(); i++) {
				Status status = workflowService.getStatus(workflowInitiatingStatusIds.get(i));
				workflowInitiatingStatuses[i] = status;
			}
		} else {
			workflowInitiatingStatuses = workflowService.getWorkflowInitialStatuses(workflowId);
		}
		return objectTransformer.transform(workflowInitiatingStatuses, workflowId);
	}

	public StatusTransitionInfoList getStatusTransitions(String workflowIdOrName, String statusIdOrName, String roleIdOrName)
			throws WorkflowNotFoundException, StatusNotFoundException, WorkflowNotFoundException, InvalidStatusException,
			QppServiceException {
		long workflowId = facadeUtility.getWorkflowIds(new String[] { workflowIdOrName })[0];
		long statusId = 0;
		if (statusIdOrName != null && statusIdOrName.trim().length() > 0) {
			statusId = facadeUtility.getStatusId(workflowId, statusIdOrName);
		}
		long roleId = 0;
		if (roleIdOrName != null && roleIdOrName.trim().length() > 0) {
			roleId = facadeUtility.getUserClassId(roleIdOrName);
		}
		StatusTransition[] statusTransitions = null;
		if (roleId > 0) {
			if (statusId > 0) {
				StatusTransition statusTransition = userClassService.getOverriddenStatusTransition(roleId, workflowId, statusId);
				if (statusTransition != null) {
					statusTransitions = new StatusTransition[1];
					statusTransitions[0] = statusTransition;
				}
			} else {
				statusTransitions  = userClassService.getOverriddenWorkflowStatusTransitions(roleId, workflowId);
			}
		} else {
			if (statusId > 0) {
				StatusTransition statusTransition = workflowService.getStatusTransition(workflowId, statusId);
				if(statusTransition != null){
					statusTransitions = new StatusTransition[1];
					statusTransitions[0] = statusTransition;
				}
			} else {
				statusTransitions = workflowService.getWorkflowStatusTransitions(workflowId);
			}
		}
		return objectTransformer.transform(statusTransitions, workflowId);
	}
	
	private long[] getLongArray(Set<Long> set) {
		if (set == null || set.size() == 0) {
			return new long[0];
		}

		long[] array = new long[set.size()];
		int counter = 0;
		Iterator<Long> iterator = set.iterator();
		while(iterator.hasNext()){
			long item = iterator.next();
			array[counter++] = item;
		}
		return array;
	}
}
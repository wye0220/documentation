/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.office.service.constants.ExcelDataOutputFormats;
import com.quark.qpp.office.service.constants.ImageOutputProperties;
import com.quark.qpp.office.service.constants.PowerPointDataOutputFormats;
import com.quark.qpp.office.service.constants.TableOutputProperties;
import com.quark.qpp.office.service.constants.VisioDataOutputFormats;
import com.quark.qpp.office.service.exceptions.ExcelDataException;
import com.quark.qpp.office.service.exceptions.ExcelOutputException;
import com.quark.qpp.office.service.exceptions.PowerPointDataException;
import com.quark.qpp.office.service.exceptions.PowerPointOutputException;
import com.quark.qpp.office.service.exceptions.VisioDataException;
import com.quark.qpp.office.service.exceptions.VisioOutputException;
import com.quark.qpp.rest.framework.annotations.WebArrayParam;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebResourcePathParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.PowerPointSlideInfoList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;
import com.quark.qpp.service.xmlBinding.VisioPageInfoList;
import com.quark.qpp.service.xmlBinding.WorksheetInfoList;

/**
 * Facade to burst an Excel document into worksheets & data objects. 
 * 
 */
@Controller(value = "officeByPathFacade")
@RequestMapping("/office")
public class OfficeByPathFacade {

	private final static String EXCEL_PATH_IDENTIFIER = "office/excelbypath"; 
	private final static String POWERPOINT_PATH_IDENTIFIER = "office/powerpointbypath"; 
	private final static String VISIO_PATH_IDENTIFIER = "office/visiobypath"; 
	private final static String EXCEL_CHART_PATH_IDENTIFIER = "office/excelchartbypath";
	private final static String EXCEL_TABLE_PATH_IDENTIFIER = "office/exceltablebypath";
	
	@Autowired
	private OfficeFacade officeFacade;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	/**
	 * Returns all worksheets defined in an Excel document. Each worksheet object encapsulates its metadata like worksheet index & name. In
	 * addition, a worksheet will also provide information about its data objects like tables, named ranges & charts.<br/>
	 * In order to retrieve specific worksheets, specify valid worksheet names in worksheetNames parameter.
	 * 
	 * @param assetPath
	 *            Collection path of the Excel asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Excel asset
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetNames
	 *            string array of worksheet names to be retrieved.In case this parameter is not defined, then all the Excel worksheets will
	 *            be returned.
	 * @return List of worksheets in the Excel document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version doesn't exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelbypath/**")
	@WebReturnType("xmlView")
	public WorksheetInfoList getExcelWorksheets(@WebResourcePathParam(EXCEL_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, @WebArrayParam("worksheets") String[] worksheetNames)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return officeFacade.getExcelWorksheets(assetId, majorVersion, minorVersion, worksheetNames);
	}

	/**
	 * Returns an Excel chart in the image format.
	 * 
	 * @param assetPath
	 *            Collection path of the Excel asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the chart is defined. In case the worksheet name is not defined, then the first chart in the
	 *            Excel with the given name is considered.
	 * @param chartName
	 *            name of the Excel chart to be retrieved.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream output stream onto which chart is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or chart name supplied is not valid. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelbypath/**", params = "chart")
	public void getChart(@WebResourcePathParam(EXCEL_PATH_IDENTIFIER) String assetPath, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "chart", required = true) String chartName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getChart(assetId, majorVersion, minorVersion, worksheetName, chartName, outputFormatProperties, httpServletResponse,
				contentDisposition, outputStream);
	}

	/**
	 * Returns an Excel table in the desired output format.
	 * 
	 * @param assetPath
	 *            Collection path of the Excel asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the table is defined. In case the worksheet name is not defined, then the first table in the
	 *            Excel with the given name is considered.
	 * @param tableName
	 *            name of the Excel table to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the table is to be rendered. List of possible output formats can be found in
	 *            constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/SMART_TABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of table is
	 *            required.
	 * @param outputStream output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or table name supplied is not valid. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelbypath/**", params = "table")
	public void getTable(@WebResourcePathParam(EXCEL_PATH_IDENTIFIER) String assetPath, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "table", required = true) String tableName,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getTable(assetId, majorVersion, minorVersion, worksheetName, tableName, outputFormat, outputFormatParameters,
				httpServletResponse, contentDisposition, outputStream);
	}

	/**
	 * Returns an Excel named range in the desired output format.
	 * 
	 * @param assetPath
	 *            Collection path of the Excel asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the named range is defined. In case the worksheet name is not defined, then the first named
	 *            range in the Excel with the given name is considered.
	 * @param namedRange
	 *            name of the Excel named range to be retrieved.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMART_TABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange supplied is not valid. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelbypath/**", params = "namedrange")
	public void getNamedRange(@WebResourcePathParam(EXCEL_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "namedrange", required = true) String rangeName,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getNamedRange(assetId, majorVersion, minorVersion, worksheetName, rangeName, outputFormat, outputFormatParameters,
				httpServletResponse, contentDisposition, outputStream);
	}

	/**
	 * Returns an Excel dynamic range in the desired output format.
	 * 
	 * @param assetPath
	 *            Collection path of the Excel asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Excel asset.
	 * @param minorVersion
	 *            minor version of the Excel asset.
	 * @param worksheetName
	 *            name of the worksheet where the dynamic range is to fetched. In case the worksheet name is not defined, then the first
	 *            worksheet of the Excel will be considered.
	 * @param dynamicRange
	 *            specify a valid dynamic range.<br/>
	 *            Dynamic range can be defined in formats like :<li>Cell reference : A1:C20</li><li>Sheet & cell reference together :
	 *            'Sheet1'!A1:C20</li><li>RC patten : 'Sheet1'!R1C2:R2C3 or R1C2:R2C3(without sheet reference in pattern)</li>
	 *            <li>Formula based : =offset('Sheet1'!A1:C12,2,2,20,10)</li>
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMART_TABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of dynamic range is
	 *            required.
	 * @param outputStream output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) doesnot exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL} or
	 *             {@link DefaultContentTypes#MICROSOFT_EXCEL_TEMPLATE}
	 * @throws ExcelDataException
	 *             If the worksheet name or name of the namedrange suppied is not valid. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelbypath/**", params = "dynamicrange")
	public void getDynamicRange(@WebResourcePathParam(EXCEL_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "worksheet", required = false) String worksheetName,
			@RequestParam(value = "dynamicrange", required = true) String dynamicRange,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getDynamicRange(assetId, majorVersion, minorVersion, worksheetName, dynamicRange, outputFormat,
				outputFormatParameters, httpServletResponse, contentDisposition, outputStream);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            QppServiceException that is to be handled
	 * @return QppServiceExceptionInfo object containing details of the exception thrown
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	/**
	 * Returns all Pages defined in a Visio document. Each page object encapsulates its metadata like page index & name.<br/>
	 * In order to retrieve specific pages, specify valid page names in pages parameter.
	 * 
	 * @param assetPath
	 * 		Collection path of the Visio asset. The assetPath is a string containing collection path followed by asset name. The
	 *		collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *		collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *		Major version of the Visio asset.
	 * @param minorVersion
	 *		Minor version of the Visio asset.
	 * @param pageNames
	 *		String array of Page names to be retrieved. In case this
	 *		parameter is not defined, then all the Visio Pages will
	 *		be returned.
	 * @return List of pages in the Visio document.
	 * @throws AssetNotFoundException
	 *		In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *		In case the asset is not of type
	 *			<li>{@link DefaultContentTypes#MICROSOFT_VISIO}</li>
	 *			<li>{@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}</li>
	 * @throws QppServiceException
	 *		Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/visiobypath/**")
	@WebReturnType("xmlView")
	public VisioPageInfoList getVisioPagesInfo(@WebResourcePathParam(VISIO_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, 
			@WebArrayParam("pages") String[] pageNames)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return officeFacade.getVisioPagesInfo(assetId, majorVersion, minorVersion, pageNames);
	}
	
	/***Returns Visio Document page output in the desired output format.
	* @param assetPath
	 *			Collection path of the Visio asset. The assetPath is a string containing collection path followed by asset name. The
	 *         	collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *         	collection. For example : Home/colA/ColB/.../../assetname.
	 * @param outputFormat
	 * 		 	Format in which Visio Document output is to be retrieved @see {@link VisioDataOutputFormats}
	 * @param pageName
	 * 		  	Name of page within Visio Document whose output is to be retrieved.
	 * @param outputFormatProperties
	 * 		  	  Properties applicable for a given Visio document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf rendering, all native properties of com.aspose.diagram.PdfSaveOptions can be set.</li>
	 *            <li>In case of svg rendering, all native properties of com.aspose.diagram.SVGSaveOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.diagram.HTMLSaveOptions can be set.</li>
	 *            <li>In case of png, jpeg and gif rendering, all native properties of com.aspose.diagram.ImageSaveOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: 
	 * 				<li>{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#RESOLUTION}</li> <br/>
	 * @param httpServletResponse
	 * 		   	FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *         	to set content type and content-disposition header values. The
	 *         	value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 * 		   	Optional value used to set content-disposition header value in
	 *         	response. Set to "attachment" if downloading of page is
	 *         	required.
	 * @param outputStream
	 * 		   	Output stream onto which output is to be written in the
	 *         	desired output format. This parameter is applicable only for
	 *         	the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 			In case the asset with the given id (or version) does not
	 *         	exist.
	 * @throws InvalidAssetException
	 * 			In case the asset is not of type
	 *         		{@link DefaultContentTypes#MICROSOFT_VISIO}
	 *         		{@link DefaultContentTypes#MICROSOFT_VISIO_TEMPLATE}
	 * @throws VisioDataException
	 * 		if Page name specified not exists       
	 * @throws VisioOutputException
	 *         If the outputformat supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	* @throws QppServiceException
	 * 			  Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/visiobypath/**", params = { "pagename" })
	public void getVisioPageOutput(@WebResourcePathParam(VISIO_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@RequestParam(value = "pagename", required = true) String pageName,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, VisioDataException, VisioOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
	    officeFacade.getVisioPageOutput(assetId, majorVersion, minorVersion, outputFormat, pageName, outputFormatProperties, httpServletResponse, contentDisposition, outputStream);
	}
	
	/**
	 * Returns all Slides defined in the PowerPoint document. Each slide object encapsulates its metadata like slide index and slide id.<br/>
	 * In order to retrieve specific slides, specify valid slideindexes in slides parameter.
	 * 
	 * @param assetPath
	 *            Collection path of the PowerPoint asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            Major version of the PowerPoint asset.
	 * @param minorVersion
	 *            Minor version of the PowerPoint asset.
	 * @param slideIndexes
	 *            Array of Slide Indexes to be retrieved. In case this
	 *            parameter is not defined, then all the PowerPoint Slides will
	 *            be returned.
	 * @return List of Slides in the PowerPoint document.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT} or
	 *             {@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpointbypath/**")
	@WebReturnType("xmlView")
	public PowerPointSlideInfoList getPowerPointSlidesInfo(@WebResourcePathParam(POWERPOINT_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, 
			@WebArrayParam("slideindexes") int[] slideIndexes)
			throws AssetNotFoundException, InvalidAssetException, QppServiceException {
		long assetId = facadeUtility.getAssetId(assetPath);
		return officeFacade.getPowerPointSlidesInfo(assetId, majorVersion, minorVersion, slideIndexes);
	}
	
	/**
	 *Returns PowerPoint Slide output in the desired output format.
	 * 
	 * @param assetPath
	 *            Collection path of the PowerPoint asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 * 			  Major version of the PowerPoint asset.
	 * @param minorVersion
	 * 			   Minor version of the PowerPoint asset.
	 * @param slideId
	 * 			Id of slide to be retrieved
	 * @param outputFormat
	 * 			Format in which slide output is to be retrieved @see {@link PowerPointDataOutputFormats}
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 * 		   FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition 
	 * 			 Optional value used to set content-disposition header value in
	 *           response. Set to "attachment" if downloading of slide is
	 *           required.
	 * @param outputStream  
	 * 			  output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 			 In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 * 			 In case the asset is not of type
	 *             <li>{@link DefaultContentTypes#MICROSOFT_POWERPOINT} or</li>
	 *             <li>{@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}</li>
	 * @throws PowerPointDataException
	 * 			If the slide id supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 * 			 If the output format provided is invalid or error occurs
	 *           during the given output generation. Exception code will
	 *           specify the exact cause of exception.
	 * @throws QppServiceException
	 * 			  Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpointbypath/**",params = { "slideid" })
	public void getPowerPointSlideOutput(@WebResourcePathParam(POWERPOINT_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "slideid", required = true) Long slideId,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, PowerPointDataException, PowerPointOutputException, QppServiceException, StreamingException, IOException{
	    	long assetId = facadeUtility.getAssetId(assetPath);
	    	officeFacade.getPowerPointSlideOutput(assetId, majorVersion, minorVersion, slideId, outputFormat, outputFormatProperties, httpServletResponse, contentDisposition, outputStream);
	}
	
	/**Returns PowerPoint Slide-Range output in the desired output format.
	* @param assetPath
	 *            Collection path of the PowerPoint asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 * 			  major version of the PowerPoint asset.
	 * @param minorVersion
	 * 			   minor version of the PowerPoint asset.
	 * @param slideRange
	 * 			Range of indexes of slides to be retrieved 
	 *            <ol>Values in following formats can be specified:
	 *            <li>Continuous slide range. For Example: "4-6" or "4-end"</li>
	 *            <li>Discrete slide range. For example: "2,5,7"</li>	 
	 *            </ol>   
	 * @param outputFormat
	 * 			Format in which slide output is to be retrieved @see {@link PowerPointDataOutputFormats}
	 * @param outputFormatProperties
	 * 			  Properties applicable for a given PowerPoint document and the desired output format.<br/>
	 * 				Following Aspose properties can be set for different output formats:<br/> 
	 *            <li>In case of pdf and pdfnotes rendering, all native properties of com.aspose.slides.PdfOptions can be set.</li>
	 *            <li>In case of html rendering, all native properties of com.aspose.slides.HtmlOptions can be set.</li>
	 *            For IMAGE output format, Platform provides following properties: <ol><li>
	 * 				{@link ImageOutputProperties#IMAGE_FORMAT}</li><li>
	 * 				{@link ImageOutputProperties#HORIZONTAL_SCALING_FACTOR}</li><li>
	 * 				{@link ImageOutputProperties#VERTICAL_SCALING_FACTOR}</li></ol>
	 * @param httpServletResponse
	 * 		   FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @param contentDisposition 
	 * 			 Optional value used to set content-disposition header value in
	 *           response. Set to "attachment" if downloading of slides is
	 *           required.
	 * @param outputStream  
	 * 			  output stream onto which output is to be written in the
	 *            desired output format. This parameter is applicable only for
	 *            the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 * 			 In case the asset with the given id (or version) does not
	 *             exist.
	 * @throws InvalidAssetException
	 * 			 In case the asset is not of type
	 *             <li>{@link DefaultContentTypes#MICROSOFT_POWERPOINT} or</li>
	 *             <li>{@link DefaultContentTypes#MICROSOFT_POWERPOINT_TEMPLATE}</li>
	 * @throws PowerPointDataException
	 * 			If the slide range supplied is not valid.
	 *          The exception code will specify the exact cause of exception.
	 * @throws PowerPointOutputException
	 * 			 If the output format provided is invalid or error occurs
	 *           during the given output generation. Exception code will
	 *           specify the exact cause of exception.
	 * @throws QppServiceException
	 * 			  Unhandled server exception.
	 * @throws StreamingException
	 * 			 In case I/O streaming fails.
	 * @throws IOException
	 * 			 In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/powerpointbypath/**", params = { "sliderange" })
	public void getPowerPointSlideRangeOutput(@WebResourcePathParam(POWERPOINT_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "sliderange", required = true) String slideRange,
			@RequestParam(value = "outputformat", defaultValue = "image") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, PowerPointDataException, PowerPointOutputException, QppServiceException, StreamingException, IOException{
	    	long assetId = facadeUtility.getAssetId(assetPath);
	    	officeFacade.getPowerPointSlideRangeOutput(assetId, majorVersion, minorVersion, slideRange, outputFormat, outputFormatProperties, httpServletResponse, contentDisposition, outputStream);
	}
	
	/**
	 * Returns the chart from a Microsoft Excel Chart document in the desired image format. A Microsoft Excel Chart is an Excel document that contains only one worksheet and one chart.
	 * 
	 * @param assetPath
	 *            Collection path of the Microsoft Excel Chart asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Microsoft Excel Chart asset.
	 * @param minorVersion
	 *            minor version of the Microsoft Excel Chart asset.
	 * @param outputFormatProperties
	 *            map of output properties applicable for image output format. The applicable output properties for image are defined in
	 *            file {@link ImageOutputProperties} file.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param outputStream 
	 * 			   output stream onto which chart is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given assetPath (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_CHART}
	 * @throws ExcelDataException
	 *             If no chart is found in the first worksheet of the Microsoft Excel Chart. The exception code will specify the exact cause of exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/excelchartbypath/**")
	public void getExcelChart(@WebResourcePathParam(EXCEL_CHART_PATH_IDENTIFIER) String assetPath, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@WebParameterMap HashMap<String, String> outputFormatProperties, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getExcelChart(assetId, majorVersion, minorVersion, outputFormatProperties, httpServletResponse, contentDisposition, outputStream);
	}

	/**
	 * Returns the named range from a Microsoft Excel Table document in the desired output format. A Microsoft Excel Table is an Excel document that contains only one worksheet and one named range.
	 * 
	 * @param assetPath
	 *            Collection path of the Microsoft Excel Table asset. The assetPath is a string containing collection path followed by asset name. The
	 *            collection path refers to the collection where the asset exists and assetName refers to the unique asset in that
	 *            collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the Microsoft Excel Table asset.
	 * @param minorVersion
	 *            minor version of the Microsoft Excel Table asset.
	 * @param outputFormat
	 *            string value of the output format in which the named range is to be rendered. List of possible output formats can be found
	 *            in constant file: {@link ExcelDataOutputFormats}
	 * @param outputFormatParameters
	 *            map of output properties applicable for an output format.<br/>
	 *            For an IMAGE output format, the applicable output properties are defined in file {@link ImageOutputProperties} file. <br/>
	 *            For a XHTML/CALS/XML/SMART_TABLE output format, the applicable output properties are defined in file {@link TableOutputProperties} file. <br/>
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values.
	 *            The value of this argument is set by the QPP REST framework.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of named range is
	 *            required.
	 * @param outputStream 
	 * 			   output stream onto which output is to be written in the desired output format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id (or version) does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type {@link DefaultContentTypes#MICROSOFT_EXCEL_TABLE}
	 * @throws ExcelDataException
	 *             If no named range is found in the first worksheet of the Microsoft Excel Table. The exception code will specify the exact cause of
	 *             exception.
	 * @throws ExcelOutputException
	 *             If the output format provided is invalid or error occurs during the given output generation. Exception code will specify
	 *             the exact cause of exception.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case I/O streaming fails.
	 * @throws IOException
	 *             In case of I/O exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/exceltablebypath/**")
	public void getExcelTable(@WebResourcePathParam(EXCEL_TABLE_PATH_IDENTIFIER) String assetPath,
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion,
			@RequestParam(value = "outputformat", defaultValue = "smarttable") String outputFormat,
			@WebParameterMap HashMap<String, String> outputFormatParameters, HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition, OutputStream outputStream) throws AssetNotFoundException,
			InvalidAssetException, ExcelDataException, ExcelOutputException, QppServiceException, StreamingException, IOException {
		long assetId = facadeUtility.getAssetId(assetPath);
		officeFacade.getExcelTable(assetId, majorVersion, minorVersion, outputFormat, outputFormatParameters, httpServletResponse, contentDisposition, outputStream);
	}
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.Value;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.FormAttribute;

/**
 * Helper class that performs asset's attribute-related operations.
 */
public class AttributeUtility {
	
	@Autowired
	private AttributeService attributeService;

	private static final String DEFAULT_TOTAL_WIDTH = "450";
	private static final String DEFAULT_LABEL_WIDTH = "150";
	private static final String DEFAULT_CONTROL_WIDTH = "300";
	public static final long DEFAULT_VERTICAL_GAP_BETWEEN_CONTROLS = 35;
	public static final long DEFAULT_Y_AXIS_START = 5;

	/**
	 * Helper method that adds or updates the value for an attribute.
	 * 
	 * @param attributeValues
	 * @param attributeId
	 * @param type
	 * @param value
	 * @return
	 */
	public AttributeValue[] addAttributeValue(AttributeValue[] attributeValues, long attributeId, int type, Value value) {
		for (int i = 0; i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			if (attributeValue.getAttributeId() == attributeId) {
				attributeValue.setAttributeValue(value);
				return attributeValues;
			}
		}
		AttributeValue attributeValue = new AttributeValue(attributeId, value, type);
		AttributeValue[] newListOfAttributes = new AttributeValue[attributeValues.length + 1];
		System.arraycopy(attributeValues, 0, newListOfAttributes, 0, attributeValues.length);
		newListOfAttributes[attributeValues.length] = attributeValue;
		return newListOfAttributes;
	}

	public AttributeValue[] getUserClientModifiableAttributeValues(AttributeValue[] attributeValues) throws AttributeNotFoundException, QppServiceException {
		ArrayList<AttributeValue> list = new ArrayList<AttributeValue>();
		for (AttributeValue attributeValue : attributeValues) {
			if ((attributeService.getAttribute(attributeValue.getAttributeId()).getModificationLevel()) != AttributeModificationLevels.SERVER_MODIFIABLE) {
				list.add(new AttributeValue(attributeValue.getAttributeId(), attributeValue.getAttributeValue(), attributeValue.getType()));
			}
		}
		return list.toArray(new AttributeValue[0]);
	}
	public List<FormAttribute> createSortedAttributeListWithDefaultPlacement(com.quark.qpp.core.attribute.service.dto.Attribute[] qpsAttributes, long maxLength) {
		List<FormAttribute> attributeList = new ArrayList<FormAttribute>();
		// Sort these attributes according to their names
		Arrays.sort(qpsAttributes, new AttributeNameComparator());
		// Assign default x, y and width
		long x = 0;// WebAdminConstants.FormConstants.DEFAULT_Y_AXIS_START;
		long y = 0;
		for (int i = 0; i < qpsAttributes.length; i++) {
			//remove name, status, workflow, collection etc form list
			if (isDisplayableAttribute(qpsAttributes[i])) {
				FormAttribute formAttribute = new FormAttribute();
				formAttribute.setId(qpsAttributes[i].getId());
				formAttribute.setName(qpsAttributes[i].getName());
				formAttribute.setValueType(qpsAttributes[i].getValueType());
				formAttribute.setXPos(String.valueOf(x));
				formAttribute.setYPos(String.valueOf(y));
				formAttribute.setTotalWidth(DEFAULT_TOTAL_WIDTH);
				formAttribute.setControlWidth(DEFAULT_CONTROL_WIDTH);
				formAttribute.setLabelWidth(DEFAULT_LABEL_WIDTH);
				attributeList.add(formAttribute);
				y += (DEFAULT_VERTICAL_GAP_BETWEEN_CONTROLS);
			}
		}
		return attributeList;
	}

	public String getNativeAttributeValue(long attributeId, AttributeValueList attributeValueList) throws AttributeNotFoundException, QppServiceException {
		String nativeAttributeValue = null;
		if (attributeValueList != null && attributeValueList.getAttributeValue() != null) {
			Iterator<com.quark.qpp.service.xmlBinding.AttributeValue> iterator = attributeValueList.getAttributeValue().iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.AttributeValue attributeValue = iterator.next();
				String attributeName = attributeService.getAttribute(attributeId).getName();
				if (attributeValue.getId() == attributeId || attributeValue.getName().equalsIgnoreCase(attributeName)) {
					nativeAttributeValue = attributeValue.getValue();
					break;
				}
			}
		}
		return nativeAttributeValue;
	}
	private static boolean isDisplayableAttribute(com.quark.qpp.core.attribute.service.dto.Attribute attribute) {
		if (attribute.isDisplayable()) {
			long attributeId = attribute.getId();
			if (attributeId == DefaultAttributes.NAME
					|| attributeId == DefaultAttributes.COLLECTION
					|| attributeId == DefaultAttributes.CONTENT_TYPE
					|| attributeId == DefaultAttributes.STATUS
					|| attributeId == DefaultAttributes.ROUTED_TO
					|| attributeId == DefaultAttributes.COMPONENT_NAME
					|| attributeId == DefaultAttributes.REVISION_COMMENTS
					|| attributeId == DefaultAttributes.WORKFLOW) {
				return false;
			} else {
				return true;
			}
		}
		return false;
	}
}

class AttributeNameComparator implements Comparator<Attribute> {
	public int compare(Attribute attribute1, Attribute attribute2) {
		if (attribute1 != null && attribute2 != null) {
			if (attribute1.getName() != null && attribute2.getName() != null) {
				return attribute1.getName().compareToIgnoreCase(
						attribute2.getName());
			}
		}
		return -1;
	}
}

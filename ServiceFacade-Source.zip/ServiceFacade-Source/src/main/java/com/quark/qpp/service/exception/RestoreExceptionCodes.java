/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.exception;

/**
 * Defines exception codes for restore failure scenarios.
 * 
 */
public abstract class RestoreExceptionCodes {

	/**
	 * Exception code when xml file not found.
	 */
	public static final String INVALID_INDEX_XML_PATH = "INVALID_INDEX_XML_PATH";

	/**
	 * Exception code when archived asset is not found.
	 */
	public static final String ARCHIVED_ASSET_FILE_NOT_FOUND = "ARCHIVED_ASSET_FILE_NOT_FOUND";
	
	/**
	 * Exception code when archived data path is not found.
	 */
	public static final String INVALID_ARCHIVED_DATA_PATH = "INVALID_ARCHIVED_DATA_PATH";

}

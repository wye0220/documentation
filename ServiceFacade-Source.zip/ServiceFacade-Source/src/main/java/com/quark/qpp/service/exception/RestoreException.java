/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/

package com.quark.qpp.service.exception;

import com.quark.qpp.common.exceptions.QppServiceException;

/**
 * This exception is thrown if either the index xml file is not found for parsing assets to be restored. Or if a particular archived asset
 * file is not found in the archive folder.
 * 
 */
public class RestoreException extends QppServiceException {

	private static final long serialVersionUID = 1L;

	/**
	 * Parameterized constructor that creates a new RestoreException object with the given exceptionCode.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 */
	public RestoreException(String exceptionCode) {
		super(exceptionCode);
	}

	/**
	 * Parameterized constructor that creates a new RestoreException object with the given exceptionCode and additional information.
	 * 
	 * @param exceptionCode
	 *            exceptionCode that is to be set for this exception.
	 * @param additionalInfo
	 *            additionalInfo that is to be set for this exception.
	 */
	public RestoreException(String exceptionCode, String[] additionalInfo) {
		super(exceptionCode, additionalInfo);
	}
}

package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.exceptions.MinorVersionNotSupportedException;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.clipboard.dto.ClipboardChannelMapping;
import com.quark.qpp.core.clipboard.dto.ClipboardDataInfo;
import com.quark.qpp.core.clipboard.dto.ClipboardFormat;
import com.quark.qpp.core.clipboard.exceptions.ClipboardDataException;
import com.quark.qpp.core.clipboard.exceptions.ClipboardServiceExceptionCodes.ClipboardDataExceptionCodes;
import com.quark.qpp.core.clipboard.service.ClipboardService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.publishing.service.exceptions.InvalidChannelException;
import com.quark.qpp.core.publishing.service.exceptions.PublishingFailedException;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryException;
import com.quark.qpp.core.storage.service.exceptions.StorageRuleNotFoundException;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.ClipboardChannelMappingInfoList;
import com.quark.qpp.service.xmlBinding.ClipboardFormatInfoList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * Clipboard facade is used for managing clipboard data at server so that it can be accessed by a user across multiple devices. Clipboard data is maintained per user and hence, can only be accessed by the user who added the data.
 * In addition to simple get/set, clipboard data can also be converted and fetched in other formats. Clipboard data can be converted to other formats - either by adding formatted data manually or by using publishing channel for conversion.
 */
@Controller(value = "clipboardFacade")
@RequestMapping("/clipboard")
public class ClipboardFacade {

	@Autowired
	ClipboardService clipboardService;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;

	/**
	 * Adds data to the user's clipboard and returns information about it such as its dataId, timeStamp and and other information associated with the data by the user. The data should be supplied in the 
	 * form of input stream. A user can add multiple data to the clipboard. dataId is the sequence-id of the data added by a user and it is the unique identifier that can be used to retrieve the data. dataId 
	 * can be accessed by API - {@link com.quark.qpp.service.xmlBinding.ClipboardDataInfo#getDataId()}. The maximum number of clipboard data a user can add is 5. When a user adds data, older data, besides the 
	 * latest 5, gets deleted. The value for maximum number of clipboard data is configurable and can be changed by changing value of 'userClipboardSizeLimit' property in file - ClipboardServiceContext.xml
	 * 
	 * @param inputStream
	 * 				input stream of the data that is to be added to the clipboard.
	 * @param contentIdOrName
	 * 				id or name of the content type of the clipboardData. The input is assumed to an id first, but if it throws exception, we check the input for name.
	 * 				Content-types supported by server are defined in file - {@link DefaultContentTypes}.
	 * @param mimeType
	 * 				mime-type of the clipboardData.
	 * @param clipboardMeta
	 * 				map of properties to be associated with the clipboardData.
	 * 
	 * @return	ClipboardDataInfo object which encapsulates information about the data added.
	 * 
	 * @throws ClipboardDataException
	 * 				If clipboardData is null or invalid or if mimeType is invalid.
	 * @throws InvalidContentTypeException
	 * 				If contentType is invalid.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, params = "op=adddata")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfo addClipboardData(@WebInputStream InputStream inputStream,
			@RequestParam(value = "contenttype", required = true) String contentIdOrName,
			@RequestParam(value = "mimetype", required = true) String mimeType,
			@WebParameterMap HashMap<String, String> clipboardMeta) throws ClipboardDataException, InvalidContentTypeException, QppServiceException {

		filterParametersMap(clipboardMeta);
		NameValue[] dataProperties = getNameValuesFromMap(clipboardMeta);
		ClipboardDataInfo clipboardData = clipboardService.addClipboardData(inputStream, facadeUtility.getContentTypeId(contentIdOrName), mimeType, dataProperties);
		return objectTransformer.transform(clipboardData);
	}
	
	/**
	 * Returns information about the data associated with the given dataId, such as its timeStamp and other information associated with the data by the user.
	 * 
	 * @param dataId
	 * 				dataId of the data whose information is to be retrieved.
	 * 
	 * @return	ClipboardDataInfo object which encapsulates information about the data.
	 * 
	 * @throws ClipboardDataException
	 * 				If data corresponding to the given dataId does not exist.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{dataId}", params = "metadata=true")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfo getClipboardDataInfo(@PathVariable("dataId") long dataId) throws ClipboardDataException, QppServiceException {
		ClipboardDataInfo clipboardData = clipboardService.getClipboardDataInfo(dataId);
		return objectTransformer.transform(clipboardData);
	}
	
	/**
	 * Returns information about the latest data added to the user's clipboard, such as its dataId, timeStamp and other information associated with the data by the user.
	 * 
	 * @return	ClipboardDataInfo object which encapsulates information about the data.
	 * 
	 * @throws ClipboardDataException
	 * 				If no data is present in clipboard.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, params = { "metadata=true", "latest=true" } )
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfo getLatestClipboardDataInfo() throws ClipboardDataException, QppServiceException {
		ClipboardDataInfo clipboardData = clipboardService.getLatestClipboardDataInfo();
		return objectTransformer.transform(clipboardData);
	}
	
	/**
	 * Returns information about all data present in clipboard, such as their dataId, timeStamp and other information associated with the data by the user.
	 * 
	 * @return	ClipboardDataInfoList object which contains information about the data.
	 * 
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, params = "metadata=true")
	@WebReturnType("xmlView")
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfoList getAllClipboardDataInfos() throws QppServiceException {
		ClipboardDataInfo[] clipboardData = clipboardService.getAllClipboardDataInfos();
		return objectTransformer.transform(clipboardData);
	}
	
	/**
	 * Returns the data associated with the given dataId.
	 * 
	 * @param dataId
	 * 				dataId of the data to be retrieved.
	 * @param httpServletResponse
	 * 				FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values. The value of this argument is set by the QPP REST framework.
	 * @param outputStream
	 *            output stream onto which output is to be written. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of data is
	 *            required.
	 * 
	 * @throws ClipboardDataException
	 * 				If data corresponding to the given dataId does not exist.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{dataId}")
	public void getClipboardData(@PathVariable("dataId") long dataId, HttpServletResponse httpServletResponse, OutputStream outputStream,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition) throws ClipboardDataException, QppServiceException {
		if (httpServletResponse != null) {
			String mimeType = clipboardService.getClipboardDataInfo(dataId).getMimeType();
			httpServletResponse.setContentType(mimeType);
			if (contentDisposition == null) {
				contentDisposition = "inline";
			}
			httpServletResponse.setHeader("Content-Disposition", contentDisposition);
		}
		try {
			OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
			clipboardService.getClipboardData(dataId, os);
		} catch(IOException e) {
			throw new ClipboardDataException(ClipboardDataExceptionCodes.CLIPBOARD_DATA_EXCEPTION, new String[] {"IO exception."}, e);
		}
	}
	
	/**
	 * Returns the latest data added to the user's clipboard.
	 * 
	 * @param httpServletResponse
	 * 				FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values. The value of this argument is set by the QPP REST framework.
	 * @param outputStream
	 *            output stream onto which output is to be written. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of data is
	 *            required.
	 * 
	 * @throws ClipboardDataException
	 * 				If no data is present in clipboard.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public void getLatestClipboardData(HttpServletResponse httpServletResponse, OutputStream outputStream,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition) throws ClipboardDataException, QppServiceException {
		if (httpServletResponse != null) {
			String mimeType = clipboardService.getLatestClipboardDataInfo().getMimeType();
			httpServletResponse.setContentType(mimeType);
			if (contentDisposition == null) {
				contentDisposition = "inline";
			}
			httpServletResponse.setHeader("Content-Disposition", contentDisposition);
		}
		try {
			OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
			clipboardService.getLatestClipboardData(os);
		} catch(IOException e) {
			throw new ClipboardDataException(ClipboardDataExceptionCodes.CLIPBOARD_DATA_EXCEPTION, new String[] {"IO exception."}, e);
		}
	}
	
	/**
	 * Adds formatted data (i.e., data in the given format) to the clipboard. If data for given dataId and format already exists, it is over-written.
	 * 
	 * @param inputStream
	 * 				input stream of the formatted data that is to be added.
	 * @param dataId
	 * 				dataId for the data whose formatted-data is to be added.
	 * @param format
	 * 				format of the data.
	 * 
	 * @throws ClipboardDataException
	 * 				if inputStream is invalid, if dataId or format is invalid.
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{dataId}", params = "op=addformatteddata")
	public void addFormattedData(@WebInputStream InputStream inputStream,
			@PathVariable("dataId") long dataId, @RequestParam(value = "format", required = true) String format)
			throws ClipboardDataException, QppServiceException {
		clipboardService.addFormattedData(inputStream, dataId, format);
	}
	
	/**
	 * Returns the formatted-data for given format and the data associated with the given dataId, if it exists.
	 * The clipboard formatted data can be generated by executing a publishing channel. There are default publishing-channel-mappings for converting data of a given content-type to supported clipboard formats. These 
	 * publishing-channel-mappings can be accessed by the API - {@link ClipboardFacade#getAllClipboardChannelsMapping()}. 
	 * If formatted-data doesn't exist but a default channel is available for the data (based on its content-type and given format), 
	 * then the default publishing-channel is used for data conversion. The data is then converted to the desired format.
	 * After conversion, the formatted data is added to clipboard, and then returned.
	 * Publishing channel to be used for formatting the data can also be supplied in he request using parameters publishingChannelId. 
	 * 
	 * @param dataId
	 * 				dataId for the data whose formatted-data is to be retrieved.
	 * @param format
	 * 				format in which data is to be retrieved.
	 * @param publishingChannelId 
	 * 				id of the publishing channel to be used for formatting data. If provided, this channel will be used for generating the formatted data.
	 * @param parametersMap 
	 * 				map of channel parameters. Applicable only if publishingChannelId is provided.
	 * @param httpServletResponse
	 * 				FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values. The value of this argument is set by the QPP REST framework.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of formatted data is
	 *            required.
	 * 
	 * @throws ClipboardDataException
	 * 				If dataId or format is invalid. Or in case formatted data doesn't exist, and no default channel exists for the data for conversion to given format.
	 * @throws InvalidChannelException
	 * 				If given publishingChannel is invalid.
	 * @throws PublishingFailedException
	 * 				In case data is published using default channel and publishing fails.
	 * @throws QppServiceException
	 * 				Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{dataId}", params = "format")
	public void getFormattedData(@PathVariable("dataId") long dataId,
			@RequestParam(value = "format", required = true) String format,
			@RequestParam(value = "publishingchannel", required = false) String publishingChannelId,
			@WebParameterMap HashMap<String, String> parametersMap,
			HttpServletResponse httpServletResponse, OutputStream outputStream,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition)
			throws ClipboardDataException, InvalidChannelException, PublishingFailedException,
			QppServiceException {
		if (httpServletResponse != null) {
			String mimeType = clipboardService.getClipboardFormat(format).getMimeType();
	
			httpServletResponse.setContentType(mimeType);
			if (contentDisposition == null) {
				contentDisposition = "inline";
			}
			httpServletResponse.setHeader("Content-Disposition", contentDisposition);
		}
		try {
			OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
			if (publishingChannelId != null && !publishingChannelId.isEmpty()) {
				filterParametersMap(parametersMap);
				clipboardService.convertAndGetFormattedData(dataId, format, publishingChannelId, getNameValuesFromMap(parametersMap),  os);
			}
			else{
				clipboardService.getFormattedData(dataId, format, os);	
			}
		} catch (IOException e) {
			throw new ClipboardDataException( ClipboardDataExceptionCodes.CLIPBOARD_DATA_EXCEPTION, new String[] { "IO exception." }, e);
		}
	}
	
	/**
	 * Returns the formatted-data for the latest data added to clipboard in the required format, if it exists.
	 * The clipboard formatted data can be generated by executing a publishing channel. There are default publishing-channel-mappings for converting data of a given content-type to supported clipboard formats. These 
	 * publishing-channel-mappings can be accessed by the API - {@link ClipboardFacade#getAllClipboardChannelsMapping()}. 
	 * If formatted-data doesn't exist but a default channel is available for the data (based on its content-type and given format), 
	 * then the default publishing-channel is used for data conversion. The data is then converted to the desired format.
	 * After conversion, the formatted data is added to clipboard, and then returned.
	 * Publishing channel to be used for formatting the data can also be supplied in he request using parameters publishingChannelId. 
	 * 
	 * 
	 * @param format
	 * 				format in which data is to be retrieved.
	 * @param publishingChannelId 
	 * 				id of the publishing channel to be used for formatting data. If provided, this channel will be used for generating the formatted data.
	 * @param parametersMap 
	 * 				map of channel parameters. Applicable only if publishingChannelId is provided.
	 * @param httpServletResponse
	 * 				FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type and content-disposition header values. The value of this argument is set by the QPP REST framework.
	 * @param outputStream
	 *            output stream onto which output is to be written in the desired format. This parameter is applicable only for the local invocations and not for REST APIs.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in response. Set to "attachment" if downloading of formatted data is
	 *            required.
	 * 
	 * @throws ClipboardDataException
	 * 				If no data is present in clipboard or if format is invalid. Or in case formatted data doesn't exist, and no default channel exists for the data for conversion to given format.
	 * @throws InvalidChannelException
	 * 				If given publishingChannel is invalid.
	 * @throws PublishingFailedException
	 * 				In case data is published using default channel and publishing fails.
	 * @throws QppServiceException
	 * 				Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "format")
	public void getLatestFormattedData(@RequestParam(value = "format", required = true) String format,
			@RequestParam(value = "publishingchannel", required = false) String publishingChannelId,
			@WebParameterMap HashMap<String, String> parametersMap,
			HttpServletResponse httpServletResponse, OutputStream outputStream,
			@RequestParam(value = "contentdisposition", required = false) String contentDisposition) 
					throws ClipboardDataException, InvalidChannelException, PublishingFailedException, QppServiceException {
		if (httpServletResponse != null) {
			String mimeType = clipboardService.getClipboardFormat(format).getMimeType();
			httpServletResponse.setContentType(mimeType);
			if (contentDisposition == null) {
				contentDisposition = "inline";
			}
			httpServletResponse.setHeader("Content-Disposition", contentDisposition);
		}
		try {
			OutputStream os = getDesiredOutputStream(httpServletResponse, outputStream);
			if (publishingChannelId != null && !publishingChannelId.isEmpty()) {
				filterParametersMap(parametersMap);
				ClipboardDataInfo latestClipboardDataInfo = clipboardService.getLatestClipboardDataInfo();
				if (latestClipboardDataInfo != null) {
					clipboardService.convertAndGetFormattedData(latestClipboardDataInfo.getDataId(), format, publishingChannelId, getNameValuesFromMap(parametersMap),  os);
				}
			}
			else{
				clipboardService.getLatestFormattedData(format, os);
			}
		} catch(IOException e) {
			throw new ClipboardDataException(ClipboardDataExceptionCodes.CLIPBOARD_DATA_EXCEPTION, new String[] {"IO exception."}, e);
		}
	}
	
	/**
	 * Returns information about all the formats supported by clipboard for formatted-data.
	 * 
	 * @return	ClipboardFormatInfoList object which encapsulates information about a format such as its name and mime-type.
	 * 
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/formats")
	@WebReturnType("xmlView")
	public ClipboardFormatInfoList getAllClipboardFormats() throws QppServiceException {
		ClipboardFormat[] cbFormats = clipboardService.getAllClipboardFormats();
		return objectTransformer.transform(cbFormats);
	}
	
	/**
	 * Returns information about the default channels available for data-conversion to the formats supported for the given content-type.
	 * 
	 * @param contentTypeIdOrName
	 * 				id or name of the content type whose channel-mappings are to be retrieved. The input is assumed to an id first, but if it throws exception, we check the input for name.
	 * @return	ClipboardChannelMappingInfoList object which contains information about the channels available for given contentType, such as format, channelId, channel-parameters, etc.
	 * 
	 * @throws InvalidContentTypeException
	 * 				If contentType is invalid.
	 * @throws QppServiceException
	 * 				Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/channelsmapping", params = { "contenttype"} )
	@WebReturnType("xmlView")
	public ClipboardChannelMappingInfoList getClipboardChannelsMapping(@RequestParam(value = "contenttype", required = true) String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException {
		ClipboardChannelMapping[] clipboardChannelMappings = clipboardService.getClipboardChannelsMapping(facadeUtility.getContentTypeId(contentTypeIdOrName));
		return objectTransformer.transform(clipboardChannelMappings);
	}
	
	/**
	 * Returns information about all default channel-mappings available for data-conversion to the formats supported by clipboard. The information includes the channel-id and channel parameters applicable for a content-type and a format.
	 * 
	 * @return	ClipboardChannelMappingInfoList object which contains information about the channels available for a contentType and a format, such as channelId, channel-parameters, etc.
	 * 
	 * @throws QppServiceException
	 * 				Unhandled server exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/channelsmapping")
	@WebReturnType("xmlView")
	public ClipboardChannelMappingInfoList getAllClipboardChannelsMapping() throws QppServiceException {
		ClipboardChannelMapping[] clipboardChannelMappings = clipboardService.getAllClipboardChannelsMapping();
		return objectTransformer.transform(clipboardChannelMappings);
	}
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 * 				QppServiceException that is to be handled
	 * 
	 * @return QppServiceExceptionInfo object containing details of the exception thrown
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

	private NameValue[] getNameValuesFromMap(HashMap<String, String> parameterMap) {
		if(parameterMap != null) {
			List<NameValue> nameValueList = new ArrayList<NameValue>();
			for(Entry<String, String> entry : parameterMap.entrySet()) {
				NameValue nameValue = new NameValue(entry.getKey(), entry.getValue());
				nameValueList.add(nameValue);
			}
			return nameValueList.toArray(new NameValue[0]);
		}
		return null;
	}
	
	private void filterParametersMap(Map<String, String> parameterMap) {
		parameterMap.remove("loginname");
		parameterMap.remove("loginpassword");
		parameterMap.remove("view");
		parameterMap.remove("contenttype");
		parameterMap.remove("mimetype");
		parameterMap.remove("op");
		parameterMap.remove("format");
		parameterMap.remove("publishingchannel");
		parameterMap.remove("qppsessionid");
	}

	/**
	 * OutputStream of the http response and normal stream, returns the one which is not null. In local invocation Outputstream will be provided
	 * whereas in REST invocations outputstream need to be httpresponse outputstream
	 * 
	 * @param httpServletResponse
	 * @param outputStream
	 * @return
	 * @throws IOException
	 */
	private OutputStream getDesiredOutputStream(HttpServletResponse httpServletResponse, OutputStream outputStream) throws IOException {
		OutputStream os = outputStream;
		if (httpServletResponse != null && httpServletResponse.getOutputStream() != null) {
			os = httpServletResponse.getOutputStream();
		}
		return os;
	}

	/**
	 * Checks-in clipboard data for the given dataId as a Platform asset and returns the corresponding AssetInfo object.
	 *
	 * When promoting the clipboard data as an asset you can set any attribute as a part of asset metadata. However, there are
	 * certain set of attributes whose value is mandatory for the creation of a new asset. Asset cannot be created without
	 * specifying values for such attributes. All such attributes can be fetched at runtime by following:
	 * <ol>
	 * <li>Calling API {@link com.quark.qpp.core.attribute.service.local.AttributeService#getApplicableAttributes(long)}
	 * and supplying the content type Id as parameter would return array of Attribute objects.</li>
	 * <li>Attribute objects array returned in step 1 can be further filtered to have attributes whose
	 * {@link Attribute#getModificationLevel()} is either {@link AttributeModificationLevels#CLIENT_MODIFIABLE} or
	 * {@link AttributeModificationLevels#USER_MODIFIABLE} and whose value mandatory flag,
	 * {@link ContentTypeAttributeMapping#isValueMandatory()} is true.</li></ol>
	 * 
	 * @param dataId
	 *            Id of the clipboard data which is to be promoted to an asset.
	 * @param attributeValueList
	 *            List of attribute values to be set for the new asset.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in asset as a new minor version or as a new major version.
	 *                       
	 * @return AssetInfo object containing metadata of the new checked in asset.
	 * 
	 * @throws ClipboardDataException
	 * 			   If data corresponding to the given dataId does not exist.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of the attribute values in terms of validity, mandatory, wrong value, etc.
	 *             The specific reason for the exception can be found by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> tells you the id of the attribute responsible for the exception.
	 * @throws StorageRuleNotFoundException
	 *             If the storage rule is not defined for the given content type.
	 * @throws InvalidRepositoryException
	 *             If the repository in which this asset is to be stored is currently either unavailable or not writable.
	 * @throws MinorVersionNotSupportedException
	 *             If trying to create asset's minor version when it is not allowed in the revision control settings of
	 *             the collection(in which the asset is being checked-in) for the given content type.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	
	@RequestMapping(method = RequestMethod.POST, value = "/{dataId}", params = "op=promotetoasset")
	@WebReturnType("xmlView")
	public AssetInfo promoteClipboardDataToAsset(@PathVariable("dataId") long dataId,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion)
			throws ClipboardDataException, InvalidAttributeValueException, StorageRuleNotFoundException,
			InvalidRepositoryException, MinorVersionNotSupportedException, StreamingException, QppServiceException {
		
		AttributeValue[] attributeValues = objectTransformer.transform(attributeValueList);
		Asset asset = clipboardService.promoteClipboardDataToAsset(dataId, attributeValues, createMinorVersion);
		return objectTransformer.transform(asset);
	}
	
}

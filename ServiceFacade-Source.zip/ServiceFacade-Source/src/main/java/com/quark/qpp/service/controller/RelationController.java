/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.relation.service.dto.RelationType;
import com.quark.qpp.core.relation.service.dto.RelationTypeAttributeMapping;
import com.quark.qpp.core.relation.service.exceptions.InvalidRelationTypeException;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeInUseException;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.relation.service.local.RelationService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.RelationTypeInfo;
import com.quark.qpp.service.xmlBinding.RelationTypeInfoList;

public class RelationController {

	@Autowired
	private RelationService relationService;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	private final Logger logger = Logger.getLogger(this.getClass());

	public RelationTypeInfoList getAllRelationTypes() throws QppServiceException {
		RelationType[] relationTypes = relationService.getAllRelationTypes();
		return objectTransformer.transform(relationTypes);
	}
	
	public RelationTypeInfoList getRelationType(String relationType) throws RelationTypeNotFoundException, QppServiceException{
		long relationTypeId = facadeUtility.getRelationTypeId(relationType);
		RelationType relType = relationService.getRelationType(relationTypeId);
		RelationTypeInfo relationTypeInfo = objectTransformer.transform(relType);
		RelationTypeInfoList relationTypeInfoList = new RelationTypeInfoList();
		relationTypeInfoList.getRelationTypeInfo().add(relationTypeInfo);
		return relationTypeInfoList;
	}

	public RelationTypeInfoList createRelationTypes(RelationTypeInfoList relationTypeInfoList)
			throws InvalidRelationTypeException, AttributeNotFoundException, QppServiceException {
		RelationTypeInfoList newRelationTypeInfoList = new RelationTypeInfoList();
		if (relationTypeInfoList != null) {
			List<RelationTypeInfo> list = relationTypeInfoList.getRelationTypeInfo();
			Iterator<RelationTypeInfo> it = list.iterator();
			while (it.hasNext()) {
				RelationTypeInfo relationInfo = it.next();
				try {
					RelationTypeInfo newRelationTypeInfo = createRelationType(relationInfo);
					if (newRelationTypeInfo != null) {
						newRelationTypeInfoList.getRelationTypeInfo().add(newRelationTypeInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while creating relation type with name " + relationInfo.getName(), e);
					if (relationTypeInfoList.getRelationTypeInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidRelationTypeException();
		}
		return newRelationTypeInfoList;
	}

	private RelationTypeInfo createRelationType(RelationTypeInfo relationTypeInfo) throws InvalidRelationTypeException, AttributeNotFoundException, QppServiceException {
		
		RelationTypeAttributeMapping[] relationTypeAttributeMappings = objectTransformer.transform(relationTypeInfo.getRelationAttributeList());
		long newRelationTypeId = relationService.createRelationType(relationTypeInfo.getName(), relationTypeInfo.isCheckOutMandatory(),
				relationTypeAttributeMappings);

		RelationType newRelationType = relationService.getRelationType(newRelationTypeId);
		return objectTransformer.transform(newRelationType);
	}

	public RelationTypeInfoList updateRelationTypes(RelationTypeInfoList relationTypeInfoList)
			throws RelationTypeNotFoundException, InvalidRelationTypeException, AttributeNotFoundException, QppServiceException {
		RelationTypeInfoList updateRelationTypeInfoList = new RelationTypeInfoList();
		if (relationTypeInfoList != null) {
			List<RelationTypeInfo> list = relationTypeInfoList.getRelationTypeInfo();
			Iterator<RelationTypeInfo> it = list.iterator();
			while (it.hasNext()) {
				RelationTypeInfo relationInfo = it.next();
				try {
					RelationTypeInfo updatedRelationTypeInfo = updateRelationType(relationInfo);
					if (updatedRelationTypeInfo != null) {
						updateRelationTypeInfoList.getRelationTypeInfo().add(updatedRelationTypeInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while updating relation type with name " + relationInfo.getName(), e);
					if (relationTypeInfoList.getRelationTypeInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new InvalidRelationTypeException();
		}
		return updateRelationTypeInfoList;
	}

	private RelationTypeInfo updateRelationType(RelationTypeInfo relationTypeInfo) throws RelationTypeNotFoundException,
			InvalidRelationTypeException, AttributeNotFoundException, QppServiceException {
		long relationTypeId = -1;
		if (relationTypeInfo.getId() == null || relationTypeInfo.getId() == 0) {
			relationTypeId = facadeUtility.getRelationTypeByName(relationTypeInfo.getName());
		} else {
			relationTypeId = relationTypeInfo.getId();
		}
		
		if (relationTypeInfo.getName() != null) {
			relationService.renameRelationType(relationTypeId, relationTypeInfo.getName());
		}

		if(relationTypeInfo.getRelationAttributeList()!=null){
			/** update attributes */
			RelationTypeAttributeMapping[] relationTypeAttributeMapping = objectTransformer.transform(relationTypeInfo
					.getRelationAttributeList());
			relationService.setRelationTypeAttributes(relationTypeId, relationTypeAttributeMapping);
		}
		
		RelationType updatedRelationType = relationService.getRelationType(relationTypeId);
		return objectTransformer.transform(updatedRelationType);
	}

	public void deleteRelationType(String relationType) throws RelationTypeNotFoundException, RelationTypeInUseException,
			InvalidRelationTypeException, QppServiceException {
		long relationTypeId = facadeUtility.getRelationTypeId(relationType);
		relationService.deleteRelationType(relationTypeId);
	}
}

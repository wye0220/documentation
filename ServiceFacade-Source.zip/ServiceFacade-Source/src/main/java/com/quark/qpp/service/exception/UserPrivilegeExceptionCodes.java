/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.exception;


/**
 * Defines exception code for scenarios where user doesn't have a specific privilege.
 */
public abstract class UserPrivilegeExceptionCodes {

	public static final String USER_DOES_NOT_HAVE_THE_PRIVILEGE = "USER_DOES_NOT_HAVE_THE_PRIVILEGE";

}

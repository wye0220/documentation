/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.content.service.dto.ContentTypeInfo;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.publishing.service.constants.ChannelTypes;
import com.quark.qpp.core.publishing.service.dto.PublishingChannel;
import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.exceptions.InvalidChannelException;
import com.quark.qpp.core.publishing.service.exceptions.InvalidPublishingContextException;
import com.quark.qpp.core.publishing.service.exceptions.PublishingFailedException;
import com.quark.qpp.core.publishing.service.exceptions.PublishingServiceExceptionCodes;
import com.quark.qpp.core.publishing.service.local.PublishingService;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebInputStream;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.rest.framework.annotations.WebSerializedParam;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.AssetInfo;
import com.quark.qpp.service.xmlBinding.AssetInfoList;
import com.quark.qpp.service.xmlBinding.AttributeValueList;
import com.quark.qpp.service.xmlBinding.PublishingChannelList;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

@Controller("publishFacade")
@RequestMapping("/publish")
public class PublishFacade {
	
	@Autowired
	private PublishingService publishingService;
	
	@Autowired
	private AssetService assetService;
	
	@Autowired
	private StreamingService publishingStreamingService;
	
	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private PrivilegeValidator privilegeValidator;
	
	/**
	 * Publishes an asset using a publishing channel. To deliver an asset using a delivery channel, specify delivery channel id.
	 * To both publish and then deliver the publishing channel output, specify both publishing and delivery channel id.
	 * Specify channel parameters for both publishing and delivery channels in parametersMap.
	 * 
	 * @param assetId
	 *            Id of the asset to be published.
	 * @param majorVersion
	 * 				majorVersion of the asset to be published.
	 * @param minorVersion
	 * 				minorVersion of the asset to be published.If major and minor version, both are not supplied, then the latest version of the asset will be published.           
	 * @param outputStream
	 *            Specify an outputStream to pipe the publishing channel output into. The published content is streamed into the specified outputStream IF no delivery channel is specified.
	 * @param publishingChannelId
	 *            id of the publishing channel or null if asset is to be processed by delivery channel only.
	 * @param deliveryChannelId
	 *            Id of the delivery channel or null if published output is required to be streamed back.
	 * @param parametersMap
	 *            Map containing publishing parameters.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type header value.
	 *            The value of this argument is set by the QPP REST framework.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             This exception is thrown whenever in/out streaming fails.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{assetId}")
	public void publishAsset(@PathVariable("assetId") long assetId, @RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, @WebOutputStream OutputStream outputStream, @RequestParam(value = "publishingchannel", required = false) String publishingChannelId, 
			@RequestParam(value = "deliverychannel", required = false) String deliveryChannelId, @WebParameterMap Map<String, String> parametersMap, HttpServletResponse httpServletResponse) throws QppServiceException, StreamingException{
		
		if(publishingChannelId != null && !publishingChannelId.isEmpty()){
			
			long contentTypeId = ((ContentTypeInfo) assetService.getAttributeValues(assetId, new long[]{DefaultAttributes.CONTENT_TYPE})[0].getAttributeValue()).getId();
			
			validatePublishingPrivileges(assetId, contentTypeId, publishingChannelId);
		}
		
		AssetVersion assetVersion = getAssetVersion(majorVersion, minorVersion);

		if(publishingChannelId != null && !publishingChannelId.isEmpty() && (deliveryChannelId == null || deliveryChannelId.isEmpty())){
			
			PublishingParameter[] publishingChannelParameters = getChannelParametersByChannelType(publishingChannelId, parametersMap, ChannelTypes.PUBLISH);
			
			long publishingContextId = 0;
			
			if (assetVersion != null) 
				publishingContextId = publishingService.publishAssetVersion(assetId, assetVersion, publishingChannelId, publishingChannelParameters);
			else 
				publishingContextId = publishingService.publishAsset(assetId, publishingChannelId, publishingChannelParameters);

			setContentHttpHeaders(httpServletResponse, publishingContextId);

			try {
				publishingStreamingService.download(outputStream, publishingContextId);
			} finally {
				publishingService.closeContext(publishingContextId);
			}
		}else if(deliveryChannelId != null && !deliveryChannelId.isEmpty() && (publishingChannelId == null || publishingChannelId.isEmpty())){
			
			PublishingParameter[] deliveryChannelParameters = getChannelParametersByChannelType(deliveryChannelId, parametersMap, ChannelTypes.DELIVER);
			
			if (assetVersion != null)
				publishingService.deliverAssetVersion(assetId, assetVersion, deliveryChannelId, deliveryChannelParameters);
			else
				publishingService.deliverAsset(assetId, deliveryChannelId, deliveryChannelParameters);
			
		}else if(publishingChannelId != null && !publishingChannelId.isEmpty() && deliveryChannelId != null && !deliveryChannelId.isEmpty()){
			
			//filter out publishing channel parameters from all the parameters
			PublishingParameter[] publishingChannelParameters = getChannelParametersByChannelType(publishingChannelId, parametersMap, ChannelTypes.PUBLISH);
			
			//filter out delivery channel parameters from all the parameters
			PublishingParameter[] deliveryChannelParameters = getChannelParametersByChannelType(deliveryChannelId, parametersMap, ChannelTypes.DELIVER);
			
			if (assetVersion != null)
				//publish and deliver the asset.
				publishingService.publishAndDeliverAssetVersion(assetId, assetVersion, publishingChannelId, publishingChannelParameters, deliveryChannelId, deliveryChannelParameters);
			else
				publishingService.publishAndDeliver(assetId, publishingChannelId, publishingChannelParameters, deliveryChannelId, deliveryChannelParameters);
		}
	}
	
	private AssetVersion getAssetVersion(Long majorVersion, Long minorVersion) {
		if (majorVersion == null) {
			majorVersion = (long) 0;
		}
		if (minorVersion == null) {
			minorVersion = (long) 0;
		}
		AssetVersion assetVersion = null;
		if (majorVersion > 0 || minorVersion > 0) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}
		return assetVersion;
	}

	private void validatePublishingPrivileges(long assetId, long contentType, String publishingChannelId) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		
		//Bug #263189 - Check if the channel is mapped to the given content type else throw exception. 
		PublishingChannel[] publishingChannels = publishingService.getPublishingChannels(contentType);
		boolean contentChannelMappingExists = false;
		for (int i = 0; i < publishingChannels.length; i++) {
			if(publishingChannels[i].getId().equals(publishingChannelId)){
				contentChannelMappingExists = true;
				break;
			}
		}
		
		if (!contentChannelMappingExists) {
			PublishingChannel[] allPubChannels = publishingService.getAllPublishingChannels();
			boolean isValidChannel = false;
			for (int i = 0; allPubChannels != null && i < allPubChannels.length; i++) {
				if (allPubChannels[i].getId().equals(publishingChannelId)) {
					isValidChannel = true;
					break;
				}
			}
			if (!isValidChannel) {
				throw new InvalidChannelException(PublishingServiceExceptionCodes.InvalidChannelExceptionCodes.INVALID_PUBLISHING_CHANNEL);
			} else {
				throw new InvalidChannelException(PublishingServiceExceptionCodes.InvalidChannelExceptionCodes.CHANNEL_NOT_MAPPED_TO_CONTENT_TYPE);
			}
		}
		
		ContentTypeInfo contentTypeInfo = new ContentTypeInfo();
		contentTypeInfo.setId(contentType);
		
		AttributeValue contentAttributeValue = new AttributeValue(DefaultAttributes.CONTENT_TYPE, contentTypeInfo , AttributeValueTypes.DOMAIN);
		AttributeValue[] attributeValues = new AttributeValue[]{contentAttributeValue};
		
		privilegeValidator.validateContentTypePrivileges(assetId, attributeValues, publishingChannelId);
	}

	/**
	 * Publish or deliver a non QPP Resource. In order to publish a non QPP Resource, specify valid publishing channel Id and publishing parameters and delivery channel id as null.
	 * To deliver a resource, specify valid delivery channel id, delivery channel parameters and publishingChannelId as null. 
	 * @param inputStream
	 * 			InputStream of the resource to be published or delivered. 
	 * @param outputStream
	 * 			OutputStream onto which the publishing channel output is to be written.
	 * @param publishingChannelId
	 * 			id of the publishing channel.
	 * @param deliveryChannelId
	 * 			id of the delivery channel.
	 * @param parametersMap
	 * 			map of publishing / delivery channel parameters
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type header value.
	 *            The value of this argument is set by the QPP REST framework.
	 * @throws StreamingException
	 * 			This exception is thrown whenever in/out streaming fails.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 * @throws IOException 
	 * 			In case of failed or interrupted I/O operations.

	 */
	@RequestMapping(method = RequestMethod.POST)
	public void publishBasedOnStreamContext(@WebInputStream InputStream inputStream, @WebOutputStream OutputStream outputStream,
			@RequestParam(value = "publishingchannel", required = false) String publishingChannelId,
			@RequestParam(value = "deliverychannel", required = false) String deliveryChannelId,
			@WebParameterMap Map<String, String> parametersMap, HttpServletResponse httpServletResponse) throws QppServiceException, StreamingException, IOException {

		//create publishing context for non QPP Resource
		long publishingContextId = publishingService.createPublishingStreamingContext();
		
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		
		ByteArrayInputStream byteArrayInputStream = null;
		
		try {
		
			pipe(inputStream, byteArrayOutputStream);
		
			byte[] fileBytes = byteArrayOutputStream.toByteArray();
		
			byteArrayInputStream = new ByteArrayInputStream(fileBytes);
		
		
			//upload the resource into QPP Server
			publishingStreamingService.upload(byteArrayInputStream , publishingContextId);

			if (publishingChannelId != null && !publishingChannelId.isEmpty()) {

				PublishingParameter[] publishingParameters = getChannelParametersByChannelType(publishingChannelId, parametersMap, ChannelTypes.PUBLISH);
				
				//Publish the file, associated with a context id
				publishingService.publishBasedOnStreamContext(publishingContextId, publishingChannelId, publishingParameters);

				setContentHttpHeaders(httpServletResponse, publishingContextId);

				//Write requested resource, whose contextId is given, at given output stream.
				publishingStreamingService.download(outputStream, publishingContextId);

			} else if (deliveryChannelId != null && !deliveryChannelId.isEmpty()) {
				
				PublishingParameter[] deliveryChannelParameters = getChannelParametersByChannelType(deliveryChannelId, parametersMap, ChannelTypes.DELIVER);
				
				//Deliver the file, associated with a context id
				publishingService.deliverBasedOnStreamContext(publishingContextId, deliveryChannelId, deliveryChannelParameters);
			}
			
		} finally{
			if(byteArrayInputStream != null){
				byteArrayInputStream.close();
			}
			byteArrayOutputStream.close();
			try{
				publishingService.closeContext(publishingContextId);
			}
			catch(InvalidPublishingContextException ipe){
				//It means the context was automatically closed by the service in case of failure.
			}
		}
	}
	
	/**
	 * Publishes a resource referred by URI using a publishing channel. To deliver an asset using a delivery channel, specify delivery channel id.
	 * To both publish and then deliver the publishing channel output, specify both publishing and delivery channel id.
	 * Specify channel parameters for both publishing and delivery channels in parametersMap.
	 * 
	 * @param outputStream
	 * 			Specify an outputStream to pipe the publishing channel output into. The published content is streamed into the specified outputStream IF no delivery channel is specified.
	 * @param uri
	 * 			URI of the resource to be published.
	 * @param publishingChannelId
	 * 			Id of the publishing channel or null in case the resource is only to be delivered using given delivery channel. 
	 * @param deliveryChannelId
	 * 			Id of the delivery channel or null in case the resource is only to be published using publishing channel.
	 * @param parametersMap
	 * 			Map containing publishing & delivery parameters. 
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type header value.
	 *            The value of this argument is set by the QPP REST framework.
	 * @throws AssetNotFoundException
	 * 			In case of QPP URI, if the asset does not exist. 
	 * @throws InvalidChannelException
	 * 			If either the publishing channel id or delivery channel id is invalid. 
	 * @throws PublishingFailedException
	 * 			In case the resource publishing fails.
	 * @throws StreamingException
	 * 			In case streaming of the published content fails.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET)
	public void publishBasedOnURI(@WebOutputStream OutputStream outputStream, @RequestParam(value="uri", required = false) String uri,
			@RequestParam(value = "publishingchannel", required = false) String publishingChannelId,
			@RequestParam(value = "deliverychannel", required = false) String deliveryChannelId,
			@WebParameterMap Map<String, String> parametersMap, HttpServletResponse httpServletResponse) throws AssetNotFoundException, InvalidChannelException,
			PublishingFailedException, StreamingException, QppServiceException{
		
		if(publishingChannelId != null && !publishingChannelId.isEmpty()){
			PublishingParameter[] parametersForPublishing = getChannelParametersByChannelType(publishingChannelId, parametersMap, ChannelTypes.PUBLISH);
			long contentTypeId = -1;
			
			uri = uri.trim();
			
			if(uri.startsWith("qpp://assets/")){
				
				long assetId = getAssetId(uri);
				
				contentTypeId = ((ContentTypeInfo) assetService.getAttributeValues(assetId, new long[]{DefaultAttributes.CONTENT_TYPE})[0].getAttributeValue()).getId();
				
				validatePublishingPrivileges(assetId, contentTypeId, publishingChannelId);
			}
			if(deliveryChannelId != null && !deliveryChannelId.isEmpty()){
				PublishingParameter[] parametersForDelivery = getChannelParametersByChannelType(deliveryChannelId, parametersMap, ChannelTypes.DELIVER);
				publishingService.publishAndDeliverBasedOnURI(uri, publishingChannelId, parametersForPublishing, deliveryChannelId, parametersForDelivery);
			}else{
				
				long publishingContextId = publishingService.publishBasedOnURI(uri, publishingChannelId, parametersForPublishing);
				setContentHttpHeaders(httpServletResponse, publishingContextId);
				try {
					publishingStreamingService.download(outputStream, publishingContextId);
				} finally {
					publishingService.closeContext(publishingContextId);
				}
			}
		}else if(deliveryChannelId != null && !deliveryChannelId.isEmpty()){
			PublishingParameter[] parametersForDelivery = getChannelParametersByChannelType(deliveryChannelId, parametersMap, ChannelTypes.DELIVER);
			publishingService.deliverBasedOnURI(uri, deliveryChannelId, parametersForDelivery);
		}
	}
	
	private long getAssetId(String uri) {
		String qppSchema = new String("qpp://assets/");
		String assetInfo = uri.replaceFirst(qppSchema, "");
		String assetIdStr = assetInfo.substring(0, assetInfo.split("\\?")[0].length());
		return Long.parseLong(assetIdStr);
	}
	

	private void pipe(InputStream is, OutputStream os) throws IOException {
		try {
			byte[] buffer = new byte[64 * 1024];
			int count = is.read(buffer);
			while (count > 0) {
				os.write(buffer, 0, count);
				count = is.read(buffer);
			}
			os.flush();
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Get details of publishing channels which may be used for delivery.
	 * @return list of all publishing channels that can be used for delivery.
	 * @throws QppServiceException
	 * 			 Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/deliverychannels")
	@WebReturnType("xmlView")
	public PublishingChannelList getAllDeliveryChannels() throws QppServiceException{
		PublishingChannel[] publishingChannels = publishingService.getAllDeliveryChannels();
		return objectTransformer.transform(publishingChannels);
	}
	
	
	/**
	 * Get details of channels which are available for delivery of a particular content type. 
	 * @param contentTypeIdOrName
	 * 			Id or name of the content type. The input is assumed to be an id first, if an exception, the input is checked for name.
	 * @return list of all delivery channels available for given content type.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/deliverychannels/{contentTypeIdOrName}")
	@WebReturnType("xmlView")
	public PublishingChannelList getDeliveryChannels(@PathVariable String contentTypeIdOrName) throws QppServiceException{
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrName);
		PublishingChannel[] publishingChannels = publishingService.getDeliveryChannels(contentTypeId);
		return objectTransformer.transform(publishingChannels);
	}

	
	/**
	 * Get details of all channels which are available for assets publishing. 
	 * @return list of all publishing channels
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels")
	@WebReturnType("xmlView")
	public PublishingChannelList getAllPublishingChannels() throws QppServiceException{
		PublishingChannel[] allPublishingChannels = publishingService.getAllPublishingChannels();
		return objectTransformer.transform(allPublishingChannels);
	}
	
	/**
	 * Get details of channels which are available for assets publishing of a particular content type. 
	 * @param contentTypeIdOrName
	 * 			Id or name of the content type. The input is assumed to be an id first, if an exception, the input is checked for name.
	 * @return list of all publishing channels available for given content type.
	 * @throws QppServiceException
	 * 			Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/publishingchannels/{contentTypeIdOrName}")
	@WebReturnType("xmlView")
	public PublishingChannelList getPublishingChannels(@PathVariable String contentTypeIdOrName) throws QppServiceException{
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrName);
		PublishingChannel[] publishingChannels = publishingService.getPublishingChannels(contentTypeId);
		return objectTransformer.transform(publishingChannels);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 * 
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
	
	/**
	 * Returns array of channels of type {@link ChannelTypes#DATADOC}
	 * 
	 * @return list of all datadoc channels.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/datadocchannels")
	@WebReturnType("xmlView")
	public PublishingChannelList getDatadocChannels() throws QppServiceException{
		PublishingChannel[] datadocChannels = publishingService.getAllDatadocChannels();
		return objectTransformer.transform(datadocChannels);
	}

	/**
	 * Returns channels of type {@link ChannelTypes#DATADOC} which are mapped to the given content type.
	 * @param contentTypeIdOrName name or id of the content type whose datadocs channels are required
	 * @return  list of all datadoc channels mapped to the given content type.
	 * @throws InvalidContentTypeException
	 *  		If the content type with the given Id does not exist.
	 * @throws QppServiceException
	 *    Unhandled server exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/datadocchannels/{contentTypeIdOrName}")
	@WebReturnType("xmlView")
	public PublishingChannelList getDatdocChannels(@PathVariable String contentTypeIdOrName) throws InvalidContentTypeException, QppServiceException{
		long contentTypeId = facadeUtility.getContentTypeId(contentTypeIdOrName);
		PublishingChannel[] publishingChannels = publishingService.getDatadocChannels(contentTypeId);
		return objectTransformer.transform(publishingChannels);
	}
	
	/**
	 * Creates a datadoc by executing the given datadoc channel and checks it in to the platform with the given metadata.
	 * 
	 * @param datadocChannelId  Id of the channel to be used for generation of the datadoc.
	 * @param parametersMap Map containing datadoc channel parameters. 
	 * @param attributeValueList  List of attribute values to be set for the datadoc asset.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in the datadoc asset as a new minor version or as a new major version.
	 * @return Metadata of the generated datadoc asset.
	 * @throws InvalidChannelException
	 *             If given publishingChannel is invalid.
	 * @throws PublishingFailedException
	 *             If any exception occurs during execution of the given channel
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws  StreamingException Streaming exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=createdatadoc")
	@WebReturnType("xmlView")
	public AssetInfo createDatadoc(@RequestParam(value = "datadocchannel", required = true) String datadocChannelId, @WebParameterMap Map<String, String> parametersMap,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws InvalidChannelException, PublishingFailedException, InvalidAttributeValueException, QppServiceException, StreamingException {

		Asset asset = publishingService.createDatadoc(datadocChannelId, getChannelParametersByChannelType(datadocChannelId, parametersMap, ChannelTypes.DATADOC), objectTransformer.transform(attributeValueList), createMinorVersion);
		
		AssetInfo assetInfo = objectTransformer.transform(asset);
		
		return assetInfo;
	}
	
	/**
	 * Updates the existing datadoc asset by creating its new version. Latest content of the asset is fetched by executing the desired
	 * datadoc channel. The datadoc channel to be used is defined in the attribute {@link DefaultAttributes#DATADOC_CHANNEL_ID} of the
	 * asset. <br/>
	 * This asset needs to be a datadoc asset. Whether the asset is datadoc asset or not - is determined by the attribute
	 * {@link DefaultAttributes#IS_DATADOC} of the asset.
	 * 
	 * @param assetId  Id of the datadoc asset to be updated.
	 * @param attributeValueList 
	 *            List of attribute values to be used as metadata of the datadoc asset while checking-in to the Platform.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in the datadoc asset as a new minor version or as a new major version.
	 * @return Metadata of the datadoc updated asset whose version is created.
	 * @throws InvalidAssetException
	 *             If the given asset is not the datadoc asset. The datadoc asset is determined by the attribute
	 *             {@link DefaultAttributes#IS_DATADOC} of the asset.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException Streaming exception.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{assetId}", params = "op=updatedatadoc")
	@WebReturnType("xmlView")
	public AssetInfo updateDatadoc(@PathVariable("assetId") long assetId, 
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList, @RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws InvalidAssetException, InvalidAttributeValueException, QppServiceException, StreamingException {

		Asset asset = publishingService.updateDatadoc(assetId, objectTransformer.transform(attributeValueList), createMinorVersion);
		
		return objectTransformer.transform(asset);

	}
	
	
	/**
	 * Returns metadata of the datadoc assets which had been created by executing the given channel and parameters.
	 * 
	 * @param datadocChannelId
	 *            Id of the channel to be used for generation of the datadoc.
	 * @param parametersMap
	 *            Map containing datadoc channel parameters.
	 * @return Metadata of the datadoc assets which had been created by executing the given channel and parameters.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             Streaming exception.
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=fetchdatadocassets")
	@WebReturnType("xmlView")
	public AssetInfoList fetchDatadocAssets(@RequestParam(value = "datadocchannel", required = true) String datadocChannelId, @WebParameterMap Map<String, String> parametersMap) throws QppServiceException, StreamingException {

		Asset[] assets = publishingService.getDatadocAssets(datadocChannelId, getChannelParametersByChannelType(datadocChannelId, parametersMap, ChannelTypes.DATADOC));
		
		ArrayList<AssetInfo> assetInfos = new ArrayList<AssetInfo>();
		for (int i = 0; assets != null && i < assets.length; i++) {
			assetInfos.add(objectTransformer.transform(assets[i]));
		}
		AssetInfoList assetInfoList = new AssetInfoList();
		assetInfoList.getAssetInfo().addAll(assetInfos);
		return assetInfoList;
		 
	}
	
	/**
	 * Executes the given datadoc channel and writes the resulted datadoc content to the given outputstream.
	 * <br/>
	 * 
	 * @param outputStream Specify an outputStream to pipe the datadoc channel output into. The datadoc content is streamed into the specified outputStream.
	 * @param datadocChannelId
	 *            Id of the channel to be used for generation of the datadoc.
	 * @param parametersMap
	 *            Map containing datadoc channel parameters.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used to set content type header value.
	 *            The value of this argument is set by the QPP REST framework.
	 * @throws InvalidChannelException
	 *             If the datadocChannelId is invalid.
	 * @throws PublishingFailedException
	 *             If any error occurs while executing the given datadoc channel.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case streaming of the datadoc content fails..
	 */
	@RequestMapping(method = RequestMethod.GET, params = "op=executedatadocchannel")
	public void executeDatadocChannel(@WebOutputStream OutputStream outputStream,
			@RequestParam(value = "datadocchannel", required = true) String datadocChannelId,
			@WebParameterMap Map<String, String> parametersMap, HttpServletResponse httpServletResponse) throws InvalidChannelException, PublishingFailedException,
			QppServiceException, StreamingException {
		PublishingParameter[] channelParameters = getChannelParametersByChannelType(datadocChannelId, parametersMap, ChannelTypes.DATADOC);
		if (datadocChannelId != null && !datadocChannelId.isEmpty()) {
			long publishingContextId = publishingService.executeDatadocChannel(datadocChannelId, channelParameters);
			setContentHttpHeaders(httpServletResponse, publishingContextId);
			try {
				publishingStreamingService.download(outputStream, publishingContextId);
			} finally {
				publishingService.closeContext(publishingContextId);
			}
		}
	}
	
	/**
	 * Detach or unlinks the given datadoc asset from its source content and creates a new version of the asset. After detaching/unlinking,
	 * the given asset will no more be a datadoc asset and thus can be checked-out and checked-in by the end user like other
	 * conventional assets in the Platform.
	 * 
	 * @param assetId
	 *            Id of the datadoc asset to be detached from the source content.
	 * @param attributeValueList
	 *            List of attribute values to be used as metadata of the datadoc asset while checking-in to the Platform.
	 * @param createMinorVersion
	 *            boolean flag specifying whether to check in the datadoc asset as a new minor version or as a new major version.
	 * @return Metadata of the datadoc updated asset whose version is created.
	 * @throws InvalidAssetException
	 *             If the given asset is not the datadoc asset. The datadoc asset is determined by the attribute
	 *             {@link DefaultAttributes#IS_DATADOC} of the asset.
	 * @throws AssetNotFoundException
	 *             If the asset with the given id does not exist.
	 * @throws InvalidAttributeValueException
	 *             If there is any discrepancy in any of attribute values in terms of validity, mandatory, wrong value, etc. The specific
	 *             reason for the exception can be determined by calling <code>getExceptionCode()</code> of the exception.
	 *             <code>getAdditionalInfo()</code> of the exception contains the id of the attribute for which the exception was thrown.
	 * @throws QppServiceException
	 *             Unhandled server exception.
	 * @throws StreamingException
	 *             In case streaming of the content fails while creating a new version.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{assetId}", params = "op=detachdatadoc")
	@WebReturnType("xmlView")
	public AssetInfo detachDatadocFromSource(@PathVariable("assetId") long assetId,
			@WebSerializedParam("attributevalues") AttributeValueList attributeValueList,
			@RequestParam(value = "createminorversion", defaultValue = "false") boolean createMinorVersion) throws AssetNotFoundException,
			InvalidAssetException, InvalidAttributeValueException, QppServiceException, StreamingException {

		Asset asset = publishingService.detachDatadocFromSource(assetId, objectTransformer.transform(attributeValueList),
				createMinorVersion);

		return objectTransformer.transform(asset);
	}
	
	/**
	 * Filters and returns those channel parameters from given map, that hold valid for given channel Id and channelType.
	 *  
	 * @param channelId
	 * @param parametersMap
	 * @param channelType
	 * @return
	 * @throws QppServiceException
	 */
	private PublishingParameter[] getChannelParametersByChannelType(String channelId, Map<String, String> parametersMap, String channelType) throws QppServiceException {
		ArrayList<PublishingParameter> publishingParametersList = new ArrayList<PublishingParameter>();
		PublishingChannel[] allChannels = null;
		if (channelType != null && !channelType.isEmpty()) {
			if (ChannelTypes.DATADOC.equals(channelType)) {
				allChannels = publishingService.getAllDatadocChannels();
			} else if (ChannelTypes.PUBLISH.equals(channelType)) {
				allChannels = publishingService.getAllPublishingChannels();
			} else if (ChannelTypes.DELIVER.equals(channelType)) {
				allChannels = publishingService.getAllDeliveryChannels();
			}
			if (allChannels != null) {
				for (int i = 0; i < allChannels.length; i++) {
					if (allChannels[i].getId().equals(channelId)) {
						PublishingParameter[] channelParameters = allChannels[i].getChannelParameters();
						for (int j = 0; j < channelParameters.length; j++) {
							String parameterValue = parametersMap.get(channelParameters[j].getName());
							if (parameterValue != null) {
								PublishingParameter publishingParameter = new PublishingParameter(channelParameters[j].getName(), parameterValue);
								publishingParametersList.add(publishingParameter);
							}
						}
						break;
					}
				}
			}
		}
		return publishingParametersList.toArray(new PublishingParameter[0]);
	}
	
	private void setContentHttpHeaders(HttpServletResponse httpServletResponse, long contextId) throws StreamingException {
		if (httpServletResponse == null) {
			return;
		}
		Map<String, String> publishedResourceAttributesMap = publishingStreamingService.getDownloadContentProperties(contextId);
		if(publishedResourceAttributesMap != null) {
			String mimeType = publishedResourceAttributesMap.get("mime-type");
			httpServletResponse.setContentType(mimeType);
		}
	}
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.quark.qpp.app.local.RuntimeConfigurationService;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.rest.framework.annotations.WebOutputStream;

/**
 * A facade to zip (compress / archive) the QPP Server log files into the given output stream.
 * 
 */
@Controller("logsFacade")
@RequestMapping("/logs")
public class LogsFacade {

	private final int SIZE = 2048;

	private Logger logger = Logger.getLogger(this.getClass());
	
	
	@Autowired
	private RuntimeConfigurationService runtimeConfigurationService;

	/**
	 * Writes the compressed / archived QPP Server log files into the given output stream.
	 * 
	 * @param outputStream
	 *            An output stream in which requested (compressed/archived) QPP Server log files content will be
	 *            written.
	 * @throws IOException
	 *             In case of failed or interrupted I/O operations.
	 * @throws QppServiceException 
	 */
	@RequestMapping(method = RequestMethod.GET, value = "")
	public void zipLogs(@WebOutputStream OutputStream outputStream) throws IOException, QppServiceException  {

		// absolute path of server log folder
		String logFolderPath = getLogsFolder();
		
		if(logFolderPath != null){
			ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
			BufferedInputStream bufferedInputStream = null;
			FileInputStream fileInputStream = null;
			try {
				// declare a buffer
				byte[] buffer = new byte[SIZE];

				File logsFolder = new File(logFolderPath);

				// get a list of files from given directory
				String[] logFiles = logsFolder.list();

				for (int i = 0; logFiles != null && i < logFiles.length; i++) {
					logger.debug("Adding: " + logFiles[i]);
					fileInputStream = new FileInputStream(logFolderPath + File.separator + logFiles[i]);
					bufferedInputStream = new BufferedInputStream(fileInputStream, SIZE);
					ZipEntry entry = new ZipEntry(logFiles[i]);
					zipOutputStream.putNextEntry(entry);
					int count;
					while ((count = bufferedInputStream.read(buffer, 0, SIZE)) != -1) {
						zipOutputStream.write(buffer, 0, count);
					}
					bufferedInputStream.close();
					fileInputStream.close();
				}
				logger.debug("Created zip file of logs : " + logFolderPath);
			} catch (Exception e) {
				if (bufferedInputStream != null) {
					bufferedInputStream.close();
				}
				if (fileInputStream != null) {
					fileInputStream.close();
				}
				e.printStackTrace();
			} finally {
				zipOutputStream.close();
			}
		}else{
			logger.error("Error while fetching logs folder path.");
		}
	}

	private String getLogsFolder() throws QppServiceException{
		String logFilePath = runtimeConfigurationService.getLogFilePath();
		int lastIndex = logFilePath.lastIndexOf(File.separator);

		//substring the absolute path of log file to get absolute path of the log folder
		String logsFolder = logFilePath.substring(0, lastIndex);
		return logsFolder;
	
	}
}

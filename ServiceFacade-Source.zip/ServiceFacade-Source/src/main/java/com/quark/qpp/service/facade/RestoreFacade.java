/*****************************************************************************
 ** Quark Publishing
 **
 ** �1986-2014 Quark Software Inc. All rights reserved.
 **
 *****************************************************************************/

package com.quark.qpp.service.facade;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateTimeValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.DomainValueList;
import com.quark.qpp.common.dto.MeasurementValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.TimeValue;
import com.quark.qpp.common.dto.Value;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.constants.Orientations;
import com.quark.qpp.core.asset.service.dto.Article;
import com.quark.qpp.core.asset.service.dto.ArticleComponent;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.dto.Layout;
import com.quark.qpp.core.asset.service.exceptions.AssetAlreadyCheckedOutException;
import com.quark.qpp.core.asset.service.exceptions.AssetCheckedOutByAnotherUserException;
import com.quark.qpp.core.asset.service.exceptions.AssetLockedException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotCheckedOutException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotLockedException;
import com.quark.qpp.core.asset.service.exceptions.AssetRelationNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.CannotDeleteAttachedComponentException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.asset.service.exceptions.MinorVersionNotSupportedException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.constants.DefaultDomains;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.dto.DomainValueListPreferences;
import com.quark.qpp.core.attribute.service.dto.DomainValuePreferences;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.local.AttributeDomainService;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.collection.service.dto.RevisionControl;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidCollectionExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.publishing.service.exceptions.InvalidChannelException;
import com.quark.qpp.core.publishing.service.local.PublishingService;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.PopupAttributeCondition;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.StringAttributeCondition;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.relation.service.local.RelationService;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryActionException;
import com.quark.qpp.core.storage.service.exceptions.StorageRuleNotFoundException;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.local.WorkflowService;
import com.quark.qpp.filetransfergateway.service.StreamingService;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.exception.RestoreException;
import com.quark.qpp.service.exception.RestoreExceptionCodes;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.ArchiveRestoreUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.validator.PrivilegeValidator;
import com.quark.qpp.service.xmlBinding.ArchiveRestoreInfo;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * The RestoreFacade will parse an Index.xml file present at the root of the Archived folder. It will then restore every asset defined
 * therein, along with its revisions, by parsing its corresponding asset version Archive.xml file. An already existing asset will be skipped
 * from the Restore process. After the Restore process has been completed, a Restore.log file is generated with detailed restore logs,
 * complete with exceptions logging if any inside the QPP server installation path /log folder. A RestoreSummary.log file is generated as
 * well at the archived folder path, that contains the count of assets restored/ failed.
 */
@Controller(value = "restoreFacade")
@RequestMapping("/restore")
public class RestoreFacade {

	@Autowired
	private AssetService assetService;

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private QueryService queryService;

	@Autowired
	private CollectionService collectionService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private AttributeDomainService attributeDomainService;

	@Autowired
	private TrusteeService trusteeService;
	
	@Autowired
	private PublishingService publishingService;

	@Autowired
	private StreamingService defaultStreamingService;

	@Autowired
	private ArchiveRestoreUtility archiveRestoreUtility;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	@Autowired
	private PrivilegeValidator privilegeValidator;
	
	@Autowired
	private RelationService relationService;

	private Logger logger = Logger.getLogger(RestoreFacade.class);
	
	private String restoreTempDirectory= System.getProperty("java.io.tmpdir")+"/QppServer/Restore";		
	
	/**
	 * Constants for defining possible strategies to be used for fetching QPP entities, like content type, relation type & attributes.
	 * Use 'name' for restore across different servers, else use 'id'.
	 */
	private static final String VALUE_BY_NAME = "name";
	private static final String VALUE_BY_ID = "id";

	/**
	 * Restore assets from the given folder path to another server. The target server here is assumed to be the same as the one from where
	 * the assets were archived.
	 *
	 * @param archivedPath
	 *            Path of the Index.xml file containing assets information to be restored, and the downloaded assets directory. For example,
	 *            /restore?archivedpath=c:/archive
	 * @return Restored assets summary containing information for all successful or failed restores.
	 * @throws Exception
	 */
	@WebReturnType(value = "xmlView")
	@RequestMapping(method = RequestMethod.GET)
	public ArchiveRestoreInfo restoreAssets(@RequestParam(value = "archivedpath", defaultValue = ".") String archivedPath) throws Exception {

		return restoreAssets(archivedPath,VALUE_BY_ID);
	}

	/**
	 * Restore assets from the given folder path to the same server. The target server here can either be same or different from the one from
	 * where the assets were archived, depending upon the value of the 'lookup' parameter.
	 *
	 * @param archivedPath
	 *            Path of the Index.xml file containing assets information to be restored, and the downloaded assets directory. For example,
	 *            /restore?archivedpath=c:/archive
	 * @param lookupEntityBy
	 *            Specify the lookup strategy to be used for fetching QPP entities, like content type, relation type & attributes. Use 'name' for
	 *            restore across different servers, else use 'id'.
	 * @return Restored assets summary containing information for all successful or failed restores.
	 * @throws Exception
	 */
	@WebReturnType(value = "xmlView")
	@RequestMapping(method = RequestMethod.GET, params = "lookup")
	public ArchiveRestoreInfo restoreAssets(@RequestParam(value = "archivedpath", defaultValue = ".") String archivedPath,
			@RequestParam(value = "lookup") String lookupEntityBy) throws Exception {
		try {
			logger.trace("--- Starting Restore --");
			// Maintain record of successfully restored assets
			//Maintaining map of each asset version successfully restored such that key = oldAssetId.oldMajorVersion.oldMinorVersion and value = new IndexAssetInfo details, 
			//so that restored versions can be figured out easily.
			Map<String,IndexAssetInfo> successfulRestores = new HashMap<String, RestoreFacade.IndexAssetInfo>();
			// Map for holding the failed asset name as key and its exception information as value, to be displayed in RestoreSummary.log
			// file
			Map<String, String> failedRestores = new HashMap<String, String>();
			// Maintain a record of assets skipped in restore process
			ArrayList<String> skippedAssets = new ArrayList<String>();

			String logText = restoreAssets(archivedPath, failedRestores, skippedAssets, successfulRestores, lookupEntityBy);

			// return the info object
			ArchiveRestoreInfo info = new ArchiveRestoreInfo();
			info.setFailureCount(failedRestores.size());
			info.setSuccessCount(successfulRestores.size());
			info.setSummary(logText);
			return info;

		} catch (Exception e) {
			logger.error("Unable to restore assets.", e);
			throw e;
		} finally {
			logger.trace("-- Restoring Complete. -- ");
		}
	}

	/**
	 * Parses archive index file and restores assets referenced in the index. It parses Index.xml file and creates a map of IndexAssetInfo
	 * objects from the parsed data, sorted on the basis of asset version in ascending order. This info is then used to drive restoration of
	 * assets corresponding to each entry parsed from Index.
	 * @throws Exception
	 */
	private String restoreAssets(String archivedPath, Map<String, String> failedRestores, ArrayList<String> skippedAssets,
			Map<String,IndexAssetInfo> successfulRestores, final String lookupEntityBy) throws Exception {
		// map of IndexAssetInfo objects that will flow through the class to restore assets
		Map<Long, IndexAssetInfo> assetsInfoMap = new HashMap<Long, IndexAssetInfo>();
		String logText = "";

		// parse the Index.xml file
		Document indexDom = parseXmlFile(archivedPath, "Index.xml");
		if (indexDom != null) {
			Element indexRootEle = indexDom.getDocumentElement();
			NodeList indexAssetsList = indexRootEle.getElementsByTagName("AssetArchived");
			logger.trace("Assets count to be restored is: " + indexAssetsList.getLength());

			for (int i = 0; i < indexAssetsList.getLength(); i++) {
				Element assetArchivedEle = (Element) indexAssetsList.item(i);
				long assetId = Long.parseLong(assetArchivedEle.getAttribute("assetId"));
				int majorVersion = Integer.parseInt(assetArchivedEle.getAttribute("majorVersion"));
				int minorVersion = Integer.parseInt(assetArchivedEle.getAttribute("minorVersion"));
				String archivePath = assetArchivedEle.getAttribute("path");

				// Populate assetsInfoMap for each asset entry in the index.xml
				// check if this is a new asset id or a version of an already saved asset info
				if (assetsInfoMap.containsKey(assetId)) {
					// get index asset object for this asset id and fetch the version array
					IndexAssetInfo info = assetsInfoMap.get(assetId);
					IndexAssetVersion[] versions = info.getAssetVersions();

					List<IndexAssetVersion> versionsList = new ArrayList<IndexAssetVersion>(Arrays.asList(versions));
					IndexAssetVersion newVersion = new IndexAssetVersion();
					newVersion.setMajorVersion(majorVersion);
					newVersion.setMinorVersion(minorVersion);
					newVersion.setPath(archivePath);
					versionsList.add(newVersion);

					// sort the versions list on the basis of version field
					Collections.sort(versionsList, new AssetVersionComparator());

					// finally, update the map value with the new asset version
					info.setAssetVersions(versionsList.toArray(new IndexAssetVersion[0]));

				} else {
					// add a new index asset info to the map
					IndexAssetInfo assetInfo = new IndexAssetInfo();
					assetInfo.setAssetId(assetId);
					assetInfo.setAlreadyCheckedin(false);
					IndexAssetVersion assetVersions = new IndexAssetVersion();
					assetVersions.setMajorVersion(majorVersion);
					assetVersions.setMinorVersion(minorVersion);
					assetVersions.setPath(archivePath);
					assetInfo.setAssetVersions(new IndexAssetVersion[] { assetVersions });
					assetsInfoMap.put(assetId, assetInfo);
				}
			}

			// Begin restoring the assets
			for (Map.Entry<Long, IndexAssetInfo> entry : assetsInfoMap.entrySet()) {
				logger.trace("");
				logger.trace("Restoring indexed asset.......");
				Long assetId = entry.getKey();
				IndexAssetInfo assetInfo = entry.getValue();
				restore(assetsInfoMap, assetId, assetInfo, archivedPath, failedRestores, skippedAssets, successfulRestores, lookupEntityBy);
			}

			if (failedRestores.size() > 0)
				logger.trace("Total number of failed restores: " + failedRestores.size());

			// write RestoreSummary.log file.
			logText = printLogFile(indexAssetsList.getLength(), failedRestores, archivedPath, skippedAssets, successfulRestores);
		}
		return logText;
	}

	/**
	 * This method restores an asset if it does not already exist in the server, or else it updates the asset info map with the existing
	 * asset id. The method is either invoked for restoring assets found in the index asset info objects map. Or recursively for a child
	 * asset found as a result of parsing a parent Archive.xml file. It returns the asset id of the existing or checked-in asset.
	 * @throws Exception
	 */
	private long restore(Map<Long, IndexAssetInfo> assetsInfoMap, long oldAssetId, IndexAssetInfo assetToRestore, String archivedPath,
			Map<String, String> failedRestores, ArrayList<String> skippedAssets, Map<String,IndexAssetInfo> successfulRestores,
			final String lookupEntityBy) throws Exception {
		// search if the asset already exists in server or not before restoring it
		long assetId = searchAsset(assetToRestore, archivedPath, lookupEntityBy);
		if (assetId <= 0) {
			restoreAsset(assetsInfoMap, assetToRestore, failedRestores, archivedPath, skippedAssets, successfulRestores, lookupEntityBy);
		} else {
			// update asset info
			if (assetToRestore.getAssetId() != assetId) {
				logger.trace("Asset exists in server but with another id. Updating map with newly fetched asset id...");
				assetToRestore.setAssetId(assetId);
			} else {
				logger.trace("Asset already exists in server. Skipping this asset..");
			}

			// fetch existing asset name and path for logging
			AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.NAME,
					DefaultAttributes.COLLECTION_PATH });
			String assetName = ((TextValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.NAME, attributeValues)).getValue();
			String collectionPath = ((TextValue) archiveRestoreUtility
					.getAttributeValue(DefaultAttributes.COLLECTION_PATH, attributeValues)).getValue();

			// an asset can exist in server even as part of the restore checkin process, so check if it was restored during this process
			// itself before adding to skipped assets list.
			if (!successfulRestores.containsValue(new IndexAssetInfo(assetId))) {
				
				//Case 1: successful restores don't have that asset but it exists in server, implies already existing asset. No versions validation is done[as per Old behavior].
				
				if (!skippedAssets.contains(collectionPath + "/" + assetName))
					skippedAssets.add(collectionPath + "/" + assetName);
			} else {

				// Case 2 : Now this becomes the scenario that successful restores contains this asset but may not have all versions been restored successfully.

				// Now check if all versions were restored ? Because some versions due to cyclic dependency could have only been
				// restored uptill that version and after that the remaining versions were not restored.
				IndexAssetVersion[] actualVersionsToBeRestored = assetToRestore.getAssetVersions();
				

				ArrayList<IndexAssetVersion> versionsYetToBeRestored = new ArrayList<RestoreFacade.IndexAssetVersion>();
				
				for (int m = 0; m < actualVersionsToBeRestored.length; m++) {
					long majorVersion = actualVersionsToBeRestored[m].getMajorVersion();
					long minorVersion =actualVersionsToBeRestored[m].getMinorVersion();
					String searchString = oldAssetId+"."+majorVersion+"."+minorVersion;
					if(!successfulRestores.containsKey(searchString)){
						versionsYetToBeRestored.add(actualVersionsToBeRestored[m]);
					}
				}

				if (versionsYetToBeRestored.size() > 0) {
					restoreAssetVersions(assetsInfoMap, versionsYetToBeRestored.toArray(new IndexAssetVersion[] {}),
							archivedPath, failedRestores, skippedAssets, successfulRestores, lookupEntityBy);
				}
			} 

			// set flag to true
			assetToRestore.setAlreadyCheckedin(true);
		}

		if (assetToRestore != null)
			return assetToRestore.getAssetId();
		else
			return -1;
	}

	/**
	 * Method to search if the given IndexAssetInfo object already exists in server or not.
	 * @throws QppServiceException
	 * @throws IOException
	 */
	private long searchAsset(IndexAssetInfo indexAssetInfo, String archivedPath, final String lookupEntityBy) throws InvalidQueryDefinitionException,
			InvalidQueryDisplayException, QppServiceException, ParserConfigurationException, SAXException, IOException {
		if (indexAssetInfo != null) {
			// search if this asset already exists in server
			String assetVersionPath = indexAssetInfo.getAssetVersions()[0].getPath();
			Document assetVersionDom = parseXmlFile(archivedPath + File.separator + assetVersionPath, "Archive.xml");
			long assetId = searchAsset(assetVersionDom.getDocumentElement(), lookupEntityBy);
			return assetId;
		}
		return -1;
	}

	/**
	 * Method to parse the given xml file and return the dom.
	 * @throws ParserConfigurationException
	 * @throws RestoreException
	 */
	private Document parseXmlFile(String archivedPath, String fileName) throws ParserConfigurationException, RestoreException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		// parse using builder to get DOM representation of the Index.xml file
		Document dom = null;
		try {
			File xml = new File(archivedPath + File.separator + fileName);
			dom = db.parse(xml);
		} catch (SAXException e) {
			logger.error("Error in parse xml.", e);
			throw new RestoreException(RestoreExceptionCodes.INVALID_INDEX_XML_PATH);
		} catch (IOException e) {
			logger.error("Invalid archive location!", e);
			throw new RestoreException(RestoreExceptionCodes.INVALID_ARCHIVED_DATA_PATH);
		}
		return dom;
	}

	/**
	 * This method determines whether an asset already exists in server or we need to check it in. This method will search an asset based on
	 * asset version name, content type, and collection path information that is fetched from the given asset node.
	 * @return id of the already existing asset or -1 if asset does not exist in server
	 * @throws QppServiceException
	 */
	private long searchAsset(Element assetNode, final String lookupEntityBy) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		// retrieve the asset information from the xml node
		NodeList asset = assetNode.getElementsByTagName("Asset");
		// execute the query and read the result
		QueryResultElement[] results = null;
		if (asset.getLength() > 0) {
			Element assetEle = (Element) asset.item(0);
			long contentTypeId = Long.parseLong(assetEle.getAttribute("ContentType"));
			String contentTypeHierarchy = assetEle.getAttribute("ContentTypeHierarchy");
			NodeList version = assetEle.getElementsByTagName("Version");
			Element versionEle = (Element) version.item(0);
			String assetName = versionEle.getAttribute("VersionName");
			String collectionPath = versionEle.getAttribute("CollectionPath");
			long collectionId = facadeUtility.getCollectionIdForCollectionPath(collectionPath);

			if (lookupEntityBy.equals(VALUE_BY_NAME)) {
				try {
					/* Overwrite the Content type id using Hierarchy, as the id may differ across servers. */
					contentTypeId = facadeUtility.getContentTypeIdForHierarchy(contentTypeHierarchy);
				} catch (InvalidContentTypeException e) {
					logger.trace("Content type with id: " + contentTypeId + " and hierarchy " + contentTypeHierarchy + " does not exist!", e);
				}
			}

			// make the query condition based on collection, content type and name
			PopupAttributeCondition queryCondition = new PopupAttributeCondition();
			queryCondition.setAttributeId(DefaultAttributes.CONTENT_TYPE);
			queryCondition.setComparisonOperator(1);
			queryCondition.setValue(contentTypeId);
			queryCondition.setNestingLevel(1);

			StringAttributeCondition queryCondition2 = new StringAttributeCondition();
			queryCondition2.setAttributeId(DefaultAttributes.NAME);
			queryCondition2.setComparisonOperator(1);
			queryCondition2.setValue(assetName);
			queryCondition2.setNestingLevel(1);
			queryCondition2.setLogicalOperator(1);
			QueryCondition[] queryConditions = new QueryCondition[] { queryCondition, queryCondition2 };

			QueryContext queryContext = new QueryContext();
			queryContext.setCollections(new long[] { collectionId });

			DisplayColumn[] displayColumns = new DisplayColumn[1];
			displayColumns[0] = new DisplayColumn(DefaultAttributes.NAME, 50, true);
			QueryDisplay queryDisplay = new QueryDisplay();
			queryDisplay.setDisplayColumns(displayColumns);

			results = queryService.getQueryResultForConditions(queryConditions, queryContext, queryDisplay);
			logger.trace("searchAsset was called for: " + assetName);
		} else
			logger.error("Invalid Archive.xml file. No asset was found!");
		if (results != null)
			if (results.length > 0) {
				// return the id of the already existing asset
				logger.trace("searchAsset found already existing asset. Id=" + ((AssetElement) results[0]).getAssetId() );
				return ((AssetElement) results[0]).getAssetId();
			}
		logger.trace("searchAsset is returning -1 as asset does not exist in server.");
		return -1;
	}

	/**
	 * Restore the given IndexAssetInfo object as a new asset.
	 * @throws Exception
	 */
	private void restoreAsset(Map<Long, IndexAssetInfo> assetsInfoMap, IndexAssetInfo assetInfo, Map<String, String> failedRestores,
			String archivedPath, ArrayList<String> skippedAssets, Map<String,IndexAssetInfo> successfulRestores, final String lookupEntityBy)
			throws Exception {
		if (assetInfo != null) {
			logger.trace("Asset not in server. Restoring asset as new asset...");
			assetInfo.setAlreadyCheckedin(false);
			// restore each asset version from its corresponding Archive.xml file
			restoreAssetVersions(assetsInfoMap, assetInfo.getAssetVersions(), archivedPath, failedRestores, skippedAssets,
					successfulRestores, lookupEntityBy);
		} else
			logger.error("Invalid asset id. Map does not contain this key!");
	}

	/**
	 * This method will restore each asset version from its corresponding Archive.xml file, by reading its metadata information.
	 * @throws Exception
	 */
	private void restoreAssetVersions(Map<Long, IndexAssetInfo> assetsInfoMap, IndexAssetVersion[] assetVersions, String archivedPath,
			Map<String, String> failedRestores, ArrayList<String> skippedAssets, Map<String,IndexAssetInfo> successfulRestores,
			final String lookupEntityBy) throws Exception {
			// restore each asset version from its corresponding Archive.xml file
		for (int i = 0; assetVersions != null && i < assetVersions.length; i++) {
			boolean isLatestVersion = false;
			if (i == assetVersions.length - 1) {
				isLatestVersion = true;
			}

			Map<String, ArrayList<Element>> cyclicRelationsMap = new HashMap<String, ArrayList<Element>>();
			try {
				restoreSpecificAssetVersion(assetsInfoMap, assetVersions[i], archivedPath, failedRestores, skippedAssets, successfulRestores, lookupEntityBy,
						null/* ancestors reference is maintained per version */, isLatestVersion /*certain datadoc attributes are to be set only on latest datadoc version*/, cyclicRelationsMap);
			} catch (Exception e) {
				break;//Can not continue when a version does not get restored.
			}
		} // for ends
	}
	
	private long restoreSpecificAssetVersion(Map<Long, IndexAssetInfo> assetsInfoMap, IndexAssetVersion assetVersion, String archivedPath,
			Map<String, String> failedRestores, ArrayList<String> skippedAssets, Map<String,IndexAssetInfo> successfulRestores,
			final String lookupEntityBy,  ArrayList<String> ancestorsReference, boolean isLatestVersion, Map<String, ArrayList<Element>> cyclicRelationToBeRestored) throws Exception{
	String assetName = null;
	String collectionPath = null;
	long assetId = -1;
	try{
		String relativePath = assetVersion.getPath();
		Document assetVersionDom = parseXmlFile(archivedPath + File.separator + relativePath, "Archive.xml");
		// get asset defined in the parent node
		NodeList asset = assetVersionDom.getDocumentElement().getElementsByTagName("Asset");
		if (asset != null && asset.getLength() > 0) {
			Element assetEle = (Element) asset.item(0);
			assetId = Long.parseLong(assetEle.getAttribute("AssetID"));
			long contentTypeId = Long.parseLong(assetEle.getAttribute("ContentType"));

			if (lookupEntityBy.equals(VALUE_BY_NAME)) {
				String contentTypeHierarchy = assetEle.getAttribute("ContentTypeHierarchy");
				try {
					/* Overwrite the Content type id using Hierarchy, as the id may differ across servers. */
					contentTypeId = facadeUtility.getContentTypeIdForHierarchy(contentTypeHierarchy);
				} catch (InvalidContentTypeException e) {
					logger.trace("Content type with id: " + contentTypeId + " and hierarchy " + contentTypeHierarchy + " does not exist!", e);
					throw e;
				}
			}

			NodeList version = assetEle.getElementsByTagName("Version");
			if (version != null && version.getLength() > 0) {
				Element versionEle = (Element) version.item(0);
				assetName = versionEle.getAttribute("VersionName");
				collectionPath = versionEle.getAttribute("CollectionPath");
				boolean isDatadoc = Boolean.valueOf(versionEle.getAttribute("isDatadoc"));
				String versionId = versionEle.getAttribute("MajorVersionID") + "."
						+ versionEle.getAttribute("MinorVersionID");
				logger.trace("");
				logger.trace("Restoring " + assetName + " with Version " + versionId);

				// create asset attributes.
				AttributeValue[] allAttributeValues = getAllAttributeValues(versionEle, lookupEntityBy, contentTypeId);
				AttributeValue[] modifiableAttributeValues = getModifiableAttributeValues(allAttributeValues);
				
				// validate asset archive privilege for the logged in user for this content type.
				privilegeValidator
						.validateContentTypePrivileges(-1, modifiableAttributeValues, "archiveAsset");

				long collectionId = ((DomainValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.COLLECTION,
						modifiableAttributeValues)).getId();

				// create article components and its attributes.
				ArrayList<ArticleComponent> components = createComponents(versionEle, lookupEntityBy);

				// create project layouts and its attributes.
				ArrayList<Layout> layouts = createLayouts(versionEle, lookupEntityBy);
				
				long versionElMajorVersion = Long.valueOf(versionEle.getAttribute("MajorVersionID"));
				long versionElMinorVersion = Long.valueOf(versionEle.getAttribute("MinorVersionID"));
				
				NodeList relations = versionEle.getElementsByTagName("Relations");
				ArrayList<Element> allRelations = new ArrayList<Element>();
				if (relations != null && relations.getLength() > 0) {
					logger.trace("Creating relations for asset " + versionEle.getAttribute("VersionName") + ", version id "
							+ Float.valueOf(versionEle.getAttribute("MajorVersionID") + "." + versionEle.getAttribute("MinorVersionID")));

					Element relationsNode = (Element) relations.item(0);
					NodeList assetRelations = relationsNode.getElementsByTagName("AssetRelation");
					for (int n = 0; assetRelations != null && n < assetRelations.getLength(); n++) {
						Element assetRelationNode = (Element) assetRelations.item(n);
						allRelations.add(assetRelationNode);
					}
				}
				
				
				Element[] assetRelationsToBeCreated = allRelations.toArray(new Element[]{});
				
				ArrayList<AssetRelation> assetRelations = new ArrayList<AssetRelation>();
				
				if (assetRelationsToBeCreated != null && assetRelationsToBeCreated.length > 0) {
					logger.trace("Creating relations for asset " + versionEle.getAttribute("VersionName") + ", version id "
							+ Float.valueOf(versionEle.getAttribute("MajorVersionID") + "." + versionEle.getAttribute("MinorVersionID")));
					// create asset relations and its attributes.
					assetRelations = createAssetRelations(versionElMajorVersion, versionElMinorVersion, assetRelationsToBeCreated, assetsInfoMap, failedRestores,
							archivedPath, skippedAssets, successfulRestores, lookupEntityBy, ancestorsReference, cyclicRelationToBeRestored);
				}

				/* If an assets's collection and workflow attribute values contain any invalid characters, then its folder path will have 
				 * replaced strings as collection and workflow name. Therefore, reading these values from archive xml file. */
				String collectionFolderName = versionEle.getAttribute("CollectionName");
				String workflowFolderName = versionEle.getAttribute("WorkflowName");
			
				// Define file input path
				String path = archivedPath + File.separator + "Data" + File.separator + collectionFolderName + File.separator
						+ workflowFolderName + File.separator + assetId + File.separator + versionId;

				// set the createMinorVersion flag based on whether minor versioning is allowed for this content type on this
				// collection or not
				boolean createMinorVersion = false;
				if (Long.valueOf(versionEle.getAttribute("MinorVersionID")) > 0) {
					RevisionControl[] revisionControls = collectionService.getCollection(collectionId).getRevisionControls();
					for (RevisionControl revisionControl : revisionControls) {
						if (revisionControl.getContentTypeId() == contentTypeId) {
							createMinorVersion = revisionControl.isMinorVersioningAllowed();
							break;
						}
					}
				}
				// checkin asset
				checkinAssetVersion(path, assetName, assetsInfoMap, assetId, versionElMajorVersion, versionElMinorVersion, contentTypeId, modifiableAttributeValues, components, layouts,
						assetRelations, createMinorVersion, successfulRestores);
				/*
				 * Cannot set datadoc attributes on all versions because, a datadoc cannot be checked out. Thus, set datadoc
				 * attributes only on the latest/last asset version.
				 */
				if (isDatadoc && isLatestVersion/*check is the latest version of data doc*/) {
					AttributeValue[] datadocAttributeValues = getDatadocAttributes(allAttributeValues);
					setDatadocSpecificAttributes(assetsInfoMap.get(assetId).getAssetId(), datadocAttributeValues);
				}
				
				//look in cyclic relations map, to see any relation to be created where this asset was child.These are relations that could not get created because child asset was ancestor.
				ArrayList<Element> rels = cyclicRelationToBeRestored.get(assetId+"."+versionElMajorVersion+"."+versionElMinorVersion);
				
				if (rels != null && rels.size() > 0){
					for (int i = 0; i < rels.size(); i++) {
						Element assetRelationNode = rels.get(i);
						
						long parentAssetMajorVersion = Long.valueOf(assetRelationNode.getAttribute("ParentMajorVersion"));
						long parentAssetMinorVersion = Long.valueOf(assetRelationNode.getAttribute("ParentMinorVersion"));
						
						ArrayList<AssetRelation> cyclicRels = createAssetRelations(parentAssetMajorVersion, parentAssetMinorVersion, new Element[]{assetRelationNode}, assetsInfoMap, failedRestores, archivedPath, skippedAssets, successfulRestores, lookupEntityBy, null, null);
						
						for(int kk = 0;kk<cyclicRels.size();kk++){
							AssetRelation aRelation = cyclicRels.get(kk);
							long parentAssetId = Long.valueOf(aRelation.getParentAssetId());
							long restoredParentAssetId = assetsInfoMap.get(parentAssetId).getAssetId();
							
							try{
								logger.trace("Creating skipped relation (cyclic ref) between parent : " + restoredParentAssetId + " "
										+ parentAssetMajorVersion + "." + parentAssetMinorVersion +" and child : "+aRelation.getChildAssetId()+" " +aRelation.getChildAssetVersion().getMajorVersion()+"."+aRelation.getChildAssetVersion().getMinorVersion());
								
								
								if(!relationService.getRelationType(aRelation.getRelationTypeId()).isCheckOutMandatory()){
									//create asset relation
									assetService.createAssetRelation(restoredParentAssetId, aRelation.getChildAssetId(), aRelation.getChildAssetVersion(), aRelation.getRelationTypeId(), aRelation.getRelationAttributes(), aRelation.isLockedToChildVersion());
								}else{
									//Bug #290087
									//The case when its a cyclic reference and relation type has checkout mandatory.
									//Ideally, this case comes up in scenario when the assets were archived using allVersionFlag=false and has references to child version that have not been archived.
									
									//Following code checkout the asset, fetch all relations, append the new relation and check-in with existing and new relation.
									
									long child_newMajorVersion = successfulRestores.get(assetId+"."+versionElMajorVersion+"."+versionElMinorVersion).getAssetVersions()[0].getMajorVersion();
									long child_newMinorVersion = successfulRestores.get(assetId+"."+versionElMajorVersion+"."+versionElMinorVersion).getAssetVersions()[0].getMinorVersion();
									
									aRelation.setChildAssetVersion(new AssetVersion(child_newMajorVersion, child_newMinorVersion));
								
									//We need to checkout the parent and check-in another version picking highres from last version.
									//Download last version highres to a temp location
									long readContextId = assetService.createReadContext(restoredParentAssetId, null, DefaultRenditionTypes.HIGH_RES);
									AssetRelation[] lastVersionRelations = assetService.getChildAssetRelations(restoredParentAssetId);
									
									File restoreTempDirectoryFile = new File(restoreTempDirectory);
									if(!restoreTempDirectoryFile.exists()) {
										restoreTempDirectoryFile.mkdirs();
									}
									
									File lastVersionHighresFile = File.createTempFile("tmp_", restoredParentAssetId+"", restoreTempDirectoryFile);
									
									FileOutputStream fileOutputStream = null;
									try{
										fileOutputStream = new FileOutputStream(lastVersionHighresFile);
										defaultStreamingService.download(fileOutputStream, readContextId);
									}finally{
										if(fileOutputStream!=null) {
												fileOutputStream.close();
										}
										assetService.closeContext(readContextId);
									}
									FileInputStream fileStream = null;
									try{
										checkOutAsset(restoredParentAssetId);
										Asset assetTobeCHeckedIn = new Asset();
										assetTobeCHeckedIn.setAssetId(restoredParentAssetId);
										
										fileStream = new FileInputStream(lastVersionHighresFile);
										
										ArrayList<AssetRelation> relationsToBeCreated = new ArrayList<AssetRelation>();
										for (int j = 0; j < lastVersionRelations.length; j++) {
											relationsToBeCreated.add(lastVersionRelations[j]);
										}
										
										relationsToBeCreated.add(aRelation);
										checkinAsset(assetTobeCHeckedIn, /*new AssetRelation[]{ar}*/relationsToBeCreated.toArray(new AssetRelation[0]), createMinorVersion, fileStream, successfulRestores, parentAssetId, parentAssetMajorVersion, parentAssetMinorVersion);
									}finally{
										if(fileStream!=null){
											fileStream.close();
										}
										lastVersionHighresFile.delete();
									}
								}
							}catch (Exception e) {
								logger.trace("Error while creating skipped relation (cyclic ref) between parent : "+aRelation.getParentAssetId() +" "+parentAssetMajorVersion+"."+parentAssetMinorVersion+" and child : "+aRelation.getChildAssetId()+" "+aRelation.getChildAssetVersion().getMajorVersion()+"."+aRelation.getChildAssetVersion().getMinorVersion(), e);
							}
						}
						
					}
					//Once relations created, remove their reference from map
					cyclicRelationToBeRestored.remove(assetId+"."+versionElMajorVersion+"."+versionElMinorVersion);
					
				}
			}
		} else
			logger.error("Invalid Archive.xml file for asset " + assetName + ", with id: " + assetId + ". No assets found!");
		
		} catch (QppServiceException e) {
			String additionalInfo = archiveRestoreUtility.getAdditionalInfoForException(e);
			logger.error("Exception occurred while restoring " + assetName + ".", e);
			failedRestores.put(collectionPath+"/"+assetName, e.toString() + ". " + additionalInfo);
			throw e;
		} catch (Exception e) {
			logger.error("Exception occurred while restoring " + assetName + ".", e);
			failedRestores.put(collectionPath+"/"+assetName, e.toString());
			throw e;
		}
		return assetsInfoMap.get(assetId).getAssetId();
	}

	private void setDatadocSpecificAttributes(long newAssetId, AttributeValue[] datadocAttributeValues) throws JAXBException,
			AssetNotFoundException, InvalidAssetException, InvalidChannelException, QppServiceException {
		String datadocChannelId = null;
		PublishingParameter[] publishingParameters = null;
		for (int i = 0; datadocAttributeValues != null && i < datadocAttributeValues.length; i++) {
			if (datadocAttributeValues[i].getAttributeId() == DefaultAttributes.DATADOC_CHANNEL_ID) {
				datadocChannelId = ((TextValue) datadocAttributeValues[i].getAttributeValue()).getValue();
			} else if (datadocAttributeValues[i].getAttributeId() == DefaultAttributes.DATADOC_CHANNEL_PARAMETERS) {
				TextValue textValue = (TextValue) datadocAttributeValues[i].getAttributeValue();
				if (textValue != null) {
					String datadocChannelParameters = textValue.getValue();
					if (datadocChannelParameters != null && datadocChannelParameters.trim().length() > 0) {
						publishingParameters = createParametersFromXml(datadocChannelParameters);
					}
				}
			}
		}
		publishingService.convertToDatadoc(newAssetId, datadocChannelId, publishingParameters);
	}
	
	private PublishingParameter[] createParametersFromXml(String channelParametersXml) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(ParamsMap.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();

		StringReader sr = new StringReader(channelParametersXml);
		ParamsMap paramsMap = (ParamsMap) jaxbUnMarshaller.unmarshal(sr);

		ArrayList<PublishingParameter> parametersList = new ArrayList<PublishingParameter>();
		TreeMap<String, String> treeMap = paramsMap.treeMap;
		Iterator it = treeMap.keySet().iterator();
		while (it.hasNext()) {
			String paramName = (String) it.next();
			String paramValue = treeMap.get(paramName);
			PublishingParameter parameter = new PublishingParameter(paramName, paramValue);
			parametersList.add(parameter);
		}

		return parametersList.toArray(new PublishingParameter[0]);
	}

	
	/**
	 * Returns client modifiable asset attribute values.
	 * @param contentTypeId
	 * @throws AttributeNotFoundException
	 * @throws QppServiceException
	 */
	private AttributeValue[] getAllAttributeValues(Element versionEle, final String lookupEntityBy, long contentTypeId) throws AttributeNotFoundException, QppServiceException {
		ArrayList<AttributeValue> attributeValues = new ArrayList<AttributeValue>();
		NodeList attributes = versionEle.getElementsByTagName("Attributes");
		if (attributes != null && attributes.getLength() > 0) {
			logger.trace("Creating attributes for asset: " + versionEle.getAttribute("VersionName") + ", version id "
					+ Float.valueOf(versionEle.getAttribute("MajorVersionID") + "." + versionEle.getAttribute("MinorVersionID")));

			Element attributeEle = (Element) attributes.item(0);
			NodeList attributeNode = attributeEle.getElementsByTagName("Attribute");
			if (attributeNode != null && attributeNode.getLength() > 0) {
				// generate the attribute array from the xml attribute node
				attributeValues = createAttributesArray(attributeNode, lookupEntityBy, contentTypeId);
			}
		}
		return attributeValues.toArray(new AttributeValue[]{});
	}

	private AttributeValue[] getModifiableAttributeValues(AttributeValue[] attributeValues) throws AttributeNotFoundException,
			QppServiceException {
		ArrayList<AttributeValue> modifiableAttrValues = new ArrayList<AttributeValue>();
		// remove any server modifiable attributes
		for (int i = 0; i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			long attrId = attributeValue.getAttributeId();
			Attribute attribute = attributeService.getAttribute(attrId);
			if (attribute.getModificationLevel() == AttributeModificationLevels.SERVER_MODIFIABLE) {
				continue;
			} else {
				modifiableAttrValues.add(attributeValue);
			}
		}
		return modifiableAttrValues.toArray(new AttributeValue[] {});
	}
	
	private AttributeValue[] getDatadocAttributes(AttributeValue[] attributeValues) throws AttributeNotFoundException, QppServiceException {
		ArrayList<AttributeValue> datadocAttributes = new ArrayList<AttributeValue>();
		for (int i = 0; i < attributeValues.length; i++) {
			AttributeValue attributeValue = attributeValues[i];
			long attrId = attributeValue.getAttributeId();
			if (attrId == DefaultAttributes.DATADOC_CHANNEL_ID || attrId == DefaultAttributes.DATADOC_CHANNEL_PARAMETERS) {
				datadocAttributes.add(attributeValue);
			}
		}
		return datadocAttributes.toArray(new AttributeValue[] {});
	}

	private ArrayList<AttributeValue> createAttributesArray(NodeList attributeList, final String lookupEntityBy, long contentTypeId) throws StatusNotFoundException, WorkflowNotFoundException, QppServiceException {
		ArrayList<AttributeValue> attributeValuesList = new ArrayList<AttributeValue>();
		String workflowName = null;
		long workflowId = 0;

		for (int k = 0; k < attributeList.getLength(); k++) {
			Element attribute = (Element) attributeList.item(k);
			long attributeId = Long.parseLong(attribute.getAttribute("id"));

			/*
			 * To get the id of the collection type domain, we need to use the collection path. So this attribute will be generated from the
			 * Collection Path. ID attribute will be generated automatically.
			 * Status will be generated from Workflow attribute.
			 */
			if (attributeId == DefaultAttributes.COLLECTION || attributeId == DefaultAttributes.COLOR_SPACE
					|| attributeId == DefaultAttributes.ID || attributeId == DefaultAttributes.STATUS) {
				continue;
			}

			int type = Integer.parseInt(attribute.getAttribute("type"));
			String value = attribute.getTextContent();
			String attributeName = attribute.getAttribute("name");

			if (lookupEntityBy.equals(VALUE_BY_NAME)) {
				try {
					/* Overwrite the attribute id using attribute name, as the id may differ across servers. */
					attributeId = attributeService.getAttributeByName(attributeName).getId();
				} catch (AttributeNotFoundException e) {
					logger.trace("Attribute with name: " + attributeName + " does not exist!", e);
					// do not add this attribute
					continue;
				}
			}

			// check if the attribute is of domain type
			if (type == AttributeValueTypes.DOMAIN) {
				boolean isMultiValued = attributeService.getAttribute(attributeId).isMultiValued();

				if (isMultiValued) {
					NodeList domainValueList = attribute.getElementsByTagName("Value");
					Long domainValueId = (long) 0;
					List<DomainValue> domainValues = new ArrayList<DomainValue>();

					for (int i = 0; i < domainValueList.getLength(); i++) {
						Element domainValueELement = (Element) domainValueList.item(i);
						String strDomainValueId = domainValueELement.getAttribute("valueId");
						
						if(strDomainValueId != null && !strDomainValueId.isEmpty()) {
							domainValueId = Long.parseLong(strDomainValueId);
						}

						if(lookupEntityBy.equals(VALUE_BY_NAME) || domainValueId == 0) {
							int domainId = ((DomainValueListPreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
							// when look by name firstly we have to check for the hierarchical domain or not
							if (attributeDomainService.getDomain(domainId).isHierarchical()) {
								String domainValueText = archiveRestoreUtility.filterXmlText(domainValueELement.getTextContent());
								Map<String,Long> domainValueMap = new HashMap<String,Long>();
								
								archiveRestoreUtility.getMValueBasedMapOfHierarchicalDomains(domainValueMap,domainId);
								domainValueId = domainValueMap.get(domainValueText.toLowerCase());																
							} else {
								String domainValueText = archiveRestoreUtility.filterXmlText(domainValueELement.getTextContent());
								domainValueId = archiveRestoreUtility.getDomainValueId(domainId, domainValueText);
							}
						}

						//If the value is null set it to -1 and let the appropriate exception be thrown by Service 
						if (domainValueId == null) {
							domainValueId = -1L;							
						}
						domainValues.add(new DomainValue(-1, domainValueId, value));
					}

					attributeValuesList.add(new AttributeValue(attributeId, new DomainValueList(
							domainValues.toArray(new DomainValue[0])), type));
					
				} else {
					String strDomainValueId = attribute.getAttribute("valueId");
					long domainValueId = 0;
					if(strDomainValueId != null && !strDomainValueId.isEmpty()) {
						domainValueId = Long.parseLong(strDomainValueId);
					}
	
					if (attributeId == DefaultAttributes.CONTENT_TYPE) {
						int domainId = ((DomainValuePreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
						if(lookupEntityBy.equals(VALUE_BY_NAME)) {
							domainValueId = archiveRestoreUtility.getDomainValueId(domainId, value);
						} else {
							domainValueId = contentTypeId;
						}
						attributeValuesList.add(new AttributeValue(attributeId, new DomainValue(-1, domainValueId, value), type));
	
					} else if (attributeId == DefaultAttributes.WORKFLOW) {
						workflowName = value;
						if(lookupEntityBy.equals(VALUE_BY_NAME) || domainValueId == 0) {
							workflowId = workflowService.getWorkflowByName(workflowName).getId();
						} else{
							workflowId = domainValueId;
						}
						attributeValuesList.add(new AttributeValue(attributeId, new DomainValue(-1, workflowId, value), type));
						attributeValuesList.add(getStatusAttributeValue(workflowId, attributeList, lookupEntityBy));
	
					}  else {
						// for all other domain type attributes
						int domainId = ((DomainValuePreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
						if(lookupEntityBy.equals(VALUE_BY_NAME) || domainValueId == 0) {
							domainValueId = archiveRestoreUtility.getDomainValueId(domainId, value);											
						}
						if(domainValueId > 0) {
							if (attributeId == DefaultAttributes.ROUTED_TO) {
								try {
									// validate routed to trustee existence
									trusteeService.getTrustee(domainValueId);
								} catch (TrusteeNotFoundException e) {
									logger.trace("Cannot set routed to name: " + value + ", id:" + domainValueId + ". User/group does not exist! ", e);
									// Do not set routed to attribute value. The asset will be routed to 'No One'.
									continue;
								}
							}
							attributeValuesList.add(new AttributeValue(attributeId, new DomainValue(-1, domainValueId, value), type));
						} else {
							// simply log and skip adding this attribute
							logger.error("Domain value " + value + " does not exist!");
						}
					}
				}
			} else {
				// other type of attributes don't need special handling
				if (attributeId == DefaultAttributes.COLLECTION_PATH){
					long collectionId = facadeUtility.getCollectionIdForCollectionPath(value);
					if (collectionId <= 0) {
						InvalidCollectionException invalidCollectionException = new InvalidCollectionException(InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
						invalidCollectionException.setAdditionalInfo(new String[] { value });
						throw invalidCollectionException;
					}
					attributeValuesList.add(new AttributeValue(DefaultAttributes.COLLECTION, new DomainValue(-1, collectionId, value), AttributeValueTypes.DOMAIN));
				}
				else if (type == AttributeValueTypes.NUMERIC)
					attributeValuesList.add(new AttributeValue(attributeId, new NumericValue(Long.parseLong(value)), type));
				else if (type == AttributeValueTypes.MEASUREMENT)
					attributeValuesList.add(new AttributeValue(attributeId, new MeasurementValue(Double.parseDouble(value)), type));
				else if (type == AttributeValueTypes.DATE)
					attributeValuesList.add(new AttributeValue(attributeId, new DateValue(value), type));
				else if (type == AttributeValueTypes.DATETIME)
					attributeValuesList.add(new AttributeValue(attributeId, new DateTimeValue(value), type));
				else if (type == AttributeValueTypes.TIME)
					attributeValuesList.add(new AttributeValue(attributeId, new TimeValue(value), type));
				else if (type == AttributeValueTypes.BOOLEAN)
					attributeValuesList.add(new AttributeValue(attributeId, new BooleanValue(Boolean.parseBoolean(value)), type));
				else if (type == AttributeValueTypes.TEXT)
					attributeValuesList.add(new AttributeValue(attributeId, new TextValue(value), type));
			}
		}
		logger.trace("Returning an array of attribute values of length: " + attributeValuesList.size());
		return attributeValuesList;
	}

	private AttributeValue getStatusAttributeValue(long workflowId, NodeList attributeList, String lookupEntityBy) throws WorkflowNotFoundException, QppServiceException {

		for (int k = 0; k < attributeList.getLength(); k++) {
			Element attribute = (Element) attributeList.item(k);
			long attributeId = Long.parseLong(attribute.getAttribute("id"));
			if (attributeId == DefaultAttributes.STATUS) {
				String value = attribute.getTextContent();
				int type = AttributeValueTypes.DOMAIN;
				String strDomainValueId = attribute.getAttribute("valueId");
				long domainValueId = 0;
				if (strDomainValueId != null && !strDomainValueId.isEmpty()) {
					domainValueId = Long.parseLong(strDomainValueId);
				}
				long statusId = 0;
				if (lookupEntityBy.equals(VALUE_BY_NAME) || domainValueId == 0) {
					statusId = getStatus(workflowId, value);
				} else {
					statusId = domainValueId;
				}
				return new AttributeValue(DefaultAttributes.STATUS, new DomainValue(-1, statusId, value), type);
			}
		}
		return null;
	}

	private long getStatus(long workflowId, String value) throws WorkflowNotFoundException, QppServiceException {

		Workflow workflow = workflowService.getWorkflow(workflowId);
		Status[] workflowStatuses = workflow.getStatuses();
		for (Status s : workflowStatuses) {
			if (s.getName().equalsIgnoreCase(value)) {
				return s.getId();
			}
		}
		return 0;
	}

	/**
	 * Returns asset relations with their attribute values.
	 * @throws Exception
	 */
	private ArrayList<AssetRelation> createAssetRelations(long parentMajorVersion, long parentMinorVersion, Element[] assetRelations, Map<Long, IndexAssetInfo> assetsInfoMap,
			Map<String, String> failedRestores, String archivedPath, ArrayList<String> skippedAssets,
			Map<String,IndexAssetInfo> successfulRestores, final String lookupEntityBy, ArrayList<String> ancestorsReference, Map<String, ArrayList<Element>> cyclicRelationToBeRestoredLater) throws Exception {
		ArrayList<AssetRelation> assetRelationsList = new ArrayList<AssetRelation>();
		for (int n = 0; assetRelations != null && n < assetRelations.length; n++) {
				boolean cyclicDependency = false;
				Element assetRelationNode = (Element) assetRelations[n];
				long relationTypeId = Long.parseLong(assetRelationNode.getAttribute("RelationType"));
				String relationType = assetRelationNode.getAttribute("RelationTypeName");
				int relationState = Integer.parseInt(assetRelationNode.getAttribute("RelationState"));
				long parentAssetId = Long.parseLong(assetRelationNode.getAttribute("ParentAssetId"));
				long childAssetId = Long.parseLong(assetRelationNode.getAttribute("ChildAssetID"));
				long childAssetMajorVersion = Long.parseLong(assetRelationNode.getAttribute("ChildMajorVersion"));
				long childAssetMinorVersion = Long.parseLong(assetRelationNode.getAttribute("ChildMinorVersion"));
				long childAssetTypeId = Long.parseLong(assetRelationNode.getAttribute("ChildAssetType"));
				String childAssetTypeHierarchy = assetRelationNode.getAttribute("ChildAssetTypeHierarchy");
				boolean isLockedToChildVersion = assetRelationNode.getAttribute("LockedToChildVersion").equals("true") ? true : false;
				String componentName = assetRelationNode.getAttribute("ComponentName");
				long attachedComponentId = Long.parseLong(assetRelationNode.getAttribute("ComponentId"));

				if (lookupEntityBy.equals(VALUE_BY_NAME)) {
					try {
						/* Overwrite the Content type id using Hierarchy, as the id may differ across servers. */
						childAssetTypeId = facadeUtility.getContentTypeIdForHierarchy(childAssetTypeHierarchy);
					} catch (InvalidContentTypeException e) {
						logger.trace("Content type with id: " + childAssetTypeId + " and hierarchy " + childAssetTypeHierarchy + " does not exist!", e);
						// do not create this asset relation
						continue;
					}
					try {
						/* Overwrite the Relation type id using name, as the id may differ across servers. */
						relationTypeId = facadeUtility.getRelationTypeByName(relationType);
					} catch (RelationTypeNotFoundException e) {
						logger.trace("Relation type with id: " + relationTypeId + " does not exist!", e);
						// do not create this asset relation
						continue;
					}
				}
				
				
				String thisChildDetail = childAssetId+"."+childAssetMajorVersion+"."+childAssetMinorVersion;
				
				if(ancestorsReference != null && ancestorsReference.contains(thisChildDetail)){
					//implies an ancestor is being referred again...
					cyclicDependency = true;
				}
				
				
			if(!cyclicDependency){
				
				// restore child asset
				logger.trace("");
				logger.trace("Restoring child asset....... parent asset Id "+parentAssetId+"."+parentMajorVersion+"."+parentMinorVersion +" child asset Id = "+thisChildDetail);
				
				/**
				 * check if the attached asset already exists in the server. If it already exists, then we check if its the same as the
				 * attached asset id mentioned in the xml. If its not same, we update the child asset id.
				 **/
				IndexAssetInfo assetInfo = null;
				if (assetsInfoMap.containsKey(childAssetId))
					assetInfo = assetsInfoMap.get(childAssetId);
				else{
					//add to some queue for relations to be restored after checkin...
					//relationsToBeRestoredAfterInitialCheckin(thisAR);
				}
				
				long assetId = -1;
				if(checkIfSuccessfullyRestored(childAssetId, childAssetMajorVersion, childAssetMinorVersion, assetsInfoMap, successfulRestores, archivedPath, lookupEntityBy)){
					
					//If an asset is successfully restored, the restoredAssetId can be collected from the assetsInfoMap.
					assetId = assetsInfoMap.get(childAssetId).getAssetId();
				}else{
					IndexAssetVersion[] indexAssetVersions = assetInfo.getAssetVersions();
					for (int kk = 0; kk < indexAssetVersions.length; kk++) {
						boolean isLatestVersion = false;
						if(kk == indexAssetVersions.length-1)
							isLatestVersion = true;
						IndexAssetVersion indexAssetVersion = indexAssetVersions[kk];
						long thisMajorVersion = indexAssetVersion.getMajorVersion();
						long thisMinorVersion = indexAssetVersion.getMinorVersion();
						
						//check if this version is not in ancestor
						if(ancestorsReference != null && ancestorsReference.contains(childAssetId+"."+thisMajorVersion+"."+thisMinorVersion)){
							cyclicDependency = true;
							
							
							//should be registered against child assetid and version
							String thisChildExistsInAncestor = childAssetId+"."+thisMajorVersion+"."+thisMinorVersion;
							ArrayList<Element> cyclicRels = cyclicRelationToBeRestoredLater.get(thisChildExistsInAncestor);
							if(cyclicRels == null){
								cyclicRels = new ArrayList<Element>();
							}
							
							assetRelationNode.setAttribute("ParentMajorVersion", parentMajorVersion+"");
							assetRelationNode.setAttribute("ParentMinorVersion", parentMinorVersion+"");
							
							cyclicRels.add(assetRelationNode);//B1.0  <>   A(1.0)
							cyclicRelationToBeRestoredLater.put(thisChildExistsInAncestor, cyclicRels);
							
							break;
						}
						
						
						//for each child version check if it exists ?
						if(checkIfSuccessfullyRestored(childAssetId, thisMajorVersion, thisMinorVersion, assetsInfoMap, successfulRestores, archivedPath, lookupEntityBy)){
							assetId = assetsInfoMap.get(childAssetId).getAssetId();
						}else{
							//Since the referred child version does not exist, we are going to create that child version, but also we will pass the parents detail, 
							//so that if that child again referred its parent, it will turn cyclic in nature. 
							if(ancestorsReference == null){
								ancestorsReference = new ArrayList<String>();
							}
							
							String thisParentDetails = parentAssetId+"."+parentMajorVersion+"."+parentMinorVersion;
							
							if(!ancestorsReference.contains(thisParentDetails))
								ancestorsReference.add(thisParentDetails);
							
							//restore if not in ancestors
							assetId = restoreSpecificAssetVersion(assetsInfoMap, indexAssetVersion, archivedPath, failedRestores, skippedAssets, successfulRestores, lookupEntityBy, ancestorsReference, isLatestVersion, cyclicRelationToBeRestoredLater);
							
							//remove ancestor after child hierarchy resolution...
							ancestorsReference.remove(thisParentDetails);
						}
						
						//in case this version is the requirement, exit the for loop.
						//Either it has to be an exact match or if the restored version is greater than required version, it implies exact version was not archived or does not exist, and next available version should be considered/referred as child.
						if((thisMajorVersion == childAssetMajorVersion && thisMinorVersion == childAssetMinorVersion) || (thisMajorVersion > childAssetMajorVersion && thisMinorVersion > childAssetMinorVersion)){
							break;
						}
					}
				}
				
				if (assetId > 0) {
					childAssetId = assetId;
					/**
					 * if the attached asset is an article then we get the component id of the already existing article by comparing the
					 * component name.
					 **/
					if (childAssetTypeId == DefaultContentTypes.ARTICLE
							|| contentStructureService.isValidAncestor(DefaultContentTypes.ARTICLE, childAssetTypeId)) {
						Article article = (Article) assetService.getAsset(childAssetId);
						ArticleComponent[] articleComponents = article.getArticleComponents();
						for (ArticleComponent articleComponent : articleComponents) {
							String articleComponentName = ((TextValue) archiveRestoreUtility.getAttributeValue(
									DefaultAttributes.COMPONENT_NAME, articleComponent.getComponentAttributeValues())).getValue();
							if (articleComponentName.equals(componentName)) {
								attachedComponentId = articleComponent.getComponentId();
								break;
							}
						}
					}
				}
				
				if(!cyclicDependency){

				ArrayList<AttributeValue> relationAttributeValues = new ArrayList<AttributeValue>();
				Element assetRelationAttributes = (Element) assetRelationNode.getElementsByTagName("Attributes").item(0);
				NodeList relationAttributes = assetRelationAttributes.getElementsByTagName("Attribute");
				if (relationAttributes != null && relationAttributes.getLength() > 0) {
					for (int p = 0; p < relationAttributes.getLength(); p++) {
						Element attribute = (Element) relationAttributes.item(p);
						int type = Integer.parseInt(attribute.getAttribute("type"));
						String value = attribute.getTextContent();
						long attributeId = Long.parseLong(attribute.getAttribute("id"));
						String attributeName = attribute.getAttribute("name");

						if (lookupEntityBy.equals(VALUE_BY_NAME)) {
							try {
								/* Overwrite the attribute id using attribute name, as the id may differ across servers. */
								attributeId = attributeService.getAttributeByName(attributeName).getId();
							} catch (AttributeNotFoundException e) {
								logger.trace("Attribute with name: " + attributeName + " does not exist!", e);
								// do not add this attribute
								continue;
							}
						}

						if (attributeId == DefaultAttributes.ATTACHED_COMPONENT_ID) {
							relationAttributeValues.add(archiveRestoreUtility.createAttributeValue(attributeId, type,
									String.valueOf(attachedComponentId)));

						} else if (attributeId == DefaultAttributes.ARTICLE_COMP_REFRENCE_ASSET_ID) {
							IndexAssetInfo referenceAssetInfo = null;
							long referenceAssetId = Long.parseLong(value);
							if (assetsInfoMap.containsKey(referenceAssetId))
								referenceAssetInfo = assetsInfoMap.get(referenceAssetId);

							if (referenceAssetInfo != null) {
								// restore reference asset
								logger.trace("");
								logger.trace("Restoring article component reference asset.......");
								long articleComponentReferenceAssetId = restore(assetsInfoMap, referenceAssetId, referenceAssetInfo, archivedPath,
										failedRestores, skippedAssets, successfulRestores, lookupEntityBy);
								relationAttributeValues.add(archiveRestoreUtility.createAttributeValue(attributeId, type,
										String.valueOf(articleComponentReferenceAssetId)));
							} else {
								logger.error("Invalid Archive data. Map does not contain reference asset info!");
							}

						} else {
							/* For domain type attributes, we need the domain value id instead of the value text. */
							if (type == AttributeValueTypes.DOMAIN) {
								if (attributeId == DefaultAttributes.COLLECTION) {
									String collectionPath = assetRelationNode.getAttribute("CollectionPath");
									value = String.valueOf(facadeUtility.getCollectionIdForCollectionPath(collectionPath));
								}
								else{
									boolean isMultiValued = attributeService.getAttribute(attributeId).isMultiValued();
									int domainId = 0;

									if (isMultiValued) {
										domainId = ((DomainValueListPreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
									} else {
										domainId = ((DomainValuePreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
									}
									
									value = String.valueOf(archiveRestoreUtility.getDomainValueId(domainId, value));
								}
							}
							relationAttributeValues.add(archiveRestoreUtility.createAttributeValue(attributeId, type, value));
						}
					}
				}

				AssetRelation assetRelation = new AssetRelation();
				assetRelation.setParentAssetId(parentAssetId);
				assetRelation.setChildAssetId(childAssetId);
				assetRelation.setRelationState(relationState);
				assetRelation.setRelationTypeId(relationTypeId);
				assetRelation.setRelationAttributes(relationAttributeValues.toArray(new AttributeValue[0]));
				assetRelation.setLockedToChildVersion(isLockedToChildVersion);
				if (isLockedToChildVersion) {
					Long oldChildAssetId = Long.parseLong(assetRelationNode.getAttribute("ChildAssetID"));
					IndexAssetInfo indexAssetInfo = successfulRestores.get(oldChildAssetId+ "."+childAssetMajorVersion + "." + childAssetMinorVersion);
					if (indexAssetInfo != null) {
						long majorVersion = indexAssetInfo.getAssetVersions()[0].getMajorVersion();
						long minorVersion = indexAssetInfo.getAssetVersions()[0].getMinorVersion();
						assetRelation.setChildAssetVersion(new AssetVersion(majorVersion, minorVersion));
					} else {
						assetRelation
								.setChildAssetVersion(new AssetVersion(childAssetMajorVersion, childAssetMinorVersion));
					}
				} else {
					assetRelation
							.setChildAssetVersion(new AssetVersion(childAssetMajorVersion, childAssetMinorVersion));
				}
				
				
				
				
				assetRelationsList.add(assetRelation);
				}
				}else{
					//should be registered against child assetid and version
					String thisChildExistsInAncestor = childAssetId+"."+childAssetMajorVersion+"."+childAssetMinorVersion;
					ArrayList<Element> cyclicRels = cyclicRelationToBeRestoredLater.get(thisChildExistsInAncestor);
					if(cyclicRels == null){
						cyclicRels = new ArrayList<Element>();
					}
					
					assetRelationNode.setAttribute("ParentMajorVersion", parentMajorVersion+"");
					assetRelationNode.setAttribute("ParentMinorVersion", parentMinorVersion+"");
					
					cyclicRels.add(assetRelationNode);//B1.0  <>   A(1.0)
					cyclicRelationToBeRestoredLater.put(thisChildExistsInAncestor, cyclicRels);
				}
				
		}
		return assetRelationsList;
	}

	/*
	 * Check if the required asset version has already been restored or exists in platform server as per the following sequence. 
	 * IMPORTANT: This API also updates assetsInfoMap in case target platform server was searched for the given asset and a match was found.  
	 * 
	 * 1. Firstly check the required asset version in successful restores map
	 * 2. If asset version does not exist in successful restores map, it is checked if other versions of this asset exist in successfulRestores or 
	 * not. If other versions exist, it implies it is the version remaining to be restored.
	 * 3. If the asset has no entry in successful restores, but the flag "isAlreadyCheckedIn=true", it implies the asset already exists in target Platform Server.
	 * Simply refer the corresponding assetId in target Platform Server
	 * 4. Next option is to search the Platform Server for given asset version.If found in search, update the restored assetId and isAlreadyCheckedIn flag in assetsInfoMap
	 * TODO: Ideally the update should not happen here....!!!
	 * 5. Lastly, if "isAlreadyCheckedIn=false" and asset does not exist in target platform, this asset and all its version are yet to be restored.
	 */
	private boolean checkIfSuccessfullyRestored(long childAssetId, long thisMajorVersion, long thisMinorVersion,
			Map<Long, IndexAssetInfo> assetsInfoMap, Map<String, IndexAssetInfo> successfulRestores, String archivedPath, String lookupEntityBy) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException, ParserConfigurationException, SAXException, IOException {
		IndexAssetInfo indexAssetInfo = assetsInfoMap.get(childAssetId);
		if (indexAssetInfo != null) {
			// means the asset is here for restore...

			
			String childSearchKey = childAssetId + "." + thisMajorVersion + "." + thisMinorVersion;
			if (successfulRestores.containsKey(childSearchKey)) {
				// Case 1. So far has already been successfully restored
				return true;
			} else {
				// there can be two scenarios:
				Set<String> allAssetsAllVersions = successfulRestores.keySet();
				for (String key : allAssetsAllVersions) {
					if (key.startsWith(childAssetId + ".")) {
						// Case 2. Few versions exist, but this version is yet to be restored.
						return false;
					}
				}
			}
			
			
			//Case 3. Though already checkedIn but no successful restores implies, asset already existing in target platform server.
			if (indexAssetInfo.isAlreadyCheckedin()) {
				return true;
			} else {
				//Case 4:
				//Since asset is not already checked-in, search platform as the asset may already exist.
				long assetId = searchAsset(indexAssetInfo, archivedPath, lookupEntityBy);
				if(assetId > 0){
					
					//Update following details in indexAssetInfo, so that if this asset is referred again in any other parent asset, it is not searched again in target platform server.
					
					//TODO : Ideally the update of indexAssetInfo object should not happen here.......!!!
					//set restored asset Id
					indexAssetInfo.setAssetId(assetId);
					indexAssetInfo.setAlreadyCheckedin(true);
					return true;
				}
				
				//Case 5: yet to be restored, therefore send this for specific restore version.
				return false;
				
			}

		}
		return false;
	}

	/**
	 * Returns article components with their attribute values.
	 * @throws QppServiceException
	 */
	private ArrayList<ArticleComponent> createComponents(Element versionEle, final String lookupEntityBy) throws AttributeNotFoundException, QppServiceException {
	ArrayList<ArticleComponent> components = new ArrayList<ArticleComponent>();
		NodeList componentsElement = versionEle.getElementsByTagName("Components");
		if (componentsElement != null && componentsElement.getLength() > 0) {
			logger.trace("Creating components for asset " + versionEle.getAttribute("VersionName") + ", version id "
					+ Float.valueOf(versionEle.getAttribute("MajorVersionID") + "." + versionEle.getAttribute("MinorVersionID")));

			Element componentElement = (Element) componentsElement.item(0);
			NodeList componentsList = componentElement.getElementsByTagName("Component");
			for (int n = 0; n < componentsList.getLength(); n++) {
				Element component = (Element) componentsList.item(n);
				Element attributesElement = (Element) component.getElementsByTagName("Attributes").item(0);
				NodeList attributes = attributesElement.getElementsByTagName("Attribute");
				ArrayList<AttributeValue> componentAttributes = new ArrayList<AttributeValue>();
				if (attributes != null && attributes.getLength() > 0) {
					for (int p = 0; p < attributes.getLength(); p++) {
						Element attribute = (Element) attributes.item(p);

						int type = Integer.parseInt((attribute.getAttribute("type")));
						String value = attribute.getTextContent();
						long attributeId = Long.parseLong(attribute.getAttribute("id"));
						String attributeName = attribute.getAttribute("name");

						if (lookupEntityBy.equals(VALUE_BY_NAME)) {
							try {
								/* Overwrite the attribute id using attribute name, as the id may differ across servers. */
								attributeId = attributeService.getAttributeByName(attributeName).getId();
							} catch (AttributeNotFoundException e) {
								logger.trace("Attribute with name: " + attributeName + " does not exist!", e);
								// do not add this attribute
								continue;
							}
						}

						/* For domain type attributes, we need the domain value id instead of the value text. */
						if (type == AttributeValueTypes.DOMAIN) {
							if (attributeId == DefaultAttributes.CONTENT_TYPE) {
								value = String.valueOf(archiveRestoreUtility.getComponentTypeId(value));
							} else {
								int domainId = 0;
								boolean isMultiValued = attributeService.getAttribute(attributeId).isMultiValued();
	
								if (isMultiValued) {
									domainId = ((DomainValueListPreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
								} else {
									domainId = ((DomainValuePreferences) attributeService.getAttribute(attributeId).getDefaultValuePreference()).getDomainId();
								}

								value = String.valueOf(archiveRestoreUtility.getDomainValueId(domainId, value));
							}
						}
						componentAttributes.add(archiveRestoreUtility.createAttributeValue(attributeId, type, value));
					}
				}
				ArticleComponent articleComponent = new ArticleComponent();
				for (int t = 0; t < componentAttributes.size(); t++) {
					Attribute attribute = attributeService.getAttribute(componentAttributes.get(t).getAttributeId());
					if (attribute.getModificationLevel() == AttributeModificationLevels.SERVER_MODIFIABLE) {
						componentAttributes.remove(t);
						continue;
					}
				}
				articleComponent.setComponentAttributeValues(componentAttributes.toArray(new AttributeValue[0]));
				components.add(articleComponent);
			}
		}
		return components;
	}

	/**
	 * Returns project layouts with their attribute values.
	 * @throws DomainNotFoundException
	 * @throws QppServiceException
	 */
	private ArrayList<Layout> createLayouts(Element versionEle, final String lookupEntityBy) throws DomainNotFoundException, QppServiceException {
		ArrayList<Layout> layoutsList = new ArrayList<Layout>();
		NodeList layoutsElement = versionEle.getElementsByTagName("Layouts");
		if (layoutsElement != null && layoutsElement.getLength() > 0) {
			logger.trace("Creating layouts for asset " + versionEle.getAttribute("VersionName") + ", version id "
					+ Float.valueOf(versionEle.getAttribute("MajorVersionID") + "." + versionEle.getAttribute("MinorVersionID")));

			Element layoutElement = (Element) layoutsElement.item(0);
			long layoutCount = Long.parseLong(layoutElement.getAttribute("LayoutCount"));
			NodeList layouts = layoutElement.getElementsByTagName("Layout");
			for (int n = 0; n < layoutCount; n++) {
				Element layoutNode = (Element) layouts.item(n);
				ArrayList<AttributeValue> layoutAttributes = new ArrayList<AttributeValue>();
				long layoutId = Long.parseLong(layoutNode.getAttribute("layoutID"));
				Element attributesElement = (Element) layoutNode.getElementsByTagName("Attributes").item(0);
				NodeList attributes = attributesElement.getElementsByTagName("Attribute");
				if (attributes != null && attributes.getLength() > 0) {
					for (int p = 0; p < attributes.getLength(); p++) {
						Element attributeNode = (Element) attributes.item(p);
						int type = Integer.parseInt(attributeNode.getAttribute("type"));
						String value = attributeNode.getTextContent();
						long attributeId = Long.parseLong(attributeNode.getAttribute("id"));
						String attributeName = attributeNode.getAttribute("name");

						if (lookupEntityBy.equals(VALUE_BY_NAME)) {
							try {
								/* Overwrite the attribute id using attribute name, as the id may differ across servers. */
								attributeId = attributeService.getAttributeByName(attributeName).getId();
							} catch (AttributeNotFoundException e) {
								logger.trace("Attribute with name: " + attributeName + " does not exist!", e);
								// do not add this attribute
								continue;
							}
						}

						if (attributeId == DefaultAttributes.ORIENTATION) {
							if (value.equals("Landscape"))
								value = String.valueOf(Orientations.LANDSCAPE);
							if (value.equals("Portrait"))
								value = String.valueOf(Orientations.PORTRAIT);
						}
						if (attributeId == DefaultAttributes.CONTENT_TYPE) {
							if (value.equals("Print"))
								value = String.valueOf(DefaultContentTypes.PRINT);
							if (value.equals("Web"))
								value = String.valueOf(DefaultContentTypes.WEB);
							if (value.equals("Interactive"))
								value = String.valueOf(DefaultContentTypes.INTERACTIVE);
							if (value.equals("App Studio"))
								value = String.valueOf(DefaultContentTypes.APP_STUDIO);
						}
						if (attributeId == DefaultAttributes.STORY_DIRECTION) {
							DomainValue[] domainValues = attributeDomainService.getDomainValues(DefaultDomains.STORY_DIRECTIONS);
							for (DomainValue domainValue : domainValues) {
								String domainVal = domainValue.getName();
								if (domainVal.equals(value)) {
									long domainId = domainValue.getId();
									value = String.valueOf(domainId);
								}
							}
						}
						layoutAttributes.add(archiveRestoreUtility.createAttributeValue(attributeId, type, value));
					}
				}
				Layout layout = new Layout();
				layout.setAttributeValues(layoutAttributes.toArray(new AttributeValue[0]));
				layout.setLayoutId(layoutId);
				layoutsList.add(layout);
			}
		}
		return layoutsList;
	}

	/**
	 * Check-in asset to QPP server. 
	 * @throws IOException
	 * @throws AssetNotFoundException
	 * @throws AssetNotLockedException
	 * @throws AssetLockedException
	 * @throws QppServiceException
	 * @throws StreamingException
	 */
	private void checkinAssetVersion(String archivedAssetPath, String assetName, Map<Long, IndexAssetInfo> assetsInfoMap, long assetId,
			long versionElMajorVersion, long versionElMinorVersion, long contentType, AttributeValue[] attributeValues, ArrayList<ArticleComponent> components, ArrayList<Layout> layouts,
			ArrayList<AssetRelation> assetRelations, boolean createMinorVersion, Map<String,IndexAssetInfo> successfulRestores)
			throws IOException, AssetNotFoundException, AssetNotLockedException, AssetLockedException, QppServiceException,
			StreamingException {
		FileInputStream fileStream = null;
		try {
			try {
				assetName = assetName.replaceAll("<|>|:|\"|/|\\\\|\\||\\?|\\*", "_");
				fileStream = new FileInputStream(archivedAssetPath + File.separator + assetName);
			} catch (Exception e) {
				logger.error("Error in checkin asset version.", e);
				throw new RestoreException(RestoreExceptionCodes.ARCHIVED_ASSET_FILE_NOT_FOUND, new String[] { assetName });
			}
			Asset asset = new Asset();
			asset.setAttributeValues(attributeValues);
			if (contentType == DefaultContentTypes.ARTICLE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.ARTICLE, contentType)) {
				asset = new Article();
				asset.setAttributeValues(attributeValues);
				((Article) asset).setArticleComponents(components.toArray(new ArticleComponent[0]));
			} else if (contentType == DefaultContentTypes.QUARK_XPRESS_PROJECT
					|| contentStructureService.isValidAncestor(DefaultContentTypes.QUARK_XPRESS_PROJECT, contentType)
					|| contentType == DefaultContentTypes.QUARK_XPRESS_TEMPLATE
					|| contentStructureService.isValidAncestor(DefaultContentTypes.QUARK_XPRESS_TEMPLATE, contentType)) {
				asset = new com.quark.qpp.core.asset.service.dto.Document();
				asset.setAttributeValues(attributeValues);
				((com.quark.qpp.core.asset.service.dto.Document) asset).setLayouts(layouts.toArray(new Layout[0]));
			}

			// to create the first version do checkinnew, to create revisions do a checkout checkin
			long restoredAssetId = -1;
			IndexAssetInfo assetInfo = assetsInfoMap.get(assetId);
			if (!assetInfo.isAlreadyCheckedin()) {
				// checkin first version
				restoredAssetId = checkinNewAsset(asset, assetRelations.toArray(new AssetRelation[0]), createMinorVersion, fileStream,
						successfulRestores, assetId, versionElMajorVersion, versionElMinorVersion);
				assetInfo.setAssetId(restoredAssetId);
				assetInfo.setAlreadyCheckedin(true);
			} else {
				// case when asset is checked in, and its relations are being restored.
				if (restoredAssetId == -1)
					restoredAssetId = assetInfo.getAssetId();
				// create revision
				checkOutAsset(restoredAssetId);
				asset.setAssetId(restoredAssetId);
				checkinAsset(asset, assetRelations.toArray(new AssetRelation[0]), createMinorVersion, fileStream, successfulRestores, assetId, versionElMajorVersion, versionElMinorVersion);
			}
		} catch (InvalidAttributeValueException e) {
			try {
				if (e.getAdditionalInfo() != null && e.getAdditionalInfo().length > 0) {
					Long attributeId = Long.valueOf(e.getAdditionalInfo()[0]);
					for (int i = 0; i < attributeValues.length; i++) {
						if (attributeValues[i].getAttributeId() == attributeId) {
							Value value = attributeValues[i].getAttributeValue();
							if (value != null && attributeValues[i].getType() == AttributeValueTypes.DOMAIN) {
								DomainValue domainValue = (DomainValue) value;
								e.setAdditionalInfo(new String[] { "Attribute Id:" + attributeId + ";value Id:" + domainValue.getId()
										+ ";value:" + domainValue.getName() });
								throw e;
							}
						}
					}
				}
			} catch (Exception e2) {
				throw e;
			}
		}finally {
			if (fileStream != null)
				fileStream.close();
		}
	}

	private long checkinNewAsset(Asset asset, AssetRelation[] assetRelations, boolean createMinorVersion, InputStream inputStream,
			Map<String,IndexAssetInfo> successfulRestores, long oldAssetId, long oldMajorVersion, long oldMinorVersion) throws AssetNotFoundException, AssetNotLockedException, AssetLockedException,
			QppServiceException, StreamingException {
		long contextId = 0;
		Asset assetCreated = null;
		try {
			if (assetRelations == null)
				contextId = assetService.createNewCheckInContext(asset, createMinorVersion);
			else
				contextId = assetService.createNewCheckInContextWithRelations(asset, createMinorVersion, assetRelations);
			defaultStreamingService.upload(inputStream, contextId);
		} finally {
			if (contextId > 0) {
				assetCreated = assetService.closeContext(contextId);
				logger.trace("Checked in new asset with id : " + assetCreated.getAssetId());
			}
			if (assetCreated != null) {
				long assetId = assetCreated.getAssetId();
				assetService.unlockAsset(assetId);
				// update successfulRestores record
				updateSuccessfulRestoresList(assetId, successfulRestores, oldAssetId, oldMajorVersion, oldMinorVersion);
				return assetId;
			}
		}
		return -1;
	}

	private long checkinAsset(Asset asset, AssetRelation[] assetRelations, boolean createMinorVersion, InputStream inputStream,
			Map<String,IndexAssetInfo> successfulRestores, long oldAssetId, long oldMajorVersion,long oldMinorVerion) throws AssetNotFoundException, AssetNotCheckedOutException,
			AssetCheckedOutByAnotherUserException, InvalidAttributeValueException, StorageRuleNotFoundException,
			InvalidRepositoryException, AssetNotLockedException, MinorVersionNotSupportedException, RelationTypeNotFoundException,
			AssetRelationNotFoundException, CannotDeleteAttachedComponentException, QppServiceException, StreamingException {
		boolean assetLocked = false;
		long contextId = 0;
		Asset assetCreated = null;
		try {
			assetService.lockAsset(asset.getAssetId());
			assetLocked = true;
			if (assetRelations == null)
				contextId = assetService.createCheckInContext(asset, createMinorVersion);
			else
				contextId = assetService.createCheckInContextWithRelations(asset, createMinorVersion, assetRelations);
			defaultStreamingService.upload(inputStream, contextId);
		} finally {
			if (contextId > 0) {
				assetCreated = assetService.closeContext(contextId);
				logger.trace("Checked in new asset version for asset id: " + asset.getAssetId());
			}
			if (assetLocked)
				assetService.unlockAsset(asset.getAssetId());
			if (assetCreated != null) {
				// update successfulRestores record
				updateSuccessfulRestoresList(asset.getAssetId(), successfulRestores, oldAssetId, oldMajorVersion, oldMinorVerion);
				return assetCreated.getAssetId();
			}
		}
		return -1;
	}

	private void checkOutAsset(long assetId) throws AssetNotFoundException, AssetNotLockedException, InvalidAttributeValueException,
			AssetAlreadyCheckedOutException, RepositoryActionException, QppServiceException {
		try {
			assetService.lockAsset(assetId);
			// Mark project as checked out on the server by setting the checkout-related attribute values
			AttributeValue path = archiveRestoreUtility.createAttributeValue(DefaultAttributes.CHECKED_OUT_FILE_PATH,
					AttributeValueTypes.TEXT, ".");
			AttributeValue name = archiveRestoreUtility.createAttributeValue(DefaultAttributes.CHECKED_OUT_APPLICATION,
					AttributeValueTypes.TEXT, "QPP RestoreFacade");
			AttributeValue[] attributeValues = new AttributeValue[] { path, name };
			assetService.checkOut(assetId, attributeValues);
			logger.trace("Checked out asset with id: " + assetId);
		} finally {
			assetService.unlockAsset(assetId);
		}
	}

	private String printLogFile(int indexAssetsLength, Map<String, String> failedRestores, String archivedPath,
			ArrayList<String> skippedAssets, Map<String,IndexAssetInfo> successfulRestores) {
		FileOutputStream fileOutputStream = null;
		try {
			File file = new File(archivedPath + File.separator + "RestoreSummary.log");
			fileOutputStream = new FileOutputStream(file);

			StringBuilder sb = new StringBuilder();
			sb.append("\n\n" + "Restore Summary Log" + "\n\n");

			// format current date to the desired format
			SimpleDateFormat formatter = new SimpleDateFormat("M/dd/yy HH:mm a");
			String outputText = formatter.format(new Date());
			Date date = formatter.parse(outputText);
			sb.append("Date: " + formatter.format(date) + "\n");

			sb.append("Archive location: " + archivedPath + "\n\n");

			sb.append("Total assets (and versions) to be restored: " + indexAssetsLength + "\n");
			sb.append("Number of successful restores: " + successfulRestores.size() + "\n");
			sb.append("Number of failed restores: " + failedRestores.size() + "\n");
			sb.append("Number of assets skipped: " + skippedAssets.size() + "\n");
			if (successfulRestores.size() != 0) {
				sb.append("-----------------------------------------------------------" + "\n");
				sb.append("List of Assets Successfully Restored: " + "\n");
				sb.append("-----------------------------------------------------------" + "\n");
				for (IndexAssetInfo assetInfo : successfulRestores.values()) {
					sb.append("&nbsp; &nbsp;" + assetInfo.getAssetPath() + ", Version: " + assetInfo.getAssetVersions()[0].getMajorVersion()+"."+assetInfo.getAssetVersions()[0].getMinorVersion()
							+ "\n");
				}
			}
			if (failedRestores.size() != 0) {
				sb.append("-----------------------------------------------------------" + "\n");
				sb.append("List of Assets Failed to Restore: " + "\n");
				sb.append("-----------------------------------------------------------" + "\n");
				for (Map.Entry<String, String> entry : failedRestores.entrySet()) {
					sb.append("&nbsp; &nbsp;" + entry.getKey() + " \n &nbsp; &nbsp;Reason: " + entry.getValue() + "\n");
				}
			}
			if (skippedAssets.size() != 0) {
				sb.append("-----------------------------------------------------------" + "\n");
				sb.append("List of Assets Skipped during Restore: " + "\n");
				sb.append("-----------------------------------------------------------" + "\n");
				for (String assetPath : skippedAssets) {
					sb.append("&nbsp; &nbsp;" + assetPath + " \n");
				}
			}
			sb.append("\n");

			String logText = sb.toString();
			fileOutputStream.write(logText.getBytes());
			return logText;
		} catch (IOException e) {
			logger.error("Unable to write summary log file.", e);
			String message = "Unable to write summary log file." + "\n";
			return message + e.getMessage();
		} catch (ParseException e) {
			logger.error("Unable to write summary log file.", e);
			String message = "Unable to write summary log file." + "\n";
			return message + e.getMessage();
		} finally {
			if (fileOutputStream != null)
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					logger.error("Exception occured in writing RestoreSummary.log file: ", e);
				}
		}
	}

	private void updateSuccessfulRestoresList(long assetId, Map<String,IndexAssetInfo> successfulRestores, long oldAssetId, long oldMajorVersion, long oldMinorVersion) throws AssetNotFoundException,
			InvalidAttributeException, QppServiceException {
		String assetPath = archiveRestoreUtility.getAssetPath(assetId);
		IndexAssetInfo assetInfo = new IndexAssetInfo(assetId, assetPath);

		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.MAJOR_VERSION,
				DefaultAttributes.MINOR_VERSION });
		int majorVersion = (int)((NumericValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.MAJOR_VERSION,attributeValues)).getValue();
		int minorVersion = (int)((NumericValue) archiveRestoreUtility.getAttributeValue(DefaultAttributes.MINOR_VERSION, attributeValues)).getValue();
		IndexAssetVersion version = new IndexAssetVersion();
		version.setMajorVersion(majorVersion);
		version.setMinorVersion(minorVersion);
		assetInfo.setAssetVersions(new IndexAssetVersion[] { version });
		
		String oldAssetId_version = oldAssetId+"."+oldMajorVersion+"."+oldMinorVersion;
		
		successfulRestores.put(oldAssetId_version, assetInfo);
	}

	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 *
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceExceptionInfo.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}

	/**
	 * This class contains the asset information for every asset that is to be restored.
	 *
	 */
	public class IndexAssetInfo {

		private long assetId;
		private String assetPath;
		private boolean isAlreadyCheckedin = false;
		private IndexAssetVersion[] assetVersions;

		/**
		 * Parameterized constructor.
		 *
		 * @param assetId
		 * @param assetPath
		 */
		public IndexAssetInfo(long assetId, String assetPath) {
			this.assetId = assetId;
			this.assetPath = assetPath;
		}

		/**
		 * Parameterized constructor.
		 *
		 * @param assetId
		 */
		public IndexAssetInfo(long assetId) {
			this.assetId = assetId;
		}

		/**
		 * Default constructor.
		 */
		public IndexAssetInfo() {
		}

		/**
		 *
		 * @return assetId
		 */
		public long getAssetId() {
			return assetId;
		}

		/**
		 *
		 * @param assetId
		 */
		public void setAssetId(long assetId) {
			this.assetId = assetId;
		}

		/**
		 *
		 * @return assetPath
		 */
		public String getAssetPath() {
			return assetPath;
		}

		/**
		 *
		 * @param assetPath
		 */
		public void setAssetPath(String assetPath) {
			this.assetPath = assetPath;
		}

		/**
		 *
		 * @return isAlreadyCheckedin
		 */
		public boolean isAlreadyCheckedin() {
			return isAlreadyCheckedin;
		}

		/**
		 *
		 * @param isAlreadyCheckedin
		 */
		public void setAlreadyCheckedin(boolean isAlreadyCheckedin) {
			this.isAlreadyCheckedin = isAlreadyCheckedin;
		}

		/**
		 *
		 * @return assetVersions
		 */
		public IndexAssetVersion[] getAssetVersions() {
			return assetVersions;
		}

		/**
		 *
		 * @param assetVersions
		 */
		public void setAssetVersions(IndexAssetVersion[] assetVersions) {
			this.assetVersions = assetVersions;
		}

		@Override
		public boolean equals(Object assetInfo2) {
			if (!(assetInfo2 instanceof IndexAssetInfo))
				return false;
			IndexAssetInfo assetInfoObj = (IndexAssetInfo) assetInfo2;
			return (assetId == assetInfoObj.assetId);
		}
	}

	/**
	 * This class contains information regarding a particular asset version and the path to its high res file.
	 *
	 */
	public class IndexAssetVersion {

		private Integer minorVersion;
		private Integer majorVersion;
		private String path;

		/**
		 *
		 * @return path
		 */
		public String getPath() {
			return path;
		}

		/**
		 *
		 * @param path
		 */
		public void setPath(String path) {
			this.path = path;
		}

		public Integer getMinorVersion() {
			return minorVersion;
		}

		public void setMinorVersion(Integer minorVersion) {
			this.minorVersion = minorVersion;
		}

		public Integer getMajorVersion() {
			return majorVersion;
		}

		public void setMajorVersion(Integer majorVersion) {
			this.majorVersion = majorVersion;
		}
		
	}

	/**
	 * This class will be used to sort the IndexAssetVersion array in an IndexAssetInfo object based on the 'version' field.
	 *
	 */
	public class AssetVersionComparator implements Comparator<IndexAssetVersion> {

		@Override
		public int compare(IndexAssetVersion assetVersion1, IndexAssetVersion assetVersion2) {
			int majorVersionCompareResult = assetVersion1.getMajorVersion().compareTo(assetVersion2.getMajorVersion());
			return majorVersionCompareResult == 0 ? assetVersion1.getMinorVersion().compareTo(assetVersion2.getMinorVersion()) : majorVersionCompareResult;
		}
	}

}
@XmlRootElement(name = "channelparams")
@XmlAccessorType(XmlAccessType.FIELD)
class ParamsMap {
	public TreeMap<String, String> treeMap;
}

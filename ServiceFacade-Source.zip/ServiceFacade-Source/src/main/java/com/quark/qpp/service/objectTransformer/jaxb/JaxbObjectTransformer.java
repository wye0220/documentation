/*****************************************************************************
 ** Quark Publishing
 **
 ** �1986-2014 Quark Software Inc. All rights reserved.
 **
 *****************************************************************************/
package com.quark.qpp.service.objectTransformer.jaxb;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.quark.qpp.common.dto.BinaryValue;
import com.quark.qpp.common.dto.BooleanValue;
import com.quark.qpp.common.dto.DateTimeValue;
import com.quark.qpp.common.dto.DateValue;
import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.dto.DomainValueList;
import com.quark.qpp.common.dto.MeasurementValue;
import com.quark.qpp.common.dto.NameValue;
import com.quark.qpp.common.dto.NumericValue;
import com.quark.qpp.common.dto.RgbColor;
import com.quark.qpp.common.dto.TextValue;
import com.quark.qpp.common.dto.TimeValue;
import com.quark.qpp.common.dto.Value;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.common.utility.StackTraceUtility;
import com.quark.qpp.core.asset.service.dto.Article;
import com.quark.qpp.core.asset.service.dto.ArticleComponent;
import com.quark.qpp.core.asset.service.dto.Asset;
import com.quark.qpp.core.asset.service.dto.AssetRelation;
import com.quark.qpp.core.asset.service.dto.AssetRendition;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.dto.Document;
import com.quark.qpp.core.asset.service.dto.Layout;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.local.AssetService;
import com.quark.qpp.core.attribute.service.constants.AttributeModificationLevels;
import com.quark.qpp.core.attribute.service.constants.AttributeValueTypes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.Attribute;
import com.quark.qpp.core.attribute.service.dto.AttributeDomain;
import com.quark.qpp.core.attribute.service.dto.AttributeValue;
import com.quark.qpp.core.attribute.service.dto.AttributeValuePreferences;
import com.quark.qpp.core.attribute.service.dto.BooleanValuePreferences;
import com.quark.qpp.core.attribute.service.dto.DateTimeValuePreferences;
import com.quark.qpp.core.attribute.service.dto.DateValuePreferences;
import com.quark.qpp.core.attribute.service.dto.DomainValueListPreferences;
import com.quark.qpp.core.attribute.service.dto.DomainValuePreferences;
import com.quark.qpp.core.attribute.service.dto.MeasurementValuePreferences;
import com.quark.qpp.core.attribute.service.dto.NumericValuePreferences;
import com.quark.qpp.core.attribute.service.dto.TextValuePreferences;
import com.quark.qpp.core.attribute.service.dto.TimeValuePreferences;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidAttributeExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidAttributeValueExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.DomainValueNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.local.AttributeDomainService;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.clipboard.dto.ClipboardChannelMapping;
import com.quark.qpp.core.clipboard.dto.ClipboardChannelParameter;
import com.quark.qpp.core.clipboard.dto.ClipboardFormat;
import com.quark.qpp.core.clipboard.dto.ClipboardDataInfo;
import com.quark.qpp.core.collection.service.constants.RoutingTypes;
import com.quark.qpp.core.collection.service.dto.Collection;
import com.quark.qpp.core.collection.service.dto.CollectionGroup;
import com.quark.qpp.core.collection.service.dto.CollectionInfo;
import com.quark.qpp.core.collection.service.dto.CollectionUser;
import com.quark.qpp.core.collection.service.dto.JobJacket;
import com.quark.qpp.core.collection.service.dto.RevisionControl;
import com.quark.qpp.core.collection.service.dto.Routing;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidCollectionExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.configuration.service.dto.CustomXmlMimeType;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentType;
import com.quark.qpp.core.content.service.dto.ContentTypeAttributeMapping;
import com.quark.qpp.core.content.service.dto.ContentTypeInfo;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.form.service.dto.Form;
import com.quark.qpp.core.preference.service.constants.FavoriteTypes;
import com.quark.qpp.core.preference.service.constants.PreferenceConstants;
import com.quark.qpp.core.preference.service.dto.FavoriteItem;
import com.quark.qpp.core.preference.service.dto.Preference;
import com.quark.qpp.core.preference.service.dto.PreferenceValue;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceException;
import com.quark.qpp.core.preference.service.exceptions.InvalidPreferenceValueException;
import com.quark.qpp.core.preference.service.exceptions.PreferenceNotFoundException;
import com.quark.qpp.core.preference.service.local.PreferenceService;
import com.quark.qpp.core.privilege.service.dto.ApplicablePrivileges;
import com.quark.qpp.core.privilege.service.dto.ContentTypePrivileges;
import com.quark.qpp.core.privilege.service.dto.PrivilegeDefinition;
import com.quark.qpp.core.privilege.service.dto.PrivilegeGroupDefinition;
import com.quark.qpp.core.privilege.service.dto.StatusPrivileges;
import com.quark.qpp.core.privilege.service.dto.UserClass;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeGroupNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.InvalidPrivilegeExceptionCodes;
import com.quark.qpp.core.privilege.service.local.PrivilegeService;
import com.quark.qpp.core.privilege.service.local.UserClassService;
import com.quark.qpp.core.publishing.service.dto.PublishingChannel;
import com.quark.qpp.core.publishing.service.dto.PublishingParameter;
import com.quark.qpp.core.query.service.constants.ConditionTypes;
import com.quark.qpp.core.query.service.constants.DefaultDisplayModes;
import com.quark.qpp.core.query.service.constants.ExploreModeTypes;
import com.quark.qpp.core.query.service.constants.QueryConstants;
import com.quark.qpp.core.query.service.constants.QueryConstants.PopupOperators;
import com.quark.qpp.core.query.service.constants.QueryResultElementTypes;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.AssignmentCondition;
import com.quark.qpp.core.query.service.dto.AttachmentCondition;
import com.quark.qpp.core.query.service.dto.AttributeCondition;
import com.quark.qpp.core.query.service.dto.AttributeTextSearchCondition;
import com.quark.qpp.core.query.service.dto.BooleanAttributeCondition;
import com.quark.qpp.core.query.service.dto.CollectionElement;
import com.quark.qpp.core.query.service.dto.ContentTypeCondition;
import com.quark.qpp.core.query.service.dto.DateAttributeCondition;
import com.quark.qpp.core.query.service.dto.DateTimeAttributeCondition;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.GroupingInfo;
import com.quark.qpp.core.query.service.dto.MeasureAttributeCondition;
import com.quark.qpp.core.query.service.dto.NumericAttributeCondition;
import com.quark.qpp.core.query.service.dto.PopupAttributeCondition;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.SortInfo;
import com.quark.qpp.core.query.service.dto.StatusCondition;
import com.quark.qpp.core.query.service.dto.StringAttributeCondition;
import com.quark.qpp.core.query.service.dto.SubQueryCondition;
import com.quark.qpp.core.query.service.dto.TextSearchCondition;
import com.quark.qpp.core.query.service.dto.TimeAttributeCondition;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.relation.service.constants.RelationStates;
import com.quark.qpp.core.relation.service.dto.RelationType;
import com.quark.qpp.core.relation.service.dto.RelationTypeAttributeMapping;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.relation.service.local.RelationService;
import com.quark.qpp.core.security.service.dto.Group;
import com.quark.qpp.core.security.service.dto.ImportedGroupInfo;
import com.quark.qpp.core.security.service.dto.Session;
import com.quark.qpp.core.security.service.dto.Trustee;
import com.quark.qpp.core.security.service.dto.User;
import com.quark.qpp.core.security.service.exceptions.GroupNotFoundException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.storage.service.constants.RepositoryStatuses;
import com.quark.qpp.core.storage.service.dto.StorageRepository;
import com.quark.qpp.core.storage.service.dto.StorageRepositoryType;
import com.quark.qpp.core.storage.service.local.StorageService;
import com.quark.qpp.core.userprovisioning.service.constants.DefaultLdapAttributes;
import com.quark.qpp.core.userprovisioning.service.constants.LdapSearchTypes;
import com.quark.qpp.core.userprovisioning.service.dto.LdapAttributeValue;
import com.quark.qpp.core.userprovisioning.service.dto.LdapProfile;
import com.quark.qpp.core.userprovisioning.service.dto.LdapQueryDefinition;
import com.quark.qpp.core.userprovisioning.service.dto.LdapServerInfo;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.userprovisioning.service.local.UserProvisioningService;
import com.quark.qpp.core.workflow.service.dto.AttributeConstraint;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.StatusRoutingUserClasses;
import com.quark.qpp.core.workflow.service.dto.StatusTransition;
import com.quark.qpp.core.workflow.service.dto.UserRedliningColor;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.local.WorkflowService;
import com.quark.qpp.office.service.dto.Chart;
import com.quark.qpp.office.service.dto.NamedRange;
import com.quark.qpp.office.service.dto.PowerPointSlide;
import com.quark.qpp.office.service.dto.Table;
import com.quark.qpp.office.service.dto.VisioPage;
import com.quark.qpp.office.service.dto.Worksheet;
import com.quark.qpp.scheduler.service.dto.Schedule;
import com.quark.qpp.scheduler.service.exceptions.ScheduleNotFoundException;
import com.quark.qpp.scheduler.service.local.SchedulerService;
import com.quark.qpp.script.service.constants.TriggerTypes;
import com.quark.qpp.script.service.dto.Script;
import com.quark.qpp.script.service.dto.ScriptExecutionDetails;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.AttributeUtility;
import com.quark.qpp.service.utility.CommonUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.*;
import com.quark.qpp.service.xmlBinding.LdapSearchCriteria.SearchType;
import com.quark.qpp.service.xmlBinding.PreferenceInfo.Category;
import com.quark.qpp.service.xmlBinding.PreferenceInfo.DefaultValue;
import com.quark.qpp.service.xmlBinding.QueryCondition.SearchAttribute;
import com.quark.qpp.service.xmlBinding.QueryCondition.SearchValue;
import com.quark.qpp.service.xmlBinding.RedlineInfo.Color;
import com.quark.qpp.service.xmlBinding.ScriptInfo.Creator;
import com.quark.qpp.service.xmlBinding.ScriptInfo.LastModifiedBy;
import com.quark.qpp.service.xmlBinding.SearchInfo.Owner;

/**
 * 
 * Provides JAXB complaint implementation of {@link ObjectTransformer}
 * 
 */
public class JaxbObjectTransformer implements ObjectTransformer {

	@Autowired
	private AttributeService attributeService;

	@Autowired
	private AssetService assetService;

	@Autowired
	private AttributeDomainService attributeDomainService;

	@Autowired
	private RelationService relationService;
	
	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private TrusteeService trusteeService;

	@Autowired
	private CollectionService collectionService;

	@Autowired
	private ContentStructureService contentStructureService;

	@Autowired
	private UserClassService userClassService;

	@Autowired
	private QueryService queryService;

	@Autowired
	private PrivilegeService privilegeService;

	@Autowired
	private StorageService storageService;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private AttributeUtility attributeUtility;
	
	@Autowired
	private PreferenceService preferenceService;

	@Autowired
	private UserProvisioningService userProvisioningService;
	
	@Autowired
	private SchedulerService schedulerService;
	
	private Logger logger = Logger.getLogger(JaxbObjectTransformer.class);
	
	private String VALUE_SEPARATOR = ";";

	private Map<Integer, String> conditionTypeMap;
	private Map<Integer, String> logicalOperatorMap;
	private Map<Integer, String> stringOperatorsMap;
	private Map<Integer, String> numericOperatorsMap;
	private Map<Integer, String> popupOperatorsMap;
	private Map<Integer, String> dateOperatorsMap;
	private Map<Integer, String> measurementOperatorsMap;
	private Map<Integer, String> statusOperatorsMap;
	private Map<Integer, String> exploreModesMap;
	private Map<Integer, String> displayModesMap;
	private Map<Integer, String> ldapSearchTypesMap;

	public JaxbObjectTransformer() {
		/** Load condition type map */
		conditionTypeMap = new HashMap<Integer, String>();
		conditionTypeMap.put(ConditionTypes.STRING_ATTR_CONDITION, "STRING_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.DATE_ATTR_CONDITION, "DATE_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.TIME_ATTR_CONDITION, "TIME_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.NUMBER_ATTR_CONDITION, "NUMBER_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.MEASURE_ATTR_CONDITION, "MEASURE_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.BOOLEAN_ATTR_CONDITION, "BOOLEAN_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.POPUP_ATTR_CONDITION, "POPUP_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.SUB_QUERY_CONDITION, "SUB_QUERY_CONDITION");
		conditionTypeMap.put(ConditionTypes.DATETIME_ATTR_CONDITION, "DATETIME_ATTR_CONDITION");
		conditionTypeMap.put(ConditionTypes.STATUS_CONDITION, "STATUS_CONDITION");
		conditionTypeMap.put(ConditionTypes.ATTACHMENT_CONDITION, "ATTACHMENT_CONDITION");
		conditionTypeMap.put(ConditionTypes.ASSIGNMENT_CONDITION, "ASSIGNMENT_CONDITION");
		conditionTypeMap.put(ConditionTypes.TEXT_SEARCH_CONDITION, "TEXT_SEARCH_CONDITION");
		conditionTypeMap.put(ConditionTypes.ATTRIBUTE_TEXT_SEARCH_CONDITION, "ATTRIBUTE_TEXT_SEARCH_CONDITION");
		conditionTypeMap.put(ConditionTypes.CONTENT_TYPE_CONDITION, "CONTENT_TYPE_CONDITION");

		/** Load logical operator map */
		logicalOperatorMap = new HashMap<Integer, String>();
		logicalOperatorMap.put(QueryConstants.LogicalOperators.AND, "AND");
		logicalOperatorMap.put(QueryConstants.LogicalOperators.OR, "OR");

		/** Load string operator map */
		stringOperatorsMap = new HashMap<Integer, String>();
		stringOperatorsMap.put(QueryConstants.StringOperators.IS, "IS");
		stringOperatorsMap.put(QueryConstants.StringOperators.IS_LESS, "IS_LESS");
		stringOperatorsMap.put(QueryConstants.StringOperators.IS_GREATER, "IS_GREATER");
		stringOperatorsMap.put(QueryConstants.StringOperators.CONTAINS, "CONTAINS");
		stringOperatorsMap.put(QueryConstants.StringOperators.STARTS_WITH, "STARTS_WITH");
		stringOperatorsMap.put(QueryConstants.StringOperators.ENDS_WITH, "ENDS_WITH");
		stringOperatorsMap.put(QueryConstants.StringOperators.IS_GREATER_OR_EQUAL, "IS_GREATER_OR_EQUAL");
		stringOperatorsMap.put(QueryConstants.StringOperators.IS_LESS_OR_EQUAL, "IS_LESS_OR_EQUAL");
		stringOperatorsMap.put(QueryConstants.StringOperators.MATCHES, "MATCHES");
		stringOperatorsMap.put(QueryConstants.StringOperators.IS_DEFINED, "IS_DEFINED");

		/** Load Numeric operator map */
		numericOperatorsMap = new HashMap<Integer, String>();
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS, "IS");
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS_LESS, "IS_LESS");
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS_GREATER, "IS_GREATER");
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS_GREATER_OR_EQUAL, "IS_GREATER_OR_EQUAL");
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS_LESS_OR_EQUAL, "IS_LESS_OR_EQUAL");
		numericOperatorsMap.put(QueryConstants.NumericOperators.IS_DEFINED, "IS_DEFINED");

		/** Load popup operator map */
		popupOperatorsMap = new HashMap<Integer, String>();
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS, "IS");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_LESS, "IS_LESS");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_GREATER, "IS_GREATER");
		popupOperatorsMap.put(QueryConstants.PopupOperators.CONTAINS, "CONTAINS");
		popupOperatorsMap.put(QueryConstants.PopupOperators.STARTS_WITH, "STARTS_WITH");
		popupOperatorsMap.put(QueryConstants.PopupOperators.ENDS_WITH, "ENDS_WITH");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_GREATER_OR_EQUAL, "IS_GREATER_OR_EQUAL");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_LESS_OR_EQUAL, "IS_LESS_OR_EQUAL");
		popupOperatorsMap.put(QueryConstants.PopupOperators.MATCHES, "MATCHES");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_DEFINED, "IS_DEFINED");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_BEFORE, "IS_BEFORE");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_AFTER, "IS_AFTER");
		popupOperatorsMap.put(QueryConstants.PopupOperators.IS_UNDER, "IS_UNDER");

		/** Load date operator map */
		dateOperatorsMap = new HashMap<Integer, String>();
		dateOperatorsMap.put(QueryConstants.DateOperators.IS, "IS");
		dateOperatorsMap.put(QueryConstants.DateOperators.IS_BEFORE, "IS_BEFORE");
		dateOperatorsMap.put(QueryConstants.DateOperators.IS_AFTER, "IS_AFTER");
		dateOperatorsMap.put(QueryConstants.DateOperators.IS_BEFORE_OR_EQUAL, "IS_BEFORE_OR_EQUAL");
		dateOperatorsMap.put(QueryConstants.DateOperators.IS_AFTER_OR_EQUAL, "IS_AFTER_OR_EQUAL");
		dateOperatorsMap.put(QueryConstants.DateOperators.IS_DEFINED, "IS_DEFINED");

		/** Load measurement operator map */
		measurementOperatorsMap = new HashMap<Integer, String>();
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS, "IS");
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS_LESS, "IS_LESS");
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS_LESS_OR_EQUAL, "IS_LESS_OR_EQUAL");
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS_GREATER, "IS_GREATER");
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS_GREATER_OR_EQUAL, "IS_GREATER_OR_EQUAL");
		measurementOperatorsMap.put(QueryConstants.MeasurementOperators.IS_DEFINED, "IS_DEFINED");

		/** Load status operator map */
		statusOperatorsMap = new HashMap<Integer, String>();
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS, "IS");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_LESS, "IS_LESS");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_GREATER, "IS_GREATER");
		statusOperatorsMap.put(QueryConstants.StatusOperators.CONTAINS, "CONTAINS");
		statusOperatorsMap.put(QueryConstants.StatusOperators.STARTS_WITH, "STARTS_WITH");
		statusOperatorsMap.put(QueryConstants.StatusOperators.ENDS_WITH, "ENDS_WITH");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_GREATER_OR_EQUAL, "IS_GREATER_OR_EQUAL");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_LESS_OR_EQUAL, "IS_LESS_OR_EQUAL");
		statusOperatorsMap.put(QueryConstants.StatusOperators.MATCHES, "MATCHES");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_DEFINED, "IS_DEFINED");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_BEFORE, "IS_BEFORE");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_OR_BEFORE, "IS_OR_BEFORE");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_AFTER, "IS_AFTER");
		statusOperatorsMap.put(QueryConstants.StatusOperators.IS_OR_AFTER, "IS_OR_AFTER");

		exploreModesMap = new HashMap<Integer, String>();
		exploreModesMap.put(ExploreModeTypes.COLLECTIONS, "COLLECTIONS");
		exploreModesMap.put(ExploreModeTypes.PLAIN, "PLAIN");
		exploreModesMap.put(ExploreModeTypes.PROJECT, "PROJECT");
		exploreModesMap.put(ExploreModeTypes.PROJECT_LAYOUT_PAGE, "PROJECT_LAYOUT_PAGE");
		exploreModesMap.put(ExploreModeTypes.RELATED_ASSETS, "RELATED_ASSETS");
		exploreModesMap.put(ExploreModeTypes.RELATION, "RELATION");

		displayModesMap = new HashMap<Integer, String>();
		displayModesMap.put(DefaultDisplayModes.DEFAULT, "DEFAULT");
		displayModesMap.put(DefaultDisplayModes.DETAILED_THUMBNAIL, "DETAILED_THUMBNAIL");
		displayModesMap.put(DefaultDisplayModes.FILMSTRIP, "FILMSTRIP");
		displayModesMap.put(DefaultDisplayModes.ICON, "ICON");
		displayModesMap.put(DefaultDisplayModes.PLAIN, "PLAIN");
		displayModesMap.put(DefaultDisplayModes.SNIPPET, "SNIPPET");
		displayModesMap.put(DefaultDisplayModes.THUMBNAIL, "THUMBNAIL");
		
		ldapSearchTypesMap = new HashMap<Integer, String>();
		ldapSearchTypesMap.put(LdapSearchTypes.GROUPS_SEARCH, "GROUPS_SEARCH");
		ldapSearchTypesMap.put(LdapSearchTypes.USERS_SEARCH, "USERS_SEARCH");
	}

	public AttributeValueList transform(AttributeValue[] attributeValues) throws AttributeNotFoundException, QppServiceException {

		AttributeValueList attributeValuesList = new AttributeValueList();
		for (AttributeValue attributeValue : attributeValues) {
			com.quark.qpp.service.xmlBinding.AttributeValue[] transformedAttrValues = transform(attributeValue);
			for (int i = 0; i < transformedAttrValues.length; i++) {
				attributeValuesList.getAttributeValue().add(transformedAttrValues[i]);
			}
		}
		return attributeValuesList;
	}

	public AssetInfo transform(com.quark.qpp.core.asset.service.dto.Asset asset) throws AttributeNotFoundException, QppServiceException {
		AssetInfo assetInfo = new AssetInfo();
		assetInfo.setId(asset.getAssetId());
		if (asset.getAssetVersion() != null) {
			assetInfo.setAssetVersion(transform(asset.getAssetVersion()));
		}
		AttributeValueList attributeValues = transform(asset.getAttributeValues());
		assetInfo.setAttributeValueList(attributeValues);
		if (Article.class.isInstance(asset)) {
			ArticleComponentInfoList articleComponentInfoList = transform(((Article) asset).getArticleComponents());
			assetInfo.setArticleComponentInfoList(articleComponentInfoList);
			assetInfo.setLayoutInfoList(null);
		} else if (Document.class.isInstance(asset)) {
			LayoutInfoList layoutInfoList = transform(((Document) asset).getLayouts());
			assetInfo.setLayoutInfoList(layoutInfoList);
			assetInfo.setArticleComponentInfoList(null);
		}
		return assetInfo;
	}

	private LayoutInfoList transform(Layout[] layouts) throws AttributeNotFoundException, QppServiceException {
		LayoutInfoList layoutInfoList = new LayoutInfoList();
		for (int i = 0; i < layouts.length; i++) {
			LayoutInfo layoutInfo = transform(layouts[i]);
			layoutInfoList.getLayoutInfo().add(layoutInfo);
		}
		return layoutInfoList;
	}

	private LayoutInfo transform(Layout layout) throws AttributeNotFoundException, QppServiceException {
		LayoutInfo layoutInfo = new LayoutInfo();
		layoutInfo.setAttributeValueList(transform(layout.getAttributeValues()));
		layoutInfo.setLayoutId(layout.getLayoutId());
		return layoutInfo;
	}

	private ArticleComponentInfoList transform(ArticleComponent[] articleComponents) throws AttributeNotFoundException, QppServiceException {
		ArticleComponentInfoList articleComponentInfoList = new ArticleComponentInfoList();
		for (int i = 0; i < articleComponents.length; i++) {
			ArticleComponentInfo articleComponentInfo = transform(articleComponents[i]);
			articleComponentInfoList.getArticleComponentInfo().add(articleComponentInfo);
		}
		return articleComponentInfoList;
	}

	private ArticleComponentInfo transform(ArticleComponent articleComponent) throws AttributeNotFoundException, QppServiceException {
		ArticleComponentInfo articleComponentInfo = new ArticleComponentInfo();
		articleComponentInfo.setAttributeValueList(transform(articleComponent.getComponentAttributeValues()));
		articleComponentInfo.setComponentId(articleComponent.getComponentId());
		return articleComponentInfo;
	}

	public AssetInfoList transform(Asset[] assets) throws AttributeNotFoundException, QppServiceException {
		AssetInfoList assetInfoList = new AssetInfoList();
		for (Asset asset : assets) {
			assetInfoList.getAssetInfo().add(transform(asset));
		}
		return assetInfoList;
	}

	public AssetRelationInfo transform(AssetRelation assetRelation) throws AttributeNotFoundException, QppServiceException {
		AssetRelationInfo relationInfo = new AssetRelationInfo();
		BeanUtils.copyProperties(assetRelation, relationInfo, new String[] { "relationState", "relationAttributes" });
		relationInfo.setRelationType(getRelationTypeString(assetRelation.getRelationTypeId()));
		relationInfo.setRelationTypeId(assetRelation.getRelationTypeId());
		relationInfo.setRelationState(getRelationStateString(assetRelation.getRelationState()));
		relationInfo.setRelationStateId(assetRelation.getRelationState());
		relationInfo.setParentAssetId(assetRelation.getParentAssetId());
		relationInfo.setAttributeValueList(transform(assetRelation.getRelationAttributes()));
		relationInfo.setChildAssetMajorVersion(assetRelation.getChildAssetVersion().getMajorVersion());
		relationInfo.setChildAssetMinorVersion(assetRelation.getChildAssetVersion().getMinorVersion());
		String childAssetName = ((TextValue) assetService.getAttributeValues(assetRelation.getChildAssetId(),
					new long[] { DefaultAttributes.NAME })[0].getAttributeValue()).getValue();
		String paentAssetName = ((TextValue) assetService.getAttributeValues(assetRelation.getParentAssetId(),
				new long[] { DefaultAttributes.NAME })[0].getAttributeValue()).getValue();
		relationInfo.setChildAssetName(childAssetName);
		relationInfo.setParentAssetName(paentAssetName);
		relationInfo.setLockedToChildVersion(assetRelation.isLockedToChildVersion());
		return relationInfo;
	}

	public AssetRelationInfoList transform(AssetRelation[] assetRelations) throws AttributeNotFoundException, QppServiceException {
		AssetRelationInfoList relationInfoList = new AssetRelationInfoList();
		for (AssetRelation assetRelation : assetRelations) {
			relationInfoList.getAssetRelationInfo().add(transform(assetRelation));
		}
		return relationInfoList;
	}

	private com.quark.qpp.service.xmlBinding.AttributeValue[] transform(AttributeValue attributeValue) throws AttributeNotFoundException,
			QppServiceException {
		ArrayList<com.quark.qpp.service.xmlBinding.AttributeValue> multipleAttrValues = new ArrayList<com.quark.qpp.service.xmlBinding.AttributeValue>();
		String attributeValueType = getAttributeTypeString(attributeValue.getType());
		Attribute attribute = attributeService.getAttribute(attributeValue.getAttributeId());
		if (com.quark.qpp.common.dto.DomainValueList.class.isInstance(attributeValue.getAttributeValue())) {
			com.quark.qpp.common.dto.DomainValueList domainValueList = (com.quark.qpp.common.dto.DomainValueList) attributeValue
					.getAttributeValue();
			if (domainValueList != null && domainValueList.getDomainValues() != null && domainValueList.getDomainValues().length > 0) {
				DomainValue[] multipleDomainValues = domainValueList.getDomainValues();
				for (int i = 0; i < multipleDomainValues.length; i++) {
					com.quark.qpp.service.xmlBinding.AttributeValue attrval = new com.quark.qpp.service.xmlBinding.AttributeValue();
					attrval.setId(attributeValue.getAttributeId());
					attrval.setName(attribute.getName());
					attrval.setType(attributeValueType);
					try {
						String valueStr = getDomainValueHierarchy(multipleDomainValues[i]);
						attrval.setValue(valueStr);
					} catch (DomainValueNotFoundException domainValueNotFoundException) {
						// suppress because a deleted user may be in context.
						logger.error("Error while retrieving domain value hierarchy for attribute id "+attributeValue.getAttributeId(), domainValueNotFoundException);
					}
					attrval.setValueId(getValueId(multipleDomainValues[i]));
					attrval.setMultiValued(attributeValue.isMultiValued());
					 attrval.setSourceReference(multipleDomainValues[i].getSourceReference());
					multipleAttrValues.add(attrval);
				}
			}
		} else {
			com.quark.qpp.service.xmlBinding.AttributeValue attrval = new com.quark.qpp.service.xmlBinding.AttributeValue();
			attrval.setId(attributeValue.getAttributeId());
			attrval.setName(attribute.getName());
			attrval.setType(attributeValueType);
			attrval.setValue(getValue(attributeValue));
			if (attributeValue.getType() == AttributeValueTypes.DOMAIN) {
				attrval.setMultiValued(attributeValue.isMultiValued());
				attrval.setValueId(getValueId(attributeValue.getAttributeValue()));
			}
			multipleAttrValues.add(attrval);
		}
		return multipleAttrValues.toArray(new com.quark.qpp.service.xmlBinding.AttributeValue[] {});
	}

	private String getAttributeTypeString(int attributeType) {
		if (attributeType == AttributeValueTypes.BOOLEAN) {
			return "boolean";
		} else if (attributeType == AttributeValueTypes.DATE) {
			return "date";
		}
		if (attributeType == AttributeValueTypes.DATETIME) {
			return "dateTime";
		}
		if (attributeType == AttributeValueTypes.DOMAIN) {
			return "popup";
		}
		if (attributeType == AttributeValueTypes.MEASUREMENT) {
			return "measurement";
		}
		if (attributeType == AttributeValueTypes.NUMERIC) {
			return "numeric";
		}
		if (attributeType == AttributeValueTypes.TEXT) {
			return "text";
		}
		if (attributeType == AttributeValueTypes.TIME) {
			return "time";
		} else
			return "";
	}

	private String getRelationTypeString(long relationTypeId) throws QppServiceException {
		RelationType[] relationTypes = relationService.getAllRelationTypes();
		for (int i = 0; i < relationTypes.length; i++) {
			if (relationTypes[i].getId() == relationTypeId) {
				return relationTypes[i].getName();
			}
		}
		return "";
	}

	private String getRelationStateString(int relationState) {
		if (relationState == RelationStates.PERMANENT) {
			return "Permanent";
		}
		if (relationState == RelationStates.RELATED_TEMPORARILY) {
			return "Related Temporarily";
		}
		if (relationState == RelationStates.RELATION_REMOVED) {
			return "Relation Removed";
		}
		return "";
	}

	private String getValue(AttributeValue attributeValue) throws AttributeNotFoundException, QppServiceException {
		Value value = attributeValue.getAttributeValue();
		Object absoluteValue = "";
		if (MeasurementValue.class.isInstance(value)) {
			MeasurementValue measurementValue = (MeasurementValue) value;
			absoluteValue = measurementValue.getValue();
		} else if (BooleanValue.class.isInstance(value)) {
			BooleanValue booleanValue = (BooleanValue) value;
			absoluteValue = booleanValue.getValue();
		} else if (NumericValue.class.isInstance(value)) {
			NumericValue numericValue = (NumericValue) value;
			absoluteValue = numericValue.getValue();
		} else if (TextValue.class.isInstance(value)) {
			TextValue textValue = (TextValue) value;
			absoluteValue = textValue.getValue();
		} else if (DomainValue.class.isInstance(value)) {
			try {
				absoluteValue = getDomainValueHierarchy((DomainValue) attributeValue.getAttributeValue());
			} catch (DomainValueNotFoundException domainValueNotFoundException) {
				// suppress because a deleted user may be in context.
				logger.debug("Error while retrieving domain value hierarchy for attribute id "+attributeValue.getAttributeId());
			}
		} else if (BinaryValue.class.isInstance(value)) {
			BinaryValue binaryValue = (BinaryValue) value;
			absoluteValue = binaryValue.getValue();
		} else if (TimeValue.class.isInstance(value)) {
			TimeValue timeValue = (TimeValue) value;
			absoluteValue = timeValue.getValue();
		} else if (DateValue.class.isInstance(value)) {
			DateValue dateValue = (DateValue) value;
			absoluteValue = dateValue.getValue();
		} else if (DateTimeValue.class.isInstance(value)) {
			DateTimeValue dateTimeValue = (DateTimeValue) value;
			absoluteValue = dateTimeValue.getValue();
		}
		if (absoluteValue != null) {
			return absoluteValue.toString();
		}
		return null;
	}
	
	/*
	 * Create domain value hierarchy for the given domain value.
	 */
	private String getDomainValueHierarchy(DomainValue domainValue) throws DomainNotFoundException, QppServiceException {
		String valueHierarchy = attributeDomainService.getDomainValueHierarchy(domainValue.getDomainId(), domainValue.getId());
		return valueHierarchy;
	}
	
	/*
	 * Create domain value hierarchy for the attribute id and domain value id.
	 */
	private String getDomainValueHierarchy(long attributeId, long valueId) throws AttributeNotFoundException, QppServiceException {
		Attribute attribute = attributeService.getAttribute(attributeId);
		int domainId = -1;
		if (attribute.isMultiValued()) {
			domainId = ((DomainValueListPreferences) attribute.getDefaultValuePreference()).getDomainId();
		} else {
			domainId = ((DomainValuePreferences) attribute.getDefaultValuePreference()).getDomainId();
		}
		DomainValue domainValue = attributeDomainService.getDomainValue(domainId, valueId);
		return getDomainValueHierarchy(domainValue);
	}

	private long getValueId(Value value) throws AttributeNotFoundException, QppServiceException {
		long valueId = 0;
		if (value instanceof DomainValue) {
			valueId = ((DomainValue) value).getId();
		}
		return valueId;
	}

	public SessionInfo transform(Session session) {
		SessionInfo sessionInfo = new SessionInfo();
		BeanUtils.copyProperties(session, sessionInfo);
		return sessionInfo;
	}

	public SessionInfoList transform(Session[] sessions) {
		SessionInfoList sessionInfoList = new SessionInfoList();
		for (int i = 0; i < sessions.length; i++) {
			sessionInfoList.getSessionInfo().add(transform(sessions[i]));
		}
		return sessionInfoList;
	}

	public AssetVersionList transform(AssetVersion[] assetVersions) {
		AssetVersionList assetVersionList = new AssetVersionList();
		for (int i = 0; i < assetVersions.length; i++) {
			assetVersionList.getAssetVersion().add(transform(assetVersions[i]));
		}
		return assetVersionList;
	}

	private com.quark.qpp.service.xmlBinding.AssetVersion transform(AssetVersion assetVersion) {
		com.quark.qpp.service.xmlBinding.AssetVersion assetVersion_jaxb = new com.quark.qpp.service.xmlBinding.AssetVersion();
		BeanUtils.copyProperties(assetVersion, assetVersion_jaxb);
		return assetVersion_jaxb;
	}

	public AssetRenditionInfoList transform(AssetRendition[] assetRenditions) throws QppServiceException {
		AssetRenditionInfoList assetRenditionInfoList = new AssetRenditionInfoList();
		for (int i = 0; i < assetRenditions.length; i++) {
			assetRenditionInfoList.getAssetRenditionInfo().add(transformAssetRendition(assetRenditions[i]));
		}
		return assetRenditionInfoList;
	}

	private AssetRenditionInfo transformAssetRendition(AssetRendition assetRendition) throws QppServiceException {
		AssetRenditionInfo assetRenditionInfo = new AssetRenditionInfo();
		BeanUtils.copyProperties(assetRendition, assetRenditionInfo, new String[] { "renditionType", "assetVersion" });
		assetRenditionInfo.setMajorVersion(assetRendition.getAssetVersion().getMajorVersion());
		assetRenditionInfo.setMinorVersion(assetRendition.getAssetVersion().getMinorVersion());
		assetRenditionInfo.setRenditionTypeId(assetRendition.getRenditionType());
		assetRenditionInfo.setRenditionType(facadeUtility.getRenditionTypeString(assetRendition.getRenditionType()));
		return assetRenditionInfo;
	}

	@Override
	public AttributeValue[] transform(AttributeValueList attributeValueList) throws AttributeNotFoundException, QppServiceException {
		if (attributeValueList == null) {
			return new AttributeValue[0];
		}
		List<com.quark.qpp.service.xmlBinding.AttributeValue> list = attributeValueList.getAttributeValue();
		HashMap<Long, AttributeValue> map = new HashMap<Long, AttributeValue>();
		//AttributeValue[] attributeValues = new AttributeValue[list.size()];
		for (int i = 0; i < list.size(); i++) {
			com.quark.qpp.service.xmlBinding.AttributeValue attrValue = list.get(i);
			Attribute attribute = null;
			if (attrValue.getName() != null && !attrValue.getName().isEmpty()) {
				attribute = attributeService.getAttributeByName(attrValue.getName());
			} else {
				attribute = attributeService.getAttribute(attrValue.getId());
			}
			int attributeValueType = attribute.getValueType();

			// create new attribute value
			AttributeValue attributeValue = new AttributeValue();
			attributeValue.setAttributeId(attribute.getId());
			attributeValue.setType(attributeValueType);
			String value = (String) attrValue.getValue();
			long valueId = attrValue.getValueId();
			if (value != null && !value.isEmpty()) {
				if (attributeValueType == AttributeValueTypes.BOOLEAN) {
					BooleanValue booleanValue = new BooleanValue(Boolean.parseBoolean(value));
					attributeValue.setAttributeValue(booleanValue);
				} else if (attributeValueType == AttributeValueTypes.DATE) {
					DateValue dateValue = new DateValue(value);
					attributeValue.setAttributeValue(dateValue);
				} else if (attributeValueType == AttributeValueTypes.DATETIME) {
					DateTimeValue dateTimeValue = new DateTimeValue(value);
					attributeValue.setAttributeValue(dateTimeValue);
				} else if (attributeValueType == AttributeValueTypes.DOMAIN) {
					int domainId = -1;
					if (attribute.isMultiValued()) {
						domainId = ((DomainValueListPreferences) attribute.getDefaultValuePreference()).getDomainId();
					} else {
						domainId = ((DomainValuePreferences) attribute.getDefaultValuePreference()).getDomainId();
					}
					DomainValue domainValue = null;
					if (attribute.getId() == DefaultAttributes.COLLECTION) {
						long collectionId = facadeUtility.getCollectionIdForText(value);
						domainValue = collectionService.getCollectionInfo(collectionId);
					} else if (attribute.getId() == DefaultAttributes.CONTENT_TYPE) {
						long contentTypeId = facadeUtility.getContentTypeIdForText(value);
						domainValue = attributeDomainService.getDomainValue(domainId, contentTypeId);
					} else {
						domainValue = facadeUtility.fetchDomainValue(domainId, value, attribute.getId(), list);
					}
					attributeValue.setAttributeValue(domainValue);
					long attributeId = attribute.getId();
					if (attribute.isMultiValued()) {
						AttributeValue attrValueFromMap = map.get(attributeId);
						if (attrValueFromMap == null) {
							DomainValueList domainValueList = new DomainValueList(
									new DomainValue[] { (DomainValue) attributeValue.getAttributeValue() });
							attributeValue.setAttributeValue(domainValueList);
						} else {
							DomainValue[] domainValues = ((DomainValueList) attrValueFromMap.getAttributeValue()).getDomainValues();
							DomainValue[] domainValuesNew = new DomainValue[domainValues.length + 1];
							System.arraycopy(domainValues, 0, domainValuesNew, 0, domainValues.length);
							domainValuesNew[domainValuesNew.length - 1] = (DomainValue) attributeValue.getAttributeValue();
							attributeValue.setAttributeValue(new DomainValueList(domainValuesNew));
						}
						attributeValue.setMultiValued(true);
					}
				} else if (attributeValueType == AttributeValueTypes.MEASUREMENT) {
					MeasurementValue measurementValue = new MeasurementValue(Double.parseDouble(value));
					attributeValue.setAttributeValue(measurementValue);
				} else if (attributeValueType == AttributeValueTypes.NUMERIC) {
					NumericValue numericValue = new NumericValue(Long.parseLong(value));
					attributeValue.setAttributeValue(numericValue);
				} else if (attributeValueType == AttributeValueTypes.TEXT) {
					TextValue textValue = new TextValue(value);
					attributeValue.setAttributeValue(textValue);
				} else if (attributeValueType == AttributeValueTypes.TIME) {
					TimeValue timeValue = new TimeValue(value);
					attributeValue.setAttributeValue(timeValue);
				}
			} else {

				// But in case domain value id has been given there maybe the requirement to set attribute value using the id mentioned in
				// valueId field
				if (attributeValueType == AttributeValueTypes.DOMAIN && valueId > 0) {
					int domainId = -1;
					if (attribute.isMultiValued()) {
						domainId = ((DomainValueListPreferences) attribute.getDefaultValuePreference()).getDomainId();
					} else {
						domainId = ((DomainValuePreferences) attribute.getDefaultValuePreference()).getDomainId();
					}
					DomainValue domainValue = attributeDomainService.getDomainValue(domainId, valueId);
					attributeValue.setAttributeValue(domainValue);
					long attributeId = attribute.getId();
					if (attribute.isMultiValued()) {
						AttributeValue attrValueFromMap = map.get(attributeId);
						if (attrValueFromMap == null) {
							DomainValueList domainValueList = new DomainValueList(
									new DomainValue[] { (DomainValue) attributeValue.getAttributeValue() });
							attributeValue.setAttributeValue(domainValueList);
						} else {
							DomainValue[] domainValues = ((DomainValueList) attrValueFromMap.getAttributeValue()).getDomainValues();
							DomainValue[] domainValuesNew = new DomainValue[domainValues.length + 1];
							System.arraycopy(domainValues, 0, domainValuesNew, 0, domainValues.length);
							domainValuesNew[domainValuesNew.length - 1] = (DomainValue) attributeValue.getAttributeValue();
							attributeValue.setAttributeValue(new DomainValueList(domainValuesNew));
						}
						attributeValue.setMultiValued(true);
					}
				} else {
					/*
					 * do nothing since this may be a scenario where we want to reset the value of an attribute to null. Example to reset
					 * the {@link DefaultAttributes#ROUTED_TO} to no one, the input will be null.
					 */
					}
				
			}
			map.put(attribute.getId(), attributeValue);
		}
		return map.values().toArray(new AttributeValue[]{});
	}
	


	public NameIdList transform(NameId[] nameIds) {
		NameIdList nameIdList = new NameIdList();
		for (int i = 0; i < nameIds.length; i++) {
			nameIdList.getNameId().add(nameIds[i]);
		}
		return nameIdList;
	}

	public AssetRelation[] transform(AssetRelationInfoList assetRelationInfoList) throws AttributeNotFoundException, QppServiceException {
		List<AssetRelationInfo> list = assetRelationInfoList.getAssetRelationInfo();
		AssetRelation[] assetRelations = new AssetRelation[list.size()];
		for (int i = 0; i < list.size(); i++) {
			AssetRelation assetRelation = transform(list.get(i));
			assetRelations[i] = assetRelation;
		}
		return assetRelations;
	}

	private AssetRelation transform(AssetRelationInfo assetRelationInfo) throws AttributeNotFoundException, RelationTypeNotFoundException,
			QppServiceException {
		AssetRelation assetRelation = new AssetRelation();
		assetRelation.setChildAssetId(assetRelationInfo.getChildAssetId());
		assetRelation.setParentAssetId(assetRelationInfo.getParentAssetId());
		boolean lockedToChildVersion = false;
		lockedToChildVersion = assetRelationInfo.isLockedToChildVersion();

		assetRelation.setLockedToChildVersion(lockedToChildVersion);
		Long relationTypeId = assetRelationInfo.getRelationTypeId();
		if (relationTypeId == 0) {
			relationTypeId = facadeUtility.getRelationTypeId(assetRelationInfo.getRelationType());
		}
		assetRelation.setRelationTypeId(relationTypeId);
		if (assetRelationInfo.getChildAssetMajorVersion() > 0 || assetRelationInfo.getChildAssetMinorVersion() > 0) {
			AssetVersion childAssetVersion = new AssetVersion(assetRelationInfo.getChildAssetMajorVersion(),
					assetRelationInfo.getChildAssetMinorVersion());
			assetRelation.setChildAssetVersion(childAssetVersion);
		}
		AttributeValue[] relationAttributes = transform(assetRelationInfo.getAttributeValueList());
		assetRelation.setRelationAttributes(relationAttributes);
		if(assetRelationInfo.getId() == null) {
			assetRelation.setId(0);
		} else {
			assetRelation.setId(assetRelationInfo.getId());
		}
		return assetRelation;
	}

	public AssetRendition[] transform(AssetRenditionInfoList assetRenditionInfoList) throws QppServiceException {
		List<AssetRenditionInfo> list = assetRenditionInfoList.getAssetRenditionInfo();
		AssetRendition[] assetRenditions = new AssetRendition[list.size()];
		for (int i = 0; i < assetRenditions.length; i++) {
			assetRenditions[i] = transform(list.get(i));
		}
		return assetRenditions;
	}

	private AssetRendition transform(AssetRenditionInfo assetRenditionInfo) throws QppServiceException {
		AssetRendition assetRendition = new AssetRendition();
		BeanUtils.copyProperties(assetRenditionInfo, assetRendition, new String[] { "majorVersion", "minorVersion", "renditionType",
				"renditionTypeId" });
		if (assetRenditionInfo.getRenditionTypeId() > 0) {
			assetRendition.setRenditionType(assetRenditionInfo.getRenditionTypeId());
		} else {
			long renditionTypeId = facadeUtility.getRenditionTypeId(assetRenditionInfo.getRenditionType());
			assetRendition.setRenditionType(renditionTypeId);
		}
		assetRendition.setAssetVersion(new AssetVersion(assetRenditionInfo.getMajorVersion(), assetRenditionInfo.getMinorVersion()));

		return assetRendition;
	}

	public QppServiceExceptionInfo transform(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = new QppServiceExceptionInfo();
		qppServiceExceptionInfo.setExceptionCode(qppServiceException.getExceptionCode());
		if (qppServiceException.getAdditionalInfo() != null) {
			AdditionalInfoList additionalInfoList = new AdditionalInfoList();
			for (String addInfo : qppServiceException.getAdditionalInfo()) {
				additionalInfoList.getAdditionalInfo().add(addInfo);
			}
			qppServiceExceptionInfo.setAdditionalInfoList(additionalInfoList);
		}

		StringBuilder sb = new StringBuilder();
		appendStackTrace(qppServiceException, sb, 1);
		qppServiceExceptionInfo.setStackTrace(sb.toString());
		return qppServiceExceptionInfo;
	}
	
	// Append stacktrace of the exception causes to the 3 level of hierarchy
	private void appendStackTrace(Throwable exception, StringBuilder stackTrace, int counter) {
		stackTrace.append(StackTraceUtility.getStackTrace(exception));
		if (exception.getCause() != null && counter <= 3) {
			appendStackTrace(exception.getCause(), stackTrace, counter + 1);
		}
	}

	// Collection Facade

	public CollectionInfoList transform(Collection[] collections) throws AttributeNotFoundException, QppServiceException {
		CollectionInfoList collectionInfoList = new CollectionInfoList();
		for (int i = 0; i < collections.length; i++) {
			com.quark.qpp.service.xmlBinding.CollectionInfo colInfo = transform(collections[i]);
			collectionInfoList.getCollectionInfo().add(colInfo);
		}
		return collectionInfoList;
	}

	public com.quark.qpp.service.xmlBinding.CollectionInfo transform(Collection collection) throws AttributeNotFoundException,
			InvalidCollectionException, QppServiceException {
		CollectionInfo colInfo = collectionService.getCollectionInfo(collection.getId());
		com.quark.qpp.service.xmlBinding.CollectionInfo collectionDef = transform(colInfo);
		collectionDef.setUserInfoList(transform(collection.getCollectionUsers()));
		collectionDef.setGroupInfoList(transform(collection.getCollectionGroups(), false));
		collectionDef.setId(collection.getId());
		collectionDef.setJobJacketInfoList(transform(collection.getJobJackets(), false, collection.getId()));
			collectionDef.setRevisionControlInfoList(transform(collection.getRevisionControls()));
		collectionDef.setRoutingInfoList(transform(collection.getRoutings()));
		collectionDef.setWorkflowInfoList(transform(collection.getWorkflows(), false));
		return collectionDef;
	}

	public com.quark.qpp.service.xmlBinding.CollectionInfo transform(CollectionInfo collectionInfo) throws InvalidContentTypeException,
			QppServiceException {
		com.quark.qpp.service.xmlBinding.CollectionInfo transformedCollectionInfo = new com.quark.qpp.service.xmlBinding.CollectionInfo();
		BeanUtils.copyProperties(collectionInfo, transformedCollectionInfo, new String[] { "collectionClass" });
		TextValue textVal = (TextValue) collectionService.getCollectionAttributeValues(collectionInfo.getId(),
				new long[] { DefaultAttributes.COLLECTION_PATH })[0].getAttributeValue();
		transformedCollectionInfo.setCollectionPath(textVal.getValue());

		transformedCollectionInfo.setCollectionClassId(collectionInfo.getCollectionClass());
		transformedCollectionInfo.setCollectionClass(getContentTypeName(collectionInfo.getCollectionClass()));
		JobJacket jobJacket = collectionService.getCollectionDefaultJobJacket(collectionInfo.getId());
		if (jobJacket != null) {
			transformedCollectionInfo.setDefaultJobJacketId(jobJacket.getId());
			transformedCollectionInfo.setDefaultJobJacketName(jobJacket.getName());
		}
		transformedCollectionInfo.setDefaultJobJacketTicket(collectionService.getCollectionDefaultTicket(collectionInfo.getId()));
		AttributeValue[] attrValues = collectionService.getCollectionAllAttributeValues(collectionInfo.getId());
		transformedCollectionInfo.setAttributeValueList(transform(attrValues));
		return transformedCollectionInfo;
	}

	public WorkflowInfoList transform(Workflow[] workflows, boolean getDetailedInfo) throws QppServiceException {
		if (workflows == null || workflows.length == 0) {
			return new WorkflowInfoList();
		}
		WorkflowInfoList workflowInfoList = new WorkflowInfoList();
		for (int i = 0; workflows != null && i < workflows.length; i++) {
			workflowInfoList.getWorkflowInfo().add(transform(workflows[i], getDetailedInfo));
		}
		return workflowInfoList;
	}

	public WorkflowInfo transform(Workflow workflow, boolean getDetailedInfo) throws QppServiceException {
		WorkflowInfo workflowInfo = new WorkflowInfo();
		BeanUtils.copyProperties(workflow, workflowInfo);
		if (getDetailedInfo) {
			String creatorName = getUserName(workflow.getCreatedBy());
			workflowInfo.setCreatorName(creatorName);
			String lastModifierName = getUserName(workflow.getLastModifiedBy());
			workflowInfo.setLastModifierName(lastModifierName);
			workflowInfo.setStatusInfoList(transform(workflow.getStatuses(), workflow.getId()));
			StatusTransition[] statusTransitions = workflowService.getWorkflowStatusTransitions(workflow.getId());
			workflowInfo.setStatusTransitionInfoList(transform(statusTransitions, workflow.getId()));
			
			workflowInfo.setContentTypeInfoList(getContentTypeInfoList(workflowInfo.getId()));
			UserClass[] allUserClasses = userClassService.getAllUserClasses();
			workflowInfo.setRoleBasedStatusTransitionInfoList(getRoleBasedStatusTransition(workflow, allUserClasses));
			workflowInfo.setConstrainedStatusTransition(workflow.isConstrainedStatusTransition());
			workflowInfo.setRoleBasedRouting(workflow.isUserclassBasedRouting());
			
			workflowInfo.setStatusRoutingRolesInfoList(getStatusRoutingRolesInfoList(workflow));
		}
		return workflowInfo;
	}
	
	@Override
	public StatusRoutingUserClasses[] transform(StatusRoutingRolesInfoList statusRoutingRolesInfoList, long workflowId) throws UserClassNotFoundException, QppServiceException {
		if (statusRoutingRolesInfoList == null || statusRoutingRolesInfoList.getStatusRoutingRolesInfo() == null) {
			return new StatusRoutingUserClasses[0];
		}
		 List<StatusRoutingRolesInfo> statusRoutingRolesInfos =  statusRoutingRolesInfoList.getStatusRoutingRolesInfo();
		 StatusRoutingUserClasses[] statusRoutingUserClasses = new StatusRoutingUserClasses[statusRoutingRolesInfos.size()];
		 for (int i = 0; i < statusRoutingRolesInfos.size(); i++) {
			 StatusRoutingRolesInfo statusRoutingRolesInfo = statusRoutingRolesInfos.get(i);
			statusRoutingUserClasses[i] = new StatusRoutingUserClasses();

			long statusId = 0;
			String statusName = statusRoutingRolesInfos.get(i).getName();

			if (statusName != null && statusName.trim().length() > 0) {
				statusId = getStatusId(workflowId, statusName);
			} else if (statusRoutingRolesInfos.get(i).getId() != null && statusRoutingRolesInfos.get(i).getId() > 0) {
				statusId = statusRoutingRolesInfos.get(i).getId();
			}

			statusRoutingUserClasses[i].setStatusId(statusId);
			 
			statusRoutingUserClasses[i].setRoutingUserClassIds(getRoutingRoleIds(statusRoutingRolesInfo.getRoutingRolesInfoList()));
		}
		
		return statusRoutingUserClasses;
	}	
	
	
	private long[] getRoutingRoleIds(RoutingRolesInfoList routingRolesInfoList) throws UserClassNotFoundException, QppServiceException {
		if (routingRolesInfoList == null || routingRolesInfoList.getRoutingRoleInfo() == null) {
			return new long[0];
		}
		List<RoutingRoleInfo> routingRoleInfos = routingRolesInfoList.getRoutingRoleInfo();
		long[] roleIDs = new long[routingRoleInfos.size()];
		for (int i = 0; i < routingRoleInfos.size(); i++) {
			String roleName = routingRoleInfos.get(i).getName();
			long roleId = 0;
			if (roleName != null && roleName.trim().length() > 0) {
				roleId = facadeUtility.getRoleId(routingRoleInfos.get(i).getName());
			} else if (routingRoleInfos.get(i).getId() != null) {
				roleId = routingRoleInfos.get(i).getId();
			}
			roleIDs[i] = roleId;
		}
		return roleIDs;
	}

	private StatusRoutingRolesInfoList getStatusRoutingRolesInfoList(Workflow workflow) throws UserClassNotFoundException, QppServiceException {
		
		StatusRoutingRolesInfoList statusRoutingRolesInfoList = new StatusRoutingRolesInfoList();
		StatusRoutingUserClasses[] statuseRoutingUserClasses = workflow.getStatusRoutingUserclasses();
		if (statuseRoutingUserClasses == null || statuseRoutingUserClasses.length == 0) {
			return null;
		}

		for (int i = 0; i < statuseRoutingUserClasses.length; i++) {
			StatusRoutingRolesInfo statusRoutingRolesInfo = new StatusRoutingRolesInfo();
			long statusId = statuseRoutingUserClasses[i].getStatusId();
			statusRoutingRolesInfo.setId(statusId);
			statusRoutingRolesInfo.setName(getStatusName(statusId, workflow.getStatuses()));

			long[] userclassIDs = statuseRoutingUserClasses[i].getRoutingUserClassIds();
			if (userclassIDs != null && userclassIDs.length > 0) {
				RoutingRolesInfoList routingRolesInfoList = new RoutingRolesInfoList();
				for (int j = 0; userclassIDs != null && j < userclassIDs.length; j++) {
					RoutingRoleInfo routingRoleInfo = new RoutingRoleInfo();
					routingRoleInfo.setId(userclassIDs[j]);
					routingRoleInfo.setName(getUserClassName(userclassIDs[j]));
					routingRolesInfoList.getRoutingRoleInfo().add(routingRoleInfo);
				}
				statusRoutingRolesInfo.setRoutingRolesInfoList(routingRolesInfoList);

			}
			statusRoutingRolesInfoList.getStatusRoutingRolesInfo().add(statusRoutingRolesInfo);
		}
		return statusRoutingRolesInfoList;
	}

	private String getStatusName(long statusId, Status[] statuses) {
		for (int i = 0; statuses != null && i < statuses.length; i++) {
			if (statuses[i].getId() == statusId) {
				return statuses[i].getName();
			}
		}
		return null;
	}

	public ContentTypeInfoList getContentTypeInfoList(long workflowId) throws WorkflowNotFoundException, QppServiceException {
		ContentTypeInfoList contentTypeInfoList = new ContentTypeInfoList();
		long[] workflowMappedcontentTypes = workflowService.getWorkflowContentTypes(workflowId);
		for (int i = 0; workflowMappedcontentTypes != null && i < workflowMappedcontentTypes.length; i++) {
			ContentTypeInfo contentTypeInfo = contentStructureService.getContentTypeInfo(workflowMappedcontentTypes[i]);
			com.quark.qpp.service.xmlBinding.ContentTypeInfo transformedContentTypeInfo = transform(contentTypeInfo);
			contentTypeInfoList.getContentTypeInfo().add(transformedContentTypeInfo);
		}
		return contentTypeInfoList;
	}

	public StatusTransitionInfoList transform(StatusTransition[] statusTransitions, long workflowId) throws QppServiceException {
		if (statusTransitions == null || statusTransitions.length == 0) {
			return null;
		}
		StatusTransitionInfoList statusTransitionInfoList = new StatusTransitionInfoList();
		for (int i = 0; statusTransitions != null && i < statusTransitions.length; i++) {
			statusTransitionInfoList.getStatusTransitionInfo().add(transform(statusTransitions[i], workflowId));
		}
		return statusTransitionInfoList;
	}
	
	public StatusTransitionInfo transform(StatusTransition statusTransition, long workflowId) throws QppServiceException{
		StatusTransitionInfo statusTransitionInfo = new StatusTransitionInfo();
		statusTransitionInfo.setId(statusTransition.getStatusId());
		statusTransitionInfo.setWorkflowInitiatingStatus(statusTransition.isWorkflowInitiatingStatus());
		
		long[] nextPossibleStatusIds = statusTransition.getNextPossibleStatusIds();
		Arrays.sort(nextPossibleStatusIds); 
		ArrayList<NextPossibleStatusInfo> nextPossibleStatuses = new ArrayList<NextPossibleStatusInfo>();
		Status[] allStatuses = workflowService.getWorkflow(workflowId).getStatuses();
		
		for (int i = 0; i < allStatuses.length; i++) {
			if (allStatuses[i].getId() == statusTransition.getStatusId()) {
				statusTransitionInfo.setName(allStatuses[i].getName());
			}
			if(Arrays.binarySearch(nextPossibleStatusIds, allStatuses[i].getId())>=0){
				NextPossibleStatusInfo nextPossibleStatusInfo = new NextPossibleStatusInfo();
				nextPossibleStatusInfo.setId(allStatuses[i].getId());
				nextPossibleStatusInfo.setName(allStatuses[i].getName());
				nextPossibleStatuses.add(nextPossibleStatusInfo);
			}
		}

		if (nextPossibleStatuses.size() > 0) {
			NextPossibleStatusInfoList nextPossibleStatusInfoList = new NextPossibleStatusInfoList();
			nextPossibleStatusInfoList.getNextPossibleStatusInfo().addAll(
					nextPossibleStatuses);
			statusTransitionInfo
					.setNextPossibleStatusInfoList(nextPossibleStatusInfoList);
		}		
		
		return statusTransitionInfo;
	}
	
	public StatusInfoList transform(Status[] status, long workflowId) throws QppServiceException {
		StatusInfoList statusInfoList = new StatusInfoList();
		long[] checkIn = workflowService.getCheckinRuleEvaluationEnabledStatuses(workflowId);
		if (checkIn != null && checkIn.length > 0) {
			Arrays.sort(checkIn);
		} else {
			checkIn = new long[0];
		}
		long[] printRule = workflowService.getPrintRuleEvaluationEnabledStatuses(workflowId);
		if (printRule != null && printRule.length > 0) {
			Arrays.sort(printRule);
		} else {
			printRule = new long[0];
		}
		long[] redLine = workflowService.getRedliningEnabledStatuses(workflowId);
		if (redLine != null && redLine.length > 0) {
			Arrays.sort(redLine);
		} else {
			redLine = new long[0];
		}
		UserClass[] allUserClasses = userClassService.getAllUserClasses();
		HashMap<Long, AttributeConstraintsInfoList> statusAttrConstraintsMap = getAttributeConstraintsInfoMap(workflowId);
		for (int i = 0; i < status.length; i++) {
			StatusInfo statusInfo = new StatusInfo();
			BeanUtils.copyProperties(status[i], statusInfo);
			statusInfo.setPrivilegeInfoList(getPrivilageInfoList(status[i].getId(), allUserClasses));
			statusInfo.setAttributeConstraintsInfoList(statusAttrConstraintsMap.get(status[i].getId()));
			boolean isRedline = Arrays.binarySearch(redLine, status[i].getId()) < 0 ? false : true;
			statusInfo.setRedlineTracking(isRedline);
			boolean isPrintRule = Arrays.binarySearch(printRule, status[i].getId()) < 0 ? false : true;
			statusInfo.setOutputLayoutEvaluation(isPrintRule);
			boolean isCheckIn = Arrays.binarySearch(checkIn, status[i].getId()) < 0 ? false : true;
			statusInfo.setCheckInLayoutEvaluation(isCheckIn);

			statusInfoList.getStatusInfo().add(statusInfo);
			
		}
		return statusInfoList;
	}

	private RoleBasedStatusTransitionInfoList getRoleBasedStatusTransition(Workflow workflow, UserClass[] allUserClasses) throws QppServiceException {
		RoleBasedStatusTransitionInfoList roleBasedStatusTransitionInfoList = new RoleBasedStatusTransitionInfoList();
		for (UserClass userclass : allUserClasses) {
			long userClassId = userclass.getId();
			StatusTransition[] statusTransitions = userClassService.getOverriddenWorkflowStatusTransitions(userClassId, workflow.getId());
			if (statusTransitions != null && statusTransitions.length > 0) {
				//Set the role based status transition if it is is overridden for the given role
				StatusTransitionInfoList statusTransitionInfoList = transform(statusTransitions, workflow.getId());
				RoleBasedStatusTransitionInfo roleBasedStatusTransitionInfo = new RoleBasedStatusTransitionInfo();
				roleBasedStatusTransitionInfo.setId(userClassId);
				roleBasedStatusTransitionInfo.setName(userclass.getName());
				roleBasedStatusTransitionInfo.setStatusTransitionInfoList(statusTransitionInfoList);
				roleBasedStatusTransitionInfoList.getRoleBasedStatusTransitionInfo().add(roleBasedStatusTransitionInfo);
			}
		}
		if (roleBasedStatusTransitionInfoList.getRoleBasedStatusTransitionInfo().size() > 0) {
			return roleBasedStatusTransitionInfoList;
		}
		//Return null if not role based transition defined
		return null;
	}

	private HashMap<Long, AttributeConstraintsInfoList> getAttributeConstraintsInfoMap(long workFlowId) throws QppServiceException {
		long[] attributeIds = getWorkflowAttributesIds(workFlowId);
		List<Long> rolesList = getAllUserClassesIds();
		HashMap<Long, AttributeConstraintsInfoList> statusAttrConstraintsMap = new HashMap<Long, AttributeConstraintsInfoList>();
		for (long attributeId : attributeIds) {
			AttributeConstraint[] attributeConstraints = workflowService.getAttributeConstraints(attributeId, workFlowId);
			for (AttributeConstraint attributeConstraint : attributeConstraints) {
				long thisStatusId = attributeConstraint.getStatusId();
				if (!rolesList.contains(attributeConstraint.getUserclassId()))
					continue;
				AttributeConstraintsInfo attributeConstraintsInfo = transform(attributeConstraint);
				AttributeConstraintsInfoList thisStatusAttributeConstraintsInfoList = statusAttrConstraintsMap.get(thisStatusId);
				if (thisStatusAttributeConstraintsInfoList == null) {
					thisStatusAttributeConstraintsInfoList = new AttributeConstraintsInfoList();
					statusAttrConstraintsMap.put(thisStatusId, thisStatusAttributeConstraintsInfoList);
				}
				thisStatusAttributeConstraintsInfoList.getAttributeConstraintsInfo().add(attributeConstraintsInfo);
			}
		}
		return statusAttrConstraintsMap;
	}

	private AttributeConstraintsInfo transform(AttributeConstraint attributeConstraint) throws AttributeNotFoundException,
			QppServiceException, UserClassNotFoundException {
		AttributeConstraintsInfo attributeConstraintsInfo = new AttributeConstraintsInfo();
		attributeConstraintsInfo.setAttributeId(attributeConstraint.getAttributeId());
		attributeConstraintsInfo.setAttributeName(getAttributeName(attributeConstraint.getAttributeId()));
		attributeConstraintsInfo.setConstraintId(attributeConstraint.getConstraintType());
		attributeConstraintsInfo.setRoleId(attributeConstraint.getUserclassId());
		try {
			attributeConstraintsInfo.setRoleName(getUserClassName(attributeConstraint.getUserclassId()));
		} catch (Exception e) {
			// Suppress the exception because attribute constraint evaluation requires multiple user classes consideration so user class id
			// is zero here
		}
		attributeConstraintsInfo.setConstraintName(facadeUtility.getAttributeConstraintString(attributeConstraint.getConstraintType()));
		return attributeConstraintsInfo;
	}
	
	public AttributeConstraintsInfoList transform(AttributeConstraint[] attributeConstraints) throws AttributeNotFoundException,
			UserClassNotFoundException, QppServiceException {
		AttributeConstraintsInfoList attributeConstraintsInfoList = new AttributeConstraintsInfoList();
		for (int i = 0; attributeConstraints != null && i < attributeConstraints.length; i++) {
			AttributeConstraintsInfo attributeConstraintsInfo = transform(attributeConstraints[i]);
			attributeConstraintsInfoList.getAttributeConstraintsInfo().add(attributeConstraintsInfo);
		}
		return attributeConstraintsInfoList;
	}
	
	public long[] getWorkflowAttributesIds(long workFlowId) throws QppServiceException {
		Attribute[] attributes = getWorkflowAttributes(workFlowId);
		long[] ids = new long[attributes.length];
		int i = 0;
		for (Attribute attribute : attributes) {
			ids[i++] = attribute.getId();
		}
		return ids;
	}

	public ContentTypePrivList transform(ContentTypePrivileges[] contentTypePrivileges) throws InvalidContentTypeException,
			QppServiceException {
		ContentTypePrivList contentTypePrivList = new ContentTypePrivList();
		if (contentTypePrivileges != null) {
			for (ContentTypePrivileges contentTypePrivilege : contentTypePrivileges) {
				ContentTypePriv contentTypePriv = transform(contentTypePrivilege);
				contentTypePrivList.getContentTypePriv().add(contentTypePriv);
			}
		}
		return contentTypePrivList;
	}

	private PrivilegeInfoList getPrivilageInfoList(long statusId, UserClass[] allUserClasses) throws StatusNotFoundException, UserClassNotFoundException,
			QppServiceException {
		PrivilegeInfoList privilegeInfoList = new PrivilegeInfoList();
		for (UserClass user : allUserClasses) {
			long userClassId = user.getId();
			StatusPrivileges statusPrivileges = userClassService.getAllEnabledStatusPrivileges(statusId, userClassId);
			PrivilegeInfo privilegeInfo = new PrivilegeInfo();
			privilegeInfo.setRoleId(userClassId);
			privilegeInfo.setRoleName(user.getName());
			privilegeInfo.setContentTypePrivList(transform(statusPrivileges.getContentTypePrivileges()));
			privilegeInfo.setOverridden(statusPrivileges.isOverridden());
			privilegeInfoList.getPrivilegeInfo().add(privilegeInfo);
		}
		return privilegeInfoList;
	}

	private String getUserName(long userId) throws QppServiceException {
		try {
			return trusteeService.getUserName(userId);
		} catch (UserNotFoundException e) {
			logger.error("User not found with id " + userId, e);
			// do nothing as it might be a deleted user.
		} catch (QppServiceException qppServiceException) {
			throw qppServiceException;
		}
		return null;
	}

	public RoutingInfoList transform(Routing[] routings) throws TrusteeNotFoundException, QppServiceException {
		if (routings == null || routings.length == 0) {
			return null;
		}
		RoutingInfoList routingInfoList = new RoutingInfoList();
		for (int i = 0; routings != null && i < routings.length; i++) {
			routingInfoList.getRoutingInfo().add(transform(routings[i]));
		}
		return routingInfoList;
	}

	private RoutingInfo transform(Routing routing) throws TrusteeNotFoundException, QppServiceException {
		RoutingInfo routingInfo = new RoutingInfo();
		BeanUtils.copyProperties(routing, routingInfo, new String[] { "routingType" });
		routingInfo.setRoutingType(getRoutingTypeName(routing.getRoutingType()));
		routingInfo.setRoutingTypeId(routing.getRoutingType());
		if (routing.getRoutingType() == RoutingTypes.GROUP || routing.getRoutingType() == RoutingTypes.USER) {
			routingInfo.setTrustee(getTrusteeName(routing.getTrusteeId()));
		}
		routingInfo.setStatus(workflowService.getStatus(routing.getStatusId()).getName());
		Status status = workflowService.getStatus(routing.getStatusId());

		routingInfo.setWorkflowId(status.getWorkflowId());
		routingInfo.setWorkflow(workflowService.getWorkflow(status.getWorkflowId()).getName());
		return routingInfo;
	}

	private String getTrusteeName(long trusteeId) throws TrusteeNotFoundException, QppServiceException {
		return trusteeService.getTrusteeName(trusteeId);
	}

	private String getRoutingTypeName(int routingType) {
		if (routingType == RoutingTypes.USER) {
			return "User";
		}
		if (routingType == RoutingTypes.GROUP) {
			return "Group";
		}
		if (routingType == RoutingTypes.NO_AUTO_ROUTING) {
			return "No Auto Routing";
		}
		if (routingType == RoutingTypes.NO_ONE) {
			return "No One";
		}
		return "";
	}

	public RevisionControlInfoList transform(RevisionControl[] revisionControls) throws InvalidContentTypeException, QppServiceException {
		if (revisionControls == null || revisionControls.length == 0) {
			return null;
		}
		RevisionControlInfoList revisionControlList = new RevisionControlInfoList();
		for (int i = 0; revisionControls != null && i < revisionControls.length; i++) {
			revisionControlList.getRevisionControlInfo().add(transform(revisionControls[i]));
		}
		return revisionControlList;
	}

	private RevisionControlInfo transform(RevisionControl revisionControl) throws InvalidContentTypeException, QppServiceException {
		RevisionControlInfo revisionControlInfo = new RevisionControlInfo();
		BeanUtils.copyProperties(revisionControl, revisionControlInfo);
		revisionControlInfo.setContentType(getContentTypeName(revisionControl.getContentTypeId()));
		return revisionControlInfo;
	}

	public JobJacketInfoList transform(JobJacket[] jobJackets, boolean getDetailedInfo, long collectionId) throws QppServiceException {
		if (jobJackets == null || jobJackets.length == 0) {
			return null;
		}
		JobJacketInfoList jobJacketInfoList = new JobJacketInfoList();
		for (int i = 0; jobJackets != null && i < jobJackets.length; i++) {
			jobJacketInfoList.getJobJacketInfo().add(transform(jobJackets[i], getDetailedInfo, collectionId));
		}
		return jobJacketInfoList;
	}

	public JobJacketInfo transform(JobJacket jobJacket, boolean getDetailedInfo, long collectionId) throws QppServiceException {
		JobJacketInfo jobJacketInfo = new JobJacketInfo();
		BeanUtils.copyProperties(jobJacket, jobJacketInfo);
		if (getDetailedInfo) {
			
			// In parseJobJacketXml(...) scenarios, createdBy and lastModifiedBy
			// are not set.Thus to avoid unnecessary USER_NOT_FOUND exceptions
			// placed the following checks
			if (jobJacket.getCreatedBy() > 0) {
				String creatorName = getUserName(jobJacket.getCreatedBy());
				jobJacketInfo.setCreatorName(creatorName);
			}
			if (jobJacket.getLastModifiedBy() > 0) {
				String lastModifierName = getUserName(jobJacket.getLastModifiedBy());
				jobJacketInfo.setLastModifierName(lastModifierName);
			}
			String[] ticketTemplates = jobJacket.getTicketTemplates();
			TicketTemplateList ticketTemplateList = new TicketTemplateList();
			for (int i = 0; ticketTemplates != null && i < ticketTemplates.length; i++) {
				ticketTemplateList.getTicketTemplate().add(ticketTemplates[i]);
			}
			jobJacketInfo.setTicketTemplateList(ticketTemplateList);
			
			// In parseJobJacketXml(...) scenario, jobJacket will not have an ID.
			if(jobJacket.getId() > 0){
				String jjContentXML = getJobJacketContent(jobJacketInfo.getId(), collectionId);
				jobJacketInfo.setContent(jjContentXML);
			}
		}
		return jobJacketInfo;
	}

	private String getJobJacketContent(long jobJacketId, long collectionId) throws InvalidCollectionException, QppServiceException {
		String jobJacketContent = null;
		/*
		 * In case collectionId is available use it else invoke
		 * getJobJacketCollections(...) API that also retains the old behavior.
		 * Ticket 30026-101195: Poor QPP performance....
		 */
		if (collectionId <= 0) {
			long[] collectionIds = collectionService.getJobJacketCollections(jobJacketId);
			if (collectionIds != null && collectionIds.length > 0) {
				collectionId = collectionIds[0];
			}
		}
		if (collectionId > 0) {
			byte[] xmlData = collectionService.getJobJacketContent(collectionId, jobJacketId);
			jobJacketContent = new String(xmlData);
		}
		return jobJacketContent;
	}

	public UserInfoList transform(CollectionUser[] collectionUsers) {
		UserInfoList collectionUserInfoList = new UserInfoList();
		for (int i = 0; collectionUsers != null && i < collectionUsers.length; i++) {
			collectionUserInfoList.getUserInfo().add(transform(collectionUsers[i]));
		}
		return collectionUserInfoList;
	}

	private UserInfo transform(CollectionUser collectionUser) {
		UserInfo userInfo = new UserInfo();
		BeanUtils.copyProperties(collectionUser.getUser(), userInfo);
		long overriddenUserClassId = collectionUser.getOverriddenUserClassId();
		if (overriddenUserClassId > 0) {
			userInfo.setOverriddenUserClassId(overriddenUserClassId);
			try {
				userInfo.setOverriddenUserClassName(getUserClassName(overriddenUserClassId));
			} catch (Exception e) {
				// suppress any exception
			}
		}
		return userInfo;
	}

	private String getContentTypeName(long collectionClassId) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfo contentTypeInfo = contentStructureService.getContentTypeInfo(collectionClassId);
		return contentTypeInfo.getName();
	}

	public GroupInfoList transform(CollectionGroup[] collectionGroups, boolean getDetailedInfo) throws GroupNotFoundException,
			QppServiceException {
		GroupInfoList collectionGroupInfoList = new GroupInfoList();
		for (int i = 0; collectionGroups != null && i < collectionGroups.length; i++) {
			com.quark.qpp.core.security.service.dto.GroupInfo group = collectionGroups[i].getGroupInfo();
			GroupInfo groupInfo = transform(group, getDetailedInfo);
			long overriddenUserClassId = collectionGroups[i].getOverriddenUserClassId();
			if(overriddenUserClassId > 0){
				String userClassName = getUserClassName(overriddenUserClassId);
				groupInfo.setOverriddenUserClassId(overriddenUserClassId);
				groupInfo.setOverriddenUserClassName(userClassName);
			}
			collectionGroupInfoList.getGroupInfo().add(groupInfo);
		}
		return collectionGroupInfoList;
	}

	public GroupInfoList transform(Group[] groups, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException {
		if (groups == null || groups.length == 0) {
			return new GroupInfoList();
		}
		GroupInfoList groupInfoList = new GroupInfoList();
		for (int i = 0; i < groups.length; i++) {
			groupInfoList.getGroupInfo().add(transform(groups[i], getDetailedInfo));
		}
		return groupInfoList;
	}

	public GroupInfoList transform(com.quark.qpp.core.security.service.dto.GroupInfo[] groups, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException {
		if (groups == null || groups.length == 0) {
			return new GroupInfoList();
		}
		GroupInfoList groupInfoList = new GroupInfoList();
		for (int i = 0; i < groups.length; i++) {
			groupInfoList.getGroupInfo().add(transform(groups[i], getDetailedInfo));
		}
		return groupInfoList;
	}
	
	public GroupInfo transform(com.quark.qpp.core.security.service.dto.GroupInfo group, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException {
		GroupInfo groupInfo = new GroupInfo();
		BeanUtils.copyProperties(group, groupInfo, new String[]{"memberIds", "ldapProfileId","deleted"});
		if (getDetailedInfo) {
			MemberList memberList = new MemberList();
			Group grpWithMembers = trusteeService.getGroup(group.getId());
			long[] memberIds = grpWithMembers.getMemberIds();
			for (int i = 0; memberIds!=null && i < memberIds.length; i++) {
				NameId nameId = new NameId();
				nameId.setId(memberIds[i]);
				nameId.setName(getTrusteeName(memberIds[i]));
				memberList.getNameId().add(nameId);
			}
			groupInfo.setMemberList(memberList);
		}
		
		if(group.getDefaultUserClassId() > 0){
			//This is the case - the userclass will be 0 as Groups are searched from LDAP service are being returned here. 
			groupInfo.setDefaultUserClass(getUserClassName(group.getDefaultUserClassId()));
		}
		if(group.getLdapProfileId() > 0){
			groupInfo.setLdapProfile(getLdapProfileName(group.getLdapProfileId()));
			groupInfo.setLdapProfileId(group.getLdapProfileId());
		}
		return groupInfo;
	}
	
	public GroupInfo transform(Group group, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException {
		GroupInfo groupInfo = new GroupInfo();
		BeanUtils.copyProperties(group, groupInfo, new String[]{"memberIds", "ldapProfileId","deleted"});
		if (getDetailedInfo) {
			MemberList memberList = new MemberList();
			long[] memberIds = group.getMemberIds();
			for (int i = 0; memberIds!=null && i < memberIds.length; i++) {
				NameId nameId = new NameId();
				nameId.setId(memberIds[i]);
				nameId.setName(getTrusteeName(memberIds[i]));
				memberList.getNameId().add(nameId);
			}
			groupInfo.setMemberList(memberList);
		}
		
		if(group.getDefaultUserClassId() > 0){
			//This is the case - the userclass will be 0 as Groups are searched from LDAP service are being returned here. 
			groupInfo.setDefaultUserClass(getUserClassName(group.getDefaultUserClassId()));
		}
		if(group.getLdapProfileId() > 0){
			groupInfo.setLdapProfile(getLdapProfileName(group.getLdapProfileId()));
			groupInfo.setLdapProfileId(group.getLdapProfileId());
		}
		return groupInfo;
	}

	public RoleInfo transform(UserClass userClass) throws PrivilegeNotFoundException, InvalidContentTypeException, QppServiceException {
		RoleInfo userClassInfo = new RoleInfo();
		BeanUtils.copyProperties(userClass, userClassInfo);
		long[] applicationPrivileges = userClass.getApplicationPrivileges();
		if (applicationPrivileges != null && applicationPrivileges.length > 0) {
			ApplicationPrivList applicationPrivList = new ApplicationPrivList();
			Privilege[] privileges = transform(applicationPrivileges);
			applicationPrivList.getPrivilege().addAll(Arrays.asList(privileges));
			userClassInfo.setApplicationPrivList(applicationPrivList);
		}
		ContentTypePrivileges[] contentTypePrivileges = userClass.getContentTypePrivileges();
		if (contentTypePrivileges != null && contentTypePrivileges.length > 0) {
			ContentTypePrivList contentTypePrivList = new ContentTypePrivList();
			for (int i = 0; contentTypePrivileges != null && i < contentTypePrivileges.length; i++) {
				ContentTypePriv contentTypePriv = transform(contentTypePrivileges[i]);
				contentTypePrivList.getContentTypePriv().add(contentTypePriv);
			}
			userClassInfo.setContentTypePrivList(contentTypePrivList);
		}
		return userClassInfo;
	}

	public ContentTypePriv transform(ContentTypePrivileges contentTypePrivileges) throws InvalidContentTypeException,
			PrivilegeNotFoundException, QppServiceException {
		ContentTypePriv contentTypePriv = new ContentTypePriv();
		contentTypePriv.setContentType(getContentTypeName(contentTypePrivileges.getContentTypeId()));
		contentTypePriv.setContentTypeId(contentTypePrivileges.getContentTypeId());
		contentTypePriv.setContentTypeHierarchy(facadeUtility.getContentTypeHierarchy(contentTypePrivileges.getContentTypeId()));
		long[] privilegeIds = contentTypePrivileges.getPrivilegeIds();
		Privilege[] privileges = transform(privilegeIds);
		contentTypePriv.getPrivilege().addAll(Arrays.asList(privileges));
		return contentTypePriv;
	}

	public Privilege[] transform(long[] privilegeIds) throws PrivilegeNotFoundException, QppServiceException {
		Privilege[] privilegesArray = new Privilege[privilegeIds != null ? privilegeIds.length : 0];
		PrivilegeDefinition[] appPrivDefs = privilegeService.getPrivilegeDefs(privilegeIds);
		Map<Long, String> privGroupHierarchiesMap = getPrivilegeGroupsHierarchies();
		for (int j = 0; appPrivDefs != null && j < appPrivDefs.length; j++) {
			PrivilegeDefinition privDef = appPrivDefs[j];
			Privilege privilege = new Privilege();
			privilege.setId(privDef.getId());
			privilege.setName(privDef.getName());
			privilege.setPrivilegeHierarchy(privGroupHierarchiesMap.get(privDef.getGroupId()) + ";" + privDef.getName());
			privilegesArray[j] = privilege;
		}
		return privilegesArray;
	}
	
	/**
	 * Returns map where key is the privilege group id and value contains colon separated privilege group hierarchy. For e.g.  Workspace;Searches 
	 * @return 
	 * @throws QppServiceException
	 */
	private Map<Long, String> getPrivilegeGroupsHierarchies() throws QppServiceException{
		PrivilegeGroupDefinition[] allPrivGroups = privilegeService.getAllPrivilegeGroupDefs();
		Map<Long, String> privGroupHiererachyMap = new HashMap<Long, String>();
		for (int i = 0; i < allPrivGroups.length; i++) {
			privGroupHiererachyMap.put(allPrivGroups[i].getId(), allPrivGroups[i].getName());
			if (allPrivGroups[i].getSubPrivilegeGroups() != null && allPrivGroups[i].getSubPrivilegeGroups().length > 0) {
				populateChildren(allPrivGroups[i].getId(), allPrivGroups[i].getSubPrivilegeGroups(), privGroupHiererachyMap);
			}
		}
		return privGroupHiererachyMap;
	}

	private void populateChildren(long parentGroupId, PrivilegeGroupDefinition[] subPrivilegeGroups,
			Map<Long, String> privGroupHiererachyMap) {
		for (int i = 0; i < subPrivilegeGroups.length; i++) {
			String parentGrpHierarchy = privGroupHiererachyMap.get(parentGroupId);
			privGroupHiererachyMap.put(subPrivilegeGroups[i].getId(), parentGrpHierarchy+";"+subPrivilegeGroups[i].getName());
			if (subPrivilegeGroups[i].getSubPrivilegeGroups() != null && subPrivilegeGroups[i].getSubPrivilegeGroups().length > 0) {
				populateChildren(subPrivilegeGroups[i].getId(), subPrivilegeGroups[i].getSubPrivilegeGroups(), privGroupHiererachyMap);
			}
		}
	}

	@Override
	public CollectionUser[] transform(UserInfoList userInfoList) throws UserClassNotFoundException, QppServiceException {
		ArrayList<CollectionUser> collectionUsers = new ArrayList<CollectionUser>();
		if (userInfoList != null && userInfoList.getUserInfo() != null) {
			List<UserInfo> list = userInfoList.getUserInfo();
			for (int i = 0; i < list.size(); i++) {
				CollectionUser collectionUser = new CollectionUser();
				UserInfo userInfo = list.get(i);
				if (userInfo.getName() != null && !userInfo.getName().isEmpty()) {
					long userId = trusteeService.getUserId(userInfo.getName());
					collectionUser.setUserId(userId);
					userInfo.setId(userId);
				} else if (userInfo.getId() != null) {
					collectionUser.setUserId(userInfo.getId());
				}
				if (userInfo.getOverriddenUserClassName() != null && !userInfo.getOverriddenUserClassName().isEmpty()) {
					collectionUser.setOverriddenUserClassId(facadeUtility.getUserClassId(userInfo.getOverriddenUserClassName()));
				} else if (userInfo.getOverriddenUserClassId() != null) {
					collectionUser.setOverriddenUserClassId(userInfo.getOverriddenUserClassId());
				}
				collectionUsers.add(collectionUser);
			}
		}
		return collectionUsers.toArray(new CollectionUser[0]);
	}

	public RevisionControl[] transform(RevisionControlInfoList revisionControlInfoList) throws InvalidContentTypeException,
			QppServiceException {
		List<RevisionControlInfo> revisionControlInfos = revisionControlInfoList.getRevisionControlInfo();
		ArrayList<RevisionControl> revisionControls = new ArrayList<RevisionControl>();
		for (int i = 0; revisionControlInfos != null && i < revisionControlInfos.size(); i++) {
			RevisionControl revisionControl = new RevisionControl();
			RevisionControlInfo revisionControlInfo = revisionControlInfos.get(i);
			BeanUtils.copyProperties(revisionControlInfo, revisionControl, new String[] { "contentTypeId" });
			if (revisionControlInfo.getContentType() != null) {
				revisionControl.setContentTypeId(facadeUtility.getContentTypeIdForText(revisionControlInfo.getContentType()));
			} else if (revisionControlInfo.getContentTypeId() != null) {
				revisionControl.setContentTypeId(revisionControlInfo.getContentTypeId());
			}
			revisionControls.add(revisionControl);
		}
		return revisionControls.toArray(new RevisionControl[0]);
	}

	public Routing[] transform(RoutingInfoList routingInfoList) {
		List<RoutingInfo> routingInfos = routingInfoList.getRoutingInfo();
		ArrayList<Routing> routings = new ArrayList<Routing>();
		for (int i = 0; i < routingInfos.size(); i++) {
			Routing routing = transform(routingInfos.get(i));
			routings.add(routing);
		}
		return routings.toArray(new Routing[0]);
	}

	public Routing transform(RoutingInfo routingInfo) {
		Routing routing = new Routing();
		BeanUtils.copyProperties(routingInfo, routing, new String[] { "routingType" });
		routing.setRoutingType(routingInfo.getRoutingTypeId());
		return routing;
	}

	// Query facade transformers

	public QueryResultInfo transform(QueryResultElement[] queryResultElements, long contentTypeId) throws AttributeNotFoundException,
			QppServiceException {
		boolean isCollection = contentStructureService.isValidAncestor(DefaultContentTypes.COLLECTION, contentTypeId);
		if (isCollection || (contentTypeId == DefaultContentTypes.COLLECTION)) {
			CollectionInfoList collectionInfoList = new CollectionInfoList();
			for (int i = 0; i < queryResultElements.length; i++) {
				int resultElmType = queryResultElements[i].getElementType();
				if (resultElmType == QueryResultElementTypes.COLLECTION) {
					CollectionElement collectionElement = (CollectionElement) queryResultElements[i];
					Collection collection = new Collection();
					collection.setAttributeValues(collectionElement.getAttributeValues());
					collection.setId(collectionElement.getCollectionId());
					collectionInfoList.getCollectionInfo().add(transform(collection));
				}
			}
			return collectionInfoList;
		} else {
			boolean isAsset = contentStructureService.isValidAncestor(DefaultContentTypes.ASSET, contentTypeId);
			if (isAsset || (contentTypeId == DefaultContentTypes.ASSET)) {
				AssetInfoList assetInfoList = new AssetInfoList();
				for (int i = 0; i < queryResultElements.length; i++) {
					int resultElmType = queryResultElements[i].getElementType();
					// Check for the query result element type
					if (resultElmType == QueryResultElementTypes.ASSET || resultElmType == QueryResultElementTypes.PROJECT) {
						AssetElement assetElement = (AssetElement) queryResultElements[i];
						Asset asset = new Asset(assetElement.getAssetId(), null, assetElement.getAttributeValues());
						assetInfoList.getAssetInfo().add(transform(asset));
					}
				}
				return assetInfoList;
			}
		}
		return null;
	}

	public UserInfoList transform(User[] users) throws UserClassNotFoundException, InvalidLdapProfileException, QppServiceException {
		UserInfoList userInfoList = new UserInfoList();
		for (int i = 0; users != null && i < users.length; i++) {
			UserInfo userInfo = transform(users[i]);
			userInfoList.getUserInfo().add(userInfo);
		}
		return userInfoList;
	}

	public UserInfo transform(User user) throws UserClassNotFoundException, InvalidLdapProfileException, QppServiceException {
		UserInfo userInfo = new UserInfo();
		BeanUtils.copyProperties(user, userInfo, new String[] { "ldapProfileId" });
		// set the default userclass name & ldap profile name explicitly.
		// we dont get default userclass while fetching ldap users.
		if (user.getDefaultUserClassId() > 0) {
			userInfo.setDefaultUserClass(getUserClassName(user.getDefaultUserClassId()));
		}
		long ldapProfileId = user.getLdapProfileId();
		if (ldapProfileId > 0) {
			userInfo.setLdapProfileId(user.getLdapProfileId());
			userInfo.setLdapProfile(getLdapProfileName(ldapProfileId));
		}
		return userInfo;
	}

	/*
	 * Returns name of the LDAP profile with given id.
	 */
	private String getLdapProfileName(long ldapProfileId) throws InvalidLdapProfileException, QppServiceException {
		LdapProfile ldapProfile = userProvisioningService.getLdapProfile(ldapProfileId);
		return ldapProfile.getName();
	}

	private String getUserClassName(long userId) throws UserClassNotFoundException, QppServiceException {
		UserClass userClass = userClassService.getUserClass(userId);
		return userClass.getName();
	}

	public RelationTypeInfoList transform(RelationType[] relationTypes) throws AttributeNotFoundException, QppServiceException {
		RelationTypeInfoList relationTypeInfoList = new RelationTypeInfoList();
		for (int i = 0; i < relationTypes.length; i++) {
			RelationTypeInfo relationTypeInfo = new RelationTypeInfo();
			BeanUtils.copyProperties(relationTypes[i], relationTypeInfo);
			RelationAttributeList relationAttributeList = transform(relationTypes[i].getRelationTypeAttributeMappings());
			relationTypeInfo.setRelationAttributeList(relationAttributeList);
			relationTypeInfoList.getRelationTypeInfo().add(relationTypeInfo);
		}
		return relationTypeInfoList;
	}

	private RelationAttributeList transform(RelationTypeAttributeMapping[] relationTypeAttributeMappings)
			throws AttributeNotFoundException, QppServiceException {
		RelationAttributeList relationAttributeList = new RelationAttributeList();
		for (int i = 0; i < relationTypeAttributeMappings.length; i++) {
			RelationAttribute relationAttribute = new RelationAttribute();
			BeanUtils.copyProperties(relationTypeAttributeMappings[i], relationAttribute);
			relationAttribute.setId(relationTypeAttributeMappings[i].getAttributeId());
			relationAttribute.setValue(getAttributeName(relationTypeAttributeMappings[i].getAttributeId()));
			relationAttributeList.getRelationAttribute().add(relationAttribute);
		}
		return relationAttributeList;
	}

	private String getAttributeName(long attributeId) throws AttributeNotFoundException, QppServiceException {
		Attribute attribute = attributeService.getAttribute(attributeId);
		return attribute.getName();
	}

	public AttributeInfoList transform(Attribute[] attributes) throws DomainNotFoundException, QppServiceException {
		AttributeInfoList attributeInfoList = new AttributeInfoList();
		for (int i = 0; i < attributes.length; i++) {
			AttributeInfo attributeInfo = transform(attributes[i]);
			attributeInfoList.getAttributeInfo().add(attributeInfo);
		}
		return attributeInfoList;
	}

	public AttributeInfo transform(Attribute attribute) throws DomainNotFoundException, QppServiceException {
		AttributeInfo attributeInfo = new AttributeInfo();
		BeanUtils.copyProperties(attribute, attributeInfo, new String[] { "valueType", "modificationLevel" });
		attributeInfo.setName(attribute.getName());
		attributeInfo.setModificationLevel(getModificationLevelString(attribute.getModificationLevel()));
		attributeInfo.setValueType(getAttributeValueTypeString(attribute.getValueType()));
		attributeInfo.setValueTypeId(attribute.getValueType());
		String creatorName = getUserName(attribute.getCreator());
		attributeInfo.setCreatorName(creatorName);
		String lastModifierName = getUserName(attribute.getLastModifier());
		attributeInfo.setLastModifierName(lastModifierName);
		if (attribute.isMultiValued()) {
			AttributeValueListPreferenceInfo attributeValueListPreferenceInfo = getAttributeValueListPreferenceInfo(
					attribute.getValueType(), attribute.getDefaultValuePreference());
			if (attributeValueListPreferenceInfo != null) {
				attributeInfo.setAttributeValueListPreferenceInfo(attributeValueListPreferenceInfo);
			}
		} else {
			AttributeValuePreferenceInfo attributeValuePreferenceInfo = getAttributeValuePreferenceInfo(attribute.getValueType(),
					attribute.getDefaultValuePreference());
			if (attributeValuePreferenceInfo != null) {
				attributeInfo.setAttributeValuePreferenceInfo(attributeValuePreferenceInfo);
			}
		}
		return attributeInfo;
	}

	
	private AttributeValueListPreferenceInfo getAttributeValueListPreferenceInfo(int attributeValueType,
			AttributeValuePreferences attributeValuePreferences) throws DomainNotFoundException, QppServiceException {
		if (attributeValuePreferences == null) {
			return null;
		}
		AttributeValueListPreferenceInfo attributeValueListPreferenceInfo = null;
		switch (attributeValueType) {
		case AttributeValueTypes.DOMAIN: {
			if (attributeValuePreferences instanceof DomainValueListPreferences) {
				DomainValueListPreferences domainValueListPreferences = (DomainValueListPreferences) attributeValuePreferences;
				int domainId = domainValueListPreferences.getDomainId();
				String domainName = attributeDomainService.getDomain(domainId).getName();
				attributeValueListPreferenceInfo = new AttributeValueListPreferenceInfo();
				attributeValueListPreferenceInfo.setDomainId(domainId);
				attributeValueListPreferenceInfo.setDomainName(domainName);
				DomainValueList defaultDomainValueList = domainValueListPreferences.getDefaultValue();
				if (defaultDomainValueList != null && defaultDomainValueList.getDomainValues() != null) {
					for (int i = 0; i < defaultDomainValueList.getDomainValues().length; i++) {
						DomainValue domainValue = defaultDomainValueList.getDomainValues()[i];
						AttributeValuePreferenceInfo attributeValuePreferenceInfo = createDomainValuePreferences(domainId, domainName,
								domainValue);
						attributeValuePreferenceInfo.setDomainId(null);
						attributeValuePreferenceInfo.setDomainName(null);
						attributeValueListPreferenceInfo.getAttributeValuePreferenceInfo().add(attributeValuePreferenceInfo);
					}
				}
			}
			break;
			}
		}
		return attributeValueListPreferenceInfo;
	}
	
	private AttributeValuePreferenceInfo createDomainValuePreferences(int domainId, String domainName, DomainValue domainValue) throws DomainNotFoundException, QppServiceException {
		AttributeValuePreferenceInfo  attributeValuePreferenceInfo = new AttributeValuePreferenceInfo();
		attributeValuePreferenceInfo.setDomainId(domainId);
		attributeValuePreferenceInfo.setDomainName(domainName);
		if (domainValue != null) {
			attributeValuePreferenceInfo.setDefaultDomainItemId(domainValue.getId());
			//Set domain value hierarchy in domain item name
			String domainValueHierarchy = getDomainValueHierarchy(domainValue);
			attributeValuePreferenceInfo.setDefaultDomainItemName(domainValueHierarchy);
		}
		return attributeValuePreferenceInfo;
	}

	private AttributeValuePreferenceInfo getAttributeValuePreferenceInfo(int attributeValueType,
			AttributeValuePreferences attributeValuePreferences) throws DomainNotFoundException, QppServiceException {
		if (attributeValuePreferences == null) {
			return null;
		}
		AttributeValuePreferenceInfo defaultAttributeValuePreferenceInfo = new AttributeValuePreferenceInfo();
		switch (attributeValueType) {
		case AttributeValueTypes.TEXT: {
			TextValuePreferences textValuePreferences = (TextValuePreferences) attributeValuePreferences;
			if (textValuePreferences.getDefaultValue() != null && textValuePreferences.getDefaultValue().getValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(textValuePreferences.getDefaultValue().getValue());
			if (textValuePreferences.getMaxLengthPossible() > 0)
				defaultAttributeValuePreferenceInfo.setMaxLengthPossible(textValuePreferences.getMaxLengthPossible());
			defaultAttributeValuePreferenceInfo.setTextSearchEnabled(textValuePreferences.isTextSearchEnabled());
			break;
		}
		case AttributeValueTypes.DATE: {
			DateValuePreferences dateValuePreferences = (DateValuePreferences) attributeValuePreferences;
			if (dateValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(dateValuePreferences.getDefaultValue().getValue());
			if (dateValuePreferences.getMinimumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMinimumPossibleValue(dateValuePreferences.getMinimumPossibleValue().getValue());
			if (dateValuePreferences.getMaximumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMaximumPossibleValue(dateValuePreferences.getMaximumPossibleValue().getValue());
			break;
		}

		case AttributeValueTypes.TIME: {
			TimeValuePreferences timeValuePreferences = (TimeValuePreferences) attributeValuePreferences;
			if (timeValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(timeValuePreferences.getDefaultValue().getValue());
			if (timeValuePreferences.getMinimumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMinimumPossibleValue(timeValuePreferences.getMinimumPossibleValue().getValue());
			if (timeValuePreferences.getMaximumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMaximumPossibleValue(timeValuePreferences.getMaximumPossibleValue().getValue());
			break;
		}

		case AttributeValueTypes.NUMERIC: {
			NumericValuePreferences numericValuePreferences = (NumericValuePreferences) attributeValuePreferences;
			if (numericValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(String.valueOf(numericValuePreferences.getDefaultValue().getValue()));
			if (numericValuePreferences.getMinimumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMinimumPossibleValue(String.valueOf(numericValuePreferences
						.getMinimumPossibleValue().getValue()));
			if (numericValuePreferences.getMaximumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMaximumPossibleValue(String.valueOf(numericValuePreferences
						.getMaximumPossibleValue().getValue()));
			break;
		}

		case AttributeValueTypes.MEASUREMENT: {
			MeasurementValuePreferences measurementValuePreferences = (MeasurementValuePreferences) attributeValuePreferences;
			if (measurementValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(String
						.valueOf(measurementValuePreferences.getDefaultValue().getValue()));
			if (measurementValuePreferences.getMinimumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMinimumPossibleValue(String.valueOf(measurementValuePreferences
						.getMinimumPossibleValue().getValue()));
			if (measurementValuePreferences.getMaximumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMaximumPossibleValue(String.valueOf(measurementValuePreferences
						.getMaximumPossibleValue().getValue()));
			defaultAttributeValuePreferenceInfo.setMeasurementUnit(measurementValuePreferences.getMeasurementUnit());
			break;
		}

		case AttributeValueTypes.BOOLEAN: {
			BooleanValuePreferences booleanValuePreferences = (BooleanValuePreferences) attributeValuePreferences;
			if (booleanValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(String.valueOf(booleanValuePreferences.getDefaultValue().getValue()));
			break;
		}

		case AttributeValueTypes.DATETIME: {
			DateTimeValuePreferences dateTimeValuePreferences = (DateTimeValuePreferences) attributeValuePreferences;
			if (dateTimeValuePreferences.getDefaultValue() != null)
				defaultAttributeValuePreferenceInfo.setDefaultValue(dateTimeValuePreferences.getDefaultValue().getValue());
			if (dateTimeValuePreferences.getMinimumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMinimumPossibleValue(String.valueOf(dateTimeValuePreferences
						.getMinimumPossibleValue().getValue()));
			if (dateTimeValuePreferences.getMaximumPossibleValue() != null)
				defaultAttributeValuePreferenceInfo.setMaximumPossibleValue(dateTimeValuePreferences.getMaximumPossibleValue().getValue());
			break;
		}

		case AttributeValueTypes.DOMAIN: {
			if(attributeValuePreferences instanceof DomainValuePreferences){
				DomainValuePreferences domainValuePreferences = (DomainValuePreferences) attributeValuePreferences;
				DomainValue defaultDomainValue = domainValuePreferences.getDefaultValue();
				int domainId = domainValuePreferences.getDomainId();
				String domainName = attributeDomainService.getDomain(domainId).getName();			
				defaultAttributeValuePreferenceInfo = createDomainValuePreferences(domainId, domainName, defaultDomainValue);
			}
			break;
		}
		}
		return defaultAttributeValuePreferenceInfo;
	}

	private String getAttributeValueTypeString(int valueType) {
		if (valueType == AttributeValueTypes.BOOLEAN)
			return "BOOLEAN";
		if (valueType == AttributeValueTypes.DATE)
			return "DATE";
		if (valueType == AttributeValueTypes.DATETIME)
			return "DATETIME";
		if (valueType == AttributeValueTypes.DOMAIN)
			return "DOMAIN";
		if (valueType == AttributeValueTypes.MEASUREMENT)
			return "MEASUREMENT";
		if (valueType == AttributeValueTypes.NUMERIC)
			return "NUMERIC";
		if (valueType == AttributeValueTypes.TEXT)
			return "TEXT";
		if (valueType == AttributeValueTypes.TIME)
			return "TIME";
		return null;
	}

	private int getAttributeValueTypeId(String valueType) {
		if (valueType.equalsIgnoreCase("BOOLEAN"))
			return AttributeValueTypes.BOOLEAN;
		if (valueType.equalsIgnoreCase("DATE"))
			return AttributeValueTypes.DATE;
		if (valueType.equalsIgnoreCase("DATETIME"))
			return AttributeValueTypes.DATETIME;
		if (valueType.equalsIgnoreCase("DOMAIN"))
			return AttributeValueTypes.DOMAIN;
		if (valueType.equalsIgnoreCase("MEASUREMENT"))
			return AttributeValueTypes.MEASUREMENT;
		if (valueType.equalsIgnoreCase("NUMERIC"))
			return AttributeValueTypes.NUMERIC;
		if (valueType.equalsIgnoreCase("TEXT"))
			return AttributeValueTypes.TEXT;
		if (valueType.equalsIgnoreCase("TIME"))
			return AttributeValueTypes.TIME;
		return 0;
	}

	private String getModificationLevelString(int modificationLevel) {
		if (modificationLevel == AttributeModificationLevels.CLIENT_MODIFIABLE) {
			return "CLIENT_MODIFIABLE";
		}
		if (modificationLevel == AttributeModificationLevels.SERVER_MODIFIABLE) {
			return "SERVER_MODIFIABLE";
		}
		if (modificationLevel == AttributeModificationLevels.USER_MODIFIABLE) {
			return "USER_MODIFIABLE";
		}
		return null;
	}

	public TrusteeInfo transform(Trustee trustee) {
		TrusteeInfo trusteeInfo = new TrusteeInfo();
		BeanUtils.copyProperties(trustee, trusteeInfo, new String[] { "domainId" });
		return trusteeInfo;
	}

	public PublishingChannelList transform(PublishingChannel[] publishingChannels) {
		PublishingChannelList publishingChannelList = new PublishingChannelList();
		for (int i = 0; publishingChannels != null && i < publishingChannels.length; i++) {
			PublishingChannel publishingChannel = publishingChannels[i];
			PublishingChannelInfo publishingChannelInfo = new PublishingChannelInfo();
			publishingChannelInfo.setId(publishingChannel.getId());
			publishingChannelInfo.setName(publishingChannel.getDisplayName());
			publishingChannelInfo.setType(publishingChannel.getType());
			publishingChannelInfo.setProcess(publishingChannel.getProcessName());
			PublishingParameter[] channelParameters = publishingChannel.getChannelParameters();
			for (PublishingParameter publishingParameter : channelParameters) {
				Parameter parameter = new Parameter();
				parameter.setName(publishingParameter.getName());
				parameter.setValue(publishingParameter.getValue());
				parameter.setAsk(publishingParameter.isRuntimeValueRequired());
				publishingChannelInfo.getParameter().add(parameter);
			}
			if (publishingChannelList == null) {
				publishingChannelList = new PublishingChannelList();
			}
			publishingChannelList.getPublishingChannelInfo().add(publishingChannelInfo);
		}
		return publishingChannelList;
	}

	public com.quark.qpp.service.xmlBinding.ContentTypeInfo transform(ContentTypeInfo contentTypeInfo) throws InvalidContentTypeException,
			QppServiceException {
		com.quark.qpp.service.xmlBinding.ContentTypeInfo aContentTypeInfo = new com.quark.qpp.service.xmlBinding.ContentTypeInfo();
		BeanUtils.copyProperties(contentTypeInfo, aContentTypeInfo, new String[] { "domainId" });
		String contentTypeHierarchy = facadeUtility.getContentTypeHierarchy(contentTypeInfo.getId());
		aContentTypeInfo.setContentTypeHierarchy(contentTypeHierarchy);
		return aContentTypeInfo;
	}

	@Override
	public RoleInfoList transform(UserClass[] userClasses) throws InvalidContentTypeException, QppServiceException {
		RoleInfoList userClassInfoList = new RoleInfoList();
		List<RoleInfo> list = userClassInfoList.getRoleInfo();
		for (int i = 0; userClasses != null && i < userClasses.length; i++) {
			RoleInfo userClassInfo = transform(userClasses[i]);
			list.add(userClassInfo);
		}
		return userClassInfoList;

	}

	public User transform(UserInfo userInfo) throws UserClassNotFoundException, InvalidLdapProfileException, QppServiceException {
		User user = new User();
		BeanUtils.copyProperties(userInfo, user, new String[] { "id", "ldapProfileId" });
		if (userInfo.getId() != null) {
			user.setId(userInfo.getId());
		}
		// userclass name is mandatory in order to set userclass
		String userClassName = userInfo.getDefaultUserClass();
		if (userClassName != null) {
			long defaultUserClassId = facadeUtility.getUserClassId(userClassName);
			user.setDefaultUserClassId(defaultUserClassId);
		}

		if (userInfo.getLdapProfileId() != null) {
			user.setLdapProfileId(userInfo.getLdapProfileId());
		}

		if (!userInfo.isNativeTrustee()) {
			String ldapProfileName = userInfo.getLdapProfile();
			if (ldapProfileName != null && !ldapProfileName.isEmpty()) {
				long validLDAPProfileId = facadeUtility.getLdapProfileId(ldapProfileName);
				user.setLdapProfileId(validLDAPProfileId);
			}
		}
		
		return user;
	}

	@Override
	public Group transform(GroupInfo groupInfo) throws UserNotFoundException, QppServiceException {
		Group group = new Group();
		if (groupInfo.getId() != null)
			group.setId(groupInfo.getId());
		group.setName(groupInfo.getName());
		if (groupInfo.getMemberList() != null && groupInfo.getMemberList().getNameId() != null) {
			List<NameId> nameIdList = groupInfo.getMemberList().getNameId();
			ArrayList<Long> memberIds = new ArrayList<Long>();
			for (int i = 0; i < nameIdList.size(); i++) {
				NameId nameId = nameIdList.get(i);
				if (nameId.getName() != null && !nameId.getName().isEmpty()) {
					String name = nameId.getName();
					long userId = trusteeService.getUserId(name);
					memberIds.add(userId);
				} else if (nameId.getId() != null) {
					memberIds.add(nameId.getId());
				}
			}
			group.setMemberIds(getLongArray(memberIds));
		}

		group.setLdapDistinguishedName(groupInfo.getLdapDistinguishedName());
		group.setEmailAddress(groupInfo.getEmailAddress());
		group.setNativeTrustee(groupInfo.isNativeTrustee());

		long userClassId = groupInfo.getDefaultUserClassId();
		String userClassName = groupInfo.getDefaultUserClass();
		if (userClassName != null && userClassName.length() > 0) {
			userClassId = facadeUtility.getUserClassId(userClassName);
		}
		group.setDefaultUserClassId(userClassId);

		if (!group.isNativeTrustee()) {
			long ldapProfileId = (groupInfo.getLdapProfileId() == null) ? -1 : groupInfo.getLdapProfileId();
			String ldapProileName = groupInfo.getLdapProfile();
			if (ldapProileName != null && ldapProileName.length() > 0) {
				ldapProfileId = facadeUtility.getLdapProfileId(ldapProileName);
			}
			group.setLdapProfileId(ldapProfileId);
		}
		return group;
	}

	private long[] getLongArray(List<Long> arrayList) {
		int size = arrayList == null ? 0 : arrayList.size();
		long[] array = new long[size];
		for (int i = 0; i < size; i++) {
			array[i] = (Long) arrayList.get(i);
		}
		return array;
	}

	@Override
	public UserClass transform(RoleInfo roleInfo) throws QppServiceException {
		UserClass userClass = new UserClass();
		
		Map<Long, String>  allPrivGrpHierarchiesMap = getPrivilegeGroupsHierarchies();
		PrivilegeDefinition[] alllPrivilegeDefinitions = privilegeService.getAllPrivilegeDefs();
		
		if (roleInfo.getApplicationPrivList() != null) {
			List<Privilege> appPrivList = roleInfo.getApplicationPrivList().getPrivilege();
			if (appPrivList != null) {
				long[] appPrivIds = new long[appPrivList.size()];
				for (int i = 0; i < appPrivList.size(); i++) {
					Privilege priv = appPrivList.get(i);
					appPrivIds[i] = getPrivilegeId(priv, allPrivGrpHierarchiesMap, alllPrivilegeDefinitions);
				}
				userClass.setApplicationPrivileges(appPrivIds);
			}
		}
		if (roleInfo.getContentTypePrivList() != null && roleInfo.getContentTypePrivList().getContentTypePriv() != null) {
			List<ContentTypePriv> contentTypePrivs = roleInfo.getContentTypePrivList().getContentTypePriv();
			ContentTypePrivileges[] contentTypePrivileges = new ContentTypePrivileges[contentTypePrivs.size()];
			for (int i = 0; i < contentTypePrivs.size(); i++) {
				ContentTypePriv contentTypePriv = contentTypePrivs.get(i);

				List<Privilege> contentPrivList = contentTypePriv.getPrivilege();
				long[] privIds = null;
				if (contentPrivList != null) {
					privIds = new long[contentPrivList.size()];
					for (int j = 0; j < contentPrivList.size(); j++) {
						Privilege priv = contentPrivList.get(j);
						privIds[j] = getPrivilegeId(priv, allPrivGrpHierarchiesMap, alllPrivilegeDefinitions);
					}
				}

				String conTypeName = contentTypePriv.getContentTypeHierarchy();
				long contentTypeId = -1;
				if (conTypeName != null && !conTypeName.isEmpty()) {
					contentTypeId = facadeUtility.getContentTypeIdForHierarchy(conTypeName);
				} else if (contentTypePriv.getContentTypeId() != null) {
					contentTypeId = contentTypePriv.getContentTypeId();
				}
				contentTypePrivileges[i] = new ContentTypePrivileges();
				contentTypePrivileges[i].setContentTypeId(contentTypeId);
				contentTypePrivileges[i].setPrivilegeIds(privIds);
			}
			userClass.setContentTypePrivileges(contentTypePrivileges);
		}
		if (roleInfo.getId() != null)
			userClass.setId(roleInfo.getId());
		userClass.setName(roleInfo.getName());
		return userClass;
	}

	
	
	/**
	 * Returns privilege id of the given privilege after evaluating the privilege hierarchy, id and name. 
	 * First privilege hierarchy is checked, then privilege Id then name.
	 * 
	 */
	private long getPrivilegeId(Privilege priv, Map<Long, String>  allPrivGrpHierarchiesMap, PrivilegeDefinition[] alllPrivilegeDefinitions) throws QppServiceException {
		long privilegeId = 0;
		
		if (priv.getPrivilegeHierarchy() != null && !priv.getPrivilegeHierarchy().isEmpty()) {
			
			Iterator<Long> privGrpIds = allPrivGrpHierarchiesMap.keySet().iterator();
			String privGrpHiererachy = priv.getPrivilegeHierarchy().substring(0, priv.getPrivilegeHierarchy().lastIndexOf(';'));
			String privName = priv.getPrivilegeHierarchy().substring(priv.getPrivilegeHierarchy().lastIndexOf(';')+1, priv.getPrivilegeHierarchy().length());
			
			while(privGrpIds.hasNext()){
				long currPrivGrpId = privGrpIds.next();
				String currPrivGrpHierarchy = allPrivGrpHierarchiesMap.get(currPrivGrpId);
				if(currPrivGrpHierarchy.equalsIgnoreCase(privGrpHiererachy)){
					privilegeId = getPrivilegeId(currPrivGrpId, privName, alllPrivilegeDefinitions);
					break;
				}
			}
			
		} else if (priv.getId() != null && priv.getId() > 0) {
			privilegeId = priv.getId();
		} else if (priv.getName() != null) {
			PrivilegeDefinition[] privilegeDefinitions = facadeUtility.getPrivilegeDefinitionByName(priv.getName());
			if(privilegeDefinitions != null && privilegeDefinitions.length >0){
				privilegeDefinitions[0].getId();
			}
		}		
		return privilegeId;
	}

	/**
	 * Returns privilege Id based on its parent group id and name. 
	 */
	private long getPrivilegeId(long parentGroupId, String privName, PrivilegeDefinition[] privilegeDefinitions) {
		for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
			if (privilegeDefinition.getName().equalsIgnoreCase(privName) && privilegeDefinition.getGroupId()== parentGroupId) {
				return privilegeDefinition.getId();
			}
		}
		return 0;
		
	}

	@Override
	public Attribute transform(AttributeInfo attributeInfo) throws QppServiceException {
		Attribute attribute = new Attribute();
		if (attributeInfo.getId() != null) {
			attribute.setId(attributeInfo.getId());
		}
		attribute.setCreated(attributeInfo.getCreated());
		attribute.setCreator(attributeInfo.getCreator());
		attribute.setDisplayable(attributeInfo.isDisplayable());
		attribute.setConstraintsChangeable(attributeInfo.isConstraintsChangeable());
		attribute.setLimitedAccess(attributeInfo.isLimitedAccess());
		attribute.setLimitedAccessChangeable(attributeInfo.isLimitedAccessChangeable());
		attribute.setName(attributeInfo.getName());
		attribute.setQueryable(attributeInfo.isQueryable());
		attribute.setMultiValued(attributeInfo.isMultiValued());
		attribute.setUserDefined(attributeInfo.isUserDefined());
		attribute.setValuePreferencesChangeable(attributeInfo.isValuePreferencesChangeable());
		if (attributeInfo.getValueTypeId() <= 0 && attributeInfo.getValueType() != null && !attributeInfo.getValueType().isEmpty()) {
			attribute.setValueType(getAttributeValueTypeId(attributeInfo.getValueType()));
		} else {
			attribute.setValueType(attributeInfo.getValueTypeId());
		}
		attribute.setModificationLevel(AttributeModificationLevels.USER_MODIFIABLE);
		if (attributeInfo.getAttributeValuePreferenceInfo() != null) {
			int valueType = attribute.getValueType();
			if (valueType <= 0) {
				valueType = attributeService.getAttribute(attributeInfo.getId()).getValueType();
			}
			AttributeValuePreferences attributeValuePreferences = transform(attributeInfo.getAttributeValuePreferenceInfo(), valueType);
			attribute.setDefaultValuePreference(attributeValuePreferences);
		}
		if (attributeInfo.getAttributeValueListPreferenceInfo() != null) {
			int valueType = attribute.getValueType();
			if (valueType <= 0) {
				valueType = attributeService.getAttribute(attributeInfo.getId()).getValueType();
			}
			AttributeValuePreferences attributeValuePreferences = transform(attributeInfo.getAttributeValueListPreferenceInfo(), valueType);
			attribute.setDefaultValuePreference(attributeValuePreferences);
		}
		return attribute;
	}

	private AttributeValuePreferences transform(AttributeValueListPreferenceInfo attributeValueListPreferenceInfo, int valueTypeId)
			throws QppServiceException {
		DomainValueListPreferences domainValueListPreferences = null;
		switch (valueTypeId) {
		case AttributeValueTypes.DOMAIN: {
			domainValueListPreferences = new DomainValueListPreferences();
			int fetchedDomainId = -1;
			String domainName = attributeValueListPreferenceInfo.getDomainName();
			try {
				fetchedDomainId = facadeUtility.getDomainId(domainName);
			} catch (QppServiceException e) {
				fetchedDomainId = attributeValueListPreferenceInfo.getDomainId() != null?attributeValueListPreferenceInfo.getDomainId():-1;
			}
			domainValueListPreferences.setDomainId(fetchedDomainId);
			ArrayList<DomainValue> domainValuesArrayList = new ArrayList<DomainValue>();
			for (int j = 0; attributeValueListPreferenceInfo.getAttributeValuePreferenceInfo() != null
					&& j < attributeValueListPreferenceInfo.getAttributeValuePreferenceInfo().size(); j++) {
				AttributeValuePreferenceInfo attributeValuePreferences = attributeValueListPreferenceInfo.getAttributeValuePreferenceInfo()
						.get(j);
				DomainValue fetchedDomainValue = getDomainValue(attributeValuePreferences, fetchedDomainId);
				if (fetchedDomainValue != null) {
					domainValuesArrayList.add(fetchedDomainValue);
				}
			}
			DomainValueList domainValueList = new DomainValueList();
			domainValueList.setDomainValues(domainValuesArrayList.toArray(new DomainValue[0]));
			domainValueListPreferences.setDefaultValue(domainValueList);
		}
		}
		return domainValueListPreferences;
	}

	public AttributeValuePreferences transform(AttributeValuePreferenceInfo attributeValuePreferences, int valueTypeId)
			throws QppServiceException {
		switch (valueTypeId) {
		case AttributeValueTypes.TEXT: {
			TextValuePreferences textValuePreferences = new TextValuePreferences();
			TextValue defaulTextValue = new TextValue();
			defaulTextValue.setValue(attributeValuePreferences.getDefaultValue());
			textValuePreferences.setDefaultValue(defaulTextValue);
			if (attributeValuePreferences.getMaxLengthPossible() != null)
				textValuePreferences.setMaxLengthPossible(attributeValuePreferences.getMaxLengthPossible());
			if (attributeValuePreferences.isTextSearchEnabled() != null)
				textValuePreferences.setTextSearchEnabled(attributeValuePreferences.isTextSearchEnabled());
			return textValuePreferences;
		}
		case AttributeValueTypes.DATE: {
			DateValuePreferences dateValuePreferences = new DateValuePreferences();
			if (attributeValuePreferences.getDefaultValue() != null)
				if (attributeValuePreferences.getDefaultValue().trim().length() > 0) {
					DateValue defaultDateValue = new DateValue();
					defaultDateValue.setValue(attributeValuePreferences.getDefaultValue());
					dateValuePreferences.setDefaultValue(defaultDateValue);
				}
			if (attributeValuePreferences.getMinimumPossibleValue() != null)
				if (attributeValuePreferences.getMinimumPossibleValue().trim().length() > 0) {
					DateValue startDateValue = new DateValue();
					startDateValue.setValue(attributeValuePreferences.getMinimumPossibleValue());
					dateValuePreferences.setMinimumPossibleValue(startDateValue);
				}
			if (attributeValuePreferences.getMaximumPossibleValue() != null)
				if (attributeValuePreferences.getMaximumPossibleValue().trim().length() > 0) {
					DateValue endDateValue = new DateValue();
					endDateValue.setValue(attributeValuePreferences.getMaximumPossibleValue());
					dateValuePreferences.setMaximumPossibleValue(endDateValue);
				}
			return dateValuePreferences;
		}
		case AttributeValueTypes.TIME: {
			TimeValuePreferences timeValuePreferences = new TimeValuePreferences();
			if (attributeValuePreferences.getDefaultValue() != null)
				if (attributeValuePreferences.getDefaultValue().trim().length() > 0) {
					TimeValue defaultTimeValue = new TimeValue();
					defaultTimeValue.setValue(attributeValuePreferences.getDefaultValue());
					timeValuePreferences.setDefaultValue(defaultTimeValue);
				}
			if (attributeValuePreferences.getMinimumPossibleValue() != null)
				if (attributeValuePreferences.getMinimumPossibleValue().trim().length() > 0) {
					TimeValue startTimeValue = new TimeValue();
					startTimeValue.setValue(attributeValuePreferences.getMinimumPossibleValue());
					timeValuePreferences.setMinimumPossibleValue(startTimeValue);
				}
			if (attributeValuePreferences.getMaximumPossibleValue() != null)
				if (attributeValuePreferences.getMaximumPossibleValue().trim().length() > 0) {
					TimeValue endTimeValue = new TimeValue();
					endTimeValue.setValue(attributeValuePreferences.getMaximumPossibleValue());
					timeValuePreferences.setMaximumPossibleValue(endTimeValue);
				}
			return timeValuePreferences;
		}
		case AttributeValueTypes.NUMERIC: {
			NumericValuePreferences numericValuePreferences = new NumericValuePreferences();
			if (attributeValuePreferences.getDefaultValue() != null && attributeValuePreferences.getDefaultValue().trim().length() > 0) {
				NumericValue defaultNumericValue = new NumericValue(Long.valueOf(attributeValuePreferences.getDefaultValue()));
				numericValuePreferences.setDefaultValue(defaultNumericValue);
			}
			if (attributeValuePreferences.getMaximumPossibleValue() != null
					&& attributeValuePreferences.getMaximumPossibleValue().trim().length() > 0) {
				NumericValue maxNumericValue = new NumericValue(Long.valueOf(attributeValuePreferences.getMaximumPossibleValue()));
				numericValuePreferences.setMaximumPossibleValue(maxNumericValue);
			}
			if (attributeValuePreferences.getMinimumPossibleValue() != null
					&& attributeValuePreferences.getMinimumPossibleValue().trim().length() > 0) {
				NumericValue minNumericValue = new NumericValue(Long.valueOf(attributeValuePreferences.getMinimumPossibleValue()));
				numericValuePreferences.setMinimumPossibleValue(minNumericValue);
			}
			return numericValuePreferences;
		}
		case AttributeValueTypes.MEASUREMENT: {
			MeasurementValuePreferences measurementValuePreferences = new MeasurementValuePreferences();
			MeasurementValue defaultMeasurementValue = new MeasurementValue();
			if (attributeValuePreferences.getDefaultValue() != null && attributeValuePreferences.getDefaultValue().trim().length() > 0) {
				defaultMeasurementValue.setValue(Double.valueOf(attributeValuePreferences.getDefaultValue()));
				measurementValuePreferences.setDefaultValue(defaultMeasurementValue);
			}
			if (attributeValuePreferences.getMinimumPossibleValue() != null
					&& attributeValuePreferences.getMinimumPossibleValue().trim().length() > 0) {
				MeasurementValue minMeasurementValue = new MeasurementValue();
				minMeasurementValue.setValue(Double.valueOf(attributeValuePreferences.getMinimumPossibleValue()));
				measurementValuePreferences.setMinimumPossibleValue(minMeasurementValue);
			}
			if (attributeValuePreferences.getMaximumPossibleValue() != null
					&& attributeValuePreferences.getMaximumPossibleValue().trim().length() > 0) {
				MeasurementValue maxMeasurementValue = new MeasurementValue();
				maxMeasurementValue.setValue(Double.valueOf(attributeValuePreferences.getMaximumPossibleValue()));
				measurementValuePreferences.setMaximumPossibleValue(maxMeasurementValue);
			}
			if (attributeValuePreferences.getMeasurementUnit() != null) {
				measurementValuePreferences.setMeasurementUnit(attributeValuePreferences.getMeasurementUnit());
			}
			if (attributeValuePreferences.isOnlyMeasurementUnitChangeable() != null) {
				measurementValuePreferences.setOnlyMeasurementUnitChangeable(attributeValuePreferences.isOnlyMeasurementUnitChangeable());
			}
			return measurementValuePreferences;
		}
		case AttributeValueTypes.BOOLEAN: {
			BooleanValuePreferences booleanValuePreferences = new BooleanValuePreferences();
			BooleanValue defaultCheckBoxValue = new BooleanValue();
			if (attributeValuePreferences.getDefaultValue() != null)
				defaultCheckBoxValue.setValue(Boolean.valueOf(attributeValuePreferences.getDefaultValue()));
			booleanValuePreferences.setDefaultValue(defaultCheckBoxValue);
			return booleanValuePreferences;
		}
		case AttributeValueTypes.DATETIME: {
			DateTimeValuePreferences dateTimeValuePreferences = new DateTimeValuePreferences();
			if (attributeValuePreferences.getDefaultValue() != null)
				if (attributeValuePreferences.getDefaultValue().trim().length() > 0) {
					DateTimeValue defaultDateTimeValue = new DateTimeValue();
					defaultDateTimeValue.setValue(attributeValuePreferences.getDefaultValue());
					dateTimeValuePreferences.setDefaultValue(defaultDateTimeValue);
				}
			if (attributeValuePreferences.getMinimumPossibleValue() != null)
				if (attributeValuePreferences.getMinimumPossibleValue().trim().length() > 0) {
					DateTimeValue startDateTimeValue = new DateTimeValue();
					startDateTimeValue.setValue(attributeValuePreferences.getMinimumPossibleValue());
					dateTimeValuePreferences.setMinimumPossibleValue(startDateTimeValue);
				}
			if (attributeValuePreferences.getMaximumPossibleValue() != null)
				if (attributeValuePreferences.getMaximumPossibleValue().trim().length() > 0) {
					DateTimeValue endDateTimeValue = new DateTimeValue();
					endDateTimeValue.setValue(attributeValuePreferences.getMaximumPossibleValue());
					dateTimeValuePreferences.setMaximumPossibleValue(endDateTimeValue);
				}
			return dateTimeValuePreferences;
		}
		case AttributeValueTypes.DOMAIN: {
			DomainValuePreferences domainValuePreferences = new DomainValuePreferences();
			int fetchedDomainId = -1;
			String domainName = attributeValuePreferences.getDomainName();
			try {
				fetchedDomainId = facadeUtility.getDomainId(domainName);
			} catch (QppServiceException e) {
				fetchedDomainId = attributeValuePreferences.getDomainId() != null?attributeValuePreferences.getDomainId() : -1;
			}
			domainValuePreferences.setDomainId(fetchedDomainId);
			DomainValue fetchedDomainValue = getDomainValue(attributeValuePreferences, fetchedDomainId);
			
			if(fetchedDomainValue!=null){
				domainValuePreferences.setDefaultValue(fetchedDomainValue);
			}
			return domainValuePreferences;
		}
		}
		return null;
	}
	
	private DomainValue getDomainValue(AttributeValuePreferenceInfo attributeValuePreferences, int fetchedDomainId)
			throws DomainNotFoundException, QppServiceException {
		DomainValue fetchedDomainValue = null;
		if (attributeValuePreferences != null) {
			if (attributeValuePreferences.getDefaultDomainItemName() != null
					&& attributeValuePreferences.getDefaultDomainItemName().trim().length() > 0) {
				fetchedDomainValue = facadeUtility.fetchDomainValue(fetchedDomainId, attributeValuePreferences.getDefaultDomainItemName(),
						0, null);
			} else if (attributeValuePreferences.getDefaultDomainItemId() != null && attributeValuePreferences.getDefaultDomainItemId() > 0) {
				fetchedDomainValue = attributeDomainService.getDomainValue(fetchedDomainId,
						attributeValuePreferences.getDefaultDomainItemId());
			}
		}
		return fetchedDomainValue;
	}

	@Override
	public ContentTypeInfoList transform(ContentType[] contentTypes) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfoList contentTypeInfoList = new ContentTypeInfoList();
		for (ContentType contentType : contentTypes) {
			com.quark.qpp.service.xmlBinding.ContentTypeInfo contentTypeInfo = transform(contentType);
			contentTypeInfoList.getContentTypeInfo().add(contentTypeInfo);
		}
		return contentTypeInfoList;
	}

	public com.quark.qpp.service.xmlBinding.ContentTypeInfo transform(ContentType contentType) throws InvalidContentTypeException,
			QppServiceException {
		// TODO use bean utils
		com.quark.qpp.service.xmlBinding.ContentTypeInfo contentTypeInfo = new com.quark.qpp.service.xmlBinding.ContentTypeInfo();
		contentTypeInfo.setId(contentType.getId());
		contentTypeInfo.setName(contentType.getName());
		String contentTypeHierarchy = facadeUtility.getContentTypeHierarchy(contentType.getId());
		contentTypeInfo.setContentTypeHierarchy(contentTypeHierarchy);
		contentTypeInfo.setSystemDefined(contentType.isSystemDefined());
		contentTypeInfo.setExtensible(contentType.isExtensible());
		contentTypeInfo.setCreated(contentType.getCreated());
		contentTypeInfo.setCreator(contentType.getCreator());
		contentTypeInfo.setCreatorName(getUserName(contentType.getCreator()));
		contentTypeInfo.setLastModified(contentType.getLastModified());// DATE
		contentTypeInfo.setLastModifier(contentType.getLastModifier());
		contentTypeInfo.setLastModifierName(getUserName(contentType.getLastModifier()));
		ContentTypeInfo[] infos = contentStructureService.getContentTypeHierarchy(contentType.getId());
		if (infos.length > 1) {
			long parentContentTypeId = infos[1].getId();
			contentTypeInfo.setParentContentTypeId(parentContentTypeId);
		}
		ContentType[] subContentTypes = contentType.getSubContentTypes();
		ContentTypeInfoList contentTypeInfoList = new ContentTypeInfoList();
		for (ContentType subContentType : subContentTypes) {
			contentTypeInfo.setChildrenAvailable(true);
			com.quark.qpp.service.xmlBinding.ContentTypeInfo subContentTypeInfo = transform(subContentType);
			contentTypeInfoList.getContentTypeInfo().add(subContentTypeInfo);
		}
		contentTypeInfo.setContentTypeInfoList(contentTypeInfoList);
		contentTypeInfo.setContentTypeAttributeMappingInfoList(getContentTypeAttributeMappingInfoList(contentType.getId()));
		return contentTypeInfo;
	}

	private ContentTypeAttributeMappingInfoList getContentTypeAttributeMappingInfoList(long contentTypeId)
			throws InvalidContentTypeException, QppServiceException {
		ContentTypeAttributeMapping[] attributeMapping = contentStructureService.getContentTypeAttributesMapping(contentTypeId);
		return transform(attributeMapping);
	}

	private ContentTypeAttributeMappingInfoList transform(ContentTypeAttributeMapping[] contentTypeAttributeMappings)
			throws AttributeNotFoundException, QppServiceException {
		ContentTypeAttributeMappingInfoList contentTypeAttributeMappingInfoList = new ContentTypeAttributeMappingInfoList();
		for (ContentTypeAttributeMapping contentTypeAttributeMapping : contentTypeAttributeMappings) {
			ContentTypeAttributeMappingInfo transformedContentTypeAttributeMappingInfo = transform(contentTypeAttributeMapping);
			contentTypeAttributeMappingInfoList.getContentTypeAttributeMappingInfo().add(transformedContentTypeAttributeMappingInfo);
		}
		return contentTypeAttributeMappingInfoList;
	}

	public ContentTypeAttributeMapping[] transform(ContentTypeAttributeMappingInfoList contentTypeAttributeMappingInfoList)
			throws AttributeNotFoundException, QppServiceException {
		List<ContentTypeAttributeMappingInfo> contentTypeAttributeMappingInfos = contentTypeAttributeMappingInfoList
				.getContentTypeAttributeMappingInfo();
		ArrayList<ContentTypeAttributeMapping> contentTypeAttributeMappings = new ArrayList<ContentTypeAttributeMapping>();
		for (int i = 0; contentTypeAttributeMappingInfos != null && i < contentTypeAttributeMappingInfos.size(); i++) {
			ContentTypeAttributeMapping contentTypeAttributeMapping = new ContentTypeAttributeMapping();
			BeanUtils.copyProperties(contentTypeAttributeMappingInfos.get(i), contentTypeAttributeMapping);
			contentTypeAttributeMappings.add(contentTypeAttributeMapping);
		}
		return contentTypeAttributeMappings.toArray(new ContentTypeAttributeMapping[0]);
	}

	private ContentTypeAttributeMappingInfo transform(ContentTypeAttributeMapping contentTypeAttributeMapping)
			throws AttributeNotFoundException, QppServiceException {
		ContentTypeAttributeMappingInfo attributeMappingInfo = new ContentTypeAttributeMappingInfo();
		BeanUtils.copyProperties(contentTypeAttributeMapping, attributeMappingInfo);
		attributeMappingInfo.setValue(getAttributeName(contentTypeAttributeMapping.getAttributeId()));
		return attributeMappingInfo;
	}
	

	public StatusTransition[] transform(StatusTransitionInfoList statusTransitionInfoList, long workflowId) throws WorkflowNotFoundException, QppServiceException{
		if (statusTransitionInfoList == null || statusTransitionInfoList.getStatusTransitionInfo() == null) {
			return new StatusTransition[0];
		}
		
		Iterator<StatusTransitionInfo> iterator = statusTransitionInfoList.getStatusTransitionInfo().iterator();
		StatusTransition[] statusTransitions = new StatusTransition[statusTransitionInfoList.getStatusTransitionInfo().size()];
		int i = 0;
		while (iterator.hasNext()) {
			StatusTransitionInfo statusTransitionInfo = iterator.next();
			statusTransitions[i++] = transform(statusTransitionInfo, workflowId);
		}
		return statusTransitions;
	}
	
	public StatusTransition transform(StatusTransitionInfo statusTransitionInfo, long workflowId) throws WorkflowNotFoundException, QppServiceException {
		StatusTransition statusTransition = new StatusTransition();
		if (statusTransitionInfo.getName() != null && statusTransitionInfo.getName().trim().length() > 0) {
			statusTransition.setStatusId(getStatusId(workflowId, statusTransitionInfo.getName()));
		} else if (statusTransitionInfo.getId() != null && statusTransitionInfo.getId() > 0) {
			statusTransition.setStatusId(statusTransitionInfo.getId());
		}
		
		statusTransition.setWorkflowInitiatingStatus(statusTransitionInfo.isWorkflowInitiatingStatus());
		if(statusTransitionInfo.getNextPossibleStatusInfoList() != null && statusTransitionInfo.getNextPossibleStatusInfoList().getNextPossibleStatusInfo()!=null && statusTransitionInfo.getNextPossibleStatusInfoList().getNextPossibleStatusInfo().size()>0){
			List<NextPossibleStatusInfo> nextPossibleStatusInfos = statusTransitionInfo.getNextPossibleStatusInfoList().getNextPossibleStatusInfo();
			long[] nextPossibleStatusIds = new long[nextPossibleStatusInfos == null ? 0 : nextPossibleStatusInfos.size()];
			for (int i = 0; nextPossibleStatusInfos != null && i < nextPossibleStatusInfos.size(); i++) {
				if (nextPossibleStatusInfos.get(i).getName() != null && nextPossibleStatusInfos.get(i).getName().trim().length() > 0) {
					nextPossibleStatusIds[i] = getStatusId(workflowId, nextPossibleStatusInfos.get(i).getName());
				}else if (nextPossibleStatusInfos.get(i).getId() != null && nextPossibleStatusInfos.get(i).getId() > 0) {
					nextPossibleStatusIds[i] = nextPossibleStatusInfos.get(i).getId();
				} 
			}
			statusTransition.setNextPossibleStatusIds(nextPossibleStatusIds);
		}
		return statusTransition;
	}

	
	private long getStatusId(long workflowId, String sName) throws WorkflowNotFoundException, QppServiceException{
		Status[] statuses =  workflowService.getWorkflow(workflowId).getStatuses();
		for (int i = 0; i < statuses.length; i++) {
			if(statuses[i].getName().equalsIgnoreCase(sName)){
				return statuses[i].getId();
			}
		}
		return -1;
	}
	
	public Status[] transform(StatusInfoList statusInfoList, String workflowName) throws UserClassNotFoundException, QppServiceException {
		if (statusInfoList == null || statusInfoList.getStatusInfo() == null) {
			return new Status[0];
		}
		Iterator<StatusInfo> iterator = statusInfoList.getStatusInfo().iterator();
		Status[] statuses = new Status[statusInfoList.getStatusInfo().size()];
		int i = 0;
		while (iterator.hasNext()) {
			Status status = new Status();
			StatusInfo statusInfo = iterator.next();
			if (statusInfo.getId() != null) {
				status.setId(statusInfo.getId());
			} else if (statusInfo.getName() != null && !statusInfo.getName().isEmpty() && workflowName != null) {
				try {
					Status statusFetched = workflowService.getStatusByName(workflowName, statusInfo.getName());
					status.setId(statusFetched.getId());
				} catch (QppServiceException e) {
					/*
					 * Do not log the exception since we are checking for the existence of status with given name in workflow.
					 * In case the status with given name doensot exist, it implies the status is to be added.
					 */
				}
			}
			status.setName(statusInfo.getName());
			status.setColorRed(statusInfo.getColorRed());
			status.setColorGreen(statusInfo.getColorGreen());
			status.setColorBlue(statusInfo.getColorBlue());
			status.setPosition(statusInfo.getPosition());			
			statuses[i++] = status;
		}
		return statuses;
	}

	public ContentTypePrivileges[] transform(ContentTypePrivList contentTypePrivList) throws QppServiceException {
		List<ContentTypePriv> list = contentTypePrivList.getContentTypePriv();
		ArrayList<ContentTypePrivileges> contentPrivArrayList = new ArrayList<ContentTypePrivileges>();
		for (int i = 0; i < list.size(); i++) {
			ContentTypePrivileges contentTypePrivileges = new ContentTypePrivileges();
			ContentTypePriv conTypePriv = list.get(i);
			long contentTypeId = -1;
			if (conTypePriv.getContentTypeHierarchy() != null) {
				contentTypeId = facadeUtility.getContentTypeIdForHierarchy(conTypePriv.getContentTypeHierarchy());
			} else if (conTypePriv.getContentTypeId() != null) {
				contentTypeId = conTypePriv.getContentTypeId();
			}
			contentTypePrivileges.setContentTypeId(contentTypeId);
			contentTypePrivileges.setPrivilegeIds(getPrivilegeIds(list.get(i).getPrivilege()));
			contentPrivArrayList.add(contentTypePrivileges);
		}
		return contentPrivArrayList.toArray(new ContentTypePrivileges[0]);
	}

	private long[] getPrivilegeIds(List<Privilege> privilegeList) throws QppServiceException {
		Iterator<Privilege> iterator = privilegeList.iterator();
		ArrayList<Long> ids = new ArrayList<Long>();

		Map<Long, String>  allPrivGrpHierarchiesMap = getPrivilegeGroupsHierarchies();
		PrivilegeDefinition[] alllPrivilegeDefinitions = privilegeService.getAllPrivilegeDefs();
		
		while (iterator.hasNext()) {
			Privilege priv = iterator.next();
			long privID = getPrivilegeId(priv, allPrivGrpHierarchiesMap, alllPrivilegeDefinitions);
			ids.add(privID);
		}
		return getLongArray(ids);
	}
	
	private List<Long> getAllUserClassesIds() throws QppServiceException {
		List<Long> list = new ArrayList<Long>();

		UserClass[] userClasses = getAllUserClasses();
		for (UserClass userClass : userClasses) {
			list.add(userClass.getId());
		}
		return list;
	}

	public Attribute[] getWorkflowAttributes(long workflowId) throws QppServiceException {
		long[] contentTypes = workflowService.getWorkflowContentTypes(workflowId);
		Map<Long, Attribute> workflowAttributeMap = new HashMap<Long, Attribute>();
		for (long contentType : contentTypes) {
			Attribute[] attributes = contentStructureService.getContentTypeAttributes(contentType, false);
			for (Attribute attribute : attributes) {
				workflowAttributeMap.put(attribute.getId(), attribute);
			}
		}
		return workflowAttributeMap.values().toArray(new Attribute[0]);
	}
	
	private UserClass[] getAllUserClasses() throws QppServiceException {
		UserClass[] userClasses = userClassService.getAllUserClasses();
		return userClasses;
	}

	public JobJacket[] transform(JobJacketInfoList jobJacketInfoList) {
		List<JobJacketInfo> list = jobJacketInfoList.getJobJacketInfo();
		ArrayList<JobJacket> jobJacket = new ArrayList<JobJacket>();
		for (int i = 0; i < list.size(); i++) {
			JobJacket jacket = transform(list.get(i));
			jobJacket.add(jacket);
		}
		return jobJacket.toArray(new JobJacket[0]);
	}

	public JobJacket transform(JobJacketInfo jobJacketInfo) {
		JobJacket jobJacket = new JobJacket();
		BeanUtils.copyProperties(jobJacketInfo, jobJacket);
		return jobJacket;
	}

	public WorkflowInfo[] transform(WorkflowInfoList infoList) {
		List<WorkflowInfo> list = infoList.getWorkflowInfo();
		ArrayList<WorkflowInfo> workflowInfoList = new ArrayList<WorkflowInfo>();
		for (int i = 0; i < list.size(); i++) {
			WorkflowInfo info = new WorkflowInfo();
			BeanUtils.copyProperties(list.get(i), info);
			workflowInfoList.add(info);
		}
		return workflowInfoList.toArray(new WorkflowInfo[0]);
	}

	public CollectionGroup[] transform(GroupInfoList groupInfoList) throws UserClassNotFoundException, QppServiceException {
		List<GroupInfo> list = groupInfoList.getGroupInfo();
		ArrayList<CollectionGroup> collectionGroupList = new ArrayList<CollectionGroup>();
		for (int i = 0; i < list.size(); i++) {
			GroupInfo groupInfo = list.get(i);
			String groupName = groupInfo.getName();
			CollectionGroup colGroup = new CollectionGroup();
			if(groupName != null && groupName.length() > 0){
				long groupId = facadeUtility.getGroupId(groupName);
				colGroup.setGroupId(groupId);
			}else if(groupInfo.getId() != null){
				colGroup.setGroupId(groupInfo.getId());
			}
			
			String overridenUserclassName = groupInfo.getOverriddenUserClassName();
			if(overridenUserclassName != null && overridenUserclassName.length() > 0){
				long userClassId = facadeUtility.getUserClassId(overridenUserclassName);
				colGroup.setOverriddenUserClassId(userClassId);
			}else if(groupInfo.getOverriddenUserClassId() != null){
				colGroup.setOverriddenUserClassId(groupInfo.getOverriddenUserClassId());
			}
			collectionGroupList.add(colGroup);
		}
		return collectionGroupList.toArray(new CollectionGroup[0]);
	}

	public StorageRepositoryInfoList transform(StorageRepository[] storageRepositories) throws QppServiceException {
		StorageRepositoryInfoList storageRepositoryInfoList = new StorageRepositoryInfoList();
		for (int i = 0; storageRepositories != null && i < storageRepositories.length; i++) {
			StorageRepositoryInfo storageRepositoryInfo = transform(storageRepositories[i]);
			storageRepositoryInfoList.getStorageRepositoryInfo().add(storageRepositoryInfo);
		}
		return storageRepositoryInfoList;
	}

	public StorageRepository transform(StorageRepositoryInfo storageRepoInfo) throws QppServiceException {
		StorageRepository storageRepository = new StorageRepository();
		if (storageRepoInfo != null) {
			BeanUtils.copyProperties(storageRepoInfo, storageRepository, new String[] { "id", "status", "repositoryTypeId",
					"connectionProperties" });
			if (storageRepoInfo.getRepositoryType() != null) {
				storageRepository.setRepositoryTypeId(facadeUtility.getRepositoryTypeId(storageRepoInfo.getRepositoryType()));
			} else if (storageRepoInfo.getRepositoryTypeId() > 0) {
				storageRepository.setRepositoryTypeId(storageRepoInfo.getRepositoryTypeId());
			}
			String connectionURL = storageRepoInfo.getConnectionInfo();
			if (connectionURL != null) {
				storageRepository.setUrl(connectionURL.trim());
			}
		}
		return storageRepository;
	}

	public StorageRepositoryInfo transform(StorageRepository storageRepository) throws QppServiceException {
		StorageRepositoryInfo storageRepositoryInfo = new StorageRepositoryInfo();
		BeanUtils.copyProperties(storageRepository, storageRepositoryInfo, new String[] { "status" });
		storageRepositoryInfo.setRepositoryType(getRepositoryTypeName(storageRepository.getRepositoryTypeId()));
		int repositoryStatus = storageRepository.getStatus();
		storageRepositoryInfo.setStatus(getStorageStatusName(repositoryStatus));
		storageRepositoryInfo.setStatusId(repositoryStatus);
		// storageRepositoryInfo.setConnectionInfo("<![CDATA["+storageRepository.getUrl()+"]]");
		storageRepositoryInfo.setConnectionInfo(storageRepository.getUrl());
		return storageRepositoryInfo;
	}

	private String getRepositoryTypeName(long repositoryTypeId) throws QppServiceException {
		StorageRepositoryType[] storageRepositoryTypes = storageService.getAllRepositoryTypes();
		String repositoryTypeName = null;
		for (StorageRepositoryType repositoryType : storageRepositoryTypes) {
			if (repositoryType.getId() == repositoryTypeId) {
				repositoryTypeName = repositoryType.getName();
				break;
			}
		}
		return repositoryTypeName;
	}

	private String getStorageStatusName(int statusId) {
		if (statusId == RepositoryStatuses.READ_ONLY)
			return "READ_ONLY";
		else if (statusId == RepositoryStatuses.READ_WRITE)
			return "READ_WRITE";
		else if (statusId == RepositoryStatuses.UNAVAILABLE)
			return "UNAVAILABLE";
		else
			return null;
	}

	public FormInfo transform(Form form, long workflowId) throws InvalidContentTypeException, QppServiceException {
		boolean isDefaultForm = true;
		FormAttributeList formAttributeInfoList = new FormAttributeList();
		List<FormAttribute> listOfFormAttributeInfo = formAttributeInfoList.getFormAttribute();
		if (form != null && form.getContent() != null) {
			String content = form.getContent();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			org.w3c.dom.Document document = null;
			try {
				DocumentBuilder builder = factory.newDocumentBuilder();
				InputSource is = new InputSource(new StringReader(content));
				document = builder.parse(is);
				NodeList attributeListNodes = document.getElementsByTagName("attributeList");
				NodeList formSettingsNodes = document.getElementsByTagName("formSettings");
				if (formSettingsNodes != null && formSettingsNodes.getLength() > 0) {
					Element formSettingElement = (Element) formSettingsNodes.item(0);
					NodeList defaultFormList = formSettingElement.getElementsByTagName("defaultForm");
					if (defaultFormList != null && defaultFormList.getLength() > 0) {
						Element defaultFormElement = (Element) defaultFormList.item(0);
						if (defaultFormElement != null && defaultFormElement.getFirstChild().getNodeValue().equalsIgnoreCase("false")) {
							isDefaultForm = false;
						}
					}
				}

				// Get all attributes applicable for a content type
				ContentTypeAttributeMapping[] contentTypeAttributeMappings = contentStructureService.getContentTypeAttributesMapping(form
						.getContentTypeId());
				List<Long> contentTypeAttributeList = new ArrayList<Long>();
				for (ContentTypeAttributeMapping contentTypeAttributeMapping : contentTypeAttributeMappings) {
					contentTypeAttributeList.add(contentTypeAttributeMapping.getAttributeId());
				}

				if (attributeListNodes != null && attributeListNodes.getLength() > 0) {
					Element attributeListElement = (Element) attributeListNodes.item(0);
					NodeList attributeList = attributeListElement.getElementsByTagName("attribute");
					for (int i = 0; i < attributeList.getLength(); i++) {
						Element attributeEl = (Element) attributeList.item(i);
						String attributeId = attributeEl.getAttribute("id");
						// if attribute is not applicable for content type. This
						// case arises when attribute mapping is removed or form
						// is
						// applied recursively this content type.
						if (!contentTypeAttributeList.contains(Long.valueOf(attributeId))) {
							continue;
						}
						FormAttribute formAttributeInfo = new FormAttribute();
						formAttributeInfo.setId(Long.valueOf(attributeId));
						NodeList sizeList = attributeEl.getElementsByTagName("size");
						if (sizeList != null && sizeList.getLength() > 0) {
							Element sizeElement = (Element) sizeList.item(0);
							String xPos = sizeElement.getAttribute("x");
							String yPos = sizeElement.getAttribute("y");
							String width = sizeElement.getAttribute("width");
							String labelWidth = sizeElement.getAttribute("labelWidth");
							String controlWidth = sizeElement.getAttribute("controlWidth");
							Attribute attribute = attributeService.getAttribute(Long.valueOf(attributeId));
							String attributeName = attribute.getName();
							formAttributeInfo.setName(attributeName);
							formAttributeInfo.setTotalWidth(width);
							formAttributeInfo.setXPos(xPos);
							formAttributeInfo.setYPos(yPos);
							formAttributeInfo.setLabelWidth(labelWidth);
							formAttributeInfo.setControlWidth(controlWidth);
							formAttributeInfo.setValueType(attribute.getValueType());
							listOfFormAttributeInfo.add(formAttributeInfo);
						}
					}
				}
			} catch (Exception e) {
				// Do nothing
			}
		}
		// If use DefaultForm is true merge form attributes and qps attributes
		// of that workflow else use attributes defined in form xml for creating
		// the form.
		if (isDefaultForm) {
			List<Attribute> mergedFormAttributeList = new ArrayList<Attribute>();
			// Get all attributes applicable to workflow
			Attribute[] defaultAttributeList = contentStructureService.getContentTypeAttributes(form.getContentTypeId(), false);
			long maxFormElementHeight = AttributeUtility.DEFAULT_Y_AXIS_START;
			if (listOfFormAttributeInfo.size() > 0) {
				for (int i = 0; i < defaultAttributeList.length; i++) {
					boolean isFormAttribute = false;
					// Check if form XML already contains the workflow attribute
					for (FormAttribute formAttribute : listOfFormAttributeInfo) {
						if (formAttribute.getId() == defaultAttributeList[i].getId()) {
							isFormAttribute = true;
							long elementHeight = Long.valueOf(formAttribute.getYPos());
							if (maxFormElementHeight < elementHeight) {
								maxFormElementHeight = elementHeight;
							}
							break;
						}
					}
					if (!isFormAttribute && defaultAttributeList[i].isDisplayable()) {
						mergedFormAttributeList.add(defaultAttributeList[i]);
					}

					if (mergedFormAttributeList.size() > 0) {
						maxFormElementHeight = maxFormElementHeight + AttributeUtility.DEFAULT_VERTICAL_GAP_BETWEEN_CONTROLS;
						List<FormAttribute> formMergedAttributeList = attributeUtility.createSortedAttributeListWithDefaultPlacement(
								mergedFormAttributeList.toArray(new Attribute[mergedFormAttributeList.size()]), maxFormElementHeight);
						listOfFormAttributeInfo.addAll(formMergedAttributeList);
					}
				}
			} else {
				listOfFormAttributeInfo = attributeUtility.createSortedAttributeListWithDefaultPlacement(defaultAttributeList,
						AttributeUtility.DEFAULT_VERTICAL_GAP_BETWEEN_CONTROLS);
				formAttributeInfoList.getFormAttribute().addAll(listOfFormAttributeInfo);
			}
		}

		FormInfo formInfo = new FormInfo();
		formInfo.setId(form.getId());
		formInfo.setContentTypeId(form.getContentTypeId());
		if (form.getContentTypeId() > 0) {
			formInfo.setContentTypeName(contentStructureService.getContentType(form.getContentTypeId()).getName());
		}
		formInfo.setDefaultView(isDefaultForm);
		formInfo.setFormAttributeList(formAttributeInfoList);
		if (workflowId > 0) {
			formInfo.setWorkflowId(workflowId);
			formInfo.setWorkflowName(workflowService.getWorkflow(workflowId).getName());
		}
		return formInfo;
	}

	public RelationTypeAttributeMapping[] transform(RelationAttributeList relationAttributeList) throws AttributeNotFoundException,
			QppServiceException {
		if (relationAttributeList == null || relationAttributeList.getRelationAttribute() == null
				|| relationAttributeList.getRelationAttribute().size() == 0) {
			return new RelationTypeAttributeMapping[] {};
		}
		List<RelationAttribute> list = relationAttributeList.getRelationAttribute();
		ArrayList<RelationTypeAttributeMapping> relationAttributeInfoList = new ArrayList<RelationTypeAttributeMapping>();
		for (int i = 0; list != null && i < list.size(); i++) {
			RelationTypeAttributeMapping mappingInfo = new RelationTypeAttributeMapping();
			RelationAttribute relationAttribute = list.get(i);
			String attributeName = relationAttribute.getValue();
			if (attributeName != null && !attributeName.isEmpty()) {
				mappingInfo.setAttributeId(attributeService.getAttributeByName(attributeName).getId());
			} else if (relationAttribute.getId() != null) {
				mappingInfo.setAttributeId(relationAttribute.getId());
			}
			mappingInfo.setValueMandatory(list.get(i).isValueMandatory());
			relationAttributeInfoList.add(mappingInfo);
		}
		return relationAttributeInfoList.toArray(new RelationTypeAttributeMapping[0]);
	}

	public RelationTypeInfo transform(RelationType relationType) throws AttributeNotFoundException, QppServiceException {
		RelationTypeInfo relationTypeInfo = new RelationTypeInfo();
		BeanUtils.copyProperties(relationType, relationTypeInfo);
		RelationAttributeList relationAttributeList = transform(relationType.getRelationTypeAttributeMappings());
		relationTypeInfo.setRelationAttributeList(relationAttributeList);
		return relationTypeInfo;
	}

	public AttributeDomainInfoList transform(AttributeDomain[] attributeDomains) throws DomainNotFoundException, QppServiceException {
		AttributeDomainInfoList attributeDomainInfoList = new AttributeDomainInfoList();
		for (int i = 0; attributeDomains != null && i < attributeDomains.length; i++) {
			AttributeDomainInfo attributeDomainInfo = transform(attributeDomains[i]);
			attributeDomainInfoList.getAttributeDomainInfo().add(attributeDomainInfo);
		}
		return attributeDomainInfoList;
	}

	public AttributeDomainInfo transform(AttributeDomain attributeDomain) throws DomainNotFoundException, QppServiceException {
		AttributeDomainInfo attributeDomainInfo = new AttributeDomainInfo();
		BeanUtils.copyProperties(attributeDomain, attributeDomainInfo, new String[] { "id" });
		attributeDomainInfo.setId(attributeDomain.getId());
		DomainValue[] domainValues = attributeDomainService.getDomainValues(attributeDomain.getId());
		com.quark.qpp.service.xmlBinding.DomainValueList domainValueList = transform(domainValues, attributeDomain.isHierarchical(), null);
		attributeDomainInfo.setDomainValueList(domainValueList);
		return attributeDomainInfo;
	}

	public com.quark.qpp.service.xmlBinding.DomainValueList transform(DomainValue[] domainValues, boolean isHierarchicalDomain) throws DomainNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.DomainValueList domainValueList = null;
		if (domainValues != null) {
			domainValueList = new com.quark.qpp.service.xmlBinding.DomainValueList();
		for (int i = 0; domainValues != null && i < domainValues.length; i++) {
				com.quark.qpp.service.xmlBinding.DomainValue domainValue = transform(domainValues[i], isHierarchicalDomain);
				domainValueList.getDomainValue().add(domainValue);
			}
		}
		return domainValueList;
	}
	
	private com.quark.qpp.service.xmlBinding.DomainValueList transform(DomainValue[] domainValues, boolean isHierarchicalDomain, String parentValuePath) throws DomainNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.DomainValueList domainValueList = null;
		if (domainValues != null) {
			domainValueList = new com.quark.qpp.service.xmlBinding.DomainValueList();
		for (int i = 0; domainValues != null && i < domainValues.length; i++) {
				com.quark.qpp.service.xmlBinding.DomainValue domainValue = transform(domainValues[i], isHierarchicalDomain, parentValuePath);
				domainValueList.getDomainValue().add(domainValue);
			}
		}
		return domainValueList;
	}
	
	public com.quark.qpp.service.xmlBinding.DomainValue transform(DomainValue domainValue, boolean isHierarchicalDomain) throws DomainNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.DomainValue targetDomainValue = null;
		if (domainValue != null) {
			targetDomainValue = new com.quark.qpp.service.xmlBinding.DomainValue();
			BeanUtils.copyProperties(domainValue, targetDomainValue);
			targetDomainValue.setDomainValueList(transform(domainValue.getChildDomainValues(), isHierarchicalDomain));
			if (isHierarchicalDomain) {
				targetDomainValue.setValueHierarchy(getDomainValueHierarchy(domainValue));
			}
		}
		return targetDomainValue;
	}
	
	private com.quark.qpp.service.xmlBinding.DomainValue transform(DomainValue domainValue, boolean isHierarchicalDomain, String parentValuePath) throws DomainNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.DomainValue targetDomainValue = null;
		if (domainValue != null) {
			String valueHierarchy = null;
			
			targetDomainValue = new com.quark.qpp.service.xmlBinding.DomainValue();
			BeanUtils.copyProperties(domainValue, targetDomainValue);
			
			if (isHierarchicalDomain) {
				if (parentValuePath == null || parentValuePath.trim().isEmpty()) {
					valueHierarchy = domainValue.getName();
				} else {
					valueHierarchy = parentValuePath + VALUE_SEPARATOR + domainValue.getName();
				}
				targetDomainValue.setValueHierarchy(valueHierarchy);
			}
			
			if (valueHierarchy != null) {
				targetDomainValue.setDomainValueList(transform(domainValue.getChildDomainValues(), isHierarchicalDomain, valueHierarchy));
			} else {
				targetDomainValue.setDomainValueList(transform(domainValue.getChildDomainValues(), isHierarchicalDomain));
			}
		}
		return targetDomainValue;
	}


	public AttributeDomain transform(AttributeDomainInfo attributeDomainInfo) {
		AttributeDomain attributeDomain = new AttributeDomain();
		BeanUtils.copyProperties(attributeDomainInfo, attributeDomain, new String[] { "id"});
		if (attributeDomainInfo.getId() != null) {
			attributeDomain.setId(attributeDomainInfo.getId());
		}
		return attributeDomain;
	}

	public DomainValue[] transform(com.quark.qpp.service.xmlBinding.DomainValueList domainValueList) {
		ArrayList<DomainValue> domainValues = new ArrayList<DomainValue>();
		if (domainValueList != null && domainValueList.getDomainValue() != null) {
			List<com.quark.qpp.service.xmlBinding.DomainValue> list = domainValueList.getDomainValue();
			for (int i = 0; list != null & i < list.size(); i++) {
				DomainValue domainValue = new DomainValue();
				com.quark.qpp.service.xmlBinding.DomainValue dValue = list.get(i);
				BeanUtils.copyProperties(dValue, domainValue, new String[] { "id" });
				if (dValue.getId() != null) {
					domainValue.setId(dValue.getId());
				}
				if(dValue.getDomainValueList() != null){
					DomainValue[] childDomainValues = transform(dValue.getDomainValueList());
					domainValue.setChildDomainValues(childDomainValues);
				}
				domainValues.add(domainValue);
			}
		}
		return domainValues.toArray(new DomainValue[0]);
	}

	public LdapProfileInfoList transform(LdapProfile[] ldapProfiles) {
		LdapProfileInfoList ldapProfileInfoList = new LdapProfileInfoList();
		for (LdapProfile ldapProfile : ldapProfiles) {
			LdapProfileInfo ldapProfileInfo = new LdapProfileInfo();
			ldapProfileInfo = transform(ldapProfile);
			ldapProfileInfoList.getLdapProfileInfo().add(ldapProfileInfo);
		}
		return ldapProfileInfoList;
	}

	public LdapProfileInfo transform(LdapProfile ldapProfile) {
		LdapProfileInfo ldapProfileInfo = new LdapProfileInfo();
		BeanUtils.copyProperties(ldapProfile, ldapProfileInfo, new String[] { "ldapServerInfos", "password", "attributesMapping", "ldapObjectsIdentificationCriteria" });
		ldapProfileInfo.setLdapServerInfoList(transform(ldapProfile.getLdapServerInfos()));
		ldapProfileInfo.setLdapAttributeInfoList(transform(ldapProfile.getLdapAttributesMapping()));
		ldapProfileInfo.setLdapObjectsIdentificationCriteria(transform(ldapProfile.getLdapObjectsIdentificationCriteria()));
		return ldapProfileInfo;
	}

	private LdapObjectsIdentificationCriteria transform(
			com.quark.qpp.core.userprovisioning.service.dto.LdapObjectsIdentificationCriteria ldapObjectsIdentificationCriteria) {
		
		LdapObjectsIdentificationCriteria identCriteria = new LdapObjectsIdentificationCriteria();
		BeanUtils.copyProperties(ldapObjectsIdentificationCriteria, identCriteria);
		return identCriteria;		
	}

	public LdapProfile transform(LdapProfileInfo info) {
		LdapProfile ldapProfile = new LdapProfile();
		BeanUtils.copyProperties(info, ldapProfile, new String[] { "ldapServerInfoList", "password", "id", "ldapAttributeInfoList", "ldapObjectsIdentificationCriteria" });
		ldapProfile.setLdapServerInfos(transform(info.getLdapServerInfoList()));
		ldapProfile.setLdapAttributesMapping(transform(info.getLdapAttributeInfoList()));
		ldapProfile.setLdapObjectsIdentificationCriteria(transform(info.getLdapObjectsIdentificationCriteria()));
		ldapProfile.setPassword(CommonUtility.getEncryptedPassword(info.getPassword()));
		return ldapProfile;
	}

	private com.quark.qpp.core.userprovisioning.service.dto.LdapObjectsIdentificationCriteria transform(
			LdapObjectsIdentificationCriteria ldapObjectsIdentificationCriteria) {
		com.quark.qpp.core.userprovisioning.service.dto.LdapObjectsIdentificationCriteria target_ldapObjectsIdentificationCriteria = new com.quark.qpp.core.userprovisioning.service.dto.LdapObjectsIdentificationCriteria();
		BeanUtils.copyProperties(ldapObjectsIdentificationCriteria, target_ldapObjectsIdentificationCriteria);
		return target_ldapObjectsIdentificationCriteria;
	}

	private LdapServerInfo[] transform(LdapServerInfoList infoList) {
		List<com.quark.qpp.service.xmlBinding.LdapServerInfo> list = infoList.getLdapServerInfo();
		ArrayList<LdapServerInfo> ldapServerInfoList = new ArrayList<LdapServerInfo>();
		for (int i = 0; i < list.size(); i++) {
			LdapServerInfo info = new LdapServerInfo();
			BeanUtils.copyProperties(list.get(i), info);
			ldapServerInfoList.add(info);
		}
		return ldapServerInfoList.toArray(new LdapServerInfo[0]);
	}

	private LdapServerInfoList transform(LdapServerInfo[] ldapServerInfos) {
		LdapServerInfoList ldapServerInfoList = new LdapServerInfoList();
		for (LdapServerInfo ldapServerInfo : ldapServerInfos) {
			com.quark.qpp.service.xmlBinding.LdapServerInfo serverInfo = new com.quark.qpp.service.xmlBinding.LdapServerInfo();
			BeanUtils.copyProperties(ldapServerInfo, serverInfo);
			ldapServerInfoList.getLdapServerInfo().add(serverInfo);
		}
		return ldapServerInfoList;
	}

	public LdapAttributeInfoList transform(LdapAttributeValue[] ldapAttributeValues) {
		LdapAttributeInfoList ldapAttributeInfoList = new LdapAttributeInfoList();
		for (int i = 0; i < ldapAttributeValues.length; i++) {
			long ldapAttributeId = ldapAttributeValues[i].getId();
			LdapAttributeInfo ldapAttributeInfo = new LdapAttributeInfo();
			ldapAttributeInfo.setId(ldapAttributeValues[i].getId());
			ldapAttributeInfo.setName(getLdapAttributeName(ldapAttributeId));
			ldapAttributeInfo.setValue(ldapAttributeValues[i].getValue());
			ldapAttributeInfoList.getLdapAttributeInfo().add(ldapAttributeInfo);
		}
		return ldapAttributeInfoList;
	}

	public String getLdapAttributeName(long ldapAttributeId) {
		int id = (int) ldapAttributeId;
		switch (id) {
		case (int)DefaultLdapAttributes.USER_SHORT_NAME:
			return "USER_SHORT_NAME";
		case (int)DefaultLdapAttributes.USER_FIRST_NAME:
			return "USER_FIRST_NAME";
		case (int)DefaultLdapAttributes.USER_LAST_NAME:
			return "USER_LAST_NAME";
		case (int)DefaultLdapAttributes.USER_EMAIL:
			return "USER_EMAIL";
		case (int)DefaultLdapAttributes.USER_TELEPHONE_NUMBER:
			return "USER_TELEPHONE_NUMBER";
		case (int)DefaultLdapAttributes.USER_ATTRIBUTE_NAME_FOR_AUTHENTICATION:
			return "USER_ATTRIBUTE_NAME_FOR_AUTHENTICATION";
		
		case (int)DefaultLdapAttributes.USER_DN_ATTRIBUTE_NAME:
			return "USER_DN_ATTRIBUTE_NAME";
		case (int)DefaultLdapAttributes.GROUP_DN_ATTRIBUTE_NAME:
			return "GROUP_DN_ATTRIBUTE_NAME";		
		case (int)DefaultLdapAttributes.GROUP_EMAIL:
			return "GROUP_EMAIL";
		case (int)DefaultLdapAttributes.GROUP_NAME:
			return "GROUP_NAME";
		default:
			return null;
		}
	}

	public long getLdapAttributeId(String ldapAttributeName) {
		if (ldapAttributeName.equalsIgnoreCase("USER_SHORT_NAME"))
			return DefaultLdapAttributes.USER_SHORT_NAME;
		else if (ldapAttributeName.equalsIgnoreCase("USER_FIRST_NAME"))
			return DefaultLdapAttributes.USER_FIRST_NAME;
		else if (ldapAttributeName.equalsIgnoreCase("USER_LAST_NAME"))
			return DefaultLdapAttributes.USER_LAST_NAME;
		else if (ldapAttributeName.equalsIgnoreCase("USER_EMAIL"))
			return DefaultLdapAttributes.USER_EMAIL;
		else if (ldapAttributeName.equalsIgnoreCase("USER_TELEPHONE_NUMBER"))
			return DefaultLdapAttributes.USER_TELEPHONE_NUMBER;
		else if (ldapAttributeName.equalsIgnoreCase("USER_ATTRIBUTE_NAME_FOR_AUTHENTICATION"))
			return DefaultLdapAttributes.USER_ATTRIBUTE_NAME_FOR_AUTHENTICATION;		
		else if (ldapAttributeName.equalsIgnoreCase("USER_DN_ATTRIBUTE_NAME"))
			return DefaultLdapAttributes.USER_DN_ATTRIBUTE_NAME;
		else if (ldapAttributeName.equalsIgnoreCase("GROUP_DN_ATTRIBUTE_NAME"))
			return DefaultLdapAttributes.GROUP_DN_ATTRIBUTE_NAME;
		else if (ldapAttributeName.equalsIgnoreCase("GROUP_EMAIL"))
			return DefaultLdapAttributes.GROUP_EMAIL;
		else if (ldapAttributeName.equalsIgnoreCase("GROUP_NAME"))
			return DefaultLdapAttributes.GROUP_NAME;
		else
			return -1;
	}

	public LdapAttributeValue transform(LdapAttributeInfo ldapAttributeInfo) {
		LdapAttributeValue ldapAttributeValue = new LdapAttributeValue();
		if (ldapAttributeInfo.getName() != null && !ldapAttributeInfo.getName().isEmpty())
			ldapAttributeValue.setId(getLdapAttributeId(ldapAttributeInfo.getName()));
		else if (ldapAttributeInfo.getId() != null)
			ldapAttributeValue.setId(ldapAttributeInfo.getId());
		ldapAttributeValue.setValue(ldapAttributeInfo.getValue());
		return ldapAttributeValue;
	}

	public LdapAttributeValue[] transform(LdapAttributeInfoList ldapAttributeInfoList2) {
		ArrayList<LdapAttributeValue> arraylist = new ArrayList<LdapAttributeValue>();
		List<LdapAttributeInfo> list = ldapAttributeInfoList2.getLdapAttributeInfo();
		for (int i = 0; list != null && i < list.size(); i++) {
			arraylist.add(transform(list.get(i)));
		}
		return arraylist.toArray(new LdapAttributeValue[0]);
	}

	public SearchInfoList transform(QueryDefinition[] queryDefinitions, boolean getConditions, boolean getDisplay, boolean getContext, boolean getSharedSearchTrustees)
			throws QppServiceException {
		SearchInfoList serachInfoList = new SearchInfoList();
		for (int i = 0; queryDefinitions != null && i < queryDefinitions.length; i++) {
			SearchInfo searchInfo = transform(queryDefinitions[i], getConditions, getDisplay, getContext, getSharedSearchTrustees);
			serachInfoList.getSearchInfo().add(searchInfo);
		}
		return serachInfoList;
	}

	public SearchInfo transform(QueryDefinition queryDefinition, boolean getConditions, boolean getDisplay, boolean getContext, boolean getSharedSearchTrustees)
			throws QppServiceException {
		SearchInfo searchInfo = new SearchInfo();
		searchInfo.setId(queryDefinition.getQueryId());
		searchInfo.setSearchName(queryDefinition.getQueryName());
		Owner owner = new Owner();
		owner.setId(queryDefinition.getOwnerId());
		String trusteeName = getTrusteeName(queryDefinition.getOwnerId());
		owner.setValue(trusteeName);
		searchInfo.setOwner(owner);
		searchInfo.setParameterized(queryDefinition.isParameterized());
		if (getConditions) {
			searchInfo.setQueryConditionList(transform(queryDefinition.getQueryConditions()));
		}
		if (getContext) {
			searchInfo.setQueryContext(transform(queryDefinition.getQueryContext()));
		}
		if (getDisplay) {
			searchInfo.setQueryDisplay(transform(queryDefinition.getQueryDisplay()));
		}
		if(getSharedSearchTrustees){
			searchInfo.setTrusteeInfoList(fetchAndTransformSharedQueryTrustees(queryDefinition.getQueryId()));
		}
		return searchInfo;
	}
	
	public TrusteeInfoList fetchAndTransformSharedQueryTrustees(long queryId) throws QueryNotFoundException, QppServiceException {
		long[] trusteeIds = queryService.getSharedQueryTrustees(queryId);
		long ownerId = queryService.getQueryDefinition(queryId).getOwnerId();
		TrusteeInfoList trusteeInfoList = new TrusteeInfoList();
		for (int i = 0; i < trusteeIds.length; i++) {
			if (trusteeIds[i] != ownerId) {
				Trustee trustee = trusteeService.getTrustee(trusteeIds[i]);
				TrusteeInfo trusteeInfo = transform(trustee);
				trusteeInfoList.getTrusteeInfo().add(trusteeInfo);
			}
		}
		return trusteeInfoList;
	}

	private com.quark.qpp.service.xmlBinding.QueryDisplay transform(com.quark.qpp.core.query.service.dto.QueryDisplay queryDisplay)
			throws AttributeNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.QueryDisplay display = new com.quark.qpp.service.xmlBinding.QueryDisplay();
		display.setDisplayMode(displayModesMap.get(queryDisplay.getDisplayMode()));
		display.setExploreMode(exploreModesMap.get(queryDisplay.getExploreMode()));
		if (queryDisplay.getDisplayColumns() != null && queryDisplay.getDisplayColumns().length > 0) {
			display.setDisplayColumnList(transform(queryDisplay.getDisplayColumns()));
		}
		if (queryDisplay.getGroupingAttributes() != null && queryDisplay.getGroupingAttributes().length > 0) {
			display.setGroupingAttributeList(transform(queryDisplay.getGroupingAttributes()));
		}
		if (queryDisplay.getSorting() != null && queryDisplay.getSorting().length > 0) {
			display.setSortInfoList(transform(queryDisplay.getSorting()));
		}
		return display;
	}

	private SortInfoList transform(SortInfo[] SortInfos) throws AttributeNotFoundException, QppServiceException {
		SortInfoList sortInfoList = new SortInfoList();
		List<com.quark.qpp.service.xmlBinding.SortInfo> list = sortInfoList.getSortInfo();
		for (SortInfo sortInfo : SortInfos) {
			com.quark.qpp.service.xmlBinding.SortInfo aSortInfo = new com.quark.qpp.service.xmlBinding.SortInfo();
			long columnId = sortInfo.getColumnId();
			boolean isAttributeColumn = sortInfo.isAttributeColumn();
			if (isAttributeColumn) {
				aSortInfo.setValue(getAttributeName(columnId));
			}
			aSortInfo.setAttributeColumn(isAttributeColumn);
			aSortInfo.setColumnId(columnId);
			if (sortInfo.isDescending()) {
				aSortInfo.setOrder("descending");
			} else {
				aSortInfo.setOrder("ascending");
			}
			list.add(aSortInfo);
		}
		return sortInfoList;
	}

	private GroupingAttributeList transform(GroupingInfo[] groupingInfos) throws AttributeNotFoundException, QppServiceException {
		GroupingAttributeList groupingAttributeList = new GroupingAttributeList();
		List<GroupingAttribute> list = groupingAttributeList.getGroupingAttribute();
		for (GroupingInfo groupingInfo : groupingInfos) {
			GroupingAttribute groupingAttribute = new GroupingAttribute();
			groupingAttribute.setValue(getAttributeName(groupingInfo.getAttributeId()));
			groupingAttribute.setAttributeId(groupingInfo.getAttributeId());
			if (groupingInfo.isDescending()) {
				groupingAttribute.setOrder("descending");
			} else {
				groupingAttribute.setOrder("ascending");
			}
			list.add(groupingAttribute);
		}
		return groupingAttributeList;
	}

	private DisplayColumnList transform(DisplayColumn[] displayColumns) throws AttributeNotFoundException, QppServiceException {
		DisplayColumnList displayColumnList = new DisplayColumnList();
		List<com.quark.qpp.service.xmlBinding.DisplayColumn> list = displayColumnList.getDisplayColumn();
		for (DisplayColumn displayColumn : displayColumns) {
			com.quark.qpp.service.xmlBinding.DisplayColumn column = new com.quark.qpp.service.xmlBinding.DisplayColumn();
			column.setAttributeColumn(displayColumn.isAttributeColumn());
			column.setColumnId(displayColumn.getColumnId());
			column.setWidth(displayColumn.getWidth());
			if (displayColumn.isAttributeColumn()) {
				String attributeName = getAttributeName(displayColumn.getColumnId());
				column.setValue(attributeName);
			}
			list.add(column);
		}
		return displayColumnList;
	}

	private com.quark.qpp.service.xmlBinding.QueryContext transform(com.quark.qpp.core.query.service.dto.QueryContext queryContext)
			throws InvalidCollectionException, QppServiceException {
		com.quark.qpp.service.xmlBinding.QueryContext context = null;
		if (queryContext != null) {
			context = new com.quark.qpp.service.xmlBinding.QueryContext();
			long contentTypeId = queryContext.getContentType();
			if (contentTypeId == DefaultContentTypes.ASSET) {
				context.setContext("ASSET");
			} else if (contentTypeId == DefaultContentTypes.COLLECTION) {
				context.setContext("COLLECTION");
			}
			Collections collections = new Collections();
			List<com.quark.qpp.service.xmlBinding.Collection> collectionsList = collections.getCollection();
			long[] collectionIds = queryContext.getCollections();
			if (collectionIds != null && collectionIds.length > 0) {
				for (long collectionId : collectionIds) {
					String colName = null;
					String colpath = null;
					AttributeValue[] colAttributeValues = collectionService.getCollectionAttributeValues(collectionId, new long[] {
							DefaultAttributes.NAME, DefaultAttributes.COLLECTION_PATH });
					if (colAttributeValues[0].getAttributeId() == DefaultAttributes.NAME) {
						colName = ((TextValue) colAttributeValues[0].getAttributeValue()).getValue();
						colpath = ((TextValue) colAttributeValues[1].getAttributeValue()).getValue();
					} else {
						colName = ((TextValue) colAttributeValues[1].getAttributeValue()).getValue();
						colpath = ((TextValue) colAttributeValues[0].getAttributeValue()).getValue();
					}
					com.quark.qpp.service.xmlBinding.Collection collection = new com.quark.qpp.service.xmlBinding.Collection();
					collection.setId(collectionId);
					collection.setName(colName);
					collection.setPath(colpath);
					collectionsList.add(collection);
				}
				collections.setRecursive(queryContext.isRecursive());
				context.setCollections(collections);
			}
		}
		return context;
	}

	private QueryConditionList transform(QueryCondition[] queryConditions) throws AttributeNotFoundException, TrusteeNotFoundException,
			AssetNotFoundException, InvalidAttributeException, DomainNotFoundException, DomainValueNotFoundException,
			InvalidContentTypeException, StatusNotFoundException, WorkflowNotFoundException, QueryNotFoundException, QppServiceException {
		QueryConditionList queryConditionList = new QueryConditionList();
		List<com.quark.qpp.service.xmlBinding.QueryCondition> list = queryConditionList.getQueryCondition();
		for (QueryCondition queryCondition : queryConditions) {
			com.quark.qpp.service.xmlBinding.QueryCondition condition = new com.quark.qpp.service.xmlBinding.QueryCondition();
			String type = conditionTypeMap.get(queryCondition.getType());
			String logicalOperator = logicalOperatorMap.get(queryCondition.getLogicalOperator());
			String comparisonOperator = evaluteComparisonOperator(queryCondition);
			condition.setComparisonOperator(comparisonOperator);
			condition.setLogicalOperator(logicalOperator);
			condition.setNegated(queryCondition.isNegated());
			condition.setNestingLevel(queryCondition.getNestingLevel());
			condition.setParameterized(queryCondition.isParameterized());
			condition.setType(type);
			SearchValue searchValue = null;
			SearchAttribute searchAttribute = null;
			long attributeId = -1;
			if (queryCondition instanceof AttributeCondition) {
				attributeId = ((AttributeCondition) queryCondition).getAttributeId();
				String attributeName = getAttributeName(attributeId);
				searchAttribute = new SearchAttribute();
				searchAttribute.setId(attributeId);
				searchAttribute.setValue(attributeName);
				condition.setSearchAttribute(searchAttribute);
			}
			if (!queryCondition.isParameterized()) {
				searchValue = new SearchValue();
				if (queryCondition instanceof AssignmentCondition) {
					long trusteeId = ((AssignmentCondition) queryCondition).getTrusteeId();
					searchValue.setId(trusteeId);
					searchValue.setValue(getTrusteeName(trusteeId));
				} else if (queryCondition instanceof AttachmentCondition) {
					long projectAssetId = ((AttachmentCondition) queryCondition).getProjectAssetId();
					searchValue.setId(projectAssetId);
					String assetPath = getAssetPath(projectAssetId);
					searchValue.setValue(assetPath);
				} else if (queryCondition instanceof AttributeCondition) {
					if (queryCondition instanceof BooleanAttributeCondition) {
						boolean booleanValue = ((BooleanAttributeCondition) queryCondition).getValue();
						searchValue.setValue(String.valueOf(booleanValue));
					} else if (queryCondition instanceof DateAttributeCondition) {
						String dateValue = ((DateAttributeCondition) queryCondition).getValue();
						searchValue.setValue(dateValue);
					} else if (queryCondition instanceof DateTimeAttributeCondition) {
						String dateTimeValue = ((DateTimeAttributeCondition) queryCondition).getValue();
						searchValue.setValue(dateTimeValue);
					} else if (queryCondition instanceof MeasureAttributeCondition) {
						double doubleValue = ((MeasureAttributeCondition) queryCondition).getValue();
						searchValue.setValue(String.valueOf(doubleValue));
					} else if (queryCondition instanceof NumericAttributeCondition) {
						long numericValue = ((NumericAttributeCondition) queryCondition).getValue();
						searchValue.setValue(String.valueOf(numericValue));
					} else if (queryCondition instanceof PopupAttributeCondition) {
						long valueId = ((PopupAttributeCondition) queryCondition).getValue();
						String strValue = ((PopupAttributeCondition) queryCondition).getStrValue();
						searchValue.setId(valueId);
						searchValue.setValue(strValue);
						// if the value id is specified and the string value is empty, then we need to populate hierarchy in str value to
						// facilitate round trip.
						if (valueId > 0 && (strValue == null || strValue.trim().length() == 0)) {
							try {
								String domainValueHierarchy = getDomainValueHierarchy(attributeId, valueId);
								searchValue.setValue(domainValueHierarchy);
							} catch (Exception e) {
								logger.error("Error occured while fetching domain value hierarchy for value id " + valueId
										+ " and attribute id " + attributeId);
							}
						}
					} else if (queryCondition instanceof StringAttributeCondition) {
						String stringValue = ((StringAttributeCondition) queryCondition).getValue();
						searchValue.setValue(stringValue);
					} else if (queryCondition instanceof TimeAttributeCondition) {
						String timeValue = ((TimeAttributeCondition) queryCondition).getValue();
						searchValue.setValue(timeValue);
					}
				} else if (queryCondition instanceof AttributeTextSearchCondition) {
					String searchString = ((AttributeTextSearchCondition) queryCondition).getSearchString();
					searchValue.setValue(searchString);
				} else if (queryCondition instanceof ContentTypeCondition) {
					long[] conteTypeIds = ((ContentTypeCondition) queryCondition).getContentTypeIds();
					boolean recursive = ((ContentTypeCondition) queryCondition).isRecursive();
					for (int i = 0; conteTypeIds != null && i < conteTypeIds.length; i++) {
						long contentTypeId = conteTypeIds[i];
						String contentTypeHierarchy = facadeUtility.getContentTypeHierarchy(contentTypeId);
						SearchValue newSearchValue = new SearchValue();
						newSearchValue.setId(contentTypeId);
						newSearchValue.setValue(contentTypeHierarchy);
						com.quark.qpp.service.xmlBinding.QueryCondition contentTypeCondition = new com.quark.qpp.service.xmlBinding.QueryCondition();
						if (i == 0) {
							contentTypeCondition.setLogicalOperator(condition.getLogicalOperator());
							contentTypeCondition.setNestingLevel(condition.getNestingLevel());
						} else {
							/*
							 * For multiple content types in content type condition we need to ensure higher nesting level for content types other
							 * than at first location to mark 'OR' evaluation of all these content types at same level. Thus the logical operator has been set to 'OR' & hard coded the nesting level to
							 * start from 1000 assuming user does not add such higher nesting levels.
							 * Bug #201822 (10.5.1)
							 */
							contentTypeCondition.setLogicalOperator("OR");
							contentTypeCondition.setNestingLevel(condition.getNestingLevel() + 1000);
						}
						contentTypeCondition.setNegated(condition.isNegated());
						contentTypeCondition.setParameterized(condition.isParameterized());
						contentTypeCondition.setType(type);
						contentTypeCondition.setSearchValue(newSearchValue);
						contentTypeCondition.setComparisonOperator("IS");
						contentTypeCondition.setRecursive(recursive);
						list.add(contentTypeCondition);
					}
					condition = null;
				} else if (queryCondition instanceof StatusCondition) {
					long statusId = ((StatusCondition) queryCondition).getStatusId();
					String statusName = workflowService.getStatus(statusId).getName();
					searchValue.setId(statusId);
					long workflowId = ((StatusCondition) queryCondition).getWorkflowId();
					String workflowName = workflowService.getWorkflow(workflowId).getName();
					searchValue.setValue(workflowName + "/" + statusName);
				} else if (queryCondition instanceof SubQueryCondition) {
					long subQueryId = ((SubQueryCondition) queryCondition).getQueryId();
					String subQueryName = queryService.getQueryDefinition(subQueryId).getQueryName();
					searchValue.setId(subQueryId);
					searchValue.setValue(subQueryName);
				} else if (queryCondition instanceof TextSearchCondition) {
					String textSearchString = ((TextSearchCondition) queryCondition).getSearchString();
					searchValue.setValue(textSearchString);
				}
			}
			if (condition != null) {
				condition.setSearchAttribute(searchAttribute);
				condition.setSearchValue(searchValue);
				list.add(condition);
			}
		}
		return queryConditionList;
	}

	private String evaluteComparisonOperator(QueryCondition queryCondition) {
		String comparisonOperator = "IS";
		if (queryCondition instanceof DateAttributeCondition) {
			comparisonOperator = dateOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof DateTimeAttributeCondition) {
			comparisonOperator = dateOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof MeasureAttributeCondition) {
			comparisonOperator = measurementOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof NumericAttributeCondition) {
			comparisonOperator = numericOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof PopupAttributeCondition) {
			comparisonOperator = popupOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof StringAttributeCondition) {
			comparisonOperator = stringOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof TimeAttributeCondition) {
			comparisonOperator = dateOperatorsMap.get(queryCondition.getComparisonOperator());
		} else if (queryCondition instanceof StatusCondition) {
			comparisonOperator = statusOperatorsMap.get(queryCondition.getComparisonOperator());
		}
		return comparisonOperator;
	}

	private String getAssetPath(long assetId) throws AssetNotFoundException, InvalidAttributeException, QppServiceException {
		AttributeValue[] attributeValues = assetService.getAttributeValues(assetId, new long[] { DefaultAttributes.NAME,
				DefaultAttributes.COLLECTION_PATH });
		String assetName = null;
		String collectionPath = null;
		if (attributeValues[0].getAttributeId() == DefaultAttributes.NAME) {
			assetName = ((TextValue) attributeValues[0].getAttributeValue()).getValue();
			collectionPath = ((TextValue) attributeValues[1].getAttributeValue()).getValue();
		} else {
			assetName = ((TextValue) attributeValues[1].getAttributeValue()).getValue();
			collectionPath = ((TextValue) attributeValues[0].getAttributeValue()).getValue();
		}
		String assetPath = collectionPath.concat("/" + assetName);
		return assetPath;
	}

	public QueryDefinition transform(SearchInfo searchInfo) throws QppServiceException {
		QueryDefinition queryDefinition = new QueryDefinition();
		Long queryId = searchInfo.getId();
		if (queryId != null) {
			queryDefinition.setQueryId(queryId);
		}
		String queryName = searchInfo.getSearchName();
		queryDefinition.setQueryName(queryName);
		if (searchInfo.getQueryConditionList() != null && searchInfo.getQueryConditionList().getQueryCondition() != null) {
			queryDefinition.setQueryConditions(transform(searchInfo.getQueryConditionList()));
		} else {
			queryDefinition.setQueryConditions(new QueryCondition[0]);// TODO : missing null check at server end
		}
		if (searchInfo.getQueryContext() != null) {
			queryDefinition.setQueryContext(transform(searchInfo.getQueryContext()));
		}
		if (searchInfo.getQueryDisplay() != null) {
			queryDefinition.setQueryDisplay(transform(searchInfo.getQueryDisplay()));
		}
		return queryDefinition;
	}

	private QueryDisplay transform(com.quark.qpp.service.xmlBinding.QueryDisplay queryDisplay) throws QppServiceException {
		QueryDisplay display = new QueryDisplay();
		if (queryDisplay.getDisplayMode() != null) {
			display.setDisplayMode(fetchId(queryDisplay.getDisplayMode(), displayModesMap));
		}
		if (queryDisplay.getExploreMode() != null) {
			display.setExploreMode(fetchId(queryDisplay.getExploreMode(), exploreModesMap));
		}
		if (queryDisplay.getDisplayColumnList() != null && queryDisplay.getDisplayColumnList().getDisplayColumn() != null) {
			display.setDisplayColumns(transform(queryDisplay.getDisplayColumnList()));
		}
		if (queryDisplay.getGroupingAttributeList() != null && queryDisplay.getGroupingAttributeList().getGroupingAttribute() != null) {
			display.setGroupingAttributes(transform(queryDisplay.getGroupingAttributeList()));
		}
		if (queryDisplay.getSortInfoList() != null && queryDisplay.getSortInfoList().getSortInfo() != null) {
			display.setSorting(transform(queryDisplay.getSortInfoList()));
		}
		return display;
	}

	public SortInfo[] transform(SortInfoList sortInfoList) throws AttributeNotFoundException, QppServiceException {
		List<com.quark.qpp.service.xmlBinding.SortInfo> list = sortInfoList.getSortInfo();
		SortInfo[] sortInfos = new SortInfo[list.size()];
		for (int i = 0; i < list.size(); i++) {
			com.quark.qpp.service.xmlBinding.SortInfo aSortInfo = list.get(i);
			SortInfo sortInfo = new SortInfo();
			boolean isAttributeColumn = aSortInfo.isAttributeColumn();
			if (isAttributeColumn) {
				String attributeName = aSortInfo.getValue();
				if (attributeName != null && !attributeName.isEmpty()) {
					long attributeId = facadeUtility.getAttributeIds(new String[] { attributeName })[0];
					sortInfo.setColumnId(attributeId);
				} else if (aSortInfo.getColumnId() != null) {
					sortInfo.setColumnId(aSortInfo.getColumnId());
				}
				sortInfo.setAttributeColumn(isAttributeColumn);
			} else if (aSortInfo.getColumnId() != null) {
				sortInfo.setColumnId(aSortInfo.getColumnId());
			}
			if (aSortInfo.getOrder().equalsIgnoreCase("descending")) {
				sortInfo.setDescending(true);
			}
			sortInfos[i] = sortInfo;
		}
		return sortInfos;
	}

	private GroupingInfo[] transform(GroupingAttributeList groupingAttributeList) throws QppServiceException {
		List<com.quark.qpp.service.xmlBinding.GroupingAttribute> list = groupingAttributeList.getGroupingAttribute();
		GroupingInfo[] groupingInfos = new GroupingInfo[list.size()];
		for (int i = 0; i < list.size(); i++) {
			GroupingAttribute groupingAttribute = list.get(i);
			GroupingInfo groupingInfo = new GroupingInfo();
			String attributeName = groupingAttribute.getValue();
			long attributeId = -1;
			if (attributeName != null && !attributeName.trim().isEmpty()) {
				attributeId = facadeUtility.getAttributeIds(new String[] { attributeName })[0];
			} else if (groupingAttribute.getAttributeId() != null) {
				attributeId = groupingAttribute.getAttributeId();
			}
			groupingInfo.setAttributeId(attributeId);
			if (groupingAttribute.getOrder().equalsIgnoreCase("descending")) {
				groupingInfo.setDescending(true);
			}
			groupingInfos[i] = groupingInfo;
		}
		return groupingInfos;
	}

	private DisplayColumn[] transform(DisplayColumnList displayColumnList) throws AttributeNotFoundException, QppServiceException {
		DisplayColumn[] displayColumns = new DisplayColumn[displayColumnList.getDisplayColumn().size()];
		List<com.quark.qpp.service.xmlBinding.DisplayColumn> list = displayColumnList.getDisplayColumn();
		for (int i = 0; i < list.size(); i++) {
			com.quark.qpp.service.xmlBinding.DisplayColumn displayColumn = list.get(i);
			DisplayColumn aDisplayColumn = new DisplayColumn();
			boolean isAttributeColumn = displayColumn.isAttributeColumn();
			if (isAttributeColumn) {
				String attributeName = displayColumn.getValue();
				if (attributeName != null && !attributeName.isEmpty()) {
					long attributeId = facadeUtility.getAttributeIds(new String[] { attributeName })[0];
					aDisplayColumn.setColumnId(attributeId);
				} else if (displayColumn.getColumnId() != null) {
					aDisplayColumn.setColumnId(displayColumn.getColumnId());
				}
				aDisplayColumn.setAttributeColumn(isAttributeColumn);
			} else if (displayColumn.getColumnId() != null) {
				aDisplayColumn.setColumnId(displayColumn.getColumnId());
			}

			if (displayColumn.getWidth() != null) {
				aDisplayColumn.setWidth(displayColumn.getWidth());
			}
			displayColumns[i] = aDisplayColumn;
		}
		return displayColumns;
	}

	private QueryContext transform(com.quark.qpp.service.xmlBinding.QueryContext queryContext) throws InvalidQueryDefinitionException,
			InvalidQueryDisplayException, InvalidCollectionException, InvalidContentTypeException, QppServiceException {
		QueryContext context = new QueryContext();

		// Evalute query context content type that can be either ASSET or COLLECTION.
		String contentType = queryContext.getContext();
		long contentTypeId = -1;
		if (contentType != null && contentType.equalsIgnoreCase("COLLECTION")) {
			contentTypeId = DefaultContentTypes.COLLECTION;
		} else if (contentType != null && contentType.equalsIgnoreCase("ASSET")) {
			contentTypeId = DefaultContentTypes.ASSET;
		}
		context.setContentType(contentTypeId);

		// Evaluate query context collections from collection path or name or id
		Collections collections = queryContext.getCollections();
		if (collections != null && collections.getCollection() != null) {
			List<com.quark.qpp.service.xmlBinding.Collection> collectionsList = collections.getCollection();
			long[] collectionsIds = new long[collectionsList.size()];
			int i = 0;
			Iterator<com.quark.qpp.service.xmlBinding.Collection> iterator = collectionsList.iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.Collection collection = iterator.next();
				String collectionPath = collection.getPath();
				if (collectionPath != null && !collectionPath.isEmpty()) {
					collectionsIds[i] = facadeUtility.getCollectionIdForCollectionPath(collectionPath);
				} else if (collection.getName() != null && !collection.getName().isEmpty()) {
					collectionsIds[i] = facadeUtility.getCollectionIdForCollectionName(collection.getName());
				} else if (collection.getId() != null) {
					collectionsIds[i] = collection.getId();
				}
				if (collectionsIds[i] <= 0) {
					InvalidCollectionException invalidCollectionException = new InvalidCollectionException(
							InvalidCollectionExceptionCodes.INVALID_COLLECTION);
					invalidCollectionException.setAdditionalInfo(new String[] { -1 + "", "Invalid collection in query context." });
					throw invalidCollectionException;
				}
				i++;
			}
			context.setCollections(collectionsIds);
			context.setRecursive(collections.isRecursive());
		}
		return context;
	}

	private QueryCondition[] transform(QueryConditionList queryConditionList) throws AttributeNotFoundException,
			InvalidQueryDefinitionException, QppServiceException {
		List<QueryCondition> list = new ArrayList<QueryCondition>();
		List<com.quark.qpp.service.xmlBinding.QueryCondition> queryConditionListXml = queryConditionList.getQueryCondition();
		Iterator<com.quark.qpp.service.xmlBinding.QueryCondition> iterator = queryConditionListXml.iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.QueryCondition queryConditionXml = (com.quark.qpp.service.xmlBinding.QueryCondition) iterator
					.next();
			QueryCondition queryCondition = transform(queryConditionXml);
			list.add(queryCondition);
		}
		QueryCondition[] conditions = list.toArray(new QueryCondition[0]);
		return conditions;
	}

	private QueryCondition transform(com.quark.qpp.service.xmlBinding.QueryCondition queryCondition) throws AttributeNotFoundException,
			InvalidAttributeValueException, InvalidQueryDefinitionException, QppServiceException {
		int queryConditionTypeId = fetchId(queryCondition.getType(), conditionTypeMap);
		QueryCondition condition = new QueryCondition();
		int comparisonOperatorId = 1;
		switch (queryConditionTypeId) {
		case ConditionTypes.STRING_ATTR_CONDITION:
			StringAttributeCondition stringAttributeCondition = new StringAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				stringAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				stringAttributeCondition.setValue(queryCondition.getSearchValue().getValue());
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), stringOperatorsMap);
			condition = stringAttributeCondition;
			break;
		case ConditionTypes.DATE_ATTR_CONDITION:
			DateAttributeCondition dateAttributeCondition = new DateAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				dateAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				dateAttributeCondition.setValue(queryCondition.getSearchValue().getValue());
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), dateOperatorsMap);
			condition = dateAttributeCondition;
			break;
		case ConditionTypes.TIME_ATTR_CONDITION:
			TimeAttributeCondition timeAttributeCondition = new TimeAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				timeAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				timeAttributeCondition.setValue(queryCondition.getSearchValue().getValue());
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), dateOperatorsMap);
			condition = timeAttributeCondition;
			break;
		case ConditionTypes.NUMBER_ATTR_CONDITION:
			NumericAttributeCondition numericAttributeCondition = new NumericAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				numericAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null
					&& queryCondition.getSearchValue().getValue() != null) {
				numericAttributeCondition.setValue(Long.valueOf(queryCondition.getSearchValue().getValue()));
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), numericOperatorsMap);
			condition = numericAttributeCondition;
			break;
		case ConditionTypes.MEASURE_ATTR_CONDITION:
			MeasureAttributeCondition measureAttributeCondition = new MeasureAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				measureAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null
					&& queryCondition.getSearchValue().getValue() != null) {
				measureAttributeCondition.setValue(Double.valueOf(queryCondition.getSearchValue().getValue()));
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), measurementOperatorsMap);
			condition = measureAttributeCondition;
			break;
		case ConditionTypes.BOOLEAN_ATTR_CONDITION:
			BooleanAttributeCondition booleanAttributeCondition = new BooleanAttributeCondition();
			if (queryCondition.getSearchAttribute() != null) {
				booleanAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null
					&& queryCondition.getSearchValue().getValue() != null) {
				booleanAttributeCondition.setValue(Boolean.valueOf(queryCondition.getSearchValue().getValue()));
			}
			condition = booleanAttributeCondition;
			break;
		case ConditionTypes.POPUP_ATTR_CONDITION:
			PopupAttributeCondition popupAttributeCondition = new PopupAttributeCondition();
			long attributeId = -1;
			if (queryCondition.getSearchAttribute() != null) {
				attributeId = getAttributeId(queryCondition.getSearchAttribute());
				popupAttributeCondition.setAttributeId(attributeId);
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), popupOperatorsMap);
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				Long popupValueId = queryCondition.getSearchValue().getId();
				String popupStringValue = queryCondition.getSearchValue().getValue();
				/*
				 * The popup string value will be overridden by null & new value id will be populated if following conditions meet 
				 * 1. The comparison operator is not a text operator 
				 * 2. Both popup value id & popup string value are present
				 * 3. A unique value id has been found against the popup string value.
				 * Else dont change any value. 
				 */
				if (!isTextOperator(comparisonOperatorId) && popupStringValue != null && popupStringValue.trim().length() > 0
						&& popupValueId != null && popupValueId > 0) {
					Attribute attribute = attributeService.getAttribute(attributeId);
					int domainId = -1;
					if (attribute.isMultiValued()) {
						domainId = ((DomainValueListPreferences) attribute.getDefaultValuePreference()).getDomainId();
					} else {
						domainId = ((DomainValuePreferences) attribute.getDefaultValuePreference()).getDomainId();
					}
					DomainValue[] allDomainValues = attributeDomainService.getDomainValues(domainId);
					DomainValue matchedDomainValue = null;
					boolean isHierarchicalDomain = attributeDomainService.getDomain(domainId).isHierarchical();
					if (isHierarchicalDomain) {
						matchedDomainValue = facadeUtility.fetchDomainValueWithHierarchy(domainId, popupStringValue, allDomainValues);
						if (matchedDomainValue == null) {
							DomainValue[] matchedDomainValues = facadeUtility.fetchDomainValuesWithName(popupStringValue, allDomainValues);
							if (matchedDomainValues != null && matchedDomainValues.length == 1) {
								matchedDomainValue = matchedDomainValues[0];
							}
						}
					} else {
						DomainValue[] matchedDomainValues = facadeUtility.fetchDomainValuesWithName(popupStringValue, allDomainValues);
						if (matchedDomainValues.length == 1) {
							matchedDomainValue = matchedDomainValues[0];
						}
					}
					/*
					 * If unique value has been found against string, then set new value id & remove popup string value.Otherwise follow the default way.
					 */
					if (matchedDomainValue != null) {
						popupAttributeCondition.setStrValue(null);
						popupAttributeCondition.setValue(matchedDomainValue.getId());
					} else {
						// The default way
						popupAttributeCondition.setStrValue(popupStringValue);
						if (popupValueId != null) {
							popupAttributeCondition.setValue(popupValueId);
						}
					}
				} else {
					// The default way
					popupAttributeCondition.setStrValue(popupStringValue);
					if (popupValueId != null) {
						popupAttributeCondition.setValue(popupValueId);
					}
				}
			}
			condition = popupAttributeCondition;
			break;
		case ConditionTypes.SUB_QUERY_CONDITION:
			SubQueryCondition subQueryCondition = new SubQueryCondition();
			long queryId = -1;
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				String queryName = queryCondition.getSearchValue().getValue();
				if (queryName != null && !queryName.trim().isEmpty()) {
					queryId = facadeUtility.getQueryId(queryName);
				} else if (queryCondition.getSearchValue().getId() != null && queryCondition.getSearchValue().getId() > 0) {
					queryId = queryCondition.getSearchValue().getId();
				}
				subQueryCondition.setQueryId(queryId);
			}
			condition = subQueryCondition;
			break;
		case ConditionTypes.DATETIME_ATTR_CONDITION:
			DateTimeAttributeCondition dateTimeAttributeCondition = new DateTimeAttributeCondition();
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null
					&& queryCondition.getSearchValue().getValue() != null) {
				dateTimeAttributeCondition.setValue(queryCondition.getSearchValue().getValue());
			}
			if (queryCondition.getSearchAttribute() != null) {
				dateTimeAttributeCondition.setAttributeId(getAttributeId(queryCondition.getSearchAttribute()));
			}
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), dateOperatorsMap);
			condition = dateTimeAttributeCondition;
			break;
		case ConditionTypes.STATUS_CONDITION:
			long workflowId = -1;
			long statusId = -1;
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				String searchValueString = queryCondition.getSearchValue().getValue();
				if (searchValueString != null && !searchValueString.trim().isEmpty()) {
					String workflowAndStatus = queryCondition.getSearchValue().getValue();
					long[] worklflowAndStatusId = facadeUtility.getWorkflowAndStatusId(workflowAndStatus);
					workflowId = worklflowAndStatusId[0];
					statusId = worklflowAndStatusId[1];
				} else if (queryCondition.getSearchValue().getId() != null) {
					statusId = queryCondition.getSearchValue().getId();
					workflowId = workflowService.getStatus(statusId).getWorkflowId();
				}
			}
			StatusCondition statusCondition = new StatusCondition();
			statusCondition.setStatusId(statusId);
			statusCondition.setWorkflowId(workflowId);
			comparisonOperatorId = fetchId(queryCondition.getComparisonOperator(), statusOperatorsMap);
			condition = statusCondition;
			break;
		case ConditionTypes.ATTACHMENT_CONDITION:
			long assetId = -1;
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				String assetPath = queryCondition.getSearchValue().getValue();
				if (assetPath != null && !assetPath.trim().isEmpty()) {
					assetId = facadeUtility.getAssetId(assetPath);
				} else if (queryCondition.getSearchValue().getId() != null && queryCondition.getSearchValue().getId() > 0) {
					assetId = queryCondition.getSearchValue().getId();
				}
			}
			AttachmentCondition attachmentCondition = new AttachmentCondition();
			attachmentCondition.setProjectAssetId(assetId);
			condition = attachmentCondition;
			break;
		case ConditionTypes.ASSIGNMENT_CONDITION:
			AssignmentCondition assignmentCondition = new AssignmentCondition();
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				String trusteeName = queryCondition.getSearchValue().getValue();
				long trusteeId = -1;
				if (trusteeName != null && !trusteeName.isEmpty()) {
					trusteeId = trusteeService.getTrusteeId(trusteeName);
				} else if (queryCondition.getSearchValue().getId() != null && queryCondition.getSearchValue().getId() > 0) {
					trusteeId = queryCondition.getSearchValue().getId();
				}
				assignmentCondition.setTrusteeId(trusteeId);
			}
			condition = assignmentCondition;
			break;
		case ConditionTypes.TEXT_SEARCH_CONDITION:
			TextSearchCondition textSearchCondition = new TextSearchCondition();
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				textSearchCondition.setSearchString(queryCondition.getSearchValue().getValue());
			}
			condition = textSearchCondition;
			break;
		case ConditionTypes.ATTRIBUTE_TEXT_SEARCH_CONDITION:
			AttributeTextSearchCondition attributeTextSearchCondition = new AttributeTextSearchCondition();
			if (queryCondition.getSearchAttribute() != null) {
				long textSearchAttributeId = getAttributeId(queryCondition.getSearchAttribute());
				attributeTextSearchCondition.setAttributeId(textSearchAttributeId);
			}
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				attributeTextSearchCondition.setSearchString(queryCondition.getSearchValue().getValue());
			}
			condition = attributeTextSearchCondition;
			break;
		case ConditionTypes.CONTENT_TYPE_CONDITION:
			ContentTypeCondition contentTypeCondition = new ContentTypeCondition();
			if (!queryCondition.isParameterized() && queryCondition.getSearchValue() != null) {
				String contentTypePathOrName = queryCondition.getSearchValue().getValue();
				long contentTypeId = -1;
				if (contentTypePathOrName != null && !contentTypePathOrName.trim().isEmpty()) {
					contentTypeId = facadeUtility.getContentTypeIdForText(contentTypePathOrName);
				} else if (queryCondition.getSearchValue().getId() != null && queryCondition.getSearchValue().getId() > 0) {
					contentTypeId = queryCondition.getSearchValue().getId();
				}
				contentTypeCondition.setContentTypeIds(new long[] { contentTypeId });
			}
			contentTypeCondition.setRecursive(queryCondition.isRecursive());
			condition = contentTypeCondition;
			break;
		default:
			throw new InvalidQueryDefinitionException(InvalidAttributeValueExceptionCodes.INVALID_TYPE);
		}
		condition.setComparisonOperator(comparisonOperatorId);
		int logicalOperatorId = fetchId(queryCondition.getLogicalOperator(), logicalOperatorMap);
		condition.setLogicalOperator(logicalOperatorId);
		condition.setNegated(queryCondition.isNegated());
		condition.setNestingLevel(queryCondition.getNestingLevel());
		condition.setParameterized(queryCondition.isParameterized());
		condition.setType(queryConditionTypeId);
		return condition;
	}

	/*
	 * Returns true if the logical operator is string operator.
	 */
	private boolean isTextOperator(int logicalOperatorId) {
		switch (logicalOperatorId) {
		case PopupOperators.CONTAINS:
		case PopupOperators.ENDS_WITH:
		case PopupOperators.IS_DEFINED:
		case PopupOperators.IS_GREATER:
		case PopupOperators.IS_GREATER_OR_EQUAL:
		case PopupOperators.IS_LESS:
		case PopupOperators.IS_LESS_OR_EQUAL:
		case PopupOperators.STARTS_WITH:
			return true;
		}
		return false;
	}

	private int fetchId(String operatorIdOrName, Map<Integer, String> map) throws QppServiceException {
		try {
			return Integer.parseInt(operatorIdOrName);
		} catch (NumberFormatException e) {
			return CommonUtility.getKeyForValue(map, operatorIdOrName.trim());
		}
	}

	private long getAttributeId(SearchAttribute searchAttribute) throws InvalidAttributeException, QppServiceException {
		String searchAttributeName = searchAttribute.getValue();
		long attributeId = -1;
		if (searchAttributeName != null && !searchAttributeName.trim().isEmpty()) {
			attributeId = facadeUtility.getAttributeIds(new String[] { searchAttributeName })[0];
		} else if (searchAttribute.getId() != null && searchAttribute.getId() > 0) {
			attributeId = searchAttribute.getId();
		} else {
			throw new InvalidAttributeException(InvalidAttributeExceptionCodes.ATTRIBUTE_NOT_FOUND, new String[] { -1 + "",
					"Invalid attribute id/name in QueryCondition of type AttributeQueryCondition." });
		}
		return attributeId;
	}

	public ArticleComponent[] transform(ArticleComponentInfoList articleComponentList) throws AttributeNotFoundException,
			QppServiceException {
		List<ArticleComponentInfo> list = articleComponentList.getArticleComponentInfo();
		ArticleComponent[] articleComponents = new ArticleComponent[list.size()];
		for (int i = 0; i < list.size(); i++) {
			ArticleComponent articleComponent = transform(list.get(i));
			articleComponents[i] = articleComponent;
		}
		return articleComponents;
	}

	private ArticleComponent transform(ArticleComponentInfo articleComponentInfo) throws AttributeNotFoundException, QppServiceException {
		ArticleComponent articleComponent = new ArticleComponent();
		if (articleComponentInfo.getComponentId() != null) {
			articleComponent.setComponentId(articleComponentInfo.getComponentId());
		}
		AttributeValue[] componentAttributes = transform(articleComponentInfo.getAttributeValueList());
		articleComponent.setComponentAttributeValues(componentAttributes);
		return articleComponent;
	}
	
	@Override
	public PreferenceInfoList transform(Preference[] preferences) throws PreferenceNotFoundException, QppServiceException {
		if (preferences != null && preferences.length > 0) {
			PreferenceInfoList preferenceInfoList = new PreferenceInfoList();
			for (Preference preference : preferences) {
				PreferenceInfo preferenceInfo = transform(preference);
				preferenceInfoList.getPreferenceInfo().add(preferenceInfo);
			}
			return preferenceInfoList;
		}
		return null;
	}

	@Override
	public Preference[] transform(PreferenceInfoList preferenceInfoList) throws PreferenceNotFoundException, InvalidPreferenceException,
			QppServiceException {
		if (preferenceInfoList != null && !preferenceInfoList.getPreferenceInfo().isEmpty()) {
			List<Preference> preferenceList = new ArrayList<Preference>();
			Iterator<PreferenceInfo> iterator = preferenceInfoList.getPreferenceInfo().iterator();
			while (iterator.hasNext()) {
				PreferenceInfo preferenceInfo = (PreferenceInfo) iterator.next();
				Preference preference = transform(preferenceInfo);
				preferenceList.add(preference);
			}
			return preferenceList.toArray(new Preference[0]);
		} else {
			return null;
		}
	}

	@Override
	public PreferenceValueList transform(PreferenceValue[] preferenceValues) throws PreferenceNotFoundException, QppServiceException {
		if (preferenceValues != null && preferenceValues.length > 0) {
			PreferenceValueList preferenceValuelist = new PreferenceValueList();
			for (PreferenceValue preferenceValue : preferenceValues) {
				com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValueInfo = transform(preferenceValue);
				preferenceValuelist.getPreferenceValue().add(preferenceValueInfo);
			}
			return preferenceValuelist;
		}
		return null;
	}

	@Override
	public PreferenceValue[] transform(PreferenceValueList preferenceValuelist) throws PreferenceNotFoundException,
			InvalidPreferenceException, QppServiceException {
		List<PreferenceValue> preferenceValueList = new ArrayList<PreferenceValue>();
		if (preferenceValuelist != null && !preferenceValuelist.getPreferenceValue().isEmpty()) {
			Iterator<com.quark.qpp.service.xmlBinding.PreferenceValue> iterator = preferenceValuelist.getPreferenceValue().iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValueInfo = (com.quark.qpp.service.xmlBinding.PreferenceValue) iterator
						.next();
				PreferenceValue preferenceValue = transform(preferenceValueInfo);
				preferenceValueList.add(preferenceValue);
			}
		}
		return preferenceValueList.toArray(new PreferenceValue[0]);
	}

	private PreferenceInfo transform(Preference preference) throws PreferenceNotFoundException, QppServiceException {
		PreferenceInfo preferenceInfo = new PreferenceInfo();
		preferenceInfo.setId(preference.getId());
		preferenceInfo.setName(preference.getName());
		// Set category
		Category category = new Category();
		category.setId(preference.getCategory());
		if (preference.getCategory() == PreferenceConstants.Category.SYSTEM) {
			category.setValue("SYSTEM");
		} else {
			category.setValue("USER");
		}
		preferenceInfo.setCategory(category);
		// Set default value
		DefaultValue defaultValue = new DefaultValue();
		if (preference.getDefaultValueId() > 0) {
			defaultValue.setId(preference.getDefaultValueId());
		}
		defaultValue.setValue(preference.getDefaultValue());
		preferenceInfo.setDefaultValue(defaultValue);
		// Set possible values
		boolean possibleValuesExist = preference.isPossibleValuesExist();
		preferenceInfo.setPossibleValuesExist(possibleValuesExist);
		if (possibleValuesExist) {
			PreferenceValueList preferenceValuelist = transform(preference.getPossibleValues());
			preferenceInfo.setPreferenceValueList(preferenceValuelist);
		}
		preferenceInfo.setSystemDefined(preference.isSystemDefined());
		return preferenceInfo;
	}

	private Preference transform(PreferenceInfo preferenceInfo) throws PreferenceNotFoundException, InvalidPreferenceException,
			QppServiceException {
		Preference preference = new Preference();
		if (preferenceInfo.getId() != null) {
			preference.setId(preferenceInfo.getId());
		}
		preference.setName(preferenceInfo.getName());
		Integer categoryId = null;
		if (preferenceInfo.getCategory() != null) {
			categoryId = preferenceInfo.getCategory().getId();
			String categoryName = preferenceInfo.getCategory().getValue();
			if (categoryId == null && categoryName != null) {
				categoryName = preferenceInfo.getCategory().getValue();
				if (categoryName != null) {
					if (categoryName.equals("SYSTEM")) {
						preference.setCategory(PreferenceConstants.Category.SYSTEM);
					} else if (categoryName.equals("USER")) {
						preference.setCategory(PreferenceConstants.Category.USER);
					}
				} else {
					preference.setCategory(-1);
				}
			} else {
				preference.setCategory(categoryId);
			}
		}
		boolean possibleValuesExist = preferenceInfo.isPossibleValuesExist();
		preference.setPossibleValuesExist(possibleValuesExist);
		if (possibleValuesExist) {
			PreferenceValueList possibleValuesList = preferenceInfo.getPreferenceValueList();
			PreferenceValue[] possibleValues = transform(possibleValuesList);
			preference.setPossibleValues(possibleValues);
		}
		DefaultValue defaultValue = preferenceInfo.getDefaultValue();
		if (defaultValue != null) {
			if (defaultValue.getId() != null) {
				preference.setDefaultValueId(defaultValue.getId());
			}
			preference.setDefaultValue(defaultValue.getValue());
		}
		return preference;
	}

	private com.quark.qpp.service.xmlBinding.PreferenceValue transform(
			com.quark.qpp.core.preference.service.dto.PreferenceValue preferenceValue) throws PreferenceNotFoundException,
			QppServiceException {
		com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValueInfo = new com.quark.qpp.service.xmlBinding.PreferenceValue();
		preferenceValueInfo.setPreferenceId(preferenceValue.getPreferenceId());
		// Set preference name
		String preferenceName = preferenceService.getPreference(preferenceValue.getPreferenceId()).getName();
		preferenceValueInfo.setPreferenceName(preferenceName);
		if (preferenceValue.getValueId() > 0) {
			preferenceValueInfo.setValueId(preferenceValue.getValueId());
		}
		preferenceValueInfo.setValue(preferenceValue.getValue());
		return preferenceValueInfo;
	}

	private PreferenceValue transform(com.quark.qpp.service.xmlBinding.PreferenceValue preferenceValueInfo)
			throws PreferenceNotFoundException, InvalidPreferenceException, InvalidPreferenceValueException, QppServiceException {
		PreferenceValue preferenceValue = new PreferenceValue();
		if (preferenceValueInfo.getPreferenceId() != null) {
			preferenceValue.setPreferenceId(preferenceValueInfo.getPreferenceId());
		}
		preferenceValue.setValue(preferenceValueInfo.getValue());
		if (preferenceValueInfo.getValueId() != null) {
			preferenceValue.setValueId(preferenceValueInfo.getValueId());
		}
		return preferenceValue;
	}

	@Override
	public FavoriteItemlist transform(FavoriteItem[] favoriteItems) throws InvalidCollectionException, QppServiceException {
		FavoriteItemlist favoriteItemlist = new FavoriteItemlist();
		for (int i = 0; favoriteItems != null && i < favoriteItems.length; i++) {
			FavoriteItem favoriteItem = favoriteItems[i];
			com.quark.qpp.service.xmlBinding.FavoriteItem favItem = new com.quark.qpp.service.xmlBinding.FavoriteItem();

			favItem.setId(favoriteItem.getId());
			favItem.setPosition(favoriteItem.getPosition());
			int favoriteType = favoriteItem.getType();
			favItem.setType(favoriteType == FavoriteTypes.COLLECTION ? "COLLECTION" : "QUERY");
			if(favoriteType == FavoriteTypes.COLLECTION){
				 TextValue collectionPath = (TextValue)collectionService.getCollectionAttributeValues(favoriteItem.getId(), new long[]{DefaultAttributes.COLLECTION_PATH})[0].getAttributeValue();
				 favItem.setValue(collectionPath.getValue());
			}else {
				QueryDefinition queryDefinition = queryService.getQueryDefinition(favoriteItem.getId());
				favItem.setValue(queryDefinition.getQueryName());
			}
			favoriteItemlist.getFavoriteItem().add(favItem);
		}
		return favoriteItemlist;
	}

	@Override
	public FavoriteItem[] transform(FavoriteItemlist favoriteItemlist) throws QppServiceException {
		if (favoriteItemlist != null) {
			List<com.quark.qpp.service.xmlBinding.FavoriteItem> list = favoriteItemlist.getFavoriteItem();
			ArrayList<FavoriteItem> arrayList = new ArrayList<FavoriteItem>();
			for (int i = 0; list != null && i < list.size(); i++) {
				com.quark.qpp.service.xmlBinding.FavoriteItem favoriteItem = list.get(i);
				FavoriteItem newFavoriteItem = new FavoriteItem();
				String favouriteType = favoriteItem.getType();
				if (favouriteType.equals("COLLECTION")) {
					newFavoriteItem.setType(FavoriteTypes.COLLECTION);
				} else if (favouriteType.equals("QUERY")) {
					newFavoriteItem.setType(FavoriteTypes.QUERY);
				}
				if(favoriteItem.getValue()!=null && !favoriteItem.getValue().trim().isEmpty()){
					String favoriteItemName = favoriteItem.getValue();
					if(favouriteType.equals("COLLECTION")){
						newFavoriteItem.setId(facadeUtility.getCollectionIdForText(favoriteItemName));
					}else if(favouriteType.equals("QUERY")){
						newFavoriteItem.setId(facadeUtility.getQueryId(favoriteItemName));
					}
					
				}else{
					newFavoriteItem.setId(favoriteItem.getId() != null ? favoriteItem.getId() : 0);
				}
				newFavoriteItem.setPosition(favoriteItem.getPosition() != null ? favoriteItem.getPosition() : 0);
				
				arrayList.add(newFavoriteItem);
			}
			return arrayList.toArray(new FavoriteItem[] {});
		} else {
			return null;
		}
	}

	@Override
	public PrivilegeDefinitionList transform(PrivilegeDefinition[] privilegeDefinitions) throws PrivilegeGroupNotFoundException, QppServiceException {
		PrivilegeDefinitionList privilegeDefinitionList = new PrivilegeDefinitionList();
		if (privilegeDefinitions != null && privilegeDefinitions.length > 0) {
			List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> list = privilegeDefinitionList.getPrivilegeDefinition();
			for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
				list.add(transform(privilegeDefinition));
			}
		}
		return privilegeDefinitionList;
	}

	@Override
	public com.quark.qpp.service.xmlBinding.PrivilegeDefinition transform(PrivilegeDefinition privilegeDefinition) throws PrivilegeGroupNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinitionXml = new com.quark.qpp.service.xmlBinding.PrivilegeDefinition();
		BeanUtils.copyProperties(privilegeDefinition, privilegeDefinitionXml, new String[] { "group", "groupId" });

		com.quark.qpp.service.xmlBinding.PrivilegeDefinition.Group group = new com.quark.qpp.service.xmlBinding.PrivilegeDefinition.Group();
		group.setId(privilegeDefinition.getGroupId());
		/** Set group name also */
		try {
			group.setValue(facadeUtility.getPrivilegeGroupName(privilegeDefinition.getGroupId()));
		} catch (Exception e) {
			//suppress exception if group not found for given Id
			logger.debug(e);
		}
		privilegeDefinitionXml.setGroup(group);
		
		/** For content type privileges get all contentTypes mapped with the privileges (created new api at service level to meet the requirement) */
		if(privilegeDefinition.isContentPrivilege()) {
			long[] contentTypeIds = privilegeService.getPrivilegeContentTypes(privilegeDefinition.getId());
			ContentTypeInfoList contentTypeInfoList = new ContentTypeInfoList();;
			for (long contentTypeId : contentTypeIds) {
				com.quark.qpp.service.xmlBinding.ContentTypeInfo contentTypeInfo = new com.quark.qpp.service.xmlBinding.ContentTypeInfo();
				contentTypeInfo.setId(contentTypeId);
				contentTypeInfo.setName(getContentTypeName(contentTypeId));
				contentTypeInfoList.getContentTypeInfo().add(contentTypeInfo);
			}
			privilegeDefinitionXml.setContentTypeInfoList(contentTypeInfoList);
		}
		return privilegeDefinitionXml;
	}

	@Override
	public PrivilegeGroupDefinitionList transform(PrivilegeGroupDefinition[] privilegeGroupDefinitions) throws PrivilegeGroupNotFoundException, QppServiceException {
		PrivilegeGroupDefinitionList privilegeGroupDefinitionList = new PrivilegeGroupDefinitionList();
		if (privilegeGroupDefinitions != null && privilegeGroupDefinitions.length > 0) {
			List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> list = privilegeGroupDefinitionList.getPrivilegeGroupDefinition();
			for (PrivilegeGroupDefinition privilegeGroupDefinition : privilegeGroupDefinitions) {
				list.add(transform(privilegeGroupDefinition));
			}
		}
		return privilegeGroupDefinitionList;
	}

	@Override
	public com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition transform(PrivilegeGroupDefinition privilegeGroupDefinition) throws PrivilegeGroupNotFoundException, QppServiceException {
		if(privilegeGroupDefinition == null)
			return null;
		com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinitionXml = new com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition();
		/** It will copy following props {name, systemDefined} */
		BeanUtils.copyProperties(privilegeGroupDefinition, privilegeGroupDefinitionXml);
		/** Set privileges */
		privilegeGroupDefinitionXml.setPrivilegeDefinitionList(transform(privilegeGroupDefinition.getPrivilegeDefinitions()));
		/** Set privileges group */
		privilegeGroupDefinitionXml.setPrivilegeGroupDefinitionList(transform(privilegeGroupDefinition.getSubPrivilegeGroups()));
		/** Set parent group id and its name */
		if(privilegeGroupDefinition.getParentGroupId() > 0){
			com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition.ParentGroup parentGroup = new com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition.ParentGroup();
			parentGroup.setId(privilegeGroupDefinition.getParentGroupId());
			try {
				parentGroup.setValue(facadeUtility.getPrivilegeGroupName(privilegeGroupDefinition.getParentGroupId()));
			} catch (Exception e) {
				// suppress exception if group not found for given Id
				logger.debug(e);
			}
			privilegeGroupDefinitionXml.setParentGroup(parentGroup);
		}
		return privilegeGroupDefinitionXml;
	}

	@Override
	public PrivilegeDefinition transform(com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition) throws PrivilegeGroupNotFoundException, QppServiceException {
		PrivilegeDefinition privilegeDefinitionDto = new PrivilegeDefinition();
		BeanUtils.copyProperties(privilegeDefinition, privilegeDefinitionDto, new String[] { "id" });

		/** Set privilege id (required for update api requests) */
		if (privilegeDefinition.getId() != null) {
			privilegeDefinitionDto.setId(privilegeDefinition.getId());
		}

		com.quark.qpp.service.xmlBinding.PrivilegeDefinition.Group group = privilegeDefinition.getGroup();
		/** recover group id from its name , if name is not given then fall back to group id given by user.*/
		if (group.getValue() != null) {
			long[] groupIds = facadeUtility.getPrivilegeGroupId(group.getValue());
			if(groupIds.length > 1 ) {
				throw new InvalidPrivilegeException(InvalidPrivilegeExceptionCodes.MULTIPLE_PRIVILEGES_WITH_GIVEN_NAME, new String[] { "Provide privilege id" });
			}
			privilegeDefinitionDto.setGroupId(groupIds[0]);
		} else if (group.getId() != null && group.getId() > 0) {
			privilegeDefinitionDto.setGroupId(group.getId());
		}
		return privilegeDefinitionDto;
	}
	
	@Override
	public WorksheetInfoList transform(Worksheet[] worksheets) {
		WorksheetInfoList worksheetInfoList = new WorksheetInfoList();
		for (int i = 0; i < worksheets.length; i++) {
			WorksheetInfo worksheetInfo = transform(worksheets[i]);
			worksheetInfoList.getWorksheetInfo().add(worksheetInfo);
		}
		return worksheetInfoList;
	}

	public WorksheetInfo transform(Worksheet worksheet) {
		WorksheetInfo worksheetInfo = new WorksheetInfo();
		BeanUtils.copyProperties(worksheet, worksheetInfo);

		Chart[] charts = worksheet.getCharts();
		if (charts != null && charts.length > 0) {
			ChartInfoList chartInfoList = transform(worksheet.getCharts());
			worksheetInfo.setChartInfoList(chartInfoList);
		}

		Table[] tables = worksheet.getTables();
		if (tables != null && tables.length > 0) {
			TableInfoList tableInfoList = transform(worksheet.getTables());
			worksheetInfo.setTableInfoList(tableInfoList);
		}

		NamedRange[] ranges = worksheet.getNamedRanges();
		if (ranges != null && ranges.length > 0) {
			NamedRangeInfoList NamedRangeInfoList = transform(worksheet.getNamedRanges());
			worksheetInfo.setNamedRangeInfoList(NamedRangeInfoList);
		}
		return worksheetInfo;
	}

	public NamedRangeInfoList transform(NamedRange[] ranges) {
		NamedRangeInfoList namedRangeInfoList = new NamedRangeInfoList();
		for (int i = 0; ranges != null && i < ranges.length; i++) {
			NamedRangeInfo rangeInfo = transform(ranges[i]);
			namedRangeInfoList.getNamedRangeInfo().add(rangeInfo);
		}
		return namedRangeInfoList;
	}

	private NamedRangeInfo transform(NamedRange range) {
		NamedRangeInfo rangeInfo = new NamedRangeInfo();
		BeanUtils.copyProperties(range, rangeInfo);
		return rangeInfo;
	}

	public TableInfoList transform(Table[] tables) {
		TableInfoList tableInfoList = new TableInfoList();
		for (int i = 0; tables != null && i < tables.length; i++) {
			TableInfo tableInfo = transform(tables[i]);
			tableInfoList.getTableInfo().add(tableInfo);
		}
		return tableInfoList;
	}

	private TableInfo transform(Table table) {
		TableInfo tableInfo = new TableInfo();
		BeanUtils.copyProperties(table, tableInfo);
		return tableInfo;
	}

	public ChartInfoList transform(Chart[] charts) {
		ChartInfoList chartInfoList = new ChartInfoList();
		for (int i = 0; charts != null && i < charts.length; i++) {
			ChartInfo chartInfo = transform(charts[i]);
			chartInfoList.getChartInfo().add(chartInfo);
		}
		return chartInfoList;
	}

	private ChartInfo transform(Chart chart) {
		ChartInfo chartInfo = new ChartInfo();
		BeanUtils.copyProperties(chart, chartInfo);
		return chartInfo;
	}

	@Override
	public UserRedliningColor transform(RedlineInfo redlineInfo) throws UserNotFoundException, QppServiceException {
		UserRedliningColor userRedliningColor = new UserRedliningColor();
		Color color = redlineInfo.getColor();

		RgbColor rgbColor = new RgbColor();
		rgbColor.setBlueColor((short) (color.getBlue() == null ? 0 : color.getBlue()));
		rgbColor.setGreenColor((short) (color.getGreen() == null ? 0 : color.getGreen()));
		rgbColor.setRedColor((short) (color.getRed() == null ? 0 : color.getRed()));
		userRedliningColor.setColor(rgbColor);

		com.quark.qpp.service.xmlBinding.RedlineInfo.User user = redlineInfo.getUser();
		long userId = (user.getValue() == null || user.getValue().length() <= 0) ? (user.getId() == null ? 0 : user.getId()) : facadeUtility.getUserId(user.getValue());
		userRedliningColor.setUserId(userId);
		
		return userRedliningColor;
	}

	@Override
	public RedlineInfo transform(UserRedliningColor userRedliningColor) throws UserNotFoundException, QppServiceException {
		RedlineInfo redlineInfo = new RedlineInfo();
		
		RgbColor rgbColor = userRedliningColor.getColor();
		com.quark.qpp.service.xmlBinding.RedlineInfo.Color color = new com.quark.qpp.service.xmlBinding.RedlineInfo.Color();
		color.setBlue((int)rgbColor.getBlueColor());
		color.setGreen((int)rgbColor.getGreenColor());
		color.setRed((int)rgbColor.getRedColor());
		redlineInfo.setColor(color);
		
		User userDto = trusteeService.getUser(userRedliningColor.getUserId());
		com.quark.qpp.service.xmlBinding.RedlineInfo.User redlineUser = new com.quark.qpp.service.xmlBinding.RedlineInfo.User();
		redlineUser.setValue(userDto.getName());
		redlineUser.setId(userDto.getId());
		redlineInfo.setUser(redlineUser);

		return redlineInfo;
	}

	@Override
	public RedlineInfoList transform(UserRedliningColor[] userRedliningColors) throws UserNotFoundException, QppServiceException {
		RedlineInfoList redlineInfoList = new RedlineInfoList();
		List<RedlineInfo> redlineInfos = redlineInfoList.getRedlineInfo();
		for (UserRedliningColor userRedliningColor : userRedliningColors) {
			RedlineInfo redlineInfo = transform(userRedliningColor);
			redlineInfos.add(redlineInfo);
		}
		return redlineInfoList;
	}

	public Schedule transform(ScheduleInfo scheduleInfo) {
		String scheduleGroup = scheduleInfo.getScheduleGroup();
		CronExpressionList cronExpressionList = scheduleInfo.getCronExpressionList();
		Schedule schedule = new Schedule();
		if (cronExpressionList != null && cronExpressionList.getCronExpression() != null) {
			schedule.setCronExpression(cronExpressionList.getCronExpression().toArray(new String[] {}));
		}
		schedule.setScheduleGroup(scheduleGroup);
		return schedule;
	}

	@Override
	public ScriptInfo transform(Script script) throws ScheduleNotFoundException, QppServiceException {
		ScriptInfo scriptInfo = new ScriptInfo();
		scriptInfo.setId(script.getId());
		scriptInfo.setName(script.getName());
		// scriptInfo.setContent(scriptCreated.getContent());
		scriptInfo.setCreatedDate(script.getCreatedDate());

		long creatorId = script.getCreator();
		String creatorName = null;
		try {
			creatorName = trusteeService.getTrustee(creatorId).getName();
		} catch (TrusteeNotFoundException e) {
		} catch (QppServiceException e) {
		}
		if (creatorId > 0) {
			Creator creator = new Creator();
			creator.setId(creatorId);
			creator.setValue(creatorName);
			scriptInfo.setCreator(creator);
		}
		long lastModifiedBy = script.getLastModifiedBy();
		String lastModifiedByName = null;
		try {
			lastModifiedByName = trusteeService.getTrustee(lastModifiedBy).getName();
		} catch (TrusteeNotFoundException e) {
		} catch (QppServiceException e) {
		}

		if (lastModifiedBy > 0) {
			LastModifiedBy lastModifiedByDetails = new LastModifiedBy();
			lastModifiedByDetails.setId(lastModifiedBy);
			lastModifiedByDetails.setValue(lastModifiedByName);
			scriptInfo.setLastModifiedBy(lastModifiedByDetails);
		}
		scriptInfo.setLanguage(script.getLanguage());
		scriptInfo.setLastExecutionLog(script.getLastExecutionLog());
		scriptInfo.setLastExecutionTime(script.getLastExecutionTime());
		scriptInfo.setLastModified(script.getLastModified());

		ScriptExecutionDetails scriptExecutionDetails = script.getScriptExecutionDetails();
		int triggerType = scriptExecutionDetails.getTriggerType();
		ScriptExecutionInfo scriptExecutionInfo = new ScriptExecutionInfo();
		if (triggerType == TriggerTypes.MANUAL) {
			scriptExecutionInfo.setTriggerType("MANUAL");
		} else if (triggerType == TriggerTypes.EVENT_DRIVEN) {
			scriptExecutionInfo.setTriggerType("EVENT_DRIVEN");
			EventInfo eventInfo = new EventInfo();
			eventInfo.setEventType(scriptExecutionDetails.getEventId());
			eventInfo.setEventChangeType(scriptExecutionDetails.getEventChangeType());
			scriptExecutionInfo.setEventInfo(eventInfo);
		} else if (triggerType == TriggerTypes.SCHEDULED) {
			scriptExecutionInfo.setTriggerType("SCHEDULED");
			long scheduleId = scriptExecutionDetails.getScheduleId();
			Schedule schedule = schedulerService.getSchedule(scheduleId);
			ScheduleInfo scheduleInfo = new ScheduleInfo();
			scheduleInfo.setId(scheduleId);
			scheduleInfo.setScheduleGroup(schedule.getScheduleGroup());
			String[] cronExpressions = schedule.getCronExpression();
			CronExpressionList cronExpressionList = new CronExpressionList();
			for (int i = 0; cronExpressions != null && i < cronExpressions.length; i++) {
				cronExpressionList.getCronExpression().add(cronExpressions[i]);
			}
			scheduleInfo.setCronExpressionList(cronExpressionList);
			scriptExecutionInfo.setScheduleInfo(scheduleInfo);
		}
		scriptInfo.setScriptExecutionInfo(scriptExecutionInfo);
		return scriptInfo;
	}

	@Override
	public ScriptInfoList transform(Script[] allScripts) throws ScheduleNotFoundException, QppServiceException {
		ScriptInfoList scriptInfoList = new ScriptInfoList();
		for (int i = 0;allScripts != null && i < allScripts.length; i++) {
			ScriptInfo scriptInfo = transform(allScripts[i]);
			scriptInfoList.getScriptInfo().add(scriptInfo);
		}
		return scriptInfoList;
	}

	public ApplicablePrivilegesInfo transform(ApplicablePrivileges adhocUserClass) throws PrivilegeNotFoundException, QppServiceException {
		ApplicablePrivilegesInfo applicablePrivilegesInfo = new ApplicablePrivilegesInfo();
		long[] applicationPrivileges = adhocUserClass.getApplicationPrivileges();
		if (applicationPrivileges != null && applicationPrivileges.length > 0) {
			ApplicationPrivList applicationPrivList = new ApplicationPrivList();
			Privilege[] privileges = transform(applicationPrivileges);
			applicationPrivList.getPrivilege().addAll(Arrays.asList(privileges));
			applicablePrivilegesInfo.setApplicationPrivList(applicationPrivList);
		}
		ContentTypePrivileges[] contentTypePrivileges = adhocUserClass.getContentTypePrivileges();
		if (contentTypePrivileges != null && contentTypePrivileges.length > 0) {
			ContentTypePrivList contentTypePrivList = new ContentTypePrivList();
			for (int i = 0; contentTypePrivileges != null && i < contentTypePrivileges.length; i++) {
				ContentTypePriv contentTypePriv = transform(contentTypePrivileges[i]);
				contentTypePrivList.getContentTypePriv().add(contentTypePriv);
			}
			applicablePrivilegesInfo.setContentTypePrivList(contentTypePrivList);
		}
		return applicablePrivilegesInfo;
	}

	@Override
	public ImportedGroupInfoList transform(ImportedGroupInfo[] groupInfos) throws TrusteeNotFoundException, GroupNotFoundException, QppServiceException{
		ImportedGroupInfoList importedGroupInfoList = new ImportedGroupInfoList();
		for (int i = 0; i < groupInfos.length; i++) {
			com.quark.qpp.service.xmlBinding.ImportedGroupInfo  importedGroupInfo = transform(groupInfos[i]);
			importedGroupInfoList.getImportedGroupInfo().add(importedGroupInfo);
		}
		return importedGroupInfoList;
	}
	
	@Override
	public com.quark.qpp.service.xmlBinding.ImportedGroupInfo transform(
			com.quark.qpp.core.security.service.dto.ImportedGroupInfo importedGroupInfo) throws TrusteeNotFoundException, GroupNotFoundException, QppServiceException {
		com.quark.qpp.service.xmlBinding.ImportedGroupInfo importedGroupInfo2 = new com.quark.qpp.service.xmlBinding.ImportedGroupInfo();
		long grpId = importedGroupInfo.getMainGroupId();
		if (grpId > 0) {
			GroupInfo grpInfo = transform(trusteeService.getGroup(grpId), false);
			importedGroupInfo2.setGroupInfo(grpInfo);
		}
		long[] subGroupIds = importedGroupInfo.getSubGroupIds();
		ArrayList<Group> subGroupsList = new ArrayList<Group>();
		for (int i = 0; subGroupIds != null && i < subGroupIds.length; i++) {
			subGroupsList.add(trusteeService.getGroup(subGroupIds[i]));
		}
		importedGroupInfo2.setSubGroupsInfoList(transformToSubGroups(subGroupsList.toArray(new Group[0]), false));
		
		long[] userIds = importedGroupInfo.getUserIds();
		ArrayList<User> usersList = new ArrayList<User>();
		for (int i = 0; userIds!= null && i < userIds.length; i++) {
			usersList.add(trusteeService.getUser(userIds[i]));
		}
		importedGroupInfo2.setUserInfoList(transform(usersList.toArray(new User[0])));
		
		return importedGroupInfo2;
	}
	
	private SubGroupsInfoList transformToSubGroups(Group[] groups, boolean getDetailedInfo) throws TrusteeNotFoundException, QppServiceException {
		if (groups == null || groups.length == 0) {
			return new SubGroupsInfoList();
		}
		SubGroupsInfoList groupInfoList = new SubGroupsInfoList();
		for (int i = 0; i < groups.length; i++) {
			groupInfoList.getGroupInfo().add(transform(groups[i], getDetailedInfo));
		}
		return groupInfoList;
	}

	public LdapSearchInfoList transform(LdapQueryDefinition[] ldapQueryDefinitions) throws InvalidLdapProfileException, QppServiceException{
		LdapSearchInfoList ldapSearchInfoList = new LdapSearchInfoList();
		for (int i = 0;ldapQueryDefinitions != null && i < ldapQueryDefinitions.length; i++) {
			com.quark.qpp.service.xmlBinding.LdapSearchInfo ldapSearchInfo = transform(ldapQueryDefinitions[i]);
			ldapSearchInfoList.getLdapSearchInfo().add(ldapSearchInfo);
		}
		return ldapSearchInfoList;
	}

	public com.quark.qpp.service.xmlBinding.LdapSearchInfo transform(LdapQueryDefinition ldapQueryDefinition) throws InvalidLdapProfileException, QppServiceException {
		LdapSearchInfo ldapSearchInfo = new LdapSearchInfo();
		ldapSearchInfo.setId(ldapQueryDefinition.getId());
		ldapSearchInfo.setName(ldapQueryDefinition.getName());
		
		com.quark.qpp.core.userprovisioning.service.dto.LdapSearchCriteria ldapSearchCriteria = ldapQueryDefinition.getSearchCriteria();
		long ldapProfileId = ldapSearchCriteria.getLdapProfileId();
		String ldapProfileName = userProvisioningService.getLdapProfile(ldapProfileId).getName();
		
		LdapSearchCriteria ldapSearchCr = new LdapSearchCriteria();
		ldapSearchCr.setBaseString(ldapSearchCriteria.getBaseString());
		ldapSearchCr.setSearchFilter(ldapSearchCriteria.getSearchFilter());
		
		com.quark.qpp.service.xmlBinding.LdapSearchCriteria.LdapProfile ldapProfile = new com.quark.qpp.service.xmlBinding.LdapSearchCriteria.LdapProfile();
		ldapProfile.setId(ldapProfileId);
		ldapProfile.setValue(ldapProfileName);
		ldapSearchCr.setLdapProfile(ldapProfile);
		
		SearchType searchType = new SearchType();
		int searchTypeId = ldapSearchCriteria.getSearchType();
		searchType.setId(searchTypeId);
		searchType.setValue(ldapSearchTypesMap.get(searchTypeId));
		ldapSearchCr.setSearchType(searchType);
		
		ldapSearchInfo.setLdapSearchCriteria(ldapSearchCr);
		return ldapSearchInfo;
	}

	public LdapQueryDefinition transform(LdapSearchInfo ldapSearchInfo) throws InvalidLdapProfileException, QppServiceException {
		LdapSearchCriteria ldapSearchCriteria = ldapSearchInfo.getLdapSearchCriteria();
		com.quark.qpp.core.userprovisioning.service.dto.LdapSearchCriteria searchCriteria = null;
		if (ldapSearchCriteria != null) {
			String baseString = ldapSearchCriteria.getBaseString();
			String searchFilter = ldapSearchCriteria.getSearchFilter();
			SearchType searchType = ldapSearchCriteria.getSearchType();
			int searchTypeId = -1;
			if (searchType != null) {
				if (searchType.getValue() != null && searchType.getValue().trim().length() > 0) {
					Iterator<Integer> iterator = ldapSearchTypesMap.keySet().iterator();
					while (iterator.hasNext()) {
						Integer id = iterator.next();
						String value = ldapSearchTypesMap.get(id);
						if (value.equals(searchType.getValue())) {
							searchTypeId = id;
							break;
						}
					}
				} else {
					searchTypeId = ldapSearchCriteria.getSearchType().getId();
				}
			}
			long ldapProfileId = -1;
			if (ldapSearchCriteria.getLdapProfile() != null) {
				String ldapProfileName = ldapSearchCriteria.getLdapProfile().getValue();
				if (ldapProfileName != null && ldapProfileName.trim().length() > 0) {
					ldapProfileId = facadeUtility.getLdapProfileId(ldapProfileName);
				} else {
					ldapProfileId = ldapSearchCriteria.getLdapProfile().getId();
				}
			}
			searchCriteria = new com.quark.qpp.core.userprovisioning.service.dto.LdapSearchCriteria();
			searchCriteria.setBaseString(baseString);
			searchCriteria.setSearchFilter(searchFilter);
			searchCriteria.setSearchType(searchTypeId);
			searchCriteria.setLdapProfileId(ldapProfileId);
		}

		LdapQueryDefinition ldapQueryDefinition = new LdapQueryDefinition();
		ldapQueryDefinition.setId(ldapSearchInfo.getId() != null ? ldapSearchInfo.getId() : 0);
		ldapQueryDefinition.setName(ldapSearchInfo.getName());
		ldapQueryDefinition.setSearchCriteria(searchCriteria);
		return ldapQueryDefinition;
	}
	@Override
	public VisioPageInfoList transform(VisioPage[] visioPages) {
		VisioPageInfoList visioPagesInfoList = new VisioPageInfoList();
		for (int i = 0; i < visioPages.length; i++) {
			VisioPageInfo visioPageInfo = transform(visioPages[i]);
			visioPagesInfoList.getVisioPageInfo().add(visioPageInfo);
		}
		return visioPagesInfoList;
	}
	
	public VisioPageInfo transform(VisioPage visioPage) {
		VisioPageInfo visioPageInfo = new VisioPageInfo();
		visioPageInfo.setIndex(visioPage.getPageIndex());
		BeanUtils.copyProperties(visioPage, visioPageInfo);
		return visioPageInfo;
	}
	
	
	@Override
	public PowerPointSlideInfoList transform(PowerPointSlide[] pptSlides) {
		PowerPointSlideInfoList powerPointSlideInfoList = new PowerPointSlideInfoList();
		for (int i = 0; i < pptSlides.length; i++) {
			PowerPointSlideInfo pptSlideInfo = transform(pptSlides[i]);
			powerPointSlideInfoList.getPowerPointSlideInfo().add(pptSlideInfo);
		}
		return powerPointSlideInfoList;
	}
	
	public PowerPointSlideInfo transform(PowerPointSlide pptSlide) {
		PowerPointSlideInfo pptSlideInfo= new PowerPointSlideInfo();
		pptSlideInfo.setIndex(pptSlide.getSlideIndex());
		BeanUtils.copyProperties(pptSlide, pptSlideInfo);
		
		return pptSlideInfo;
	}
	@Override
	public MimeTypeInfoList transform(CustomXmlMimeType[] customXmlMimeTypes) {
		MimeTypeInfoList mimeInfo = new MimeTypeInfoList();
		for (int i = 0; i < customXmlMimeTypes.length; i++) {
			MimeTypeInfo mimeTypeInfo = transform(customXmlMimeTypes[i]);
			mimeInfo.getMimeTypeInfo().add(mimeTypeInfo);
		}
		return mimeInfo;
	}
	
	public MimeTypeInfo transform(CustomXmlMimeType customXmlMimeType) {
							
		MimeTypeInfo mimeType = new MimeTypeInfo();
		
		mimeType.setType(customXmlMimeType.getMimeType());
		mimeType.setParentMimeType(customXmlMimeType.getParentMimeType());
		mimeType.setXpath(customXmlMimeType.getXpath());
		if (customXmlMimeType.getPiName() != null && customXmlMimeType.getPiValue() != null) {	
			Pi pi = new Pi();
			pi.setName(customXmlMimeType.getPiName());
			pi.setValue(customXmlMimeType.getPiValue());			
			mimeType.setPi(pi);
		}
		return mimeType;
	}

	@Override
	public NameValueList transform(NameValue[] nameValues) {
		NameValueList nameValueList = new NameValueList();
		for (int i = 0; nameValues != null && i < nameValues.length; i++) {
			com.quark.qpp.service.xmlBinding.NameValue nameValue = new com.quark.qpp.service.xmlBinding.NameValue();
			nameValue.setName(nameValues[i].getName());
			nameValue.setValue(nameValues[i].getValue());
			nameValueList.getNameValue().add(nameValue);
		}
		return nameValueList;
	}
	
	@Override
	public ClipboardDataInfoList transform(ClipboardDataInfo[] clipboardDataArr) {
		ClipboardDataInfoList clipboardDataInfoList = new ClipboardDataInfoList();
		for (int i = 0; i < clipboardDataArr.length; i++) {
			com.quark.qpp.service.xmlBinding.ClipboardDataInfo clipboardDataInfo = transform(clipboardDataArr[i]);
			clipboardDataInfoList.getClipboardDataInfo().add(clipboardDataInfo);
		}
		return clipboardDataInfoList;
	}
	
	@Override
	public com.quark.qpp.service.xmlBinding.ClipboardDataInfo transform(ClipboardDataInfo clipboardData) {
		com.quark.qpp.service.xmlBinding.ClipboardDataInfo clipboardDataInfo = new com.quark.qpp.service.xmlBinding.ClipboardDataInfo();
		
		clipboardDataInfo.setDataId(clipboardData.getDataId());
		clipboardDataInfo.setDataUri(clipboardData.getDataUri());
		com.quark.qpp.service.xmlBinding.ClipboardDataInfo.ContentType contentType = new com.quark.qpp.service.xmlBinding.ClipboardDataInfo.ContentType();
		contentType.setId(clipboardData.getContentTypeId());
		contentType.setName(clipboardData.getContentTypeName());
		clipboardDataInfo.setContentType(contentType);
		clipboardDataInfo.setTimestamp(clipboardData.getTimeStamp());
		clipboardDataInfo.setMimeType(clipboardData.getMimeType());
		NameValue[] dataProperties = clipboardData.getDataProperties();
		ClipboardMeta clipboardMeta = new ClipboardMeta();
		for(int i = 0; i < dataProperties.length; i++) {
			com.quark.qpp.service.xmlBinding.NameValue nameValue = new com.quark.qpp.service.xmlBinding.NameValue();
			nameValue.setName(dataProperties[i].getName());
			nameValue.setValue(dataProperties[i].getValue());
			clipboardMeta.getNameValue().add(nameValue);
		}
		clipboardDataInfo.setClipboardMeta(clipboardMeta);
		return clipboardDataInfo;
	}

	@Override
	public ClipboardFormatInfoList transform(ClipboardFormat[] cbDataformats) {
		ClipboardFormatInfoList clipboardFormatInfoList = new ClipboardFormatInfoList();
		for(int i = 0; i < cbDataformats.length; i++) {
			ClipboardFormatInfo clipboardFormatInfo = transform(cbDataformats[i]);
			clipboardFormatInfoList.getClipboardFormatInfo().add(clipboardFormatInfo);
		}
		return clipboardFormatInfoList;
	}
	
	@Override
	public ClipboardFormatInfo transform(ClipboardFormat clipboardDataFormat) {
		ClipboardFormatInfo clipboardFormatInfo = new ClipboardFormatInfo();
		clipboardFormatInfo.setName(clipboardDataFormat.getName());
		clipboardFormatInfo.setMimeType(clipboardDataFormat.getMimeType());
		return clipboardFormatInfo;
	}

	@Override
	public ClipboardChannelMappingInfoList transform(ClipboardChannelMapping[] clipboardChannelMappings) {
		ClipboardChannelMappingInfoList clipboardChannelMappingInfoList = new ClipboardChannelMappingInfoList();
		for(int i = 0; i < clipboardChannelMappings.length; i++) {
			ClipboardChannelMappingInfo clipboardChannelMappingInfo = transform(clipboardChannelMappings[i]);
			clipboardChannelMappingInfoList.getClipboardChannelMappingInfo().add(clipboardChannelMappingInfo);
		}
		return clipboardChannelMappingInfoList;
	}
	
	@Override
	public ClipboardChannelMappingInfo transform(ClipboardChannelMapping clipboardChannelMapping) {
		ClipboardChannelMappingInfo clipboardChannelMappingInfo = new ClipboardChannelMappingInfo();
		clipboardChannelMappingInfo.setId(clipboardChannelMapping.getId());
		clipboardChannelMappingInfo.setContentType(clipboardChannelMapping.getContentType());
		clipboardChannelMappingInfo.setClipboardFormat(clipboardChannelMapping.getDataFormat());
		ClipboardChannelParameter[] params = clipboardChannelMapping.getChannelParameters();
		ChannelParameters channelParameters = new ChannelParameters();
		for(int i = 0; i < params.length; i++) {
			com.quark.qpp.service.xmlBinding.NameValue nameValue = new com.quark.qpp.service.xmlBinding.NameValue();
			nameValue.setName(params[i].getName());
			nameValue.setValue(params[i].getValue());
			channelParameters.getNameValue().add(nameValue);
		}
		clipboardChannelMappingInfo.setChannelParameters(channelParameters);
		return clipboardChannelMappingInfo;
	}	
	
}
/***************************************************************************** 
 ** Quark Publishing 
 ** 
 ** �1986-2014 Quark Software Inc. All rights reserved. 
 ** 
 *****************************************************************************/
package com.quark.qpp.service.facade;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.quark.qpp.charting.service.constants.ChartingOutputFormats;
import com.quark.qpp.charting.service.constants.ChartingOutputProperties;
import com.quark.qpp.charting.service.constants.ChartingSourceTypes;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.InvalidAssetException;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.filetransfergateway.service.exception.StreamingException;
import com.quark.qpp.rest.framework.annotations.WebParameterMap;
import com.quark.qpp.rest.framework.annotations.WebResourcePathParam;
import com.quark.qpp.rest.framework.annotations.WebReturnType;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.QppServiceExceptionInfo;

/**
 * A facade that defines methods to get the chart for a given source data 
 * using the chart template specified.
 */
@Controller(value = "chartingByPathFacade")
@RequestMapping("/chartsbypath/**")
public class ChartingByPathFacade {

	@Autowired
	private ChartingFacade chartingFacade;
	
	@Autowired
	private FacadeUtility facadeUtility;
	
	@Autowired
	private ObjectTransformer objectTransformer;

	/**
	 * Draws chart for the given asset using the specified template.
	 * 
	 * @param assetPath
	 *            Collection path of the source data asset whose chart has to be retrieved. The assetPath is a string containing collection path followed by
	 *            asset name. The collection path refers to the collection where the asset exists and assetName refers to that unique asset
	 *            in that collection. For example : Home/colA/ColB/.../../assetname.
	 * @param majorVersion
	 *            major version of the source data asset.
	 * @param minorVersion
	 *            minor version of the source data asset.
	 * @param sourceDataType
	 *            type of the source data using which the chart will be drawn. Current supported types can be found in
	 *            {@link ChartingSourceTypes}.
	 * @param chartTemplateAssetId
	 *            asset id of the FreeMarker chart template asset.
	 * @param chartTemplateMajorversion
	 *            major version of the FreeMarker chart template asset.
	 * @param chartTemplateMinorversion
	 *            minor version of the FreeMarker chart template asset.
	 * @param outputFormat
	 *            string value of the output format in which the chart is to be
	 *            rendered. List of possible output formats can be found in
	 *            constant file: {@link ChartingOutputFormats}
	 * @param inputOutputProperties
	 *            map of input / output properties applicable in case of
	 *            transforming source content to SmartTable or for image output
	 *            format. <br>
	 *            The applicable properties for transforming source content to
	 *            SmartTable are defined in
	 *            {@link SmartTableTransformProperties} file. <br>
	 *            The applicable output properties for image are defined in file
	 *            {@link ChartingOutputProperties} file.
	 * @param contentDisposition
	 *            Optional value used to set content-disposition header value in
	 *            response. Set to "attachment" if downloading of chart is
	 *            required.
	 * @param httpServletResponse
	 *            FOR INTERNAL USE ONLY. The HttpServletResponse object is used
	 *            to set content type and content-disposition header values. The
	 *            value of this argument is set by the QPP REST framework.
	 * @throws AssetNotFoundException
	 *             In case the asset with the given id & version does not exist.
	 * @throws InvalidAssetException
	 *             In case the asset is not of type
	 *             {@link DefaultContentTypes#SMART_TABLE}
	 * @throws QppServiceException
	 *             Unhandled server exception
	 * @throws IOException 
	 * @throws StreamingException 
	 */
	@RequestMapping(method = RequestMethod.GET)
	public void getChart(@WebResourcePathParam("chartsbypath") String assetPath, 
			@RequestParam(value = "majorversion", required = false) Long majorVersion,
			@RequestParam(value = "minorversion", required = false) Long minorVersion, 
			@RequestParam(value = "sourcedatatype", defaultValue = "smarttable") String sourceDataType,
			@RequestParam(value = "templateuri", required = true) String templateUri,
			@RequestParam(value = "outputformat", required = false) String outputformat,
			@WebParameterMap HashMap<String, String> outputFormatProperties,
			HttpServletResponse httpServletResponse,
			@RequestParam(value = "contentDisposition", required = false) String contentDisposition,
			OutputStream outputStream)
			throws AssetNotFoundException, QppServiceException, IOException, StreamingException {

		long assetId = facadeUtility.getAssetId(assetPath);
		chartingFacade.getChart(assetId, majorVersion, minorVersion, sourceDataType, templateUri, outputformat, outputFormatProperties, httpServletResponse, contentDisposition, outputStream);
	}
	
	
	/**
	 * Handles {@link QppServiceException} thrown by handler methods in this facade.
	 *
	 * @param qppServiceException
	 *            exception that is to be handled
	 * @return QppServiceException info.
	 */
	@ExceptionHandler(value = QppServiceException.class)
	@WebReturnType(value = "xmlView")
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public QppServiceExceptionInfo exceptionHandler(QppServiceException qppServiceException) {
		QppServiceExceptionInfo qppServiceExceptionInfo = objectTransformer.transform(qppServiceException);
		return qppServiceExceptionInfo;
	}
}

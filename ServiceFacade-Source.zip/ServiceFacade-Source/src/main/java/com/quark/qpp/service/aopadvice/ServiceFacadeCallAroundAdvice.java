/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2016 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/

package com.quark.qpp.service.aopadvice;

import java.util.List;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.log4j.Logger;

import com.quark.qpp.common.exceptions.QppServiceException;

public class ServiceFacadeCallAroundAdvice implements MethodInterceptor {
	
	private List<String> controllerPackageNames;

	public void setControllerPackageNames(List<String> controllerPackageNames) {
		this.controllerPackageNames = controllerPackageNames;
	}

	
	/**
	 * This advice is configured to be called on each invocation of the method
	 * i.e. before any method call and also after returning from the method.
	 */
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {

		// Create a logger for the given that is to be logged
		Class classObject = methodInvocation.getMethod().getDeclaringClass();
		Logger logger = Logger.getLogger(classObject);

		String methodName = methodInvocation.getMethod().getName();

		// Log before the method call
		logger.trace("Entering " + methodName);
		long startTime = System.nanoTime();
		try {
			// Call the desired method
			return methodInvocation.proceed();
		}
		catch (QppServiceException e) {
			if(isFacadeLayerException(e)){
				String[] additionalInfo = e.getAdditionalInfo();
				String msg = "QppService Exception Occurred. ";
				if (additionalInfo != null && additionalInfo.length > 0) {
					msg += "Additional Info of exception: ";
					for (int i = 0; i < additionalInfo.length; i++) {
						if (additionalInfo[i] != null)
							msg += additionalInfo[i] + ", ";
					}
				}
				Object[] arguments = methodInvocation.getArguments();
				for (int i = 0; arguments!=null && i < arguments.length; i++) {
					msg += " #Argument" +(i+1) +"="+arguments[i];
				}
				logger.error(msg, e);
			}
			throw e;
		} catch (Throwable e) {
			String msg = "Unknown Exception Occurred: ";
			Object[] arguments = methodInvocation.getArguments();
			for (int i = 0; arguments != null && i < arguments.length; i++) {
				msg += " #Argument" + (i + 1) + "="
						+ arguments[i] ;
			}
			logger.error(msg, e);
			throw e;
		} finally {
				if (logger.isTraceEnabled()) {
					long timeTakenInMillis = (System.nanoTime() - startTime) / 1000000;
					logger.trace("Exiting " + methodName + "; Time taken: "
							+ timeTakenInMillis + " ms");
				}
		}
	}
	
	private boolean isFacadeLayerException(Exception ex) {
		StackTraceElement[] stackTraceElements = ex.getStackTrace();
		if (stackTraceElements != null && stackTraceElements.length > 0){
			String className = stackTraceElements[0].getClassName();
			if (controllerPackageNames != null){
				for (String controllerPackageName : controllerPackageNames) {
					if (className != null && className.startsWith(controllerPackageName)) {
						return true;
					}	
				}
			}
		}
		return false;
	}

}
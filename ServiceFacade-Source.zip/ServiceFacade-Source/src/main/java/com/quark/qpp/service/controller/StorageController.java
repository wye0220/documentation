/*****************************************************************************\
 **
 ** �1990-2014 Quark Software Inc., All rights reserved.
 **
 \****************************************************************************/
package com.quark.qpp.service.controller;

import java.util.Iterator;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.storage.service.dto.StorageRepository;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryException;
import com.quark.qpp.core.storage.service.exceptions.InvalidRepositoryTypeException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryInUseException;
import com.quark.qpp.core.storage.service.exceptions.RepositoryNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.StorageServiceExceptionCodes.RepositoryNotFoundExceptionCodes;
import com.quark.qpp.core.storage.service.local.StorageService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfo;
import com.quark.qpp.service.xmlBinding.StorageRepositoryInfoList;

public class StorageController {

	@Autowired
	private StorageService storageService;

	@Autowired
	private FacadeUtility facadeUtility;

	@Autowired
	private ObjectTransformer objectTransformer;

	private final Logger logger = Logger.getLogger(this.getClass());

	public StorageRepositoryInfoList createRepositories(StorageRepositoryInfoList storageRepositoryInfoList) throws InvalidRepositoryException, InvalidRepositoryTypeException,
			QppServiceException {
		StorageRepositoryInfoList newStorageRepositoryInfoList = new StorageRepositoryInfoList();
		if (storageRepositoryInfoList != null) {
			Iterator<StorageRepositoryInfo> iterator = storageRepositoryInfoList.getStorageRepositoryInfo().iterator();
			while (iterator.hasNext()) {
				StorageRepositoryInfo storageInfo = iterator.next();
				try {
					StorageRepositoryInfo newStorageRepositoryInfo = createRepository(storageInfo);
					if (newStorageRepositoryInfo != null) {
						newStorageRepositoryInfoList.getStorageRepositoryInfo().add(newStorageRepositoryInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while creating storage repository with name " + storageInfo.getName(), e);
					if (storageRepositoryInfoList.getStorageRepositoryInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new RepositoryNotFoundException();
		}
		return newStorageRepositoryInfoList;
	}

	private StorageRepositoryInfo createRepository(StorageRepositoryInfo storageInfo) throws InvalidRepositoryException,
			InvalidRepositoryTypeException, QppServiceException {
		StorageRepository repository = objectTransformer.transform(storageInfo);
		long repositoryId = storageService.createRepository(repository.getRepositoryTypeId(), repository.getName(), repository.getUrl());
		StorageRepository createStorageRepository = getRepository(repositoryId);
		return objectTransformer.transform(createStorageRepository);
	}

	public StorageRepositoryInfoList updateRepositories(StorageRepositoryInfoList storageRepositoryInfoList) throws InvalidRepositoryException, InvalidRepositoryTypeException,
			QppServiceException {
		StorageRepositoryInfoList updatedStorageRepositoryInfoList = new StorageRepositoryInfoList();
		if (storageRepositoryInfoList != null) {
			Iterator<StorageRepositoryInfo> iterator = storageRepositoryInfoList.getStorageRepositoryInfo().iterator();
			while (iterator.hasNext()) {
				StorageRepositoryInfo storageInfo = iterator.next();
				try {
					StorageRepositoryInfo updatedStorageRepositoryInfo = updateStorageRepository(storageInfo);
					if (updatedStorageRepositoryInfo != null) {
						updatedStorageRepositoryInfoList.getStorageRepositoryInfo().add(updatedStorageRepositoryInfo);
					}
				} catch (QppServiceException e) {
					logger.error("Error while updating Storage repository with name " + storageInfo.getName(), e);
					if (storageRepositoryInfoList.getStorageRepositoryInfo().size() == 1) {
						throw e;
					}
				}
			}
		} else {
			throw new RepositoryNotFoundException();
		}
		return updatedStorageRepositoryInfoList;
	}

	private StorageRepositoryInfo updateStorageRepository(StorageRepositoryInfo storageRepositoryInfo) throws RepositoryNotFoundException,
			InvalidRepositoryTypeException, QppServiceException {
		long repositoryId = -1;
		if (storageRepositoryInfo.getId() == null || storageRepositoryInfo.getId()<=0) {
			repositoryId = facadeUtility.getRepositoryByName(storageRepositoryInfo.getName());
		} else {
			repositoryId = storageRepositoryInfo.getId();
		}

		StorageRepository repository = objectTransformer.transform(storageRepositoryInfo);
		repository.setId(repositoryId);
		storageService.updateRepository(repository);
		StorageRepository updatedStorageRepository = getRepository(repositoryId);
		return objectTransformer.transform(updatedStorageRepository);
	}

	public void deleteRepository(String repository) throws RepositoryNotFoundException, RepositoryInUseException, 
			QppServiceException {
		long repositoryId = facadeUtility.getRepository(repository);
		storageService.deleteRepository(repositoryId);
	}

	public StorageRepositoryInfoList getAllRepositories() throws QppServiceException {
		StorageRepository[] storageRepositories = storageService.getAllRepositories();
		return objectTransformer.transform(storageRepositories);
	}

	public StorageRepositoryInfoList getRepository(String repository) throws RepositoryNotFoundException, QppServiceException {
		long repositoryId = facadeUtility.getRepository(repository);
		StorageRepository storageRepository = getRepository(repositoryId);
		StorageRepositoryInfo storageRepositoryInfo = objectTransformer.transform(storageRepository);
		StorageRepositoryInfoList storageRepositoryInfoList = new StorageRepositoryInfoList();
		storageRepositoryInfoList.getStorageRepositoryInfo().add(storageRepositoryInfo);
		return storageRepositoryInfoList;
	}

	private StorageRepository getRepository(long repositoryId) throws QppServiceException {
		StorageRepository[] storageRepositorys = storageService.getAllRepositories();
		StorageRepository repository = null;
		for (StorageRepository storageRepository : storageRepositorys) {
			if (repositoryId == storageRepository.getId()) {
				repository = storageRepository;
				break;
			}
		}
		if(repository == null){
			throw new RepositoryNotFoundException(RepositoryNotFoundExceptionCodes.REPOSITORY_NOT_FOUND);
		}
		return repository;
	}
}

/***************************************************************************** 
** Quark Publishing 
** 
** �1986-2014 Quark Software Inc. All rights reserved. 
** 
*****************************************************************************/
package com.quark.qpp.service.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.dto.DomainValue;
import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.asset.service.constants.DefaultRenditionTypes;
import com.quark.qpp.core.asset.service.dto.AssetVersion;
import com.quark.qpp.core.asset.service.exceptions.AssetNotFoundException;
import com.quark.qpp.core.asset.service.exceptions.AssetServiceExceptionCodes.AssetNotFoundExceptionCodes;
import com.quark.qpp.core.attribute.service.constants.DefaultAttributes;
import com.quark.qpp.core.attribute.service.dto.AttributeDomain;
import com.quark.qpp.core.attribute.service.exceptions.AttributeNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.DomainValueNotFoundExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidDomainValueExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.DomainValueNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidAttributeValueException;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.DomainNotFoundExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.AttributeServiceExceptionCodes.InvalidAttributeValueExceptionCodes;
import com.quark.qpp.core.attribute.service.exceptions.DomainNotFoundException;
import com.quark.qpp.core.attribute.service.exceptions.InvalidDomainValueException;
import com.quark.qpp.core.attribute.service.local.AttributeDomainService;
import com.quark.qpp.core.attribute.service.local.AttributeService;
import com.quark.qpp.core.collection.service.dto.JobJacket;
import com.quark.qpp.core.collection.service.exceptions.CollectionServiceExceptionCodes.InvalidCollectionExceptionCodes;
import com.quark.qpp.core.collection.service.exceptions.InvalidCollectionException;
import com.quark.qpp.core.collection.service.exceptions.InvalidJobJacketException;
import com.quark.qpp.core.collection.service.local.CollectionService;
import com.quark.qpp.core.content.service.constants.DefaultContentTypes;
import com.quark.qpp.core.content.service.dto.ContentTypeInfo;
import com.quark.qpp.core.content.service.exceptions.ContentServiceExceptionCodes.InvalidContentTypeExceptionCodes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.content.service.local.ContentStructureService;
import com.quark.qpp.core.indexing.service.dto.RenditionType;
import com.quark.qpp.core.indexing.service.exceptions.InvalidRenditionTypeException;
import com.quark.qpp.core.indexing.service.local.IndexingService;
import com.quark.qpp.core.preference.service.exceptions.PreferenceNotFoundException;
import com.quark.qpp.core.preference.service.local.PreferenceService;
import com.quark.qpp.core.privilege.service.dto.PrivilegeDefinition;
import com.quark.qpp.core.privilege.service.dto.PrivilegeGroupDefinition;
import com.quark.qpp.core.privilege.service.dto.UserClass;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeGroupNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.UserClassNotFoundExceptionCodes;
import com.quark.qpp.core.privilege.service.local.PrivilegeService;
import com.quark.qpp.core.privilege.service.local.UserClassService;
import com.quark.qpp.core.query.service.constants.ConditionTypes;
import com.quark.qpp.core.query.service.constants.QueryConstants.LogicalOperators;
import com.quark.qpp.core.query.service.constants.QueryConstants.StringOperators;
import com.quark.qpp.core.query.service.constants.SystemQueries;
import com.quark.qpp.core.query.service.dto.AssetElement;
import com.quark.qpp.core.query.service.dto.CollectionElement;
import com.quark.qpp.core.query.service.dto.DisplayColumn;
import com.quark.qpp.core.query.service.dto.QueryCondition;
import com.quark.qpp.core.query.service.dto.QueryContext;
import com.quark.qpp.core.query.service.dto.QueryDefinition;
import com.quark.qpp.core.query.service.dto.QueryDisplay;
import com.quark.qpp.core.query.service.dto.QueryResultElement;
import com.quark.qpp.core.query.service.dto.SortInfo;
import com.quark.qpp.core.query.service.dto.StringAttributeCondition;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDefinitionException;
import com.quark.qpp.core.query.service.exceptions.InvalidQueryDisplayException;
import com.quark.qpp.core.query.service.exceptions.QueryNotFoundException;
import com.quark.qpp.core.query.service.local.QueryService;
import com.quark.qpp.core.relation.service.dto.RelationType;
import com.quark.qpp.core.relation.service.exceptions.RelationServiceExceptionCodes.RelationTypeNotFoundExceptionCodes;
import com.quark.qpp.core.relation.service.exceptions.RelationTypeNotFoundException;
import com.quark.qpp.core.relation.service.local.RelationService;
import com.quark.qpp.core.security.service.exceptions.GroupNotFoundException;
import com.quark.qpp.core.security.service.exceptions.TrusteeNotFoundException;
import com.quark.qpp.core.security.service.exceptions.UserNotFoundException;
import com.quark.qpp.core.security.service.local.TrusteeService;
import com.quark.qpp.core.storage.service.dto.StorageRepository;
import com.quark.qpp.core.storage.service.dto.StorageRepositoryType;
import com.quark.qpp.core.storage.service.exceptions.RepositoryNotFoundException;
import com.quark.qpp.core.storage.service.exceptions.StorageServiceExceptionCodes.RepositoryNotFoundExceptionCodes;
import com.quark.qpp.core.storage.service.local.StorageService;
import com.quark.qpp.core.userprovisioning.service.dto.LdapProfile;
import com.quark.qpp.core.userprovisioning.service.dto.LdapQueryDefinition;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapProfileException;
import com.quark.qpp.core.userprovisioning.service.exceptions.InvalidLdapQueryDefinitionException;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapProfileExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.exceptions.UserProvisioningServiceExceptionCodes.InvalidLdapQueryDefinitionExceptionCodes;
import com.quark.qpp.core.userprovisioning.service.local.UserProvisioningService;
import com.quark.qpp.core.workflow.service.constants.ConstraintTypes;
import com.quark.qpp.core.workflow.service.dto.Status;
import com.quark.qpp.core.workflow.service.dto.Workflow;
import com.quark.qpp.core.workflow.service.exceptions.InvalidStatusException;
import com.quark.qpp.core.workflow.service.exceptions.StatusNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowNotFoundException;
import com.quark.qpp.core.workflow.service.exceptions.WorkflowServiceExceptionCodes.InvalidStatusExceptionCodes;
import com.quark.qpp.core.workflow.service.local.WorkflowService;

public class FacadeUtility {
	
	@Autowired
	private QueryService queryService;
	
	@Autowired
	private WorkflowService workflowService;
	
	@Autowired
	private AttributeService attributeService;
	
	@Autowired
	private IndexingService indexingService;
	
	@Autowired
	private ContentStructureService contentStructureService;
	
	@Autowired
	private RelationService relationService;
	
	@Autowired
	private UserClassService userClassService;
	
	@Autowired
	private StorageService storageService;
	
	@Autowired
	private TrusteeService trusteeService;
	
	@Autowired
	private UserProvisioningService userProvisioningService;
	
	@Autowired
	private CollectionService collectionService;
	
	@Autowired
	private AttributeDomainService attributeDomainService;
	
	@Autowired
	private PreferenceService preferenceService;
	
	@Autowired
	private PrivilegeService privilegeService;
	
	public long getAssetId(String assetPathStr) throws AssetNotFoundException, InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		if(assetPathStr == null || assetPathStr.trim().length() == 0){
			throw new AssetNotFoundException(AssetNotFoundExceptionCodes.ASSET_NOT_FOUND, new String[]{assetPathStr});
		}
		if (assetPathStr.contains("/")) {
			int index = assetPathStr.lastIndexOf("/");
			String collectionPath = assetPathStr.substring(0, index);
			if (collectionPath != null && collectionPath.length() > 0) {
				String assetName = assetPathStr.substring(index + 1, assetPathStr.length());
				return queryForAsset(collectionPath, assetName);
			}
		} 
		try {
			long assetId = Long.valueOf(assetPathStr);
			return assetId;
		} catch (NumberFormatException e) {
			throw new AssetNotFoundException(AssetNotFoundExceptionCodes.ASSET_NOT_FOUND, new String[]{assetPathStr});
		}
			
	}
	
	public long getUserClassId(String userClassIdOrName) throws UserClassNotFoundException, QppServiceException{
		try {
			long userClassId = Long.parseLong(userClassIdOrName);
			return userClassId;
		} catch (NumberFormatException e) {
			UserClass[] allUserClasses = userClassService.getAllUserClasses();
			for (UserClass currentUserClass : allUserClasses) {
				if(currentUserClass.getName().equalsIgnoreCase(userClassIdOrName)){
					return currentUserClass.getId();
				}
			}
		}
		throw new UserClassNotFoundException(UserClassNotFoundExceptionCodes.USERCLASS_NOT_FOUND, new String[]{userClassIdOrName});	
	}

	private long queryForAsset(String collectionPath, String assetName) throws InvalidQueryDefinitionException, InvalidQueryDisplayException,
			QppServiceException {
		ArrayList<QueryCondition> queryConditions = new ArrayList<QueryCondition>();

		StringAttributeCondition assetNameAttributeCond = new StringAttributeCondition();
		assetNameAttributeCond.setAttributeId(DefaultAttributes.NAME);
		assetNameAttributeCond.setComparisonOperator(StringOperators.IS);
		assetNameAttributeCond.setLogicalOperator(LogicalOperators.AND);
		assetNameAttributeCond.setNestingLevel(1);
		assetNameAttributeCond.setType(ConditionTypes.STRING_ATTR_CONDITION);
		assetNameAttributeCond.setValue(assetName);
		assetNameAttributeCond.setNegated(false);
		assetNameAttributeCond.setParameterized(false);
		queryConditions.add(assetNameAttributeCond);

		StringAttributeCondition collectionPathAttrCond = new StringAttributeCondition();
		collectionPathAttrCond.setAttributeId(DefaultAttributes.COLLECTION_PATH);
		collectionPathAttrCond.setComparisonOperator(StringOperators.IS);
		collectionPathAttrCond.setLogicalOperator(LogicalOperators.AND);
		collectionPathAttrCond.setNestingLevel(1);
		collectionPathAttrCond.setType(ConditionTypes.STRING_ATTR_CONDITION);
		collectionPathAttrCond.setValue(collectionPath);
		collectionPathAttrCond.setNegated(false);
		collectionPathAttrCond.setParameterized(false);
		queryConditions.add(collectionPathAttrCond);

		// Create Query Display, include asset name and publication in the
		// display
		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[2];
		displayColumns[0] = new DisplayColumn();
		displayColumns[1] = new DisplayColumn();

		displayColumns[0].setColumnId(DefaultAttributes.NAME);
		displayColumns[0].setAttributeColumn(true);
		displayColumns[0].setWidth(100);
		displayColumns[1].setColumnId(DefaultAttributes.COLLECTION);
		displayColumns[1].setAttributeColumn(true);
		displayColumns[1].setWidth(100);
		queryDisplay.setDisplayColumns(displayColumns);

		// Set the sorting based on collection, name-desc
		SortInfo sortFirstByWorkflow = new SortInfo();
		sortFirstByWorkflow.setColumnId(DefaultAttributes.COLLECTION);
		SortInfo sortSecondByNameDesc = new SortInfo();
		sortSecondByNameDesc.setColumnId(DefaultAttributes.NAME);
		sortSecondByNameDesc.setDescending(true);
		queryDisplay.setSorting(new SortInfo[] { sortFirstByWorkflow, sortSecondByNameDesc });

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.ASSET);

		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions.toArray(new QueryCondition[0]),
				queryContext, queryDisplay);
		if (queryResultElements.length > 0) {
			AssetElement assetElement = (AssetElement) queryResultElements[0];
			return assetElement.getAssetId();
		}
		return 0;
	}
	
	public long getQueryId(String queryIdOrName) throws QueryNotFoundException, QppServiceException {
	if(queryIdOrName != null && queryIdOrName.trim().length() > 0){
		try {
			return Long.parseLong(queryIdOrName);
		} catch (NumberFormatException e) {
			QueryDefinition[] queryDefinitions = queryService.getAllQueries();
			for (int i = 0; i < queryDefinitions.length; i++) {
				if(queryDefinitions[i].getQueryName().equalsIgnoreCase(queryIdOrName)){
					return queryDefinitions[i].getQueryId();
				}
			}
		}
		String myAssignmentsQueryName = queryService.getQueryDefinition(SystemQueries.MYASSIGNMENTS).getQueryName();
		if(queryIdOrName.equalsIgnoreCase(myAssignmentsQueryName)){
			return SystemQueries.MYASSIGNMENTS;
		}
		
		String myCheckedOutAssetsQueryName = queryService.getQueryDefinition(SystemQueries.MY_CHECKED_OUT_ASSETS).getQueryName();
		if(queryIdOrName.equalsIgnoreCase(myCheckedOutAssetsQueryName)){
			return SystemQueries.MY_CHECKED_OUT_ASSETS;
		}
		
		String attachmentsQueryName = queryService.getQueryDefinition(SystemQueries.ATTACHMENTS).getQueryName();
		if(queryIdOrName.equalsIgnoreCase(attachmentsQueryName)){
			return SystemQueries.ATTACHMENTS;
		}
		
		String depthQueryName = queryService.getQueryDefinition(SystemQueries.DEPTH).getQueryName();
		if(queryIdOrName.equalsIgnoreCase(depthQueryName)){
			return SystemQueries.DEPTH;
		}
	}
		QueryNotFoundException queryNotFoundException = new QueryNotFoundException();
		queryNotFoundException.setAdditionalInfo(new String[]{queryIdOrName});
		throw queryNotFoundException;
	}
	
	private long getWorkflowId(String workflowIdOrName) throws WorkflowNotFoundException, QppServiceException {
		try {
			return Long.parseLong(workflowIdOrName);
		} catch (NumberFormatException e) {
			return workflowService.getWorkflowByName(workflowIdOrName).getId();
		}
	}
	
	public long[] getWorkflowIds(String[] workflowIdOrNames) throws WorkflowNotFoundException, QppServiceException {
		ArrayList<Long> workflowIds = new ArrayList<Long>();
		for (int i = 0; workflowIdOrNames != null && i < workflowIdOrNames.length; i++) {
			long workflowId = getWorkflowId(workflowIdOrNames[i]);
			workflowIds.add(workflowId);
		}
		return getLongArray(workflowIds);
	}
	
	public long[] getGroupIds(String[] groupIdOrNames) throws GroupNotFoundException, QppServiceException {
		ArrayList<Long> groupIds = new ArrayList<Long>();
		for (int i = 0; groupIdOrNames != null && i < groupIdOrNames.length; i++) {
			long groupId = getGroupId(groupIdOrNames[i]);
			groupIds.add(groupId);
		}
		return getLongArray(groupIds);
	}

	public long getStatusId(long workflowId, String statusIdOrName) throws StatusNotFoundException, WorkflowNotFoundException, QppServiceException {
		try {
			return Long.valueOf(statusIdOrName);
		} catch (NumberFormatException e) {
			String workFlowName= workflowService.getWorkflow(workflowId).getName();
			Status statusDef = workflowService.getStatusByName(workFlowName, statusIdOrName);
			return statusDef.getId();
		}
	}
	
	public long[] getPrivilegeIds(String[] privilegeIdsOrNames) throws QppServiceException {
		ArrayList<Long> list = new ArrayList<Long>();
		for (int i = 0; i < privilegeIdsOrNames.length; i++) {
			long privilegeId = getPrivilegeId(privilegeIdsOrNames[i]);
			list.add(privilegeId);
		}
		return getLongArray(list);
	}
	
	private long getPrivilegeId(String privilegeIdOrName) throws QppServiceException {
		try {
			return Long.parseLong(privilegeIdOrName);
		} catch (Exception NumberFormatException) {
			PrivilegeDefinition[] privilegeDefinitions = getPrivilegeDefinitionByName(privilegeIdOrName);
			if (privilegeDefinitions != null && privilegeDefinitions.length == 1) {
				return privilegeDefinitions[0].getId();
			} else {
				throw new InvalidPrivilegeException("There are multiple privileges with same name : " + privilegeIdOrName);
			}
		}
	}
	
	public long getCollectionId(String collectionIdOrPathOrName) throws InvalidQueryDefinitionException, InvalidQueryDisplayException,
			InvalidCollectionException, QppServiceException {
		long fetchedCollectionId = -1;
		try {
			fetchedCollectionId = Long.valueOf(collectionIdOrPathOrName);
		} catch (NumberFormatException e) {
			fetchedCollectionId = getCollectionIdForCollectionPath(collectionIdOrPathOrName);
			if (fetchedCollectionId <= 0) {
				fetchedCollectionId = getCollectionIdForCollectionName(collectionIdOrPathOrName);
			}
		}
		if (fetchedCollectionId > 0) {
			return fetchedCollectionId;
		} else {
			InvalidCollectionException inaCollectionException = new InvalidCollectionException(
					InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
			inaCollectionException.setAdditionalInfo(new String[]{collectionIdOrPathOrName});
			throw inaCollectionException;
		}
	}
	
	/**
	 * This API resolves the given collection text on the following preference order: <br>
	 * 1. The input is assumed to be collection path first <br>
	 * 2. If not resolved, input is assumed to be collection name. <br>
	 * 
	 * @param collectionPathOrName
	 * @return
	 * @throws InvalidQueryDefinitionException
	 * @throws InvalidQueryDisplayException
	 * @throws InvalidCollectionException
	 * @throws QppServiceException
	 */
	public long getCollectionIdForText(String collectionPathOrName) throws InvalidQueryDefinitionException,
			InvalidQueryDisplayException, InvalidCollectionException, QppServiceException {
		long fetchedCollectionId = getCollectionIdForCollectionPath(collectionPathOrName);
		if (fetchedCollectionId <= 0) {
			fetchedCollectionId = getCollectionIdForCollectionName(collectionPathOrName);
		}
		if (fetchedCollectionId > 0) {
			return fetchedCollectionId;
		} else {
			InvalidCollectionException inaCollectionException = new InvalidCollectionException(
					InvalidCollectionExceptionCodes.COLLECTION_NOT_FOUND);
			inaCollectionException.setAdditionalInfo(new String[]{collectionPathOrName});
			throw inaCollectionException;
		}
	}
	
	/*
	 * Query's for all collections with given name and returns collection id of the first result element.
	 */
	public long getCollectionIdForCollectionName(String collectionName) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		ArrayList<QueryCondition> queryConditions = new ArrayList<QueryCondition>();

		StringAttributeCondition collectionNameCondn = new StringAttributeCondition();
		collectionNameCondn.setAttributeId(DefaultAttributes.NAME);
		collectionNameCondn.setComparisonOperator(StringOperators.IS);
		collectionNameCondn.setLogicalOperator(LogicalOperators.AND);
		collectionNameCondn.setNestingLevel(1);
		collectionNameCondn.setType(ConditionTypes.STRING_ATTR_CONDITION);
		collectionNameCondn.setValue(collectionName);
		collectionNameCondn.setNegated(false);
		collectionNameCondn.setParameterized(false);
		queryConditions.add(collectionNameCondn);

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.COLLECTION);

		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[1];
		displayColumns[0] = new DisplayColumn();

		displayColumns[0].setColumnId(DefaultAttributes.COLLECTION);
		displayColumns[0].setAttributeColumn(true);
		displayColumns[0].setWidth(100);
		queryDisplay.setDisplayColumns(displayColumns);
		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions.toArray(new QueryCondition[0]),
				queryContext, queryDisplay);
		if (queryResultElements != null && queryResultElements.length > 0) {
			//return collection id of the first element
			long collectionId = ((CollectionElement) queryResultElements[0]).getCollectionId();
			return collectionId;
		}
		return -1;
	}
	
	public long getCollectionIdForCollectionPath(String collectionPath) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, QppServiceException {
		ArrayList<QueryCondition> queryConditions = new ArrayList<QueryCondition>();

		com.quark.qpp.core.query.service.dto.StringAttributeCondition collectionPathAttrCond = new com.quark.qpp.core.query.service.dto.StringAttributeCondition();
		collectionPathAttrCond.setAttributeId(DefaultAttributes.COLLECTION_PATH);
		collectionPathAttrCond.setComparisonOperator(StringOperators.IS);
		collectionPathAttrCond.setLogicalOperator(LogicalOperators.AND);
		collectionPathAttrCond.setNestingLevel(1);
		collectionPathAttrCond.setType(ConditionTypes.STRING_ATTR_CONDITION);
		collectionPathAttrCond.setValue(collectionPath);
		collectionPathAttrCond.setNegated(false);
		collectionPathAttrCond.setParameterized(false);
		queryConditions.add(collectionPathAttrCond);

		QueryContext queryContext = new QueryContext();
		queryContext.setContentType(DefaultContentTypes.COLLECTION);

		QueryDisplay queryDisplay = new QueryDisplay();
		DisplayColumn[] displayColumns = new DisplayColumn[1];
		displayColumns[0] = new DisplayColumn();

		displayColumns[0].setColumnId(DefaultAttributes.COLLECTION);
		displayColumns[0].setAttributeColumn(true);
		displayColumns[0].setWidth(100);
		queryDisplay.setDisplayColumns(displayColumns);

		QueryResultElement[] queryResultElements = queryService.getQueryResultForConditions(queryConditions.toArray(new QueryCondition[0]),
				queryContext, queryDisplay);
		if (queryResultElements != null && queryResultElements.length > 0) {
			return ((CollectionElement) queryResultElements[0]).getCollectionId();
		}
		return 0;
	}

	public long[] getCollectionIds(String[] collectionIdOrPathOrName) throws InvalidQueryDefinitionException, InvalidQueryDisplayException, InvalidCollectionException, QppServiceException {
		int arrayLength = collectionIdOrPathOrName == null ? 0 : collectionIdOrPathOrName.length;
		long[] collectionIds = new long[arrayLength];
		for (int i = 0; i < arrayLength; i++) {
			collectionIds[i] = getCollectionId(collectionIdOrPathOrName[i]);
		}
		return collectionIds;
	}
	
	/**
	 * This method ensures there is only one content type with given name & returns the content type id. But in case there are
	 * more than one content types with given name, it throws InvalidContentTypeException.
	 * 
	 * @param contentTypeName
	 * @return
	 * @throws QppServiceException
	 */
	public long getUniqueContentTypeWithName(String contentTypeName) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfo[] allContentTypeInfos = contentStructureService.getAllContentTypes();
		long fetchedContentTypeId = 0;
		for (int i = 0; i < allContentTypeInfos.length; i++) {
			if (allContentTypeInfos[i].getName().equalsIgnoreCase(contentTypeName)) {
				if (fetchedContentTypeId > 0) {
					throw new InvalidContentTypeException(new String[] { "There are multiple content types with same name : "
							+ contentTypeName });
				}
				fetchedContentTypeId = allContentTypeInfos[i].getId();
			}
		}
		return fetchedContentTypeId;
	}
	
	public long[] getAttributeIds(String[] attributeIdsOrNames) throws AttributeNotFoundException, QppServiceException {
		int arrayLength = attributeIdsOrNames == null ? 0 : attributeIdsOrNames.length;
		long[] attributeIds = new long[arrayLength];
		for (int i = 0; i < arrayLength; i++) {
			try {
				attributeIds[i] = Long.valueOf(attributeIdsOrNames[i]);
			} catch (NumberFormatException numberFormatException) {
				attributeIds[i] = attributeService.getAttributeByName(attributeIdsOrNames[i]).getId();
			}
		}
		return attributeIds;
	}
	
	public String getRenditionTypeString(long renditionTypeId) throws InvalidRenditionTypeException, QppServiceException {
		RenditionType[] renditionTypes = indexingService.getAllRenditionTypes();
		for (int i = 0; i < renditionTypes.length; i++) {
			if (renditionTypes[i].getId() == renditionTypeId) {
				return renditionTypes[i].getName();
			}
		}
		throw new InvalidRenditionTypeException(renditionTypeId+"");
	}
	
	public long getRenditionTypeId(String renditionType) throws QppServiceException {
		if(renditionType.equalsIgnoreCase("highres")){
			return DefaultRenditionTypes.HIGH_RES;
		}
		RenditionType[] renditionTypes = indexingService.getAllRenditionTypes();
		for (int i = 0; i < renditionTypes.length; i++) {
			if (renditionTypes[i].getName().equalsIgnoreCase(renditionType)) {
				return renditionTypes[i].getId();
			}
		}
		return 0;
	}
	
	/**
	 * For the given input, the content type id is fetched on the basis of following approach :
	 * </br>
	 * 1. The input is checked to be an id first. </br> 2. In case option 1 fails, the input is checked to be content type hierarchy. </br>
	 * 3. In case option 2 fails, the input is checked to be a content type name, & we return the first fetched content type with this name.
	 * </br>
	 * In case all the above three options fail, InvalidContentTypeException is thrown.
	 */
	public long[] getContentTypeIds(String[] contentTypeIdOrPathOrNames) throws InvalidContentTypeException, QppServiceException {
		Set<Long> idsSet = new HashSet<Long>();
		for (int j = 0; contentTypeIdOrPathOrNames != null && j < contentTypeIdOrPathOrNames.length; j++) {
			long contentTypeId = getContentTypeId(contentTypeIdOrPathOrNames[j]);
			idsSet.add(contentTypeId);
		}
		long[] contentTypeIdsArray = new long[idsSet.size()];
		Iterator<Long> itr = idsSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			contentTypeIdsArray[i] = itr.next();
			i++;
		}
		return contentTypeIdsArray;
	}

	/**
	 * For the given input, the content type id is fetched on the basis of following approach :
	 * </br>
	 * 1. The input is checked to be an id first. </br> 2. In case option 1 fails, the input is checked to be content type hierarchy. </br>
	 * 3. In case option 2 fails, the input is checked to be a content type name, & we return the first fetched content type with this name.
	 * </br>
	 * In case all the above three options fail, InvalidContentTypeException is thrown.
	 */
	public long getContentTypeId(String contentTypeIdOrPathOrName) throws InvalidContentTypeException, QppServiceException {
		long fetchedContentTypeId = -1;
		try {
			fetchedContentTypeId = Long.parseLong(contentTypeIdOrPathOrName);
		} catch (NumberFormatException numberFormatException) {
			try {
				fetchedContentTypeId = getContentTypeIdForHierarchy(contentTypeIdOrPathOrName);
			} catch (Exception exception) {
				fetchedContentTypeId = getContentTypeIdForName(contentTypeIdOrPathOrName);
			}
		}
		return fetchedContentTypeId;
	}
	
	/**
	 * For the given input, the content type id is fetched on the basis of following approach:<br>
	 * 1. The id is fetched by assuming input to be content type hierarchy first<br>
	 * 2.If not resolved, the input is assumed to be content type name<br>
	 * 
	 * @param contentTypePathOrName
	 * @return
	 * @throws InvalidContentTypeException
	 * @throws QppServiceException
	 */
	public long getContentTypeIdForText(String contentTypePathOrName) throws InvalidContentTypeException, QppServiceException {
		long fetchedContentTypeId = -1;
		try {
			fetchedContentTypeId = getContentTypeIdForHierarchy(contentTypePathOrName);
		} catch (Exception exception) {
			fetchedContentTypeId = getContentTypeIdForName(contentTypePathOrName);
		}
		return fetchedContentTypeId;
	}
	
	/**
	 * Returns the id of the first fetched content type with given name.
	 * 
	 * @param contentTypeName
	 *            name of the content type
	 * @return
	 * @throws InvalidContentTypeException
	 * @throws QppServiceException
	 */
	public long getContentTypeIdForName(String contentTypeName) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfo[] allContentTypes = contentStructureService.getAllContentTypes();
		for (int i = 0; i < allContentTypes.length; i++) {
			if (allContentTypes[i].getName().equalsIgnoreCase(contentTypeName)) {
				return allContentTypes[i].getId();
			}
		}
		InvalidContentTypeException invalidContentTypeException = new InvalidContentTypeException(
				InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
		invalidContentTypeException.setAdditionalInfo(new String[] { contentTypeName });
		throw invalidContentTypeException;
	}
	
	public long getRelationTypeId(String relationType) throws RelationTypeNotFoundException, QppServiceException {
		long relationTypeId = 0;
		try {
			relationTypeId = new Long(relationType);
		} catch (NumberFormatException e) {
			relationTypeId = getRelationTypeByName(relationType);
		}
		return relationTypeId;
	}
	
	public String getRelationTypeName(long relationTypeId) throws RelationTypeNotFoundException, QppServiceException{
		String relationTypeName = null;
		 RelationType relationType = relationService.getRelationType(relationTypeId);
		 if(relationType != null) {
			 relationTypeName = relationType.getName();
		 }
		return relationTypeName;
	}
	
	public long getRelationTypeByName(String relationTypeName) throws RelationTypeNotFoundException, QppServiceException {
		long relationTypeId = 0;
		if (relationTypeName != null) {
			RelationType[] relationTypes = relationService.getAllRelationTypes();
			for (RelationType relType : relationTypes) {
				if (relType.getName().equalsIgnoreCase(relationTypeName)) {
					relationTypeId = relType.getId();
					break;
				}
			}
		}
		if (relationTypeId <= 0) {
			throw new RelationTypeNotFoundException(RelationTypeNotFoundExceptionCodes.RELATION_TYPE_NOT_FOUND,new String[]{relationTypeName});
		}
		return relationTypeId;
	}
	
	public long[] getLongArray(List<Long> arrayList) {
		int size = arrayList == null ? 0 : arrayList.size();
		long[] array = new long[size];
		for (int i = 0; i < size; i++) {
			array[i] = (Long) arrayList.get(i);
		}
		return array;
	}
	
	public long getLdapProfileId(String ldapProfileIdOrName) throws InvalidLdapProfileException, QppServiceException {
		try {
			return Long.valueOf(ldapProfileIdOrName);
		} catch (NumberFormatException e) {
			LdapProfile[] allLdapProfiles = userProvisioningService.getAllLdapProfiles();
			for (int i = 0; allLdapProfiles != null && i < allLdapProfiles.length; i++) {
				LdapProfile currentLdapProfile = allLdapProfiles[i];
				if(currentLdapProfile.getName().equalsIgnoreCase(ldapProfileIdOrName)){
					return currentLdapProfile.getId();
				}
			}
		}
		throw new InvalidLdapProfileException(InvalidLdapProfileExceptionCodes.INVALID_PROFILE_ID);
	}

	public long getLdapQueryDefId(String savedLdapQueryDefIdOrName) throws InvalidLdapQueryDefinitionException, QppServiceException {
		try {
			return Long.valueOf(savedLdapQueryDefIdOrName);
		} catch (NumberFormatException e) {
		LdapQueryDefinition[] allLdapQueryDefinitions = userProvisioningService.getAllLdapQueryDefinitions();
		for (int i = 0;allLdapQueryDefinitions!=null && i < allLdapQueryDefinitions.length; i++) {
			LdapQueryDefinition currentDefinition = allLdapQueryDefinitions[i];
				if(currentDefinition.getName().equalsIgnoreCase(savedLdapQueryDefIdOrName))
				return currentDefinition.getId();
		}
		}
			throw new InvalidLdapQueryDefinitionException(InvalidLdapQueryDefinitionExceptionCodes.INVALID_QUERY_ID);
	}
	
	public long getContentTypeIdForHierarchy(String contentTypeHierarchy) throws InvalidContentTypeException, QppServiceException {
		String[] contentTypes = contentTypeHierarchy.split(";");
		String contentTypeName = contentTypes[contentTypes.length - 1];
		ContentTypeInfo[] allContentTypes = contentStructureService.getAllContentTypes();
		long id = 0;
		for(ContentTypeInfo info : allContentTypes) {
			if(info.getName().equalsIgnoreCase(contentTypeName)) {
				id = info.getId();
				if(!contentTypeHierarchy.endsWith(";")){
					contentTypeHierarchy = contentTypeHierarchy+";";
				}
				if(contentTypeHierarchy.equalsIgnoreCase(getContentTypeHierarchy(id))){
					return id;
				}
			}
		}
		throw new InvalidContentTypeException(new String[]{contentTypeHierarchy});
	}

	public String getContentTypeHierarchy(long contentTyepId) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfo[] contentTypeInfos = contentStructureService.getContentTypeHierarchy(contentTyepId);
		StringBuilder contentTypsHierarchy = new StringBuilder(); 
		int i = contentTypeInfos.length-1;
		while(i>=0){
			contentTypsHierarchy.append(contentTypeInfos[i].getName());
			contentTypsHierarchy.append(";");
			i--;
		}
		return contentTypsHierarchy.toString();
	}
	
	public long getContentTypeWithName(String name, long parentContentTypeId) throws InvalidContentTypeException, QppServiceException {
		ContentTypeInfo[] contentTypeInfos = contentStructureService.getChildContentTypesInfo(parentContentTypeId);
		for (int i = 0; i < contentTypeInfos.length; i++) {
			if(contentTypeInfos[i].getName().equalsIgnoreCase(name)){
				return contentTypeInfos[i].getId();
			}
		}
		return -1;
	}
	
	public long getRoleId(String roleIdOrName) throws UserClassNotFoundException, QppServiceException {
		try {
			return Long.parseLong(roleIdOrName);
		} catch (NumberFormatException e) {
			UserClass[] userClasses = userClassService.getAllUserClasses();
			for (UserClass userClass : userClasses) {
				if (userClass.getName().equalsIgnoreCase(roleIdOrName)) {
					return userClass.getId();
				}
			}
		}
		throw new UserClassNotFoundException(UserClassNotFoundExceptionCodes.USERCLASS_NOT_FOUND, new String[] { roleIdOrName });
	}
	
	public long getUserId(String user) throws UserNotFoundException, QppServiceException {
		try {
			return Long.parseLong(user);
		} catch (NumberFormatException e) {
			return trusteeService.getUserId(user);
		}
	}
	
	public long getGroupId(String groupIdOrName) throws GroupNotFoundException, QppServiceException {
		try{
			return Long.parseLong(groupIdOrName);
		}catch(NumberFormatException e){
			return trusteeService.getGroupId(groupIdOrName);
		}
	}
	
	public String getAttributeConstraintString(int constraintId) {
		if (constraintId == ConstraintTypes.PREVENT_CHANGE)
			return "PREVENT CHANGE";
		if (constraintId == ConstraintTypes.REQUIRE_CHANGE)
			return "REQUIRE CHANGE";
		if (constraintId == ConstraintTypes.REQUIRE_VALUE)
			return "REQUIRE VALUE";		
		return null;
	}

	public int getAttributeConstraintId(String constraint) {
		if (constraint.equalsIgnoreCase("PREVENT CHANGE"))
			return ConstraintTypes.PREVENT_CHANGE;
		if (constraint.equalsIgnoreCase("REQUIRE CHANGE"))
			return ConstraintTypes.REQUIRE_CHANGE;
		if (constraint.equalsIgnoreCase("REQUIRE VALUE"))
			return ConstraintTypes.REQUIRE_VALUE;
		return 0;
	}
	
	public long getJJIdByName(String jobJacketName) throws InvalidJobJacketException, QppServiceException {
		JobJacket[] jobJackets = collectionService.getAllJobJackets();
		for (int i = 0; i < jobJackets.length; i++) {
			if(jobJackets[i].getName().equalsIgnoreCase(jobJacketName)){
				return jobJackets[i].getId();
			}
		}
		return -1;
	}
	
	public long getRepository(String repositoryIdOrName) throws RepositoryNotFoundException, QppServiceException {
		try {
			return Long.parseLong(repositoryIdOrName);
		} catch (NumberFormatException e) {
			return getRepositoryByName(repositoryIdOrName);
		}
	}

	public long getRepositoryByName(String repositoryName) throws RepositoryNotFoundException, QppServiceException {
		long repoId = 0;
		if (repositoryName != null) {
			StorageRepository[] storageRepositorys = storageService.getAllRepositories();
			for (StorageRepository storageRepository : storageRepositorys) {
				if (repositoryName.equalsIgnoreCase(storageRepository.getName())) {
					repoId = storageRepository.getId();
					break;
				}
			}
		}
		if (repoId <= 0) {
			throw new RepositoryNotFoundException(RepositoryNotFoundExceptionCodes.REPOSITORY_NOT_FOUND);
		}
		return repoId;
	}
	
	public long getRepositoryTypeId(String repositoryTypeName) throws QppServiceException {
		StorageRepositoryType[] storageRepositoryTypes = storageService.getAllRepositoryTypes();
		long repositoryTypeId = -1;
		for (StorageRepositoryType repositoryType : storageRepositoryTypes) {
			if (repositoryTypeName.equalsIgnoreCase(repositoryType.getName())) {
				repositoryTypeId = repositoryType.getId();
				break;
			}
		}
		return repositoryTypeId;
	}

	public int getDomainId(String domainIdOrName) throws DomainNotFoundException, QppServiceException {
		try {
			return Integer.parseInt(domainIdOrName);
		} catch (NumberFormatException e) {
			AttributeDomain[] attributeDomains = attributeDomainService.getAllDomains();
			for (int i = 0; i < attributeDomains.length; i++) {
				if(attributeDomains[i].getName().equalsIgnoreCase(domainIdOrName)){
					return attributeDomains[i].getId();
				}
			}
		}
		throw new DomainNotFoundException(DomainNotFoundExceptionCodes.DOMAIN_NOT_FOUND, new String[]{domainIdOrName});
	}
	
	public long[] getDomainValueIds(int domainId, String[] domainValueIdOrNameOrHierarchy) throws DomainValueNotFoundException, InvalidDomainValueException, QppServiceException {
		if((domainValueIdOrNameOrHierarchy != null) && (domainValueIdOrNameOrHierarchy.length > 0)) {
			long[] domainValueIds = new long[domainValueIdOrNameOrHierarchy.length];
			for(int i = 0; i < domainValueIdOrNameOrHierarchy.length; i++) {
				if(domainValueIdOrNameOrHierarchy[i] != null && domainValueIdOrNameOrHierarchy[i].length() > 0) {
					try {
						domainValueIds[i] = Long.parseLong(domainValueIdOrNameOrHierarchy[i]);
					} catch (NumberFormatException e) {
						try {		
							domainValueIds[i] = fetchDomainValue(domainId, domainValueIdOrNameOrHierarchy[i], 0, null).getId();
						} catch (InvalidAttributeValueException exp) {
							throw new DomainValueNotFoundException(DomainValueNotFoundExceptionCodes.DOMAIN_VALUE_NOT_FOUND,
									new String[] {domainValueIdOrNameOrHierarchy[i] + ""});
						}
					}
				}
				else {
					throw new InvalidDomainValueException(InvalidDomainValueExceptionCodes.NULL_VALUE);
				}
			}	
			return domainValueIds;
		} else {
			throw new InvalidDomainValueException(InvalidDomainValueExceptionCodes.NULL_VALUE);
		}
	}
	
	public long[] getWorkflowAndStatusId(String statusIdOrNameOrWorkflowStatusCombination) throws InvalidStatusException, QppServiceException{
		long[] workflowAndStatusId = new long[2];
		try {
			workflowAndStatusId[1] = Long.parseLong(statusIdOrNameOrWorkflowStatusCombination);
			workflowAndStatusId[0] = workflowService.getStatus(workflowAndStatusId[1]).getWorkflowId();
		} catch (NumberFormatException e) {
			if(statusIdOrNameOrWorkflowStatusCombination.contains("/")){
				int statusIndex = statusIdOrNameOrWorkflowStatusCombination.indexOf("/");
				String workflowName = statusIdOrNameOrWorkflowStatusCombination.substring(0,statusIndex);
				String statusName = statusIdOrNameOrWorkflowStatusCombination.substring(statusIndex+1);
				Status status = workflowService.getStatusByName(workflowName, statusName);
				workflowAndStatusId[0] = status.getWorkflowId();
				workflowAndStatusId[1] = status.getId();
			}else{
				Workflow[] allWorklfows = workflowService.getAllWorkflows();
				for (int i = 0; i < allWorklfows.length; i++) {
					Status[] allStatuses = allWorklfows[i].getStatuses();
					for (int j = 0; j < allStatuses.length; j++) {
						if(allStatuses[j].getName().equalsIgnoreCase(statusIdOrNameOrWorkflowStatusCombination)){
							workflowAndStatusId[0] = allWorklfows[i].getId(); 
							workflowAndStatusId[1] = allStatuses[j].getId();
							break;
						}
					}
				}
			}
		}
		if(workflowAndStatusId[0] > 0  && workflowAndStatusId[1]>0){
			return workflowAndStatusId;
		}else{
			throw new InvalidStatusException(InvalidStatusExceptionCodes.INVALID_STATUS, new String[]{statusIdOrNameOrWorkflowStatusCombination});
		}
		
	}
	
	public long[] getTrusteeIds(String[] trusteeIdsOrNames) throws TrusteeNotFoundException, QppServiceException {
		long[] trusteeIds = new long[trusteeIdsOrNames.length];
		for (int i = 0; i < trusteeIdsOrNames.length; i++) {
			String trusteeIdOrName = trusteeIdsOrNames[i];
			try {
				trusteeIds[i] = Long.parseLong(trusteeIdOrName);
			} catch (NumberFormatException numberFormatException) {
				trusteeIds[i] = trusteeService.getTrusteeId(trusteeIdOrName);
			}
		}
		return trusteeIds;
	}
	
	/*
	 * Returns array of preference ids for the given array of preference ids or names.
	 */
	public long[] getPreferenceIds(String[] preferenceIdOrNames) throws PreferenceNotFoundException, QppServiceException {
		long[] preferenceIds = new long[preferenceIdOrNames.length];
		for (int i = 0; i < preferenceIdOrNames.length; i++) {
			preferenceIds[i] = getPreferenceId(preferenceIdOrNames[i]);
		}
		return preferenceIds;
	}

	/*
	 * Returns id of the preference with the given id or name.
	 */
	public long getPreferenceId(String preferenceIdOrName) throws PreferenceNotFoundException, QppServiceException {
		try {
			return Long.parseLong(preferenceIdOrName);
		} catch (NumberFormatException e) {
			return preferenceService.getPreferenceByName(preferenceIdOrName).getId();
		}
	}
	
	public String getPrivilegeGroupName(long groupId) throws PrivilegeGroupNotFoundException, QppServiceException {
		PrivilegeGroupDefinition[] privilegeGroupDefinitions = privilegeService.getPrivilegeGroupDefs(new long[] { groupId });
		if (privilegeGroupDefinitions.length > 0) {
			return privilegeGroupDefinitions[0].getName();
		}
		return null;
	}

	/**
	 * It gets all the privilege group definition available in system and
	 * compare there name to given name and returns its definition object.
	 */
	public PrivilegeGroupDefinition[] getPrivilegeGroupDefinitionByName(String privilegeGroupName) throws QppServiceException {
		List<PrivilegeGroupDefinition> sameNameList = new ArrayList<PrivilegeGroupDefinition>();
		List<PrivilegeGroupDefinition> all = getAllPrivilegeGroups();
		for (PrivilegeGroupDefinition privilegeGroupDefinition : all) {
			if (privilegeGroupDefinition.getName().equalsIgnoreCase(privilegeGroupName)) {
				sameNameList.add(privilegeGroupDefinition);
			}
		}
		return sameNameList.toArray(new PrivilegeGroupDefinition[0]);
	}

	/**
	 * It return all the privilege group definitions available inn system.
	 * Service level api only provides the top level groups.
	 */
	private List<PrivilegeGroupDefinition> getAllPrivilegeGroups() throws QppServiceException {
		List<PrivilegeGroupDefinition> list = new ArrayList<PrivilegeGroupDefinition>();
		PrivilegeGroupDefinition[] privilegeGroupDefinitions = privilegeService.getAllPrivilegeGroupDefs();
		
		list.addAll(Arrays.asList(privilegeGroupDefinitions));		
		for (PrivilegeGroupDefinition privilegGroupDefinition : privilegeGroupDefinitions) {			
			list.addAll(getSubprivileges(privilegGroupDefinition));					
		}
		return list;
	}

	private List<PrivilegeGroupDefinition> getSubprivileges(PrivilegeGroupDefinition pvDefinition){
		PrivilegeGroupDefinition[] subGrpDefinitions = pvDefinition.getSubPrivilegeGroups();
		ArrayList<PrivilegeGroupDefinition> list = new ArrayList<PrivilegeGroupDefinition>();
		for (int i = 0; i < subGrpDefinitions.length; i++) {
			List<PrivilegeGroupDefinition> subgrp = getSubprivileges(subGrpDefinitions[i]);
			list.addAll(subgrp);
		}
		list.addAll(Arrays.asList(subGrpDefinitions));
		return list;
	}

	public long[] getPrivilegeGroupId(String name) throws PrivilegeGroupNotFoundException, QppServiceException {
		List<Long> ids = new ArrayList<Long>();
		PrivilegeGroupDefinition[] privilegeGroupDefinitions = getPrivilegeGroupDefinitionByName(name);
		if (privilegeGroupDefinitions.length > 0) {
			for (PrivilegeGroupDefinition privilegeGroupDefinition : privilegeGroupDefinitions) {
				ids.add(privilegeGroupDefinition.getId());
			}
		}
		return CommonUtility.getLongArray(ids); 
	}

	/**
	 * It gets all the privilege definition available in system and compare
	 * there name to given name
	 */
	public PrivilegeDefinition[] getPrivilegeDefinitionByName(String privilegeName) throws QppServiceException {
		List<PrivilegeDefinition> list = new ArrayList<PrivilegeDefinition>();
		PrivilegeDefinition[] privilegeDefinitions = privilegeService.getAllPrivilegeDefs();
		for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
			if (privilegeDefinition.getName().equalsIgnoreCase(privilegeName)) {
				list.add(privilegeDefinition);
			}
		}
		return list.toArray(new PrivilegeDefinition[0]);
	}
	
	public AssetVersion getAssetVersion(Long majorVersion, Long minorVersion) {
		if (majorVersion == null) {
			majorVersion = (long) 0;
		}
		if (minorVersion == null) {
			minorVersion = (long) 0;
		}
		AssetVersion assetVersion = null;
		if (majorVersion > 0 || minorVersion > 0) {
			assetVersion = new AssetVersion(majorVersion, minorVersion);
		}
		return assetVersion;
	}
	
	/**
	 * Iterate through the domain values recursively to find domain value corresponding to the given domain value name
	 * 
	 * @param attributeId
	 * @param domainValueName
	 *            Domain value name for which domain value is to be fetched.
	 * @param domainValues
	 * @param list
	 * @return
	 * @throws QppServiceException
	 */
	private DomainValue compareDomainValuesRecursivelyForNameMatch(Long attributeId,
			String domainValueName, DomainValue[] domainValues, List<com.quark.qpp.service.xmlBinding.AttributeValue> list) throws QppServiceException {
		for (int i = 0; domainValues != null && i < domainValues.length; i++) {
			DomainValue domainValue = domainValues[i];
			if (domainValue.getName().equalsIgnoreCase(domainValueName)) {
				if (attributeId != null && attributeId == DefaultAttributes.STATUS) {
					// In case of status attribute, duplicate status names are permissible under different workflows, so we need
					// to validate status name for given workflow id.
					Status status = (Status) domainValue;
					Long workflowId = getWorkflowId(list);
					if (workflowId == null || (workflowId != null && workflowId == status.getWorkflowId())) {
						return domainValue;
					}
				} else {
					return domainValue;
				}
			}
			DomainValue[] childDomainValues = domainValue.getChildDomainValues();
			DomainValue matchedDV = compareDomainValuesRecursivelyForNameMatch(attributeId, domainValueName, childDomainValues, list);
			if (matchedDV != null) {
				return matchedDV;
		}
	}
		return null;
	}
	
	/*
	 * Compare domain values recursively & put matched values into ArrayList.
	 */
	private void compareDomainValuesRecursivelyForNameMatch(String domainValueName, DomainValue[] domainValues,
			ArrayList<DomainValue> matchedDomainValues) throws QppServiceException {
		for (int i = 0; domainValues != null && i < domainValues.length; i++) {
			DomainValue domainValue = domainValues[i];
			if (domainValue.getName().equals(domainValueName)) {
				matchedDomainValues.add(domainValue);
			}
			DomainValue[] childDomainValues = domainValue.getChildDomainValues();
			compareDomainValuesRecursivelyForNameMatch(domainValueName, childDomainValues, matchedDomainValues);

		}
	}
	
	private Long getWorkflowId(List<com.quark.qpp.service.xmlBinding.AttributeValue> list) throws QppServiceException {
		for (int i = 0; i < list.size(); i++) {
			com.quark.qpp.service.xmlBinding.AttributeValue attributeValue = list.get(i);
			if (attributeValue.getId() == DefaultAttributes.WORKFLOW || attributeValue.getName().equalsIgnoreCase("workflow")) {
				String workflowString = attributeValue.getValue();
				return getWorkflowIds(new String[] { workflowString })[0];
			}
		}
		return null;
	}
//	private Long getWorkflowId(Map<String, String> map) throws QppServiceException {
//		String workflowVal = map.get(String.valueOf(DefaultAttributes.WORKFLOW));
//		if (workflowVal == null) {
//			workflowVal = map.get("Workflow");
//		}
//		try{
//			return Long.parseLong(workflowVal);
//		}catch(NumberFormatException e){
//			Workflow wf =  workflowService.getWorkflowByName(workflowVal);
//			return wf.getId();
//		}
//	}

	/*
	 * Fetches the domain value from the input string on the basis of following approach:
	 * 1. The input is assumed to be hierarchy first.
	 * 2. In case the input is not hierarchy, the input is assumed to be a name.
	 * </p>
	 * In case all the three options fail, InvalidAttributeValueException is thrown.
	 */
	public DomainValue fetchDomainValue(int domainId, String domainValueIdOrHierarchyOrName, long attributeId,
			List<com.quark.qpp.service.xmlBinding.AttributeValue> list) throws DomainNotFoundException, DomainValueNotFoundException,
			QppServiceException {
		DomainValue domainValue = null;
		AttributeDomain attributeDomain = attributeDomainService.getDomain(domainId);
		boolean isHierachical = attributeDomain.isHierarchical();
		// Consider resolving hierarchy only if the domain is hierarchical. Otherwise, resolve it by name only.
		DomainValue[] domainValues = attributeDomainService.getDomainValues(domainId);
		
		if (isHierachical) {
			domainValue = fetchDomainValueWithHierarchy(domainId, domainValueIdOrHierarchyOrName, domainValues);
			if (domainValue == null) {
				domainValue = fetchDomainValueWithName(domainValueIdOrHierarchyOrName, domainId, attributeId, list, domainValues);
			}
		} else {
			domainValue = fetchDomainValueWithName(domainValueIdOrHierarchyOrName, domainId, attributeId, list, domainValues);
		}
		if (domainValue == null) {
			throw new InvalidAttributeValueException(InvalidAttributeValueExceptionCodes.INVALID_ATTRIBUTE_VALUE,
					new String[] { "Attribute domain Id :"+attributeDomain.getId(),", Attribute domain name :"+attributeDomain.getName(),", Domain value :"+domainValueIdOrHierarchyOrName});
		}
		return domainValue;
	}
	
	private DomainValue fetchDomainValueWithName(String domainValueName, int domainId, long attributeId,
			List<com.quark.qpp.service.xmlBinding.AttributeValue> list, DomainValue[] domainValues) throws DomainNotFoundException, QppServiceException {
		DomainValue selectedDomainValue = compareDomainValuesRecursivelyForNameMatch(attributeId, domainValueName, domainValues, list);
		return selectedDomainValue;
	}
	
	/*
	 * Fetch all domain values with the given domain value name.
	 */
	public DomainValue[] fetchDomainValuesWithName(String domainValueName, DomainValue[] domainValues) throws DomainNotFoundException, QppServiceException {
		ArrayList<DomainValue> matchedDomainValues = new ArrayList<DomainValue>();
		compareDomainValuesRecursivelyForNameMatch(domainValueName, domainValues, matchedDomainValues);
		return matchedDomainValues.toArray(new DomainValue[0]);
	}

	/*
	 * Fetch the given domain for a matching domain value hierarchy.
	 */
	public DomainValue fetchDomainValueWithHierarchy(int domainId, String dominaValueHierarchy, DomainValue[] domainValues) throws DomainNotFoundException,
			QppServiceException {
		for (int i = 0; domainValues != null && i < domainValues.length; i++) {
			DomainValue dv = compareDomainValuesRecursivelyForHierarchyMatch(null, domainValues[i], dominaValueHierarchy);
			if (dv != null) {
				return dv;
			}
		}
		return null;
	}

	/*
	 * Compare the given domain value hierarchy & its children recursively to return a domain value with the givenDomainValueHierarchy.
	 */
	private DomainValue compareDomainValuesRecursivelyForHierarchyMatch(String parentDomainValueHierarchy, DomainValue domainValue,
			String givenDomainValueHierarchy) {
		String domainValueHierarchy = null;
		if (parentDomainValueHierarchy != null) {
			domainValueHierarchy = parentDomainValueHierarchy + ";" + domainValue.getName();
		} else {
			domainValueHierarchy = domainValue.getName();
		}
		if (domainValueHierarchy.equals(givenDomainValueHierarchy)) {
			return domainValue;
		} else {
			DomainValue[] childDomainValues = domainValue.getChildDomainValues();
			for (int i = 0; childDomainValues != null && i < childDomainValues.length; i++) {
				DomainValue dv = compareDomainValuesRecursivelyForHierarchyMatch(domainValueHierarchy, childDomainValues[i],
						givenDomainValueHierarchy);
				if (dv != null) {
					return dv;
				}
			}
		}
		return null;
	}

}


package com.quark.qpp.service.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.quark.qpp.common.exceptions.QppServiceException;
import com.quark.qpp.core.content.service.exceptions.ContentServiceExceptionCodes.InvalidContentTypeExceptionCodes;
import com.quark.qpp.core.content.service.exceptions.InvalidContentTypeException;
import com.quark.qpp.core.privilege.service.dto.PrivilegeDefinition;
import com.quark.qpp.core.privilege.service.dto.PrivilegeGroupDefinition;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeException;
import com.quark.qpp.core.privilege.service.exceptions.InvalidPrivilegeGroupException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeGroupNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.PrivilegeNotFoundException;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.InvalidPrivilegeExceptionCodes;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.InvalidPrivilegeGroupExceptionCodes;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.PrivilegeGroupNotFoundExceptionCodes;
import com.quark.qpp.core.privilege.service.exceptions.UserClassServiceExceptionCodes.PrivilegeNotFoundExceptionCodes;
import com.quark.qpp.core.privilege.service.local.PrivilegeService;
import com.quark.qpp.service.objectTransformer.ObjectTransformer;
import com.quark.qpp.service.utility.CommonUtility;
import com.quark.qpp.service.utility.FacadeUtility;
import com.quark.qpp.service.xmlBinding.ContentTypeInfo;
import com.quark.qpp.service.xmlBinding.ContentTypeInfoList;
import com.quark.qpp.service.xmlBinding.PrivilegeDefinition.Group;
import com.quark.qpp.service.xmlBinding.PrivilegeDefinitionList;
import com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition.ParentGroup;
import com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinitionList;

public class PrivilegeController {

	@Autowired
	private PrivilegeService privilegeService;

	@Autowired
	private ObjectTransformer objectTranformer;

	@Autowired
	private FacadeUtility facadeUtility;

	private final Logger logger = Logger.getLogger(this.getClass());

	public PrivilegeDefinitionList getAllPrivileges(boolean getContentTypePrivileges, boolean getApplicationPrivileges) throws PrivilegeGroupNotFoundException, QppServiceException {
		PrivilegeDefinition[] privilegeDefinitions = privilegeService.getAllPrivilegeDefs();
		/** By default all privileges will be returned */
		if (!getContentTypePrivileges | !getApplicationPrivileges) {
			/**
			 * Get content or application privileges based on user's input.
			 */
			privilegeDefinitions = extractDesiredPrivileges(privilegeDefinitions, getContentTypePrivileges, getApplicationPrivileges);
		}
		PrivilegeDefinitionList privilegeDefinitionList = objectTranformer.transform(privilegeDefinitions);
		return privilegeDefinitionList;
	}

	public PrivilegeDefinitionList getPrivilege(String privilegeIdOrName) throws PrivilegeNotFoundException, QppServiceException {
		boolean isNumeric = CommonUtility.isNumeric(privilegeIdOrName);
		PrivilegeDefinition[] privilegeDefinitions = null;
		/** Is numeric true , means user has given id instead of name */
		if (isNumeric) {
			privilegeDefinitions = privilegeService.getPrivilegeDefs(new long[] { Long.parseLong(privilegeIdOrName) });
		} else {
			privilegeDefinitions = facadeUtility.getPrivilegeDefinitionByName(privilegeIdOrName);
		}
		if (privilegeDefinitions == null || privilegeDefinitions.length <= 0) {
			throw new PrivilegeNotFoundException(PrivilegeNotFoundExceptionCodes.PRIVILEGE_NOT_FOUND, new String[] { privilegeIdOrName });
		}
		return objectTranformer.transform(privilegeDefinitions);
	}

	public PrivilegeDefinitionList createPrivileges(PrivilegeDefinitionList privilegeDefinitionList) throws InvalidContentTypeException, PrivilegeGroupNotFoundException, QppServiceException {
		if (privilegeDefinitionList != null) {
			ArrayList<PrivilegeDefinition> createdPrivilegeDefinitions = new ArrayList<PrivilegeDefinition>();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = privilegeDefinitionList.getPrivilegeDefinition().iterator();
			/** Create privileges one by one */
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition = iterator.next();
				try {
					PrivilegeDefinition createdPrivilegeDefinition = createPrivilege(privilegeDefinition);
					createdPrivilegeDefinitions.add(createdPrivilegeDefinition);
				} catch (QppServiceException e) {
					logger.error("Error while creating Privilege with name : " + privilegeDefinition.getName(), e);
					if (privilegeDefinitionList.getPrivilegeDefinition().size() == 1) {
						/**
						 * Throw error , in case of only one privilege is to
						 * created else log the error.
						 */
						throw e;
					}
				}
			}
			return objectTranformer.transform(createdPrivilegeDefinitions.toArray(new PrivilegeDefinition[0]));
		} else {
			throw new InvalidPrivilegeException(InvalidPrivilegeExceptionCodes.INVALID_PRIVILEGE_DEFINITION);
		}
	}

	public PrivilegeGroupDefinitionList getAllPrivilegeGroups() throws QppServiceException {
		PrivilegeGroupDefinition[] privilegeGroupDefinitions = privilegeService.getAllPrivilegeGroupDefs();
		return objectTranformer.transform(privilegeGroupDefinitions);
	}

	public PrivilegeGroupDefinitionList getPrivilegeGroup(String privilegeGroupIdOrName) throws PrivilegeGroupNotFoundException, QppServiceException {
		boolean isNumeric = CommonUtility.isNumeric(privilegeGroupIdOrName);
		PrivilegeGroupDefinition[] privilegeGroupDefinitions = null;
		if (isNumeric) {
			privilegeGroupDefinitions = privilegeService.getPrivilegeGroupDefs(new long[] { Long.parseLong(privilegeGroupIdOrName) });
		} else {
			privilegeGroupDefinitions = facadeUtility.getPrivilegeGroupDefinitionByName(privilegeGroupIdOrName);
		}
		if (privilegeGroupDefinitions == null || privilegeGroupDefinitions.length <= 0) {
			throw new PrivilegeGroupNotFoundException(PrivilegeGroupNotFoundExceptionCodes.PRIVILEGE_GROUP_NOT_FOUND, new String[] { privilegeGroupIdOrName });
		}
		return objectTranformer.transform(privilegeGroupDefinitions);
	}

	public PrivilegeGroupDefinitionList createPrivilegeGroups(PrivilegeGroupDefinitionList privilegeGroupDefinitionList) throws QppServiceException {
		if (privilegeGroupDefinitionList != null && privilegeGroupDefinitionList.getPrivilegeGroupDefinition() != null) {
			ArrayList<PrivilegeGroupDefinition> createdPrivilegeGroupDefinitions = new ArrayList<PrivilegeGroupDefinition>();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = privilegeGroupDefinitionList.getPrivilegeGroupDefinition().iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinition = iterator.next();
				try {
					long createdPrivilegeGroupId = createPrivilegeGroup(privilegeGroupDefinition, -1);
					PrivilegeGroupDefinition privilegeGroupDefinitionCreated = privilegeService.getPrivilegeGroupDefs(new long[] { createdPrivilegeGroupId })[0];
					createdPrivilegeGroupDefinitions.add(privilegeGroupDefinitionCreated);
				} catch (QppServiceException e) {
					logger.error("Error while creating Privilege group with name : " + privilegeGroupDefinition.getName(), e);
					if (privilegeGroupDefinitionList.getPrivilegeGroupDefinition().size() == 1) {
						/**
						 * Throw error , in case of only one privilege group is
						 * to created else log the error.
						 */
						throw e;
					}
				}
			}
			return objectTranformer.transform(createdPrivilegeGroupDefinitions.toArray(new PrivilegeGroupDefinition[0]));
		} else {
			throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.INVALID_PRIVILEGE_GROUP);
		}
	}

	public PrivilegeDefinitionList updatePrivileges(PrivilegeDefinitionList privilegeDefinitionList) throws PrivilegeGroupNotFoundException, InvalidPrivilegeException, QppServiceException {
		if (privilegeDefinitionList != null) {
			ArrayList<PrivilegeDefinition> updatedPrivilegeDefinitions = new ArrayList<PrivilegeDefinition>();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = privilegeDefinitionList.getPrivilegeDefinition().iterator();
			/** Create privileges one by one */
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition = iterator.next();
				try {
					PrivilegeDefinition updatedPrivilegeDefinition = updatePrivilege(privilegeDefinition);
					updatedPrivilegeDefinitions.add(updatedPrivilegeDefinition);
				} catch (QppServiceException e) {
					logger.error("Error while updating Privilege with name : " + privilegeDefinition.getName(), e);
					if (privilegeDefinitionList.getPrivilegeDefinition().size() == 1) {
						/**
						 * Throw error , in case of only one privilege is to
						 * updated else log the error.
						 */
						throw e;
					}
				}
			}
			return objectTranformer.transform(updatedPrivilegeDefinitions.toArray(new PrivilegeDefinition[0]));
		} else {
			throw new InvalidPrivilegeException(InvalidPrivilegeExceptionCodes.INVALID_PRIVILEGE_DEFINITION);
		}
	}

	public PrivilegeGroupDefinitionList updatePrivilegeGroups(PrivilegeGroupDefinitionList privilegeGroupDefinitionList) throws InvalidPrivilegeGroupException, PrivilegeGroupNotFoundException, QppServiceException {
		if (privilegeGroupDefinitionList != null) {
			ArrayList<PrivilegeGroupDefinition> updatedPrivilegeGroupDefinitions = new ArrayList<PrivilegeGroupDefinition>();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = privilegeGroupDefinitionList.getPrivilegeGroupDefinition().iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinition = iterator.next();
				try {
					PrivilegeGroupDefinition updatedPrivilegeGroupDefinition = updatePrivilegeGroup(privilegeGroupDefinition);
					updatedPrivilegeGroupDefinitions.add(updatedPrivilegeGroupDefinition);
				} catch (QppServiceException e) {
					logger.error("Error while creating Privilege group with name : " + privilegeGroupDefinition.getName(), e);
					if (privilegeGroupDefinitionList.getPrivilegeGroupDefinition().size() == 1) {
						/**
						 * Throw error , in case of only one privilege group is
						 * to created else log the error.
						 */
						throw e;
					}
				}
			}
			return objectTranformer.transform(updatedPrivilegeGroupDefinitions.toArray(new PrivilegeGroupDefinition[0]));
		} else {
			throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.INVALID_PRIVILEGE_GROUP);
		}
	}

	public void deletePrivilege(String privilegeIdOrName) throws PrivilegeNotFoundException, InvalidPrivilegeException, QppServiceException {
		boolean isNumeric = CommonUtility.isNumeric(privilegeIdOrName);
		long privilegeId = -1;
		if (isNumeric) {
			privilegeId = Long.parseLong(privilegeIdOrName);
		} else {
			PrivilegeDefinition[] privilegeDefinitions = facadeUtility.getPrivilegeDefinitionByName(privilegeIdOrName);
			/**
			 * If only one privilege for given name is in system then delete it
			 * else throw exception
			 */
			if (privilegeDefinitions == null || privilegeDefinitions.length == 0) {
				throw new PrivilegeNotFoundException();
			}
			else if (privilegeDefinitions.length == 1) {
				privilegeId = privilegeDefinitions[0].getId();
			} else {
				throw new InvalidPrivilegeException(InvalidPrivilegeExceptionCodes.MULTIPLE_PRIVILEGES_WITH_GIVEN_NAME, new String[] { "Provide privilege id" });
			}
		}
		privilegeService.deletePrivilegeDefinition(privilegeId);
	}

	public void deletePrivilegeGroup(String privilegeGroupIdOrName) throws PrivilegeGroupNotFoundException, InvalidPrivilegeGroupException, QppServiceException, NumberFormatException {
		boolean isNumeric = CommonUtility.isNumeric(privilegeGroupIdOrName);
		long privilegeGroupId = -1;
		if (isNumeric) {
			privilegeGroupId = Long.parseLong(privilegeGroupIdOrName);
		} else {
			PrivilegeGroupDefinition[] privilegeGroupDefinition = facadeUtility.getPrivilegeGroupDefinitionByName(privilegeGroupIdOrName);
			/**
			 * If only one privilege group for given name is in system then
			 * delete it else throw exception
			 */
			if (privilegeGroupDefinition.length == 1) {
				privilegeGroupId = privilegeGroupDefinition[0].getId();
			} else {
				throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.MULTIPLE_PRIVILEGE_GROUPS_WITH_GIVEN_NAME, new String[] { "Provide privilege group id" });
			}
		}
		privilegeService.deletePrivilegeGroupDefinition(privilegeGroupId);
	}

	private PrivilegeGroupDefinition updatePrivilegeGroup(com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinition) throws PrivilegeGroupNotFoundException, QppServiceException {
		Long privilegeGroupId = privilegeGroupDefinition.getId();
		PrivilegeGroupDefinition privilegeGroupDefinitionFromSystem = null;
		if (privilegeGroupId != null) {
			privilegeGroupDefinitionFromSystem = privilegeService.getPrivilegeGroupDefs(new long[] { privilegeGroupId })[0];
			/** Rename privilege group */
			if (!privilegeGroupDefinitionFromSystem.getName().equalsIgnoreCase(privilegeGroupDefinition.getName())) {
				privilegeService.setPrivilegeGroupName(privilegeGroupId, privilegeGroupDefinition.getName());
			}
		} else {
			long[] privilegeGroupIds = facadeUtility.getPrivilegeGroupId(privilegeGroupDefinition.getName());
			if (privilegeGroupIds.length > 1) {
				throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.MULTIPLE_PRIVILEGE_GROUPS_WITH_GIVEN_NAME, new String[] { "Provide privilege group id" });
			}
			privilegeGroupId = privilegeGroupIds[0];
			privilegeGroupDefinitionFromSystem = privilegeService.getPrivilegeGroupDefs(new long[] { privilegeGroupId })[0];
		}

		/**
		 * Update information only if user has given privilege definitions list
		 * else skip.
		 */
		if (privilegeGroupDefinition.getPrivilegeDefinitionList() != null) {
			/** Update/Create/Delete privileges definitions for given group. */
			PrivilegeDefinition[] privilegeDefinitions = privilegeGroupDefinitionFromSystem.getPrivilegeDefinitions();

			/**
			 * Get list of name of all privileges definitions available in
			 * system.
			 */
			List<String> namesInSystem = getNames(privilegeDefinitions);
			/** Get list of name of all privileges definitions provided by user. */
			List<String> namesInProvided = getNames(privilegeGroupDefinition.getPrivilegeDefinitionList());

			/** Create newly added privileges definition for this group */
			List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeCreated = toBeCreated(namesInSystem, privilegeGroupDefinition.getPrivilegeDefinitionList());
			for (com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition : toBeCreated) {
				updateGroupIdsAndNames(privilegeDefinition, privilegeGroupId);
				createPrivilege(privilegeDefinition);
			}

			/**
			 * Update existing privileges definition using information provided
			 * by user
			 */
			List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeUpdated = toBeUpdated(namesInSystem, privilegeGroupDefinition.getPrivilegeDefinitionList());
			for (com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition : toBeUpdated) {
				updateGroupIdsAndNames(privilegeDefinition, privilegeGroupId);
				updatePrivilege(privilegeDefinition);
			}

			/**
			 * Remove all those privilege definition from system which are not
			 * provided by user
			 */
			List<PrivilegeDefinition> toBeRemoved = toBeRemoved(privilegeDefinitions, namesInProvided);
			for (PrivilegeDefinition privilegeDefinition : toBeRemoved) {
				deletePrivilege(Long.toString(privilegeDefinition.getId()));
			}
		}

		/**
		 * Create/Update/Delete child privileges group if group defintion list
		 * is provided
		 */
		if (privilegeGroupDefinition.getPrivilegeGroupDefinitionList() != null) {

			PrivilegeGroupDefinition[] privilegeGroupDefinitions = privilegeGroupDefinitionFromSystem.getSubPrivilegeGroups();
			/** Get list of names of all privileges groups available in system */
			List<String> namesInSystem = getNames(privilegeGroupDefinitions);
			/** Get list of names of all user given privilege group definitions */
			List<String> namesInProvided = getNames(privilegeGroupDefinition.getPrivilegeGroupDefinitionList());

			/**
			 * Create all the privileges groups which are not available in
			 * system
			 */
			List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeCreated = toBeCreated(namesInSystem, privilegeGroupDefinition.getPrivilegeGroupDefinitionList());
			for (com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegGroupDefinition : toBeCreated) {
				createPrivilegeGroup(privilegGroupDefinition, privilegeGroupId);
			}

			/**
			 * Update all privileges groups which are provided by user and also
			 * available in system
			 */
			List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeUpdated = toBeUpdated(namesInSystem, privilegeGroupDefinition.getPrivilegeGroupDefinitionList());
			for (com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegGroupDefinition : toBeUpdated) {
				updatePrivilegeGroup(privilegGroupDefinition);
			}

			/**
			 * Delete all those privileges groups which are available in system
			 * but not ptovided by user
			 */
			List<PrivilegeGroupDefinition> toBeRemoved = toBeRemoved(privilegeGroupDefinitions, namesInProvided);
			for (PrivilegeGroupDefinition privilegGroupDefinition : toBeRemoved) {
				deletePrivilege(Long.toString(privilegGroupDefinition.getId()));
			}
		}

		return privilegeService.getPrivilegeGroupDefs(new long[] { privilegeGroupId })[0];
	}

	private List<PrivilegeGroupDefinition> toBeRemoved(PrivilegeGroupDefinition[] privilegeGroupDefinitions, List<String> namesInProvided) {
		List<PrivilegeGroupDefinition> toBeRemoved = new ArrayList<PrivilegeGroupDefinition>();
		for (PrivilegeGroupDefinition privilegeGroupDefinition : privilegeGroupDefinitions) {
			if (!namesInProvided.contains(privilegeGroupDefinition.getName())) {
				toBeRemoved.add(privilegeGroupDefinition);
			}
		}
		return toBeRemoved;
	}

	private List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeUpdated(List<String> namesInSystem, PrivilegeGroupDefinitionList privilegeGroupDefinitionList) {
		List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeUpdated = new ArrayList<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition>();
		Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = privilegeGroupDefinitionList.getPrivilegeGroupDefinition().iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition provided = iterator.next();
			if (namesInSystem.contains(provided.getName())) {
				toBeUpdated.add(provided);
			}
		}
		return toBeUpdated;
	}

	private List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeCreated(List<String> namesInSystem, PrivilegeGroupDefinitionList privilegeGroupDefinitionList) {
		List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> toBeCreated = new ArrayList<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition>();
		Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = privilegeGroupDefinitionList.getPrivilegeGroupDefinition().iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition provided = iterator.next();
			if (!namesInSystem.contains(provided.getName())) {
				toBeCreated.add(provided);
			}
		}
		return toBeCreated;
	}

	private List<String> getNames(PrivilegeGroupDefinitionList privilegeGroupDefinitionList) {
		List<String> names = new ArrayList<String>();
		if (privilegeGroupDefinitionList != null) {
			List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> list = privilegeGroupDefinitionList.getPrivilegeGroupDefinition();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = list.iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinition = iterator.next();
				names.add(privilegeGroupDefinition.getName());
			}
		}
		return names;
	}

	private List<String> getNames(PrivilegeGroupDefinition[] privilegeGroupDefinitions) {
		List<String> names = new ArrayList<String>();
		if (privilegeGroupDefinitions != null && privilegeGroupDefinitions.length > 0) {
			for (PrivilegeGroupDefinition privilegeGroupDefinition : privilegeGroupDefinitions) {
				names.add(privilegeGroupDefinition.getName());
			}
		}
		return names;
	}

	private List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeCreated(List<String> namesInSystem, PrivilegeDefinitionList privilegeDefinitionList) {
		List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeCreated = new ArrayList<com.quark.qpp.service.xmlBinding.PrivilegeDefinition>();
		Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = privilegeDefinitionList.getPrivilegeDefinition().iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.PrivilegeDefinition provided = iterator.next();
			if (!namesInSystem.contains(provided.getName())) {
				toBeCreated.add(provided);
			}
		}
		return toBeCreated;
	}

	private List<PrivilegeDefinition> toBeRemoved(PrivilegeDefinition[] privilegeDefinitions, List<String> namesInProvided) {
		List<PrivilegeDefinition> toBeRemoved = new ArrayList<PrivilegeDefinition>();
		for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
			if (!namesInProvided.contains(privilegeDefinition.getName())) {
				toBeRemoved.add(privilegeDefinition);
			}
		}
		return toBeRemoved;
	}

	private List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeUpdated(List<String> namesInSystem, PrivilegeDefinitionList privilegeDefinitionList) {
		List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> toBeUpdated = new ArrayList<com.quark.qpp.service.xmlBinding.PrivilegeDefinition>();
		Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = privilegeDefinitionList.getPrivilegeDefinition().iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.PrivilegeDefinition provided = iterator.next();
			if (namesInSystem.contains(provided.getName())) {
				toBeUpdated.add(provided);
			}
		}
		return toBeUpdated;
	}

	private List<String> getNames(PrivilegeDefinitionList privilegeDefinitionList) {
		List<String> names = new ArrayList<String>();
		if (privilegeDefinitionList != null) {
			List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> list = privilegeDefinitionList.getPrivilegeDefinition();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = list.iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition = iterator.next();
				names.add(privilegeDefinition.getName());
			}
		}
		return names;
	}

	private List<String> getNames(PrivilegeDefinition[] privilegeDefinitions) {
		List<String> names = new ArrayList<String>();
		if (privilegeDefinitions != null && privilegeDefinitions.length > 0) {
			for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
				names.add(privilegeDefinition.getName());
			}
		}
		return names;
	}

	private PrivilegeDefinition updatePrivilege(com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition) throws InvalidContentTypeException, InvalidPrivilegeException, PrivilegeNotFoundException, QppServiceException {
		long privilegeId = -1;
		if (privilegeDefinition.getId() != null) {
			privilegeId = privilegeDefinition.getId();
			privilegeService.setPrivilegeName(privilegeId, privilegeDefinition.getName());
		} else {
			/**
			 * No need to update name of privilege definition because we don't
			 * have id for which name is to be updated
			 */
			PrivilegeDefinition[] definitions = facadeUtility.getPrivilegeDefinitionByName(privilegeDefinition.getName());
			if (definitions != null && definitions.length == 1) {
				privilegeId = definitions[0].getId();
			} else {
				Group group = privilegeDefinition.getGroup();
				if (group != null) {
					long groupId = -1;
					// Fall-back from name to ID for group
					if (group.getValue() != null) {
						long[] groupIds = facadeUtility.getPrivilegeGroupId(group.getValue());
						if (groupIds.length > 1) {
							throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.MULTIPLE_PRIVILEGE_GROUPS_WITH_GIVEN_NAME, new String[] { "Provide privilege group id" });
						}
						groupId = groupIds[0];
					} else if (group.getId() != null) {
						groupId = group.getId();
					}
					for (PrivilegeDefinition definition : definitions) {
						if (definition.getGroupId() == groupId) {
							privilegeId = definition.getId();
						}
					}
				} else {
					throw new InvalidPrivilegeException(InvalidPrivilegeExceptionCodes.MULTIPLE_PRIVILEGES_WITH_GIVEN_NAME, new String[] { "Provide privilege id" });
				}
			}
		}
		/**
		 * Update content type mapping for content type privileges. Service will
		 * take care of which content type to be added and which is to be
		 * deleted. If contentTypeInfoList object is not given then skip the
		 * content type ids updating.
		 */
		if (privilegeDefinition.isContentPrivilege() && privilegeDefinition.getContentTypeInfoList() != null) {
			long[] contentTypeIds = getContentTypeIds(privilegeDefinition.getContentTypeInfoList());
			privilegeService.setContentTypesForPrivilegeDef(privilegeId, contentTypeIds);
		}

		return privilegeService.getPrivilegeDefs(new long[] { privilegeId })[0];
	}

	private PrivilegeDefinition createPrivilege(com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition) throws PrivilegeGroupNotFoundException, InvalidContentTypeException, QppServiceException {
		/** transform xmlbinding - DTO to database - DTO */
		PrivilegeDefinition privilegeDefinitionDto = objectTranformer.transform(privilegeDefinition);
		/** Get content types IDs for content type privilege */
		long[] contentTypeIds = null;
		if (privilegeDefinition.isContentPrivilege()) {
			contentTypeIds = getContentTypeIds(privilegeDefinition.getContentTypeInfoList());
		}
		long createdPrivId = privilegeService.createPrivilegeDefinition(privilegeDefinitionDto, contentTypeIds);
		return privilegeService.getPrivilegeDefs(new long[] { createdPrivId })[0];
	}

	/** It will return id of all content types in ContentTypeInfoList object. */
	private long[] getContentTypeIds(ContentTypeInfoList contentTypeInfoList) throws InvalidContentTypeException, QppServiceException {
		
		if(contentTypeInfoList == null || contentTypeInfoList.getContentTypeInfo().isEmpty()){
			throw new InvalidContentTypeException(InvalidContentTypeExceptionCodes.CONTENT_TYPE_NOT_FOUND);
		}
		
		Set<Long> ids = new HashSet<Long>();
		if (!contentTypeInfoList.getContentTypeInfo().isEmpty()) {
			Iterator<ContentTypeInfo> iterator = contentTypeInfoList.getContentTypeInfo().iterator();
			while (iterator.hasNext()) {
				/**
				 * Recover name from ContentTypeInfo object , if name is not
				 * given then id of content type is used , and if both are
				 * missing then this content type DTO is simply ignored.
				 */
				ContentTypeInfo contentTypeInfo = iterator.next();
				if (contentTypeInfo.getName() != null && !contentTypeInfo.getName().trim().isEmpty()) {
					 long contentTypeId = facadeUtility.getContentTypeIdForText(contentTypeInfo.getName());
					 ids.add(contentTypeId);
				} else if (contentTypeInfo.getId() != null && contentTypeInfo.getId() > 0) {
					ids.add(contentTypeInfo.getId());
				}
			}
		}
		return getLongArray(ids);
	}

	private long createPrivilegeGroup(com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition privilegeGroupDefinition, long parentGroupId) throws PrivilegeGroupNotFoundException, QppServiceException {
		/** For first call parent group id will be -ve */
		if (parentGroupId <= 0) {
			ParentGroup parentGroup = privilegeGroupDefinition.getParentGroup();
			if (parentGroup != null && parentGroup.getValue() != null && !parentGroup.getValue().isEmpty()) {
				long[] parentGroupIds = facadeUtility.getPrivilegeGroupId(parentGroup.getValue());
				if (parentGroupIds.length > 1) {
					throw new InvalidPrivilegeGroupException(InvalidPrivilegeGroupExceptionCodes.MULTIPLE_PRIVILEGE_GROUPS_WITH_GIVEN_NAME, new String[] { "Provide privilege group id" });
				}
				parentGroupId = parentGroupIds[0]; 
			} else if ( parentGroup != null && parentGroup.getId() != null) {
				parentGroupId = parentGroup.getId();
			}
		}

		String privilegeGroupName = privilegeGroupDefinition.getName();
		long newPrivilegeGroupId = privilegeService.createPrivilegeGroupDefinition(parentGroupId, privilegeGroupName);
		if (privilegeGroupDefinition.getPrivilegeDefinitionList() != null && !privilegeGroupDefinition.getPrivilegeDefinitionList().getPrivilegeDefinition().isEmpty()) {
			/**
			 * It uses the existing logic for privilege creation , where fall
			 * back is from group name to group id. So , we will update the id
			 * of group as returned above and set name to null so that it would
			 * skip the overhead of calculating id using name again.
			 */
			updateGroupIdsAndNames(privilegeGroupDefinition.getPrivilegeDefinitionList(), newPrivilegeGroupId);
			createPrivileges(privilegeGroupDefinition.getPrivilegeDefinitionList());
		}

		/**
		 * Check for child privilege groups , if yes then create them also by
		 * calling this method recursively.
		 */
		if (privilegeGroupDefinition.getPrivilegeGroupDefinitionList() != null && !privilegeGroupDefinition.getPrivilegeGroupDefinitionList().getPrivilegeGroupDefinition().isEmpty()) {
			List<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> childGroups = privilegeGroupDefinition.getPrivilegeGroupDefinitionList().getPrivilegeGroupDefinition();
			Iterator<com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition> iterator = childGroups.iterator();
			while (iterator.hasNext()) {
				com.quark.qpp.service.xmlBinding.PrivilegeGroupDefinition groupDefinition = iterator.next();
				/** create child group using just created group as parent group */
				createPrivilegeGroup(groupDefinition, newPrivilegeGroupId);
			}
		}
		return newPrivilegeGroupId;
	}

	private void updateGroupIdsAndNames(PrivilegeDefinitionList privilegeDefinitionList, long groupId) {
		List<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> privilegeDefinitions = privilegeDefinitionList.getPrivilegeDefinition();
		Iterator<com.quark.qpp.service.xmlBinding.PrivilegeDefinition> iterator = privilegeDefinitions.iterator();
		while (iterator.hasNext()) {
			com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition = iterator.next();
			updateGroupIdsAndNames(privilegeDefinition, groupId);
		}
	}

	private void updateGroupIdsAndNames(com.quark.qpp.service.xmlBinding.PrivilegeDefinition privilegeDefinition, long groupId) {
		Group group = privilegeDefinition.getGroup();
		if (group == null) {
			group = new Group();
			group.setId(groupId);
			/** set name to null so preference goes to id */
			group.setValue(null);
			privilegeDefinition.setGroup(group);
		} else {
			privilegeDefinition.getGroup().setId(groupId);
			privilegeDefinition.getGroup().setValue(null);
		}
	}

	private PrivilegeDefinition[] extractDesiredPrivileges(PrivilegeDefinition[] privilegeDefinitions, boolean getContentTypePrivileges, boolean getApplicationPrivileges) {
		List<PrivilegeDefinition> list = new ArrayList<PrivilegeDefinition>();
		for (PrivilegeDefinition privilegeDefinition : privilegeDefinitions) {
			/** Check for content or application privileges */
			if (getContentTypePrivileges && privilegeDefinition.isContentPrivilege()) {
				list.add(privilegeDefinition);
			} else if (getApplicationPrivileges && !privilegeDefinition.isContentPrivilege()) {
				list.add(privilegeDefinition);
			}
		}
		return list.toArray(new PrivilegeDefinition[0]);
	}
	
	private long[] getLongArray(Set<Long> set) {
		if (set == null || set.size() == 0) {
			return new long[0];
		}

		long[] array = new long[set.size()];
		int counter = 0;
		Iterator<Long> iterator = set.iterator();
		while(iterator.hasNext()){
			long item = iterator.next();
			array[counter++] = item;
		}
		return array;
	}
}
